// 记忆点增强回归测试：黑名单(|||分隔)、时间衰减与回忆加权、锁定不参与整理。

import 'package:flutter_test/flutter_test.dart';

import 'package:deepshart/ai/memory_blacklist.dart';
import 'package:deepshart/data/models/chat_message.dart';
import 'package:deepshart/data/models/important_memory.dart';

ImportantMemory _memory({
  required double importance,
  required DateTime createdAt,
  int reextractCount = 0,
  bool locked = false,
}) =>
    ImportantMemory(
      id: 'm',
      conversationId: 'c1',
      summary: '测试记忆',
      tags: const <String>[],
      importance: importance,
      createdAt: createdAt,
      versionVector: VectorClock.empty(),
      deviceId: 'A',
      reextractCount: reextractCount,
      locked: locked,
    );

void main() {
  group('MemoryBlacklist', () {
    test('按 ||| 分隔多个关键词', () {
      final words = MemoryBlacklist.parse('前女友|||赌博||| 某人 |||');
      expect(words, ['前女友', '赌博', '某人']);
    });

    test('包含匹配，归一化后比较（忽略标点大小写）', () {
      final words = MemoryBlacklist.parse('前女友|||DeepSeek');
      expect(MemoryBlacklist.matches('我前女友叫小明', words), isTrue);
      expect(MemoryBlacklist.matches('在用 deepseek 的 api', words), isTrue);
      expect(MemoryBlacklist.matches('今天天气不错', words), isFalse);
    });

    test('空黑名单不匹配任何内容', () {
      expect(MemoryBlacklist.matches('任意内容', const <String>[]), isFalse);
    });
  });

  group('时间衰减与回忆加权', () {
    final now = DateTime.utc(2026, 11, 19);

    test('高级记忆(≥0.7)不随时间衰减', () {
      final old = _memory(importance: 0.9, createdAt: now.subtract(const Duration(days: 365)));
      expect(old.effectiveImportance(now: now), closeTo(0.9, 0.001));
    });

    test('低级记忆随时间明显衰减', () {
      final old = _memory(importance: 0.5, createdAt: now.subtract(const Duration(days: 90)));
      expect(old.effectiveImportance(now: now), lessThan(0.5));
      expect(old.effectiveImportance(now: now), lessThan(0.2));
    });

    test('反复重提取给旧记忆加权', () {
      final base = _memory(importance: 0.5, createdAt: now.subtract(const Duration(days: 30)));
      final recalled = _memory(
        importance: 0.5,
        createdAt: now.subtract(const Duration(days: 30)),
        reextractCount: 5,
      );
      expect(recalled.effectiveImportance(now: now), greaterThan(base.effectiveImportance(now: now)));
    });

    test('有效权重不超过 1', () {
      final m = _memory(importance: 1.0, createdAt: now, reextractCount: 100);
      expect(m.effectiveImportance(now: now), lessThanOrEqualTo(1.0));
    });
  });

  group('锁定字段', () {
    test('edit 能切换 locked 且 tick 时钟', () {
      final m = _memory(importance: 0.9, createdAt: DateTime.utc(2026, 11, 1), locked: false);
      final locked = m.edit(editingDeviceId: 'A', newLocked: true);
      expect(locked.locked, isTrue);
      // 时钟被 tick：不再是空时钟。
      expect(locked.versionVector.compare(m.versionVector) == ClockRelation.before ||
          locked.versionVector.compare(m.versionVector) == ClockRelation.after, isTrue);
    });

    test('locked 走 toJson/fromJson 往返不丢', () {
      final m = _memory(importance: 0.8, createdAt: DateTime.utc(2026, 11, 1), locked: true);
      final restored = ImportantMemory.fromJson(m.toJson());
      expect(restored.locked, isTrue);
      expect(restored.reextractCount, 0);
    });
  });
}
