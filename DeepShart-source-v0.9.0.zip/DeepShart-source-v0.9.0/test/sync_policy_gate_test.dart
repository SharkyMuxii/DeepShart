// 验证统一同步策略闸门：请求入队、选择回填、超时兜底为合并。
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:deepshart/sync/sync_policy.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('策略枚举的标签与线路名一致', () {
    expect(SyncPolicy.merge.name, 'merge');
    expect(SyncPolicy.localWins.name, 'localWins');
    expect(SyncPolicy.remoteWins.name, 'remoteWins');
    for (final p in SyncPolicy.values) {
      expect(p.label.isNotEmpty, true);
      expect(p.detail.isNotEmpty, true);
    }
  });

  test('ask 入队后 answer 回填对应请求', () async {
    final container = ProviderContainer();
    addTearDown(container.dispose);
    final gate = container.read(syncPolicyGateProvider.notifier);

    gate.registerUI();
    final f1 = gate.ask('设备A');
    // 第一个请求应成为当前 state。
    expect(container.read(syncPolicyGateProvider)?.source, '设备A');

    // 第二个请求入队，尚未成为当前。
    final f2 = gate.ask('设备B');
    expect(container.read(syncPolicyGateProvider)?.source, '设备A');

    gate.answer(SyncPolicy.localWins);
    expect(await f1, SyncPolicy.localWins);
    // 第一个完成后，第二个自动上位。
    expect(container.read(syncPolicyGateProvider)?.source, '设备B');

    gate.answer(SyncPolicy.merge);
    expect(await f2, SyncPolicy.merge);
    expect(container.read(syncPolicyGateProvider), isNull);
  });

  test('未注册 UI 时不弹请求，注册后才上位', () async {
    final container = ProviderContainer();
    addTearDown(container.dispose);
    final gate = container.read(syncPolicyGateProvider.notifier);

    final f = gate.ask('云端');
    expect(container.read(syncPolicyGateProvider), isNull, reason: '未注册 UI 不推给界面');

    gate.registerUI();
    expect(container.read(syncPolicyGateProvider)?.source, '云端');
    gate.answer(SyncPolicy.remoteWins);
    expect(await f, SyncPolicy.remoteWins);
  });

  test('四种同步行为齐全，含不同步，且覆盖行为有丢失警示', () {
    expect(SyncPolicy.values, hasLength(4));
    expect(SyncPolicy.none.label, '不同步');
    expect(SyncPolicy.merge.isOverwrite, isFalse);
    expect(SyncPolicy.localWins.isOverwrite, isTrue);
    expect(SyncPolicy.remoteWins.isOverwrite, isTrue);
    expect(SyncPolicy.none.isOverwrite, isFalse);
    expect(SyncPolicy.localWins.overwriteHint, contains('丢失'));
    for (final p in SyncPolicy.values) {
      expect(p.label.isNotEmpty, true);
      expect(p.detail.isNotEmpty, true); // 每种都要有详细说明
    }
  });

  test('出错定夺请求带同步方式标注，answer 回填', () async {
    final container = ProviderContainer();
    addTearDown(container.dispose);
    final gate = container.read(syncPolicyGateProvider.notifier);
    gate.registerUI();

    final f = gate.askOnError('云端快照 · 平板', method: SyncMethod.cos, errorDetail: '无法完成合并');
    final req = container.read(syncPolicyGateProvider)!;
    expect(req.method, SyncMethod.cos);
    expect(req.errorDetail, '无法完成合并');
    gate.answer(SyncPolicy.none);
    expect(await f, SyncPolicy.none);
  });

  test('默认行为加载：存储值映射为四态，缺省为合并', () async {
    // 通过 prefs mock 验证 load/save 往返。
    SharedPreferences.setMockInitialValues({});
    final sqflite = await SharedPreferences.getInstance();
    expect(await loadSyncBehavior(sqflite), SyncPolicy.merge);
    await saveSyncBehavior(sqflite, SyncPolicy.none);
    expect(await loadSyncBehavior(sqflite), SyncPolicy.none);
    await saveSyncBehavior(sqflite, SyncPolicy.remoteWins);
    expect(await loadSyncBehavior(sqflite), SyncPolicy.remoteWins);
  });
}
