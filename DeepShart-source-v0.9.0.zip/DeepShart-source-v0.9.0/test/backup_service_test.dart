// 备份系统回归测试。
//
// 背景：同步/导入是破坏性操作，用户要求"每次同步前都备份，可回溯"。
// 这里验证：备份能落盘、列表能读、超限会删最旧且至少留一份、回溯能恢复数据。

import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:deepshart/data/models/chat_message.dart';
import 'package:deepshart/data/store/message_store.dart';
import 'package:deepshart/sync/backup_service.dart';

void main() {
  sqfliteFfiInit();

  late Directory tmpDir;
  late Database db;
  late SqliteMessageStore store;
  late BackupService service;

  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    tmpDir = await Directory.systemTemp.createTemp('deepshart_backup_test');
    final dbPath = '${tmpDir.path}/app.db';
    db = await databaseFactoryFfi.openDatabase(dbPath);
    store = await SqliteMessageStore.open(db, localDeviceId: 'A');
    final prefs = await SharedPreferences.getInstance();
    service = BackupService(db: db, prefs: prefs);
  });

  tearDown(() async {
    await store.dispose();
    await db.close();
    if (await tmpDir.exists()) {
      await tmpDir.delete(recursive: true);
    }
  });

  Future<void> seed(int count) async {
    for (var i = 0; i < count; i++) {
      await store.insertOrMerge(ChatMessage.create(
        conversationId: 'c1',
        role: i.isEven ? MessageRole.user : MessageRole.assistant,
        content: '第$i条消息 ${'内容' * 50}',
        deviceId: 'A',
      ));
    }
  }

  test('手动备份能落盘且能列出', () async {
    await seed(5);
    final entry = await service.backup(reason: 'manual', force: true);

    expect(entry, isNotNull);
    expect(await File(entry!.path).exists(), isTrue);

    final list = await service.list();
    expect(list, hasLength(1));
    expect(list.single.reason, 'manual');
    expect(list.single.sizeBytes, greaterThan(0));
  });

  test('同步前自动备份带 60 秒节流', () async {
    await seed(3);

    final first = await service.backupBeforeSync();
    expect(first, isNotNull, reason: '第一次同步应触发备份');

    final second = await service.backupBeforeSync();
    expect(second, isNull, reason: '60 秒内重复同步不应再次备份');

    final list = await service.list();
    expect(list, hasLength(1));
  });

  test('禁用后不备份', () async {
    await seed(2);
    await service.setEnabled(false);

    final entry = await service.backupBeforeSync();
    expect(entry, isNull);

    final list = await service.list();
    expect(list, isEmpty);
  });

  test('超限时从最旧开始删，且至少保留最新一份', () async {
    await seed(3);
    // 生成三份备份，中间各间隔一下，确保时间可区分。
    await service.backup(reason: 'manual', force: true);
    await Future<void>.delayed(const Duration(milliseconds: 1100));
    await service.backup(reason: 'manual', force: true);
    await Future<void>.delayed(const Duration(milliseconds: 1100));
    await service.backup(reason: 'manual', force: true);

    expect((await service.list()).length, 3);

    // 把上限压到极小，触发回收，但至少保留一份。
    await service.setLimitBytes(1);
    final removed = await service.enforceLimit();
    expect(removed, greaterThan(0));

    final list = await service.list();
    expect(list.length, 1, reason: '至少保留最新一份');
  });

  test('回溯能把旧数据恢复回来', () async {
    await seed(3);
    final snapshot = await service.backup(reason: 'manual', force: true);

    // 快照之后再新增 2 条。
    await seed(2);
    expect((await store.readAll('c1')).length, 5);

    // 回溯到快照。
    await service.restore(snapshot!.path);

    final restored = await store.readAll('c1');
    expect(restored.length, 3, reason: '回溯后应回到快照时的 3 条');

    // 回溯前会自动留一份"回溯前"的安全备份。
    final list = await service.list();
    expect(list.any((e) => e.reason == 'restore'), isTrue);
  });

  test('回溯：备份含主库缺失的表时自动补建，不再报 no such table', () async {
    // 复现用户 bug：备份库里有 important_memories 表，但主库（Store 未懒加载）
    // 没有该表。旧实现用 unqualified PRAGMA 误判主库有表 → INSERT 报 no such table。
    await seed(2);
    final backupPath = '${tmpDir.path}/with_memories.db';
    final backupDb = await databaseFactoryFfi.openDatabase(backupPath);
    await backupDb.execute('''
      CREATE TABLE chat_messages (
        id TEXT PRIMARY KEY, conversation_id TEXT, role TEXT, content TEXT,
        device_id TEXT, created_at INTEGER, version_vector TEXT,
        deleted INTEGER DEFAULT 0, locked INTEGER DEFAULT 0
      )
    ''');
    await backupDb.execute('''
      CREATE TABLE important_memories (
        id TEXT PRIMARY KEY, conversation_id TEXT, summary TEXT, tags TEXT,
        importance REAL, created_at INTEGER, version_vector TEXT,
        device_id TEXT, deleted INTEGER DEFAULT 0
      )
    ''');
    await backupDb.execute(
      "INSERT INTO important_memories (id, conversation_id, summary, tags, importance, "
      "created_at, version_vector, device_id, deleted) VALUES ('m1','c1','要点','[]',0.5,1,'{}','A',0)",
    );
    await backupDb.close();

    // 主库此时没有 important_memories 表（确认前提）。
    final before = await db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type='table' AND name='important_memories'",
    );
    expect(before.isEmpty, isTrue);

    // 回溯不应抛 "no such table"。
    await service.restore(backupPath);

    // 补建的表数据也恢复回来了。
    final mems = await db.rawQuery('SELECT * FROM important_memories');
    expect(mems.length, 1);
    expect(mems.first['summary'], '要点');
  });

  test('删除备份后列表减少', () async {
    await seed(2);
    final entry = await service.backup(reason: 'manual', force: true);

    await service.delete(entry!.path);
    expect((await service.list()).length, 0);
  });
}
