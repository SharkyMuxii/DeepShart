// 验证：1) MessageAttachment 新增字段的 JSON 往返与 isImage；
//       2) DeepSeek 导入器能识别多种时间戳格式并写入 createdAt。

import 'dart:convert';

import 'package:deepshart/data/models/chat_message.dart';
import 'package:deepshart/import/deepseek_json_importer.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('MessageAttachment 附件信息', () {
    test('本地路径/文件名/mime 往返保留，isImage 正确', () {
      final img = MessageAttachment(
        type: 'image',
        location: 'file-api-123',
        fileName: 'photo.PNG',
        mimeType: 'image/png',
        localPath: '/tmp/photo.PNG',
      );
      expect(img.isImage, isTrue);

      final restored = MessageAttachment.fromJson(jsonDecode(jsonEncode(img.toJson())) as Map<String, dynamic>);
      expect(restored.localPath, '/tmp/photo.PNG');
      expect(restored.fileName, 'photo.PNG');
      expect(restored.mimeType, 'image/png');
      expect(restored.isImage, isTrue);

      final doc = MessageAttachment(
        type: 'file',
        location: 'file-api-456',
        fileName: 'report.pdf',
        mimeType: 'application/pdf',
      );
      expect(doc.isImage, isFalse);

      // 老数据没有 local_path 字段也能解析。
      final legacy = MessageAttachment.fromJson({'type': 'file', 'location': 'file-api-old'});
      expect(legacy.localPath, isNull);
    });
  });

  group('DeepSeek 导入时间戳识别', () {
    final importer = DeepSeekJsonImporter();

    ChatMessage parseOne(Map<String, dynamic> msg) {
      final jsonText = jsonEncode({
        'id': 'conv-test',
        'title': '测试',
        'messages': [msg],
      });
      final result = importer.parse(jsonText);
      expect(result.messages.length, 1);
      return result.messages.first;
    }

    test('秒级 Unix 时间戳（create_time）', () {
      final m = parseOne({
        'role': 'user',
        'content': '你好',
        'create_time': 1736932245,
      });
      // 1736932245 秒 = 2025-01-15
      expect(m.createdAt.year, 2025);
      expect(m.createdAt.month, 1);
    });

    test('毫秒级时间戳（timestamp）', () {
      final m = parseOne({
        'role': 'user',
        'content': '你好',
        'timestamp': 1736932245000,
      });
      expect(m.createdAt.year, 2025);
      expect(m.createdAt.month, 1);
    });

    test('ISO 8601 字符串（inserted_at）', () {
      final m = parseOne({
        'role': 'assistant',
        'content': '你好',
        'inserted_at': '2024-06-01T08:30:00.000Z',
      });
      expect(m.createdAt.year, 2024);
      expect(m.createdAt.month, 6);
      expect(m.createdAt.day, 1);
    });

    test('纯数字字符串时间戳', () {
      final m = parseOne({
        'role': 'user',
        'content': '你好',
        'time': '1736932245',
      });
      expect(m.createdAt.year, 2025);
    });

    test('无时间戳时回退当前时间（不抛异常）', () {
      final m = parseOne({'role': 'user', 'content': '你好'});
      expect(m.createdAt.isAfter(DateTime.now().toUtc().subtract(const Duration(minutes: 1))), isTrue);
    });
  });
}
