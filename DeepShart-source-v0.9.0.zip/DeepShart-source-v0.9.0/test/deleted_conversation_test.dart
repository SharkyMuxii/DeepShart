// 验证会话删除墓碑：删除会话写墓碑、按内部ID精确过滤、合并远端墓碑、随整库恢复。
import 'dart:io';

import 'package:deepshart/data/store/conversation_store.dart';
import 'package:deepshart/data/store/deleted_conversation_store.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();

  late Database db;
  late SqliteConversationStore convStore;
  late DeletedConversationStore deleted;

  setUp(() async {
    db = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath);
    convStore = await SqliteConversationStore.open(db);
    // delete() 会级联清这些表，测试库里补建（真实环境由各 Store 建）。
    await db.execute('CREATE TABLE IF NOT EXISTS chat_messages (id TEXT PRIMARY KEY, conversation_id TEXT)');
    await db.execute('CREATE TABLE IF NOT EXISTS important_memories (id TEXT PRIMARY KEY, conversation_id TEXT)');
    await DeletedConversationStore.ensureTable(db);
    deleted = DeletedConversationStore(db);
  });

  tearDown(() async {
    await convStore.dispose();
    await db.close();
  });

  test('删除会话会在同一事务写入墓碑（内部ID，不是标题）', () async {
    const id = 'conv-20261120103000-uuid-1';
    await convStore.upsert(Conversation.create(id: id, title: '新对话'));
    expect(await deleted.isDeleted(id), isFalse);

    await convStore.delete(id);

    expect(await deleted.isDeleted(id), isTrue, reason: '删除后必须留墓碑');
    expect(await convStore.get(id), isNull, reason: '会话本体应被删掉');
  });

  test('墓碑按内部ID精确匹配，不误伤同名标题的其他会话', () async {
    const idA = 'conv-20261120103000-uuid-A';
    const idB = 'conv-20261120103100-uuid-B';
    // 两个会话都叫"新对话"，但内部ID不同。
    await convStore.upsert(Conversation.create(id: idA, title: '新对话'));
    await convStore.upsert(Conversation.create(id: idB, title: '新对话'));

    await convStore.delete(idA);

    expect(await deleted.isDeleted(idA), isTrue);
    expect(await deleted.isDeleted(idB), isFalse, reason: '删A绝不能误伤同名的B');
    expect(await convStore.get(idB), isNotNull, reason: 'B必须还活着');
  });

  test('合并远端墓碑：更新本机墓碑表', () async {
    await deleted.mergeRemote({
      'conv-remote-deleted': DateTime.utc(2026, 11, 20).millisecondsSinceEpoch,
    });
    expect(await deleted.isDeleted('conv-remote-deleted'), isTrue);
  });

  test('合并远端墓碑保留较新的删除时间', () async {
    final t1 = DateTime.utc(2026, 11, 18).millisecondsSinceEpoch;
    final t2 = DateTime.utc(2026, 11, 20).millisecondsSinceEpoch;
    await deleted.tombstone('c1', at: DateTime.fromMillisecondsSinceEpoch(t1));
    await deleted.mergeRemote({'c1': t2});
    final all = await deleted.readAll();
    expect(all['c1'], t2, reason: '远端更晚的删除时间应覆盖本机');
  });

  test('墓碑随整库 VACUUM 备份一起恢复（回溯后不丢墓碑）', () async {
    await convStore.upsert(Conversation.create(id: 'c1', title: 'x'));
    await convStore.delete('c1');
    expect(await deleted.isDeleted('c1'), isTrue);

    // 模拟整库快照：VACUUM INTO 到临时库，再验证墓碑表被完整带过去。
    final tmp = '${Directory.systemTemp.path}/tombstone-backup-test.db';
    final f = File(tmp);
    try {
      await db.execute("VACUUM INTO '${tmp.replaceAll("'", "''")}'");
      final backupDb = await databaseFactoryFfi.openDatabase(tmp);
      final backupDeleted = DeletedConversationStore(backupDb);
      expect(await backupDeleted.isDeleted('c1'), isTrue, reason: '墓碑必须随备份一起保存');
      await backupDb.close();
    } finally {
      if (await f.exists()) await f.delete();
    }
  });
}
