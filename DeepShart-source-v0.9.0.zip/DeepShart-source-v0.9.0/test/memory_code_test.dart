// 记忆共享编码回归测试：4 位编码在 copyWith / toJson / fromJson 往返不丢。

import 'package:flutter_test/flutter_test.dart';

import 'package:deepshart/data/models/conversation_settings.dart';

void main() {
  test('memoryCode 经 toJson/fromJson 往返不丢', () {
    final s = ConversationSettings.forNew('c1').copyWith(
          memorySync: true,
          memoryCode: 'A1B2',
        );
    final restored = ConversationSettings.fromJson(s.toJson());
    expect(restored.memorySync, isTrue);
    expect(restored.memoryCode, 'A1B2');
  });

  test('clearMemoryCode 能清空', () {
    final s = ConversationSettings.forNew('c1').copyWith(memoryCode: 'ZZ99');
    final cleared = s.copyWith(clearMemoryCode: true);
    expect(cleared.memoryCode, isNull);
  });

  test('旧库无 memory_code 列时兼容为 null', () {
    final json = ConversationSettings.forNew('c1').toJson();
    json.remove('memory_code');
    final restored = ConversationSettings.fromJson(json);
    expect(restored.memoryCode, isNull);
  });
}
