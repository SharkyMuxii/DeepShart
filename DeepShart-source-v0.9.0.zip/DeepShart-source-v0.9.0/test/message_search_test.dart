// 跨会话搜索回归测试：按会话分组、时间越早越靠后、展开后每条命中带摘要。

import 'package:flutter_test/flutter_test.dart';

import 'package:deepshart/data/models/chat_message.dart';
import 'package:deepshart/ui/message_search.dart';

ChatMessage _msg(String id, String conv, String content, DateTime at) => ChatMessage(
      id: id,
      conversationId: conv,
      role: MessageRole.user,
      content: content,
      createdAt: at,
      updatedAt: at,
      deviceId: 'A',
      versionVector: VectorClock.empty(),
    );

void main() {
  final base = DateTime.utc(2026, 11, 19, 12, 0);
  final titles = <String, String>{'c1': '会话一', 'c2': '会话二'};

  test('snippet 包含命中关键词，长文本截断', () {
    final content = '${'前' * 80}目标关键词${'后' * 80}';
    final snippet = MessageSearch.snippetOf(content, '目标关键词');
    expect(snippet, contains('目标关键词'));
    expect(snippet.length, lessThan(content.length));
  });

  test('按会话分组，组间按最新命中时间倒序（越早越靠后）', () {
    final hits = [
      _msg('m1', 'c1', '关键词旧', base.subtract(const Duration(days: 10))),
      _msg('m2', 'c2', '关键词新', base.subtract(const Duration(days: 1))),
    ];
    final groups = MessageSearch.group(hits, keyword: '关键词', titles: titles);
    expect(groups.length, 2);
    // c2 有更新的命中，应排在 c1 前面。
    expect(groups.first.conversationId, 'c2');
    expect(groups.last.conversationId, 'c1');
  });

  test('组内命中按时间倒序（最新在前）', () {
    final hits = [
      _msg('old', 'c1', '关键词A', base.subtract(const Duration(days: 5))),
      _msg('new', 'c1', '关键词B', base.subtract(const Duration(days: 1))),
    ];
    final groups = MessageSearch.group(hits, keyword: '关键词', titles: titles);
    expect(groups.single.hits.first.message.id, 'new');
    expect(groups.single.hits.last.message.id, 'old');
  });

  test('未知会话 id 回落到"未命名会话"', () {
    final hits = [_msg('m', 'unknown', '关键词', base)];
    final groups = MessageSearch.group(hits, keyword: '关键词', titles: titles);
    expect(groups.single.conversationTitle, '未命名会话');
  });

  test('思考块内容不进入摘要', () {
    final hits = [
      _msg('m', 'c1', '<thinking>关键词在思考里</thinking>正文没有词', base),
      _msg('m2', 'c1', '正文有关键词', base.subtract(const Duration(days: 1))),
    ];
    final groups = MessageSearch.group(hits, keyword: '关键词', titles: titles);
    // 第一条的思考块被剥离后不含关键词，摘要不应带思考内容。
    expect(groups.single.hits.first.snippet, isNot(contains('<thinking>')));
  });
}
