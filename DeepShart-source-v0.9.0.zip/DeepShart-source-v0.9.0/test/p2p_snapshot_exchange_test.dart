// 验证 P2P 双向快照交换的 wire 消息解析、分片标志，以及会话ID内嵌创建时间。
import 'package:deepshart/sync/sync_engine.dart';
import 'package:deepshart/state/chat_controller.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('P2P 双向快照交换 wire', () {
    test('snapshot_exchange 消息可解析，携带分片与来源', () {
      final msg = SyncWireMessage.parse({
        'type': 'snapshot_exchange',
        'fromDevice': 'Shardows1234',
        'data': 'YWJjZA==',
        'last': false,
      });
      expect(msg, isA<SnapshotExchangeMessage>());
      final m = msg as SnapshotExchangeMessage;
      expect(m.fromDevice, 'Shardows1234');
      expect(m.base64Content, 'YWJjZA==');
      expect(m.isLast, isFalse);
    });

    test('snapshot_exchange 序列化往返', () {
      const m = SnapshotExchangeMessage(
        fromDevice: 'Anrk5678',
        base64Content: 'eHl6',
        isLast: true,
      );
      final json = m.toJson();
      expect(json['type'], 'snapshot_exchange');
      final back = SyncWireMessage.parse(json) as SnapshotExchangeMessage;
      expect(back.fromDevice, m.fromDevice);
      expect(back.base64Content, m.base64Content);
      expect(back.isLast, m.isLast);
    });

    test('与覆盖消息类型互不混淆', () {
      final snapshot = SyncWireMessage.parse({
        'type': 'snapshot_exchange', 'data': 'x', 'fromDevice': 'a',
      });
      final overwrite = SyncWireMessage.parse({
        'type': 'overwrite', 'data': 'x', 'fromDevice': 'a',
      });
      expect(snapshot, isA<SnapshotExchangeMessage>());
      expect(overwrite, isA<OverwriteSnapshotMessage>());
    });
  });

  group('会话ID内嵌创建时间', () {
    test('新ID带 conv-14位时间-UUID 结构', () {
      final id = newConversationId();
      expect(id, startsWith('conv-'));
      // 去掉前缀后按 '-' 分段：YYYYMMDDHHMMSS + uuid
      final rest = id.substring('conv-'.length);
      final parts = rest.split('-');
      expect(parts.length, greaterThanOrEqualTo(2));
      final stamp = parts.first;
      expect(stamp.length, 14, reason: '创建时间应含年月日时分秒共14位');
      expect(int.tryParse(stamp), isNotNull, reason: '时间部分必须是纯数字');
    });

    test('连续两次生成的ID不重复', () {
      final a = newConversationId();
      final b = newConversationId();
      expect(a, isNot(b));
    });
  });
}
