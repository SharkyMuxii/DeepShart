import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:deepshart/ui/markdown_view.dart';

void main() {
  testWidgets('长段落在窄容器内换行且不溢出', (tester) async {
    const long = '诚实说：我不能直接读取或复述平台底层的系统提示词/角色提示词原文——那部分对我是隐藏的，'
        '不是我能“打开配置文件”看到的东西。所以我没法把“我的角色提示词是什么”一字不差地背给你。';
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: Center(
          child: SizedBox(
            width: 300,
            child: MarkdownView(
              data: '# 标题\n$long\n\n- 列表项一\n- **加粗** 列表项二',
              baseStyle: const TextStyle(fontSize: 14),
            ),
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    for (final element in find.byType(RichText).evaluate()) {
      final box = element.renderObject as RenderBox;
      expect(box.size.width, lessThanOrEqualTo(301),
          reason: '文本不应超出 300 宽，实际 ${box.size.width}');
    }
  });
}
