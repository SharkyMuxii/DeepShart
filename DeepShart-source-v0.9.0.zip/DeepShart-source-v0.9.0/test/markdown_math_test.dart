// 数学公式渲染回归测试：
// 覆盖 \(\)、\[\]、$$、嵌套 \(\(...\)\)、双反斜杠、下划线、
// 跨行、畸形不炸，以及" LaTeX 不裸奔"（防止 onErrorFallback 悄悄回退原文）。

import 'package:flutter/material.dart';
import 'package:flutter_math_fork/flutter_math.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:deepshart/ui/markdown_view.dart';

Widget _wrap(String md) => MaterialApp(
      home: Scaffold(
        body: MarkdownView(data: md, baseStyle: const TextStyle(fontSize: 14)),
      ),
    );

/// 收集整棵 widget 树里所有可见的纯文本，用于断言"没有裸 LaTeX"。
String _allText(WidgetTester tester) {
  final buf = StringBuffer();
  for (final el in tester.allElements) {
    final w = el.widget;
    if (w is Text && w.data != null) buf.writeln(w.data);
    if (w is RichText) buf.writeln(w.text.toPlainText());
  }
  return buf.toString();
}

void main() {
  testWidgets('行内 \\( ... \\) 公式被渲染', (tester) async {
    await tester.pumpWidget(_wrap(r'求极限 \(\lim_{x\to\infty} \frac{x+\cos x}{x}\) 的值'));
    expect(find.byType(Math), findsOneWidget);
    // 下划线/frac 命令不应作为纯文本裸奔（截图里的 bug）。
    expect(_allText(tester), isNot(contains(r'\frac')));
  });

  testWidgets('嵌套 \\(\\(...\\)\\) 公式被渲染且不裸奔', (tester) async {
    await tester.pumpWidget(_wrap(r"分子求导：\(\(x + \cos x\)' = 1 - \sin x\)"));
    expect(find.byType(Math), findsOneWidget);
    expect(_allText(tester), isNot(contains(r'\cos')));
  });

  testWidgets('双反斜杠公式被渲染', (tester) async {
    await tester.pumpWidget(_wrap(r'原式 \\(\frac{a}{b}\\) 结束'));
    expect(find.byType(Math), findsOneWidget);
  });

  testWidgets('块级 \\[ ... \\] 公式被渲染', (tester) async {
    await tester.pumpWidget(_wrap(r'\[ E = mc^2 \]'));
    expect(find.byType(Math), findsOneWidget);
  });

  testWidgets(r'块级 $$ ... $$ 公式被渲染', (tester) async {
    await tester.pumpWidget(_wrap(r'$$ a^2 + b^2 = c^2 $$'));
    expect(find.byType(Math), findsOneWidget);
  });

  testWidgets('多个行内公式都能渲染', (tester) async {
    await tester.pumpWidget(_wrap(r'\(a+b\) 与 \(c \times d\)'));
    expect(find.byType(Math), findsNWidgets(2));
  });

  testWidgets('跨行的行内公式仍能渲染', (tester) async {
    await tester.pumpWidget(_wrap('原式 \\(\\lim_{x\\to\\infty}\n\\frac{x+\\cos x}{x}\\) 求极限'));
    expect(find.byType(Math), findsOneWidget);
  });

  testWidgets('畸形公式不抛异常', (tester) async {
    await tester.pumpWidget(_wrap(r'\(\frac{ 未闭合'));
    expect(tester.takeException(), isNull);
  });

  testWidgets('普通 Markdown 仍正常工作', (tester) async {
    await tester.pumpWidget(_wrap('这是 **加粗** 和 `代码`'));
    final texts = tester.widgetList<RichText>(find.byType(RichText))
        .map((w) => w.text.toPlainText())
        .join('\n');
    expect(texts, contains('加粗'));
    expect(texts, contains('代码'));
    expect(find.byType(Math), findsNothing);
  });
}
