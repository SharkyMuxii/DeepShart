// 记忆索引回归测试：问记忆检测、关键词提取、上下文覆盖判定。

import 'package:flutter_test/flutter_test.dart';

import 'package:deepshart/ai/memory_indexer.dart';

void main() {
  group('问记忆检测', () {
    test('命中"记得/说过/之前"', () {
      expect(MemoryIndexer.looksLikeMemoryQuery('你还记得我喜欢什么颜色吗'), isTrue);
      expect(MemoryIndexer.looksLikeMemoryQuery('我之前说过的那个约定是什么'), isTrue);
      expect(MemoryIndexer.looksLikeMemoryQuery('remenber 不对，do you remember my dog'), isTrue);
    });
    test('普通提问不触发', () {
      expect(MemoryIndexer.looksLikeMemoryQuery('1'), isFalse);
      expect(MemoryIndexer.looksLikeMemoryQuery('求极限怎么算'), isFalse);
    });
  });

  group('关键词提取', () {
    test('中文问题提取核心词，剔除停用词', () {
      final kws = MemoryIndexer.extractKeywords('我还记得我的猫叫什么名字吗');
      expect(kws, isNotEmpty);
      expect(kws.any((k) => k.contains('猫')), isTrue);
      expect(kws, isNot(contains('的')));
      expect(kws, isNot(contains('我')));
    });
    test('英文词也能提取', () {
      final kws = MemoryIndexer.extractKeywords('do you remember my birthday');
      expect(kws, contains('birthday'));
    });
    test('结果去重且长词优先', () {
      final kws = MemoryIndexer.extractKeywords('颜色偏好颜色偏好');
      expect(kws.length, kws.toSet().length);
    });
  });

  group('上下文覆盖判定', () {
    test('已有记忆含关键词则视为覆盖', () {
      expect(
        MemoryIndexer.contextCovers(
          ['用户喜欢深海蓝色'],
          ['深海', '颜色'],
        ),
        isTrue,
      );
    });
    test('没有相关记忆则未覆盖，触发全库检索', () {
      expect(
        MemoryIndexer.contextCovers(
          ['用户是医学生'],
          ['猫', '宠物'],
        ),
        isFalse,
      );
    });
    test('无关键词视为已覆盖（不触发无效检索）', () {
      expect(MemoryIndexer.contextCovers(['任意'], const []), isTrue);
    });
  });
}
