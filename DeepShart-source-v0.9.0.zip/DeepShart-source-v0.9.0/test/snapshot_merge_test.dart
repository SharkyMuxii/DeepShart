// 验证统一合并逻辑的基石：向量时钟能否正确区分
//   1) 一方多聊（before/after 包含关系）→ 自动合并，不问用户；
//   2) 真·方向冲突（concurrent）→ 产生 ConflictRecord，交用户选版本。
// COS 快照合并与 P2P 都复用这套 MessageStore.insertOrMerge 语义。

import 'package:deepshart/data/models/chat_message.dart';
import 'package:deepshart/data/models/conflict_record.dart';
import 'package:deepshart/data/store/message_store.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();

  late Database db;
  late SqliteMessageStore store;

  setUp(() async {
    db = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath);
    store = await SqliteMessageStore.open(db, localDeviceId: 'local');
  });

  tearDown(() async {
    await store.dispose();
    await db.close();
  });

  ChatMessage msg({
    required String id,
    required String content,
    required VectorClock clock,
    String device = 'remote',
  }) =>
      ChatMessage(
        id: id,
        conversationId: 'c1',
        role: MessageRole.user,
        content: content,
        createdAt: DateTime.utc(2026, 1, 1),
        updatedAt: DateTime.utc(2026, 1, 1),
        deviceId: device,
        versionVector: clock,
      );

  test('一方多聊：对端版本支配本地 → 自动合并，无冲突', () async {
    // 本地：devA tick 1
    await store.insertOrMerge(msg(
      id: 'm1',
      content: '第一天聊的方向',
      clock: VectorClock.fromJson({'A': 1}),
      device: 'A',
    ));
    // 对端：在 A:1 基础上又 tick 到 A:2（含 A 的历史）→ after
    final result = await store.insertOrMerge(msg(
      id: 'm1',
      content: '第一天聊的方向 + 第二天继续聊',
      clock: VectorClock.fromJson({'A': 2}),
      device: 'A',
    ));
    expect(result.updated, isTrue, reason: '因果支配应自动更新');
    expect(result.hasConflict, isFalse, reason: '单纯一方多聊不该打扰用户');

    final all = await store.readAll('c1');
    expect(all.single.content, '第一天聊的方向 + 第二天继续聊');
  });

  test('真方向冲突：向量时钟并发 → 产生 ConflictRecord 交用户选', () async {
    // 本地：A:1, B:0 视角
    await store.insertOrMerge(msg(
      id: 'm2',
      content: '手机聊的方向 A',
      clock: VectorClock.fromJson({'A': 1}),
      device: 'A',
    ));
    // 对端：B:1, A:0 视角（双方互不知晓 → concurrent）
    final result = await store.insertOrMerge(msg(
      id: 'm2',
      content: '平板聊的方向 B',
      clock: VectorClock.fromJson({'B': 1}),
      device: 'B',
    ));
    expect(result.hasConflict, isTrue, reason: '真并发必须产生冲突让用户选');
    expect(result.conflicts.first.status, ConflictStatus.pending);
  });

  test('重复投递幂等：相同版本不产生冲突、不重复', () async {
    final m = msg(
      id: 'm3',
      content: '同一份快照重复合并',
      clock: VectorClock.fromJson({'A': 1}),
    );
    final first = await store.insertOrMerge(m);
    final second = await store.insertOrMerge(m);
    expect(first.inserted, isTrue);
    expect(second.ignored, isTrue, reason: '重复合并应幂等忽略');
    expect((await store.readAll('c1')).length, 1);
  });
}
