// target: test/context_budget_test.dart
// 职责：锁定"上下文上限 = 单次请求输入上限"这一行为的边界，防止回归成静默全量发送。

import 'package:flutter_test/flutter_test.dart';

import 'package:deepshart/ai/context_budget.dart';
import 'package:deepshart/ai/token_estimator.dart';
import 'package:deepshart/data/models/chat_message.dart';
import 'package:deepshart/data/models/conversation_settings.dart';
import 'package:deepshart/data/models/important_memory.dart';

ChatMessage _msg(int index, {required int chars, MessageRole role = MessageRole.user}) {
  final content = '字' * chars;
  return ChatMessage.create(
    conversationId: 'c1',
    role: role,
    content: content,
    deviceId: 'dev-a',
    createdAt: DateTime.utc(2026, 1, 1).add(Duration(seconds: index)),
  );
}

/// 一问一答交替构造历史，符合真实序列形状。
List<ChatMessage> _history(int turns, {required int charsPerMessage}) {
  final list = <ChatMessage>[];
  for (var i = 0; i < turns; i++) {
    list.add(_msg(i * 2, chars: charsPerMessage, role: MessageRole.user));
    list.add(_msg(i * 2 + 1, chars: charsPerMessage, role: MessageRole.assistant));
  }
  return list;
}

void main() {
  final settings = ConversationSettings.forNew('c1');

  test('默认上限是 64K：超长历史被裁到上限以内，且报告丢弃条数', () {
    final history = _history(200, charsPerMessage: 500); // 约 200*2*325 ≈ 130K token
    final current = _msg(9999, chars: 20);

    final result = ContextBudget.fit(
      history: history,
      current: current,
      settings: settings,
      modelId: 'deepseek-flash',
    );

    expect(result.report.totalTokens, lessThanOrEqualTo(ContextBudget.defaultLimit));
    expect(result.report.droppedMessages, greaterThan(0));
    expect(result.report.includedMessages, lessThan(history.length));
    expect(result.history, isNotEmpty);
  });

  test('当前提问过长时放宽上限，并把历史压到最小（绝不裁剪提问）', () {
    final history = _history(50, charsPerMessage: 300);
    // 约 13 万 token 的单条提问，本身就超过 64K 上限。
    final huge = _msg(9999, chars: 200000);

    final result = ContextBudget.fit(
      history: history,
      current: huge,
      settings: settings,
      modelId: 'deepseek-flash',
    );

    expect(result.report.questionOverflow, isTrue);
    expect(result.report.limit, greaterThan(ContextBudget.defaultLimit));
    expect(result.report.currentTokens, greaterThan(ContextBudget.defaultLimit));
  });

  test('记忆点按重要度排序并受 15% 预算约束', () {
    final history = _history(10, charsPerMessage: 100);
    final memories = List<ImportantMemory>.generate(
      200,
      (i) => ImportantMemory.create(
        conversationId: 'c1',
        summary: '记' * 300,
        tags: const <String>['t'],
        importance: i == 199 ? 1.0 : 0.5,
        deviceId: 'dev-a',
      ),
    );

    final result = ContextBudget.fit(
      history: history,
      current: _msg(9999, chars: 20),
      memories: memories,
      settings: settings,
      modelId: 'deepseek-flash',
    );

    expect(result.report.memoryIncluded, lessThan(memories.length));
    expect(result.report.memoryIncluded, greaterThan(0));
    expect(result.report.memoryTokens,
        lessThanOrEqualTo((ContextBudget.defaultLimit * ContextBudget.memoryShare).ceil() + 10));
  });

  test('首次触顶会滑窗，并保留约 55% 的历史预算', () {
    final history = _history(300, charsPerMessage: 500);
    final result = ContextBudget.fit(
      history: history,
      current: _msg(9999, chars: 20),
      settings: settings,
      modelId: 'deepseek-flash',
    );

    expect(result.report.slid, isTrue);
    expect(result.report.nextAnchorId, isNotNull);
    // 滑窗后仍应留有余量，而不是贴着上限塞满。
    expect(result.report.historyTokens,
        lessThan((ContextBudget.defaultLimit * 0.9).round()));
  });

  test('带锚点且仍装得下时不滑窗，保证前缀稳定（缓存友好）', () {
    final history = _history(50, charsPerMessage: 200);
    final anchorId = history[history.length - 10].id;

    final result = ContextBudget.fit(
      history: history,
      current: _msg(9999, chars: 20),
      settings: settings,
      modelId: 'deepseek-flash',
      slideAnchorId: anchorId,
    );

    expect(result.report.slid, isFalse);
    // 起点与"开头锚点"之间的大段历史不应被带上；最开头几条仍会作为锚点保留。
    final includedIds = result.history.map((m) => m.id).toSet();
    expect(includedIds.contains(history[50].id), isFalse);
    expect(includedIds.contains(history.last.id), isTrue);
  });

  test('历史首条是 assistant 时被丢弃，避免对话从回答开始', () {
    final history = <ChatMessage>[
      _msg(0, chars: 50, role: MessageRole.assistant),
      _msg(1, chars: 50, role: MessageRole.user),
      _msg(2, chars: 50, role: MessageRole.assistant),
    ];

    final result = ContextBudget.fit(
      history: history,
      current: _msg(9999, chars: 10),
      settings: settings,
      modelId: 'deepseek-flash',
    );

    expect(result.history.first.role, MessageRole.user);
  });

  test('设置的上限超过模型窗口时被收窄，避免必然的 400', () {
    final s = ConversationSettings.forNew('c1').copyWith(contextLimit: 512000);
    final result = ContextBudget.fit(
      history: _history(10, charsPerMessage: 100),
      current: _msg(9999, chars: 20),
      settings: s,
      modelId: 'deepseek-chat', // 128K 窗口
    );

    expect(result.report.limit, 128000);
  });

  test('token 估算按中文 0.65 校准，不再 1 字 1 token', () {
    final tokens = TokenEstimator.estimate('字' * 1000);
    expect(tokens, 650);
  });
}
