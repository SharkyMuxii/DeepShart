import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:deepshart/data/models/chat_message.dart';
import 'package:deepshart/data/models/conflict_record.dart';
import 'package:deepshart/ui/conflict_resolution_sheet.dart';
import 'package:deepshart/data/store/message_store.dart';

ChatMessage _msg({
  required String id,
  required String content,
  required String device,
  int counter = 1,
}) =>
    ChatMessage(
      id: id,
      conversationId: 'c1',
      role: MessageRole.user,
      content: content,
      createdAt: DateTime.utc(2026, 1, 1),
      updatedAt: DateTime.utc(2026, 1, 1),
      deviceId: device,
      versionVector: VectorClock.fromJson({device: counter}),
    );

void main() {
  late Database db;
  late SqliteMessageStore store;

  setUp(() async {
    sqfliteFfiInit();
    db = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath);
    store = await SqliteMessageStore.open(db, localDeviceId: 'A');
  });

  tearDown(() async {
    await store.dispose();
    await db.close();
  });

  test('内容完全相同的并发版本不产生冲突，只合并时钟', () async {
    await store.insertOrMerge(_msg(id: 'm1', content: '一样的话', device: 'A'));
    final second =
        await store.insertOrMerge(_msg(id: 'm1', content: '一样的话', device: 'B'));

    expect(second.hasConflict, isFalse,
        reason: '两端各 tick 一次但内容相同，不该让用户裁决');

    final conflicts = await store.watchConflicts().first;
    expect(conflicts, isEmpty);

    final messages = await store.readAll('c1');
    expect(messages, hasLength(1));
    // 时钟取并集，下一轮摘要交换直接判 equal，不会反复冲突。
    expect(messages.single.versionVector.counters, {'A': 1, 'B': 1});
  });

  test('内容真不同才产生冲突', () async {
    await store.insertOrMerge(_msg(id: 'm2', content: '本地版本', device: 'A'));
    final second =
        await store.insertOrMerge(_msg(id: 'm2', content: '远端版本', device: 'B'));
    expect(second.hasConflict, isTrue);

    final conflicts = await store.watchConflicts().first;
    expect(conflicts, hasLength(1));
    expect(conflicts.single.versionA.content, '本地版本');
    expect(conflicts.single.versionB.content, '远端版本');
  });

  test('整体裁决一次性处理全部冲突', () async {
    for (var i = 0; i < 50; i++) {
      await store.insertOrMerge(_msg(id: 'm$i', content: '本地$i', device: 'A'));
      await store.insertOrMerge(_msg(id: 'm$i', content: '远端$i', device: 'B'));
    }
    expect((await store.watchConflicts().first), hasLength(50));

    final applied = await store.resolveConflictsBulk(
        strategy: ConflictMergeStrategy.remote);
    expect(applied, 50);

    expect(await store.watchConflicts().first, isEmpty);
    final messages = await store.readAll('c1');
    expect(messages.every((m) => m.content.startsWith('远端')), isTrue);
  });

  test('按时间合并：两边内容都留下，一条都不丢', () async {
    await store.insertOrMerge(_msg(id: 'mm', content: 'A 设备写的内容', device: 'A'));
    await store.insertOrMerge(_msg(id: 'mm', content: 'B 设备写的内容', device: 'B'));
    expect(await store.watchConflicts().first, hasLength(1));

    final handled =
        await store.resolveConflictsBulk(strategy: ConflictMergeStrategy.merge);
    expect(handled, 1);

    final messages = await store.readAll('c1');
    final contents = messages.map((m) => m.content).toList()..sort();
    expect(contents, ['A 设备写的内容', 'B 设备写的内容'],
        reason: '合并策略必须保留双方原文，而不是选一边');
    expect(await store.watchConflicts().first, isEmpty);
  });

  test('按时间合并不会静默删掉对端的删除标记以外的版本', () async {
    await store.insertOrMerge(_msg(id: 'mg', content: '本地版', device: 'A'));
    await store.insertOrMerge(_msg(id: 'mg', content: '远端版', device: 'B'));
    await store.resolveConflictsBulk(strategy: ConflictMergeStrategy.merge);

    final messages = await store.readAll('c1');
    expect(messages, hasLength(2));
    // 合并后的副本时钟必须前进，否则下一轮同步又会判成并发。
    for (final m in messages) {
      expect(m.versionVector.counters.containsKey('A'), isTrue);
    }
  });

  test('整体裁决选本机时保留本地内容', () async {
    await store.insertOrMerge(_msg(id: 'm9', content: '本地内容', device: 'A'));
    await store.insertOrMerge(_msg(id: 'm9', content: '远端内容', device: 'B'));

    await store.resolveConflictsBulk(strategy: ConflictMergeStrategy.local);
    final messages = await store.readAll('c1');
    expect(messages.single.content, '本地内容');
    expect(await store.watchConflicts().first, isEmpty);
  });

  _sheetTests();

  test('清掉内容一致的历史伪冲突', () async {
    // 造一条"历史遗留"的伪冲突：直接写进冲突表，模拟旧版本的行为。
    await store.insertOrMerge(_msg(id: 'legacy', content: '同样的内容', device: 'A'));
    final record = (await store.insertOrMerge(
            _msg(id: 'legacy2', content: '同样的内容', device: 'A')))
        .conflicts;
    expect(record, isEmpty);

    await db.insert('conflict_records', {
      'message_id': 'legacy',
      'conversation_id': 'c1',
      'version_a': _json(_msg(id: 'legacy', content: '同样的内容', device: 'A')),
      'version_b': _json(_msg(id: 'legacy', content: '同样的内容', device: 'B')),
      'detected_at': DateTime.now().millisecondsSinceEpoch,
      'status': 0,
    });

    final removed = await store.pruneIdenticalConflicts();
    expect(removed, 1);
    expect(await store.watchConflicts().first, isEmpty);
  });
}

ConflictRecord _record(int i) => ConflictRecord(
      messageId: 'c\$i',
      conversationId: 'c1',
      versionA: _msg(id: 'c\$i', content: '本机第\$i条内容', device: 'A'),
      versionB: _msg(id: 'c\$i', content: '对端第\$i条内容', device: 'B'),
      detectedAt: DateTime.utc(2026, 1, 1),
    );

void _sheetTests() {
  testWidgets('整体裁决弹窗一次选择即应用全部，不逐条追问', (tester) async {
    final conflicts = List<ConflictRecord>.generate(300, _record);
    ConflictMergeStrategy? choice;
    var calls = 0;

    await tester.pumpWidget(MaterialApp(
      home: Builder(
        builder: (context) => Scaffold(
          body: Center(
            child: ElevatedButton(
              onPressed: () => showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                builder: (_) => ConflictResolutionSheet(
                  conflicts: conflicts,
                  onResolveAll: (strategy) async {
                    calls++;
                    choice = strategy;
                    return conflicts.length;
                  },
                  onDeferAll: () async {},
                ),
              ),
              child: const Text('open'),
            ),
          ),
        ),
      ),
    ));

    await tester.tap(find.text('open'));
    await tester.pumpAndSettle();

    // 只出现一次"共 N 处"，不是 300 个弹窗。
    expect(find.text('300 处'), findsOneWidget);
    expect(find.textContaining('还有 295 处未列出'), findsOneWidget);
    expect(tester.takeException(), isNull);

    await tester.tap(find.text('全部使用对端版本'));
    await tester.pumpAndSettle();

    expect(calls, 1, reason: '整体裁决只应调用一次');
    expect(choice, ConflictMergeStrategy.remote);
    expect(find.byType(ConflictResolutionSheet), findsNothing, reason: '应用后应关闭弹窗');
    expect(tester.takeException(), isNull);
  });
}

String _json(ChatMessage m) => '{"id":"${m.id}","conversation_id":"${m.conversationId}",'
    '"role":"user","content":"${m.content}",'
    '"created_at":${m.createdAt.millisecondsSinceEpoch},'
    '"updated_at":${m.updatedAt.millisecondsSinceEpoch},'
    '"device_id":"${m.deviceId}","version_vector":${m.versionVector.serialize()}}';
