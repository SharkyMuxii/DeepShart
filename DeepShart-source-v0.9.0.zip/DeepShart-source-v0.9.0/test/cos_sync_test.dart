// 验证 COS 同步的纯逻辑：配置本机存取、对象键格式（设备名+时间标注）、
// 设备名清洗、每5轮计数。不依赖真实网络（真实连通性已用用户密钥实测通过）。

import 'package:deepshart/sync/cos_sync_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('CosConfig 本机配置', () {
    test('保存后能读回，isComplete 正确', () async {
      SharedPreferences.setMockInitialValues({});
      final prefs = await SharedPreferences.getInstance();
      const cfg = CosConfig(
        secretId: ' id ',
        secretKey: ' key ',
        bucket: ' bucket-123 ',
        region: ' ap-shanghai ',
      );
      await cfg.save(prefs);
      final loaded = CosConfig.fromPrefs(prefs);
      expect(loaded.secretId, 'id');
      expect(loaded.secretKey, 'key');
      expect(loaded.bucket, 'bucket-123');
      expect(loaded.region, 'ap-shanghai');
      expect(loaded.isComplete, isTrue);
      expect(loaded.host, 'bucket-123.cos.ap-shanghai.myqcloud.com');

      await loaded.clear(prefs);
      expect(CosConfig.fromPrefs(prefs).isComplete, isFalse);
    });
  });

  group('COS 对象键格式', () {
    late CosSyncService svc;
    setUp(() async {
      SharedPreferences.setMockInitialValues({});
      final prefs = await SharedPreferences.getInstance();
      svc = CosSyncService(prefs: prefs);
    });

    test('设备名清洗：去掉非法字符、压缩空白', () {
      expect(svc.deviceTag('DeepShart (iPhone)'), 'DeepShart_(iPhone)');
      expect(svc.deviceTag('我的/电脑:1'), '我的_电脑_1');
      expect(svc.deviceTag(''), 'device');
    });

    test('快照键含设备名与可读时间，备份键含原因', () {
      final at = DateTime.utc(2026, 11, 19, 17, 30, 45);
      final snap = svc.snapshotKey('MyPC', at);
      // 新格式：设备名_年-月-日_时-分-秒.db（本地时间，正则断言避开时区差异）
      expect(snap, matches(RegExp(r'^deepshart/snapshots/MyPC/MyPC_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}\.db$')));

      final backup = svc.backupKey('MyPC', at, 'sync');
      expect(backup, matches(RegExp(r'^deepshart/backups/MyPC/MyPC_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}_sync\.db$')));

      final latest = svc.latestSnapshotKey('MyPC');
      expect(latest, 'deepshart/snapshots/MyPC/latest_MyPC.db');
    });
  });

  group('每5轮计数', () {
    test('未启用 COS 时不计数', () async {
      SharedPreferences.setMockInitialValues({});
      final prefs = await SharedPreferences.getInstance();
      final svc = CosSyncService(prefs: prefs);
      for (var i = 0; i < 6; i++) {
        expect(svc.tickRound(cosModeEnabled: false), isFalse);
      }
      expect(svc.pendingRounds, 0);
    });

    test('开启"每N条"开关时第5轮返回 true 并清零', () async {
      SharedPreferences.setMockInitialValues({
        'deepshart.cos.secret_id': 'id',
        'deepshart.cos.secret_key': 'key',
        'deepshart.cos.bucket': 'bucket',
        'deepshart.cos.region': 'ap-guangzhou',
        'deepshart.cos.auto_rounds_enabled': true,
      });
      final prefs = await SharedPreferences.getInstance();
      final svc = CosSyncService(prefs: prefs);
      expect(svc.tickRound(cosModeEnabled: true), isFalse); // 1
      expect(svc.tickRound(cosModeEnabled: true), isFalse); // 2
      expect(svc.tickRound(cosModeEnabled: true), isFalse); // 3
      expect(svc.tickRound(cosModeEnabled: true), isFalse); // 4
      expect(svc.tickRound(cosModeEnabled: true), isTrue);  // 5 -> 触发
      expect(svc.pendingRounds, 0);
    });

    test('未开启"每N条"开关时不计数（新行为）', () async {
      SharedPreferences.setMockInitialValues({
        'deepshart.cos.secret_id': 'id',
        'deepshart.cos.secret_key': 'key',
        'deepshart.cos.bucket': 'bucket',
        'deepshart.cos.region': 'ap-guangzhou',
      });
      final prefs = await SharedPreferences.getInstance();
      final svc = CosSyncService(prefs: prefs);
      for (var i = 0; i < 10; i++) {
        expect(svc.tickRound(cosModeEnabled: true), isFalse);
      }
      expect(svc.pendingRounds, 0);
    });

    test('N 可配置：设为 3 时第3轮触发', () async {
      SharedPreferences.setMockInitialValues({
        'deepshart.cos.secret_id': 'id',
        'deepshart.cos.secret_key': 'key',
        'deepshart.cos.bucket': 'bucket',
        'deepshart.cos.region': 'ap-guangzhou',
        'deepshart.cos.auto_rounds_enabled': true,
        'deepshart.cos.auto_rounds': 3,
      });
      final prefs = await SharedPreferences.getInstance();
      final svc = CosSyncService(prefs: prefs);
      expect(svc.tickRound(cosModeEnabled: true), isFalse);
      expect(svc.tickRound(cosModeEnabled: true), isFalse);
      expect(svc.tickRound(cosModeEnabled: true), isTrue);
    });

    test('三个自动开关配置读写往返', () async {
      SharedPreferences.setMockInitialValues({});
      final prefs = await SharedPreferences.getInstance();
      const cfg = CosAutoSyncConfig(
        intervalEnabled: true, intervalMinutes: 15,
        roundsEnabled: false, rounds: 8,
        startupEnabled: true,
      );
      await cfg.save(prefs);
      final read = CosAutoSyncConfig.fromPrefs(prefs);
      expect(read.intervalEnabled, isTrue);
      expect(read.intervalMinutes, 15);
      expect(read.roundsEnabled, isFalse);
      expect(read.rounds, 8);
      expect(read.startupEnabled, isTrue);
    });
  });
}
