// 压缩回归测试。
//
// 背景：用户实测"压缩报告说省了 token、也确实扣了余额，但对话一条没少"。
// 根因是压缩器改消息时没有 tick 向量时钟，store 判定 equal 后直接忽略。
// 这里的核心断言就是：压缩之后库里的可见消息必须真的变少。

import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:deepshart/ai/ai_provider.dart';
import 'package:deepshart/data/models/chat_message.dart';
import 'package:deepshart/data/models/compression_level.dart';
import 'package:deepshart/data/models/conversation_settings.dart';
import 'package:deepshart/data/models/important_memory.dart';
import 'package:deepshart/data/models/session_summary.dart';
import 'package:deepshart/data/store/message_store.dart';
import 'package:deepshart/import/context_compressor.dart';

/// 假模型：只回一句固定摘要，避免测试打真实接口（也就不会花用户的钱）。
class _FakeAi implements AiProvider {
  int calls = 0;

  @override
  String get displayName => 'fake';

  @override
  bool get supportsThinking => false;

  @override
  bool get supportsSearch => false;

  @override
  bool get supportsFileUpload => false;

  @override
  Future<AiResponse> sendMessage(
    List<AiMessage> messages, {
    AiRequestOptions options = const AiRequestOptions(),
  }) async {
    calls++;
    return const AiResponse(finalAnswer: '这是一段压缩摘要：用户在此处讨论了若干事项。');
  }

  @override
  Stream<AiStreamChunk> sendMessageStream(
    List<AiMessage> messages, {
    AiRequestOptions options = const AiRequestOptions(),
  }) async* {
    yield const AnswerChunk('这是一段压缩摘要：用户在此处讨论了若干事项。');
  }

  @override
  Future<UploadedFile> uploadFile(String path) async =>
      const UploadedFile(fileId: 'fake', fileName: 'fake');
}

List<ChatMessage> _buildMessages(int count) => List<ChatMessage>.generate(count, (i) {
      final minutes = i * 10;
      return ChatMessage(
        id: 'm$i',
        conversationId: 'c1',
        role: i.isEven ? MessageRole.user : MessageRole.assistant,
        // 每条都足够长，确保"截成片段"这一档真的有内容可截。
        content: '第$i条消息：${'内容' * 160}',
        createdAt: DateTime.utc(2026, 1, 1).add(Duration(minutes: minutes)),
        updatedAt: DateTime.utc(2026, 1, 1).add(Duration(minutes: minutes)),
        deviceId: 'A',
        versionVector: VectorClock.fromJson({'A': 1}),
      );
    });

void main() {
  late Database db;
  late SqliteMessageStore store;
  late _FakeAi ai;

  setUp(() async {
    sqfliteFfiInit();
    db = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath);
    store = await SqliteMessageStore.open(db, localDeviceId: 'A');
    ai = _FakeAi();
  });

  tearDown(() async {
    await store.dispose();
    await db.close();
  });

  Future<void> seed(List<ChatMessage> messages) async {
    for (final m in messages) {
      await store.insertOrMerge(m);
    }
  }

  ConversationSettings settingsWith({
    int level = 1,
    double recent = 0.15,
    double oldest = 0.10,
  }) =>
      ConversationSettings.forNew('c1').copyWith(
        compressionLevel: level,
        keepRecentRatio: recent,
        keepOldestRatio: oldest,
      );

  test('压缩只改变发送视图，库内原文一条不少', () async {
    final messages = _buildMessages(60);
    await seed(messages);
    expect(await store.readAll('c1'), hasLength(60));

    final compressor = ContextCompressor(provider: ai, store: store);
    final outcome = await compressor.compress(
      conversationId: 'c1',
      messages: messages,
      settings: settingsWith(),
      localDeviceId: 'A',
    );

    final after = await store.readAll('c1');
    expect(outcome.skipped, isFalse);
    // 甲方案的底线：压缩不碰消息表。
    expect(after.length, 60, reason: '压缩不得删除或改写任何消息');
    final effective = outcome.view!.materialize(after);
    expect(effective.length, lessThan(60),
        reason: '发出去的视图必须真的变短');
    expect(outcome.afterTokens, lessThan(outcome.beforeTokens));
    expect(outcome.deletedCount, greaterThan(0));
  });

  test('摘要出现在视图里，并带系统标记', () async {
    final messages = _buildMessages(40);
    await seed(messages);
    final outcome = await ContextCompressor(provider: ai, store: store).compress(
      conversationId: 'c1',
      messages: messages,
      settings: settingsWith(),
      localDeviceId: 'A',
    );

    final effective = outcome.view!.materialize(messages);
    final summaries =
        effective.where((m) => m.content.contains(CompressionMarkers.openTag)).toList();
    expect(summaries, hasLength(1));
    expect(summaries.single.content, contains('压缩摘要'));
  });

  test('最新与最老的消息原样保留', () async {
    final messages = _buildMessages(50);
    await seed(messages);
    await ContextCompressor(provider: ai, store: store).compress(
      conversationId: 'c1',
      messages: messages,
      settings: settingsWith(recent: 0.10, oldest: 0.10),
      localDeviceId: 'A',
    );

    final after = await store.readAll('c1');
    final ids = after.map((m) => m.id).toSet();
    // 最老 5 条（10% of 50）与最新 5 条必须完整在位。
    for (var i = 0; i < 5; i++) {
      expect(ids, contains('m$i'), reason: '最老的第 $i 条被误删');
    }
    for (var i = 45; i < 50; i++) {
      expect(ids, contains('m$i'), reason: '最新的第 $i 条被误删');
    }
    // 且最新那几条的正文没有被截断。
    final newest = after.firstWhere((m) => m.id == 'm49');
    expect(newest.content.contains('……'), isFalse);
  });

  test('越老的消息保留得越少：中段出现片段、尾部为原文', () async {
    final messages = _buildMessages(80);
    await seed(messages);
    final outcome = await ContextCompressor(provider: ai, store: store).compress(
      conversationId: 'c1',
      messages: messages,
      settings: settingsWith(level: CompressionLevel.heavy.index),
      localDeviceId: 'A',
    );

    final effective = outcome.view!.materialize(messages);
    final truncated = effective.where((m) => m.content.endsWith('……')).toList();
    expect(truncated, isNotEmpty, reason: '重度压缩应产生被截成片段的消息');

    // 片段消息的时间必须早于最新保护段：越老越轻。
    final newestKept = effective.last;
    for (final t in truncated) {
      expect(t.createdAt.isBefore(newestKept.createdAt), isTrue);
    }
  });

  test('三档压缩：轻度保留最多，重度最少', () async {
    final messages = _buildMessages(80);

    Future<int> keptFor(CompressionLevel level) async {
      final fresh = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath);
      final s = await SqliteMessageStore.open(fresh, localDeviceId: 'A');
      for (final m in messages) {
        await s.insertOrMerge(m);
      }
      final outcome = await ContextCompressor(provider: ai, store: s).compress(
        conversationId: 'c1',
        messages: messages,
        settings: settingsWith(level: level.index),
        localDeviceId: 'A',
      );
      // 以"视图应用后的条数"衡量强度：库内条数永远不变。
      final kept = outcome.view!.materialize(messages).length;
      await s.dispose();
      await fresh.close();
      return kept;
    }

    final light = await keptFor(CompressionLevel.light);
    final medium = await keptFor(CompressionLevel.medium);
    final heavy = await keptFor(CompressionLevel.heavy);

    expect(light, greaterThan(medium), reason: 'light=$light medium=$medium');
    expect(medium, greaterThan(heavy), reason: 'medium=$medium heavy=$heavy');
  });

  test('重要记忆保护：被标记的那条不会被压掉', () async {
    final messages = _buildMessages(60);
    await seed(messages);

    // 取一条中段消息，把它的开头存成记忆点（用户在 UI 上就是这么做的）。
    final target = messages[25];
    final memory = ImportantMemory.create(
      conversationId: 'c1',
      summary: '${target.content.substring(0, 24)}（重点）',
      tags: const <String>['重点'],
      importance: 1,
      deviceId: 'A',
    );

    final outcome = await ContextCompressor(provider: ai, store: store).compress(
      conversationId: 'c1',
      messages: messages,
      settings: settingsWith(level: CompressionLevel.heavy.index),
      localDeviceId: 'A',
      memories: <ImportantMemory>[memory],
    );

    expect(outcome.memoryProtectedCount, greaterThan(0));
    final after = await store.readAll('c1');
    final kept = after.firstWhere((m) => m.id == target.id);
    expect(kept.content, target.content, reason: '记忆点必须原样保留，不能被截断');
  });

  test('消息太少时明确跳过，不扣钱也不改数据', () async {
    final messages = _buildMessages(4);
    await seed(messages);

    final outcome = await ContextCompressor(provider: ai, store: store).compress(
      conversationId: 'c1',
      messages: messages,
      settings: settingsWith(),
      localDeviceId: 'A',
    );

    expect(outcome.skipped, isTrue);
    expect(outcome.skipReason, isNotNull);
    expect(ai.calls, 0, reason: '没东西可压时不该调用模型');
    expect(await store.readAll('c1'), hasLength(4));
  });

  test('保留比例调高后，可压缩的中段变少', () async {
    final messages = _buildMessages(60);

    Future<CompressionOutcome> run(double recent, double oldest) async {
      final fresh = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath);
      final s = await SqliteMessageStore.open(fresh, localDeviceId: 'A');
      for (final m in messages) {
        await s.insertOrMerge(m);
      }
      final outcome =
          await ContextCompressor(provider: ai, store: s).compress(
        conversationId: 'c1',
        messages: messages,
        settings: settingsWith(recent: recent, oldest: oldest),
        localDeviceId: 'A',
      );
      await s.dispose();
      await fresh.close();
      return outcome;
    }

    final narrow = await run(0.05, 0.0);
    final wide = await run(0.40, 0.30);

    expect(narrow.deletedCount, greaterThan(wide.deletedCount),
        reason: '保留得越多，能折叠的越少');
  });

  test('压缩只产出视图，绝不写消息表', () async {
    final messages = _buildMessages(30);

    final outcome = await ContextCompressor(provider: ai, store: store).compress(
      conversationId: 'c1',
      messages: messages,
      settings: settingsWith(),
      localDeviceId: 'A',
    );

    expect(outcome.view, isNotNull);
    // finalMessages 是"应用视图后"的样子，条数应当变少。
    expect(outcome.finalMessages.length, lessThan(30));
    // 库里必须一条都没有：压缩不改库是甲方案的底线。
    expect(await store.readAll('c1'), isEmpty);
    // 视图本身要能完整复现同样的结果。
    final materialized = outcome.view!.materialize(messages);
    expect(materialized.length, outcome.finalMessages.length);
  });
}
