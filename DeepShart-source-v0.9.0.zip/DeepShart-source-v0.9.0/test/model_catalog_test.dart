// 模型名回归测试：服务端 2026-11 报错 "supported: deepseek-flash,
// deepseek-v4-pro"，失效的 deepseek-pro / deepseek-v4-flash 不得再出现在
// 可选表；老设置里的失效名必须被归一化，否则升级后一发送就 400。

import 'package:flutter_test/flutter_test.dart';

import 'package:deepshart/ai/model_catalog.dart';

void main() {
  test('内置表不含已失效的 deepseek-pro / deepseek-v4-flash', () {
    final ids = ModelCatalog.builtin.map((m) => m.id).toList();
    expect(ids, isNot(contains('deepseek-pro')));
    expect(ids, isNot(contains('deepseek-v4-flash')));
    expect(ids, contains('deepseek-v4-pro'));
    expect(ids, contains('deepseek-flash'));
  });

  test('失效名归一化为有效名', () {
    expect(ModelCatalog.canonicalize('deepseek-pro'), 'deepseek-v4-pro');
    expect(ModelCatalog.canonicalize('deepseek-v4-flash'), 'deepseek-flash');
    // 大小写与空格容错。
    expect(ModelCatalog.canonicalize('  DEEPSEEK-PRO  '), 'deepseek-v4-pro');
  });

  test('有效名与未知名原样返回', () {
    expect(ModelCatalog.canonicalize('deepseek-v4-pro'), 'deepseek-v4-pro');
    expect(ModelCatalog.canonicalize('some-new-model'), 'some-new-model');
  });

  test('merge 不收录失效名（缓存里的旧 id 也被归一化）', () {
    final merged = ModelCatalog.merge(['deepseek-pro', 'brand-new']);
    final ids = merged.map((m) => m.id).toList();
    expect(ids, isNot(contains('deepseek-pro')));
    expect(ids, contains('deepseek-v4-pro')); // 归一化后收录
    expect(ids, contains('brand-new')); // 新模型保留
  });
}
