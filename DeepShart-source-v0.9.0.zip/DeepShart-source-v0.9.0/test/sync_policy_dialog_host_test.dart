// 回归测试：同步策略弹窗宿主必须能在 Stack 中直接渲染并回填 completer。
//
// 背景 bug：宿主原先放在 MaterialApp.router.builder 里用 Overlay.maybeOf +
// OverlayEntry 弹窗，但 builder 位于 Router 之上、没有 Overlay，弹窗永不出现，
// 同步闸门 ask() 一直挂起 → 用户看到"无限转"。改为 Stack 直接渲染后修复。
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:deepshart/ui/agreement_gate.dart';
import 'package:deepshart/ui/sync_policy_dialog.dart';
import 'package:deepshart/sync/sync_policy.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('协议已同意时，出错定夺能让顶层宿主弹出四选一，选择后回填 completer',
      (tester) async {
    // 协议已同意：宿主才会注册 UI、策略框才会渲染。
    SharedPreferences.setMockInitialValues({
      'deepshart.agreement_accepted_v1': true,
    });

    final container = ProviderContainer();
    addTearDown(container.dispose);
    final gate = container.read(syncPolicyGateProvider.notifier);

    // 模拟 App 顶层的 Stack：底层占位 + 两个常驻宿主。
    await tester.pumpWidget(
      UncontrolledProviderScope(
        container: container,
        child: const MaterialApp(
          home: Stack(
            children: [
              SizedBox.expand(child: ColoredBox(color: Colors.white)),
              AgreementGate(),
              SyncPolicyDialogHost(),
            ],
          ),
        ),
      ),
    );
    // 跑完 postFrame：宿主注册 UI + 协议 FutureProvider 读出 true。
    await tester.pumpAndSettle();

    // 触发一次出错定夺请求（静默同步失败时调用 askOnError）。
    final future = gate.askOnError(
      '云端快照 · 平板A',
      method: SyncMethod.cos,
      errorDetail: '合并快照时数据库损坏',
    );
    await tester.pumpAndSettle();

    // 定夺窗标题、同步方式标注、错误详情、四个选项都应出现。
    expect(find.text('同步未完成，请选择处理方式'), findsOneWidget,
        reason: '定夺窗必须真正渲染出来');
    expect(find.textContaining('出错的同步方式：腾讯云 COS'), findsOneWidget);
    expect(find.textContaining('合并快照时数据库损坏'), findsOneWidget);
    expect(find.textContaining('云端快照 · 平板A'), findsOneWidget);
    // 四种并列行为都在（含"不同步"）。
    for (final p in SyncPolicy.values) {
      expect(find.textContaining(p.label), findsWidgets, reason: '${p.label} 应出现在定夺窗');
    }

    // 点击"不同步"，future 应立即回填，不再挂起等待。
    await tester.tap(find.text('不同步'));
    await tester.pumpAndSettle();
    expect(await future, SyncPolicy.none);
    expect(container.read(syncPolicyGateProvider), isNull);
  });

  testWidgets('协议未同意时不渲染策略弹窗（两个遮罩不打架）', (tester) async {
    SharedPreferences.setMockInitialValues({
      'deepshart.agreement_accepted_v1': false,
    });
    final container = ProviderContainer();
    addTearDown(container.dispose);
    final gate = container.read(syncPolicyGateProvider.notifier);

    await tester.pumpWidget(
      UncontrolledProviderScope(
        container: container,
        child: const MaterialApp(
          home: Stack(
            children: [
              SizedBox.expand(child: ColoredBox(color: Colors.white)),
              AgreementGate(),
              SyncPolicyDialogHost(),
            ],
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    // 协议框应出现，策略请求即使入队也不渲染策略框。
    expect(find.text('用户协议与免责声明'), findsOneWidget);
    final f = gate.askOnError('云端', method: SyncMethod.p2p, errorDetail: 'x');
    await tester.pumpAndSettle();
    expect(find.text('同步未完成，请选择处理方式'), findsNothing);
    // answer 掉，避免 180s 超时 Timer 在 fake async 下遗留。
    gate.answer(SyncPolicy.merge);
    expect(await f, SyncPolicy.merge);
  });
}
