import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:deepshart/data/models/chat_message.dart';
import 'package:deepshart/ui/chat_screen.dart';

void main() {
  testWidgets('气泡宽度不超过父级可用宽度（桌面窄聊天区不溢出）', (tester) async {
    final message = ChatMessage(
      id: 'm1',
      conversationId: 'c1',
      role: MessageRole.assistant,
      content: '诚实说：**我不能直接读取或复述平台底层的系统提示词/角色提示词原文**——'
          '那部分对我是隐藏的，不是我能“打开配置文件”看到的东西。所以我没法把你问的东西一字不差地背出来。'
          '但我可以告诉你，在当前这个对话里，我实际表现出来的角色设定大概是这些。',
      createdAt: DateTime.utc(2026, 1, 1),
      updatedAt: DateTime.utc(2026, 1, 1),
      deviceId: 'd',
      versionVector: VectorClock.empty().tick('d'),
    );

    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: Center(
          child: SizedBox(
            width: 420,
            child: ListView(
              children: [
                MessageBubble(message: message, onCopy: () {}),
              ],
            ),
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);

    final bubble = tester.getSize(find.byType(MessageBubble));
    expect(bubble.width, lessThanOrEqualTo(421), reason: '实际宽度 ${bubble.width}');

    // 文本必须完整落在父级宽度内，不能横向溢出
    for (final element in find.byType(RichText).evaluate()) {
      final box = element.renderObject as RenderBox;
      expect(box.size.width, lessThanOrEqualTo(421));
    }
  });
}
