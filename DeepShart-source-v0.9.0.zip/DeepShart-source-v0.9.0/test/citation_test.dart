// 联网搜索引用回归测试。
// 用户实测 bug：联网搜索后"搜索引用"变成一列 "-"，来源标题和链接全不显示。
// 根因：DeepSeek 官方结构把字段藏在 annotations[].url_citation 里，
// 旧代码只读 annotation['url'] → 全空 → 渲染出分隔符 "-"。

import 'package:flutter_test/flutter_test.dart';

import 'package:deepshart/ai/ai_provider.dart';
import 'package:deepshart/ai/citation_codec.dart';
import 'package:deepshart/ai/deepseek_provider.dart';

void main() {
  group('parseAnnotations', () {
    test('解析官方 url_citation 嵌套结构（用户 bug 的真实场景）', () {
      final annotations = [
        {
          'type': 'url_citation',
          'url_citation': {
            'url': 'https://example.com/a',
            'title': '深度求索官网',
            'snippet': '一段摘要',
            'start_index': 3,
            'end_index': 8,
          },
        },
      ];

      final citations = DeepSeekProvider.parseAnnotations(annotations);
      expect(citations, hasLength(1));
      expect(citations.first.title, '深度求索官网');
      expect(citations.first.url, 'https://example.com/a');
      expect(citations.first.snippet, '一段摘要');
      expect(citations.first.startIndex, 3);
      expect(citations.first.endIndex, 8);
    });

    test('多条引用都能解析，且顺序保持', () {
      final annotations = [
        {
          'type': 'url_citation',
          'url_citation': {'url': 'https://a.com', 'title': 'A'},
        },
        {
          'type': 'url_citation',
          'url_citation': {'url': 'https://b.com', 'title': 'B'},
        },
      ];
      final citations = DeepSeekProvider.parseAnnotations(annotations);
      expect(citations.map((c) => c.title).toList(), ['A', 'B']);
    });

    test('空壳引用被丢弃（绝不再渲染出 "-" 横线）', () {
      final annotations = [
        {'type': 'url_citation', 'url_citation': {'url': '', 'title': ''}},
        {'type': 'url_citation'}, // 连 url_citation 都没有
        {},
      ];
      expect(DeepSeekProvider.parseAnnotations(annotations), isEmpty);
    });

    test('兼容扁平结构与 search_result 嵌套', () {
      final flat = DeepSeekProvider.parseAnnotations([
        {'type': 'url_citation', 'url': 'https://flat.com', 'title': '扁平'},
      ]);
      expect(flat.single.url, 'https://flat.com');

      final sr = DeepSeekProvider.parseAnnotations([
        {
          'type': 'search_result',
          'search_result': {'url': 'https://sr.com', 'title': '搜索结果'},
        },
      ]);
      expect(sr.single.title, '搜索结果');
    });

    test('null / 空列表安全', () {
      expect(DeepSeekProvider.parseAnnotations(null), isEmpty);
      expect(DeepSeekProvider.parseAnnotations(const []), isEmpty);
    });
  });

  group('CitationCodec 编解码', () {
    test('编码后解码能完整还原引用（含 start_index）', () {
      final citations = [
        const AiCitation(
          title: '标题含 - 和 [引用] 也不怕',
          url: 'https://example.com/a?x=1&y=2',
          snippet: '摘要',
          startIndex: 5,
          endIndex: 12,
        ),
      ];
      final encoded = CitationCodec.encode('这是正文内容', citations);
      final decoded = CitationCodec.decode(encoded);

      expect(decoded.body, '这是正文内容');
      expect(decoded.citations, hasLength(1));
      expect(decoded.citations.first.title, citations.first.title);
      expect(decoded.citations.first.url, citations.first.url);
      expect(decoded.citations.first.startIndex, 5);
      expect(decoded.citations.first.endIndex, 12);
    });

    test('没有引用时正文原样返回，不产生标记', () {
      final encoded = CitationCodec.encode('纯正文', const []);
      expect(encoded, '纯正文');
      expect(CitationCodec.decode(encoded).citations, isEmpty);
    });

    test('strip 去掉编码块但保留正文', () {
      final encoded = CitationCodec.encode(
        '正文在这里',
        const [AiCitation(title: '来源', url: 'https://x.com')],
      );
      expect(CitationCodec.strip(encoded), '正文在这里');
    });

    test('withInlineMarkers 按索引插入角标', () {
      final citations = [
        const AiCitation(title: 'A', url: 'https://a', startIndex: 2),
      ];
      final result = CitationCodec.withInlineMarkers('012345', citations);
      expect(result, '01〔1〕2345');
    });

    test('越界索引被跳过，正文不变', () {
      final citations = [
        const AiCitation(title: 'A', url: 'https://a', startIndex: 999),
      ];
      expect(CitationCodec.withInlineMarkers('短', citations), '短');
    });

    test('坏编码不炸，正文照常显示', () {
      const bad = '正文<citations_b64>!!!坏数据!!!</citations_b64>';
      final decoded = CitationCodec.decode(bad);
      expect(decoded.body, '正文');
      expect(decoded.citations, isEmpty);
    });
  });
}
