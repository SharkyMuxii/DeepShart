import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:deepshart/ui/markdown_view.dart';

void main() {
  Future<void> pump(WidgetTester tester, String data) async {
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: SingleChildScrollView(
          child: MarkdownView(
            data: data,
            baseStyle: const TextStyle(fontSize: 14),
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();
  }

  String allText(WidgetTester tester) {
    final texts = tester.widgetList<RichText>(find.byType(RichText));
    return texts.map((t) => t.text.toPlainText()).join('\n');
  }

  testWidgets('加粗/斜体/高亮/行内代码不再裸露标记', (tester) async {
    await pump(tester, '诚实说：**我不能直接读取**，*斜体*，`code`，==重点==，~~删除~~');
    final text = allText(tester);
    expect(text.contains('**'), isFalse, reason: '加粗标记不应出现: $text');
    expect(text.contains('`'), isFalse);
    expect(text.contains('=='), isFalse);
    expect(text.contains('~~'), isFalse);
    expect(text.contains('我不能直接读取'), isTrue);
  });

  testWidgets('跨行加粗也能闭上', (tester) async {
    await pump(tester, '**这是一段\n被折行的加粗文本**结束');
    final text = allText(tester);
    expect(text.contains('**'), isFalse, reason: text);
  });

  testWidgets('标题会放大，列表有项目符号', (tester) async {
    await pump(tester, '## 小标题\n- 第一条\n- 第二条');
    final text = allText(tester);
    expect(text.contains('##'), isFalse);
    expect(text.contains('小标题'), isTrue);
    expect(text.contains('第一条'), isTrue);

    Iterable<TextSpan> flatten(InlineSpan span) sync* {
      if (span is TextSpan) {
        yield span;
        for (final child in span.children ?? const <InlineSpan>[]) {
          yield* flatten(child);
        }
      }
    }

    final heading = tester
        .widgetList<RichText>(find.byType(RichText))
        .firstWhere((t) => t.text.toPlainText().contains('小标题'));
    final child = flatten(heading.text)
        .firstWhere((s) => (s.text ?? '').contains('小标题'));
    expect(child.style?.fontSize, greaterThan(14), reason: '标题字号应大于正文');
  });
}
