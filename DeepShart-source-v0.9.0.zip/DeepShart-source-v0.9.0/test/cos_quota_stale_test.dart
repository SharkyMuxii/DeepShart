// 验证 COS 历史版本容量上限、废弃同步文件分级提醒状态机。
import 'package:deepshart/sync/cos_sync_service.dart';
import 'package:deepshart/sync/stale_sync_tracker.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('历史版本容量上限', () {
    test('默认 500MB，换算字节正确', () async {
      SharedPreferences.setMockInitialValues({});
      final prefs = await SharedPreferences.getInstance();
      final cfg = CosQuotaConfig.fromPrefs(prefs);
      expect(cfg.value, 500);
      expect(cfg.unit, 'mb');
      expect(cfg.bytes, 500 * 1024 * 1024);
    });

    test('最大硬上限 1TB：填 5PB 也夹到 1TB', () async {
      SharedPreferences.setMockInitialValues({
        'deepshart.cos.quota_value': 5.0,
        'deepshart.cos.quota_unit': 'pb',
      });
      final prefs = await SharedPreferences.getInstance();
      final cfg = CosQuotaConfig.fromPrefs(prefs);
      expect(cfg.bytes, CosQuotaConfig.maxBytes);
      expect(cfg.bytes, 1024 * 1024 * 1024 * 1024);
    });

    test('填 0 表示不限制', () async {
      SharedPreferences.setMockInitialValues({
        'deepshart.cos.quota_value': 0.0,
        'deepshart.cos.quota_unit': 'mb',
      });
      final prefs = await SharedPreferences.getInstance();
      expect(CosQuotaConfig.fromPrefs(prefs).bytes, 0);
    });

    test('配置读写往返', () async {
      SharedPreferences.setMockInitialValues({});
      final prefs = await SharedPreferences.getInstance();
      await const CosQuotaConfig(value: 200, unit: 'kb').save(prefs);
      final read = CosQuotaConfig.fromPrefs(prefs);
      expect(read.value, 200);
      expect(read.unit, 'kb');
      expect(read.bytes, 200 * 1024);
    });
  });

  group('废弃同步文件分级提醒', () {
    final now = DateTime.utc(2026, 11, 20, 12);

    test('3天内不提醒', () async {
      SharedPreferences.setMockInitialValues({});
      final prefs = await SharedPreferences.getInstance();
      final tracker = StaleSyncTracker(prefs);
      final level = tracker.evaluate('devA', now.subtract(const Duration(days: 2)), now: now);
      expect(level, StaleLevel.none);
    });

    test('满3天首次提醒=软提示', () async {
      SharedPreferences.setMockInitialValues({});
      final prefs = await SharedPreferences.getInstance();
      final tracker = StaleSyncTracker(prefs);
      final level = tracker.evaluate('devA', now.subtract(const Duration(days: 4)), now: now);
      expect(level, StaleLevel.soft);
    });

    test('软提示后用户保留，3天内不再提醒', () async {
      SharedPreferences.setMockInitialValues({});
      final prefs = await SharedPreferences.getInstance();
      final tracker = StaleSyncTracker(prefs);
      tracker.evaluate('devA', now.subtract(const Duration(days: 4)), now: now);
      await tracker.decline('devA');
      final level = tracker.evaluate('devA', now.subtract(const Duration(days: 4)), now: now);
      expect(level, StaleLevel.none);
    });

    test('软提示保留后再过3天=硬提示（红色）', () async {
      SharedPreferences.setMockInitialValues({});
      final prefs = await SharedPreferences.getInstance();
      final tracker = StaleSyncTracker(prefs);
      tracker.evaluate('devA', now.subtract(const Duration(days: 10)), now: now);
      // 模拟用户 6 天前点了保留。
      await prefs.setString('deepshart.stale_file.devA',
          'first=${now.subtract(const Duration(days: 10)).millisecondsSinceEpoch};'
          'declined=${now.subtract(const Duration(days: 6)).millisecondsSinceEpoch};permanent=0');
      final level = tracker.evaluate('devA', now.subtract(const Duration(days: 10)), now: now);
      expect(level, StaleLevel.hard);
    });

    test('硬提示后仍保留→永久忽略，不再提示', () async {
      SharedPreferences.setMockInitialValues({});
      final prefs = await SharedPreferences.getInstance();
      final tracker = StaleSyncTracker(prefs);
      await tracker.permanentIgnore('devA');
      final level = tracker.evaluate('devA', now.subtract(const Duration(days: 100)), now: now);
      expect(level, StaleLevel.none);
    });

    test('文件重新更新后状态清零', () async {
      SharedPreferences.setMockInitialValues({});
      final prefs = await SharedPreferences.getInstance();
      final tracker = StaleSyncTracker(prefs);
      tracker.evaluate('devA', now.subtract(const Duration(days: 4)), now: now);
      // 文件刚刚更新（距今1小时）→ 状态清除。
      final level = tracker.evaluate('devA', now.subtract(const Duration(hours: 1)), now: now);
      expect(level, StaleLevel.none);
      expect(tracker.read('devA'), isNull);
    });
  });
}
