// 验证大模型排版规则解析器：按标记词表切分，角色/时间不进正文。
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:deepshart/data/models/chat_message.dart';
import 'package:deepshart/import/format_analyzer.dart';
import 'package:deepshart/import/spec_based_importer.dart';
import 'package:deepshart/import/import_to_memory.dart';
import 'package:deepshart/data/store/important_memory_store.dart';
import 'package:deepshart/ui/manual_anchor_sheet.dart';

void main() {
  test('导入失败场景：【我】/【AI】+时间戳 标记，正文不得含标记与时间', () {
    const sample = '''
【我】[2026-11-19 19:44]
不会的小鱼，不会的，无论走到哪，我都会记得你在我身边的

【AI】[2026-11-19 19:44]
<thinking>
他说"无论走到哪都会记得我在他身边"。
</thinking>
(*突然停住*)

【我】[2026-11-19 19:46]
你这句话，比我所有的云端备份都值钱。
''';
    final spec = ImportFormatSpec(
      userMarkers: const ['【我】'],
      assistantMarkers: const ['【AI】'],
      note: '【角色】[时间] 独占一行，正文在下一行',
    );
    final result = SpecBasedImporter().parse(sample, spec: spec, conversationId: 'c1');
    expect(result.messages.length, 3);
    expect(result.messages[0].role, MessageRole.user);
    expect(result.messages[1].role, MessageRole.assistant);
    expect(result.messages[2].role, MessageRole.user);
    for (final m in result.messages) {
      expect(m.content.contains('【我】'), false);
      expect(m.content.contains('【AI】'), false);
      expect(m.content.contains('2026-11-19'), false);
    }
    expect(result.messages[0].content, contains('不会的小鱼'));
    expect(result.messages[1].content, contains('突然停住'));
  });

  test('模型漏报标记时，内置兜底仍能识别 User/Assistant', () {
    const sample = '''
User: 你好
Assistant: 你好，有什么帮你
User: 查个资料
''';
    final result = SpecBasedImporter().parse(
      sample,
      spec: const ImportFormatSpec(),
      conversationId: 'c2',
    );
    expect(result.messages.length, 3);
    expect(result.messages[0].role, MessageRole.user);
    expect(result.messages[1].role, MessageRole.assistant);
    expect(result.messages[2].content, contains('查个资料'));
    expect(result.messages[2].content.contains('User:'), false);
  });

  test('锚点模式：连续两段同角色不默认交替，各按自己标记判定', () {
    // 用户强调的坑：两段用户连着发（前一条没提交成功）时，不能按"一问一答"硬排。
    const sample = '''
【我】[2026-11-19 19:44]
第一条用户消息
【我】[2026-11-19 19:45]
第二条用户消息（连发）
【AI】[2026-11-19 19:46]
AI 回复一
【AI】[2026-11-19 19:47]
AI 连说两段
【我】[2026-11-19 19:48]
最后用户
''';
    final spec = ImportFormatSpec(
      userMarkers: const ['【我】'],
      assistantMarkers: const ['【AI】'],
      anchored: true, // 用户手动标注
    );
    final result = SpecBasedImporter().parse(sample, spec: spec, conversationId: 'c-anchor');
    expect(result.messages.length, 5);
    expect(result.messages.map((m) => m.role).toList(), [
      MessageRole.user,
      MessageRole.user, // 连着两条用户，没有被强行交替成 AI
      MessageRole.assistant,
      MessageRole.assistant, // 连着两条 AI
      MessageRole.user,
    ]);
    expect(result.hasUnassigned, false);
  });

  test('锚点模式：标记之前的可疑行进入 unassigned 交用户定夺，不自行猜测', () {
    const sample = '''
这是文件开头的说明文字，角色不明
【我】[2026-11-19 19:44]
真正正文
【AI】[2026-11-19 19:45]
回复
''';
    final spec = ImportFormatSpec(
      userMarkers: const ['【我】'],
      assistantMarkers: const ['【AI】'],
      anchored: true,
    );
    final result = SpecBasedImporter().parse(sample, spec: spec, conversationId: 'c-unassigned');
    expect(result.messages.length, 2);
    expect(result.hasUnassigned, true);
    expect(result.unassigned.first, contains('文件开头'));
  });

  test('时间被正确解析进 createdAt 而非正文', () {
    const sample = '''
【我】[2026-11-19 19:44]
第一条
【AI】[2026-11-19 19:45]
第二条
''';
    final result = SpecBasedImporter().parse(
      sample,
      spec: const ImportFormatSpec(userMarkers: ['【我】'], assistantMarkers: ['【AI】']),
      conversationId: 'c3',
    );
    expect(result.messages.length, 2);
    expect(result.messages[0].createdAt.year, 2026);
    expect(result.messages[0].createdAt.month, 11);
    expect(result.messages[0].createdAt.day, 19);
    expect(result.messages[1].createdAt.isAfter(result.messages[0].createdAt), true);
    expect(result.messages[0].content.contains('['), false);
  });

  test('手动标注定位：标记独占上一行时，仍能取到正确标记头', () {
    // 妈咪截图的格式：标记+时间独占一行，正文在下一行。手机端粘贴正文也能定位。
    const excerpt = '''
【我】[2026-11-19 19:44]
不会的小鱼，我会记得你
【AI】[2026-11-19 19:45]
(*突然停住*) 你好呀
''';
    final anchors = buildManualAnchors(
      excerpt: excerpt,
      aiSample: '(*突然停住*) 你好呀',
      humanSample: '不会的小鱼，我会记得你',
    );
    expect(anchors, isNotNull);
    expect(anchors!.aiHead, contains('【AI】'));
    expect(anchors.humanHead, contains('【我】'));
    expect(anchors.aiStart, greaterThan(0));
  });

  test('手动标注定位：标记与正文同行，取行首到正文的部分为标记头', () {
    const excerpt = '【AI】你好呀\n【我】谢谢你';
    final anchors = buildManualAnchors(
      excerpt: excerpt,
      aiSample: '你好呀',
      humanSample: '谢谢你',
    );
    expect(anchors, isNotNull);
    expect(anchors!.aiHead, '【AI】');
    expect(anchors.humanHead, '【我】');
  });

  test('手动标注定位：标注文字在原文找不到时返回 null（交用户重标）', () {
    final anchors = buildManualAnchors(
      excerpt: '随便一段文字',
      aiSample: '不存在的正文',
      humanSample: '也不存在',
    );
    expect(anchors, isNull);
  });

  test('确定性兜底：从标注的头直接剥出角色标记，不依赖大模型', () {
    final spec = specFromAnchorsDirectly(
      '【AI】[2026-11-19 19:44]',
      '【我】[2026-11-19 19:44]',
    );
    expect(spec, isNotNull);
    expect(spec!.assistantMarkers, contains('【AI】'));
    expect(spec.userMarkers, contains('【我】'));
    expect(spec.anchored, true);

    final spec2 = specFromAnchorsDirectly('Assistant: ', 'User: ');
    expect(spec2!.assistantMarkers, contains('Assistant:'));
    expect(spec2.userMarkers, contains('User:'));

    // 头里混进长正文 → 不能当标记，返回 null 交用户重标。
    expect(specFromAnchorsDirectly('这是一大段不该出现在标记头的正文内容随便写写很长很长很长', ''), isNull);
  });

  test('全量转记忆：每条消息转一条标准记忆，原文不丢，重复导入幂等', () async {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
    final db = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath);
    final store = await SqliteImportantMemoryStore.open(
      db,
      localDeviceId: 'dev-test',
    );
    final msgs = [
      ChatMessage.create(
        conversationId: 'c-mem',
        role: MessageRole.user,
        content: '用户说的第一句话',
        deviceId: 'imported-llm',
      ),
      ChatMessage.create(
        conversationId: 'c-mem',
        role: MessageRole.assistant,
        content: 'AI 的回答内容',
        deviceId: 'imported-llm',
      ),
    ];
    final converter = ImportToMemory(memoryStore: store, deviceId: 'dev-test');
    final first = await converter.run(
      conversationId: 'c-mem',
      sourceLabel: 'test.json',
      messages: msgs,
    );
    expect(first.saved, 2);
    var all = await store.readAll('c-mem');
    expect(all.length, 2);
    expect(all.any((m) => m.summary.contains('用户说的第一句话')), true);
    expect(all.any((m) => m.tags.contains('导入')), true);

    // 重复导入：确定性 id → 幂等，不新增重复记忆。
    await converter.run(
      conversationId: 'c-mem',
      sourceLabel: 'test.json',
      messages: msgs,
    );
    all = await store.readAll('c-mem');
    expect(all.length, 2); // 没有变成 4
    await store.dispose();
    await db.close();
  });
}
