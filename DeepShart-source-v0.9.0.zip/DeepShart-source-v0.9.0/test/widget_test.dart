// target: test/widget_test.dart
// 职责：单元测试——验证作者标注、应用品牌信息与 CRDT 向量时钟的并发判定逻辑。

import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:dio/dio.dart';

import 'package:deepshart/ai/ai_provider.dart';
import 'package:deepshart/ai/deepseek_provider.dart';
import 'package:deepshart/core/app_info.dart';
import 'package:deepshart/data/models/chat_message.dart';
import 'package:deepshart/data/models/conversation_settings.dart';
import 'package:deepshart/data/models/session_summary.dart';
import 'package:deepshart/data/store/conversation_store.dart';
import 'package:deepshart/export/conversation_exporter.dart';
import 'package:deepshart/import/deepseek_json_importer.dart';
import 'package:deepshart/state/chat_controller.dart';
import 'package:deepshart/sync/sync_engine.dart';

void main() {
  test('作者标注与品牌信息', () {
    expect(AppInfo.author, 'Made by Muxi');
    expect(AppInfo.name, 'DeepShart');
  });

  group('VectorClock 并发判定', () {
    test('同源递增形成因果支配，不算并发', () {
      final a = VectorClock.empty().tick('devA');
      final b = a.tick('devA');
      expect(b.compare(a), ClockRelation.after);
      expect(a.compare(b), ClockRelation.before);
    });

    test('两设备各自修改产生并发', () {
      final base = VectorClock.empty().tick('devA');
      final a = base.tick('devA');
      final b = base.tick('devB');
      expect(a.compare(b), ClockRelation.concurrent);
    });

    test('摘要稳定（按设备排序）', () {
      final c = VectorClock.empty().tick('devB').tick('devA');
      expect(c.digest(), 'devA:1|devB:1');
    });
  });

  group('会话设置', () {
    test('temperature 语义标签分档', () {
      expect(ConversationSettings.forNew('c').copyWith(temperature: 0.2).temperatureLabel,
          contains('严谨'));
      expect(ConversationSettings.forNew('c').copyWith(temperature: 1.0).temperatureLabel,
          contains('发散'));
      expect(ConversationSettings.forNew('c').copyWith(temperature: 1.8).temperatureLabel,
          contains('高随机性'));
    });

    test('默认值为 1.0 且压缩阈值 80%', () {
      final s = ConversationSettings.forNew('c');
      expect(s.temperature, 1.0);
      expect(s.compressionThreshold, 0.8);
      expect(s.keepRecentCount, 6);
    });

    test('角色提示词可清空', () {
      final s = ConversationSettings.forNew('c').copyWith(systemPrompt: '你是助手');
      expect(s.systemPrompt, '你是助手');
      expect(s.copyWith(clearSystemPrompt: true).systemPrompt, isNull);
    });

    test('深度思考强度三档与 wire 值映射', () {
      final s = ConversationSettings.forNew('c');
      expect(s.thinkingEffort, 1);
      expect(s.reasoningEffort, 'high');
      expect(s.copyWith(thinkingEffort: 0).reasoningEffort, 'low');
      expect(s.copyWith(thinkingEffort: 2).reasoningEffort, 'max');
      // 超出范围时收敛到合法档位，不把非法值发给服务端
      expect(s.copyWith(thinkingEffort: 9).reasoningEffort, 'max');
    });

    test('深度思考强度可序列化往返', () {
      final s = ConversationSettings.forNew('c').copyWith(thinkingEffort: 2);
      expect(ConversationSettings.fromJson(s.toJson()).thinkingEffort, 2);
    });
  });

  test('摘要序列化往返', () {
    final s = SessionSummary.create(
      conversationId: 'c1',
      summaryText: '讨论 P2P',
      sourceMessageCount: 10,
      deviceId: 'devA',
    );
    final decoded = SessionSummary.fromJson(s.toJson());
    expect(decoded.summaryText, '讨论 P2P');
    expect(decoded.sourceMessageCount, 10);
    expect(decoded.versionVector, s.versionVector);
  });

  test('上下文压缩标记包裹', () {
    final wrapped = CompressionMarkers.wrap('摘要内容');
    expect(wrapped, contains(CompressionMarkers.openTag));
    expect(wrapped, contains('摘要内容'));
    expect(wrapped, contains('系统自动生成'));
  });

  group('DeepSeek 请求参数映射', () {
    const msg = [AiMessage(role: 'user', content: 'hi')];

    test('联网搜索工具格式为新版 deepseek_web_search（否则 422）', () {
      final body = DeepSeekProvider.buildRequestBody(
        'deepseek-flash',
        msg,
        const AiRequestOptions(searchEnabled: true),
      );
      final tools = body['tools'] as List;
      expect(tools, hasLength(1));
      expect((tools.first as Map)['type'], 'deepseek_web_search');
      // 不应出现旧版的嵌套字段
      expect((tools.first as Map).containsKey('web_search'), isFalse);
    });

    test('未开启搜索时不带 tools', () {
      final body = DeepSeekProvider.buildRequestBody(
        'deepseek-flash',
        msg,
        const AiRequestOptions(),
      );
      expect(body.containsKey('tools'), isFalse);
    });

    test('思考模式开启时不发送 temperature', () {
      final body = DeepSeekProvider.buildRequestBody(
        'deepseek-flash',
        msg,
        const AiRequestOptions(thinkingEnabled: true, temperature: 0.7),
      );
      expect(body['thinking'], {'type': 'enabled'});
      expect(body.containsKey('temperature'), isFalse);
    });

    test('思考强度作为 reasoning_effort 下发（low/high/max）', () {
      String effortOf(String value) => DeepSeekProvider.buildRequestBody(
            'deepseek-flash',
            msg,
            AiRequestOptions(thinkingEnabled: true, reasoningEffort: value),
          )['reasoning_effort'] as String;

      expect(effortOf('low'), 'low');
      expect(effortOf('max'), 'max');
      // 非法值回落到 high，避免服务端 400
      expect(effortOf('medium'), 'high');
      expect(effortOf(''), 'high');
    });

    test('关闭思考时不发送 reasoning_effort', () {
      final body = DeepSeekProvider.buildRequestBody(
        'deepseek-flash',
        msg,
        const AiRequestOptions(thinkingEnabled: false, reasoningEffort: 'max'),
      );
      expect(body.containsKey('reasoning_effort'), isFalse);
    });

    test('联网搜索 + 深度思考组合合法', () {
      final body = DeepSeekProvider.buildRequestBody(
        'deepseek-flash',
        msg,
        const AiRequestOptions(searchEnabled: true, thinkingEnabled: true),
      );
      expect(body['thinking'], {'type': 'enabled'});
      expect((body['tools'] as List).first, {'type': 'deepseek_web_search'});
    });

    test('附件内容块 file_id 必须在顶层（官方格式，嵌套会 400）', () {      final body = DeepSeekProvider.buildRequestBody(
        'deepseek-flash',
        const [
          AiMessage(role: 'user', content: '看图', fileIds: ['file-api-abc']),
        ],
        const AiRequestOptions(),
      );
      final content = ((body['messages'] as List).first as Map)['content'] as List;
      final fileBlock = content.firstWhere((e) => (e as Map)['type'] == 'file') as Map;
      expect(fileBlock['file_id'], 'file-api-abc');
      // 不能包一层 file 对象
      expect(fileBlock.containsKey('file'), isFalse);
    });

    test('角色提示词在最后一条消息前再注入一次（长对话仍生效）', () {
      final body = DeepSeekProvider.buildRequestBody(
        'deepseek-flash',
        const [
          AiMessage(role: 'user', content: '你好'),
          AiMessage(role: 'assistant', content: '我是 AI 助手'),
          AiMessage(role: 'user', content: '你的物种是什么'),
        ],
        const AiRequestOptions(systemPrompt: '你的物种是鲨鱼。'),
      );
      final messages = (body['messages'] as List).cast<Map<String, dynamic>>();
      expect(messages.first['role'], 'system');
      expect(messages.first['content'], '你的物种是鲨鱼。');
      // 最后一条必须还是用户问题，倒数第二条是加固后的设定
      expect(messages.last['content'], '你的物种是什么');
      expect(messages[messages.length - 2]['role'], 'system');
      expect(messages[messages.length - 2]['content'], contains('鲨鱼'));
    });

    test('没有角色提示词时不会凭空插入 system 消息', () {
      final body = DeepSeekProvider.buildRequestBody(
        'deepseek-flash',
        const [
          AiMessage(role: 'user', content: 'hi'),
          AiMessage(role: 'assistant', content: 'hello'),
          AiMessage(role: 'user', content: 'again'),
        ],
        const AiRequestOptions(),
      );
      final messages = (body['messages'] as List).cast<Map<String, dynamic>>();
      expect(messages.where((m) => m['role'] == 'system'), isEmpty);
    });
  });

  group('导入 JSON 结构容错', () {
    final importer = DeepSeekJsonImporter();

    String convJson({int n = 2}) => '''
{
  "id": "conv-obj",
  "title": "对象形态",
  "messages": [
    ${List.generate(n, (i) => '{"role":"${i.isEven ? 'user' : 'assistant'}","content":"m$i","inserted_at":"2026-11-18T09:0$i:00Z"}').join(',')}
  ]
}''';

    test('裸对象形态（真实导出常见）可解析', () {
      final r = importer.parse(convJson());
      expect(r.conversationId, 'conv-obj');
      expect(r.title, '对象形态');
      expect(r.messages, hasLength(2));
    });

    test('顶层数组仍可解析', () {
      final r = importer.parse('[${convJson()}]');
      expect(r.messages, hasLength(2));
    });

    test('套一层 data 容器可解析', () {
      final r = importer.parse('{"data":[${convJson()}]}');
      expect(r.messages, hasLength(2));
    });

    test('带 UTF-8 BOM 可解析', () {
      final r = importer.parse('\uFEFF${convJson()}');
      expect(r.messages, hasLength(2));
    });

    test('空文件报错说明是空的', () {
      expect(
        () => importer.parse('   '),
        throwsA(predicate((e) => e is FormatException && e.message.contains('空'))),
      );
    });

    test('非 JSON 报错说明不是合法 JSON', () {
      expect(
        () => importer.parse('这不是 json'),
        throwsA(predicate((e) => e is FormatException && e.message.contains('不是合法的 JSON'))),
      );
    });

    test('找不到 messages 时说明实际顶层是什么', () {
      expect(
        () => importer.parse('{"foo":1,"bar":2}'),
        throwsA(predicate(
            (e) => e is FormatException && e.message.contains('找不到 messages'))),
      );
    });

    test('真实导出的 fragments 结构能取到正文（曾整份导入成空白气泡）', () {
      const real = '''
{
  "id": "conv-frag",
  "title": "测试会话",
  "messages": [
    {"id": 1, "role": "USER", "inserted_at": "2025-11-13T14:27:36.275Z",
     "fragments": [{"type": "REQUEST", "content": "我是谁"}]},
    {"id": 2, "role": "ASSISTANT", "inserted_at": "2025-11-13T14:27:36.285Z",
     "fragments": [
       {"type": "THINK", "content": "先想想"},
       {"type": "RESPONSE", "content": "你是鲸鱼"}
     ]}
  ]
}''';
      final r = importer.parse(real);
      expect(r.messages, hasLength(2));
      expect(r.messages[0].role, MessageRole.user);
      expect(r.messages[0].content, '我是谁');
      expect(r.messages[1].role, MessageRole.assistant);
      // 思考与正文都要保留，UI 才有内容可分区渲染
      expect(r.messages[1].content, contains('<thinking>'));
      expect(r.messages[1].content, contains('先想想'));
      expect(r.messages[1].content, contains('你是鲸鱼'));
      expect(r.skippedEmpty, 0);
      // 角色明确时不应该再报"部分角色需人工确认"
      expect(r.needsConfirmation, isFalse);
    });

    test('角色无法识别时按片段猜角色并请求确认', () {
      const raw = '''
{"id":"c2","messages":[
  {"role":"narrator","content":"旁白：潮水退去","inserted_at":"2026-11-18T09:00:00Z"}
]}''';
      final r = importer.parse(raw);
      expect(r.messages, hasLength(1));
      expect(r.needsConfirmation, isTrue);
      expect(r.confirmationRequest!.segments, hasLength(1));
      final fixed = importer.buildConfirmedMessages(
        r,
        roleOverrides: {0: MessageRole.assistant},
      );
      expect(fixed.single.role, MessageRole.assistant);
    });

    test('完全没有正文的记录被跳过而不是导入空气泡', () {
      const raw = '''
{"id":"c3","messages":[
  {"role":"user","inserted_at":"2026-11-18T09:00:00Z"},
  {"role":"user","content":"有内容","inserted_at":"2026-11-18T09:01:00Z"}
]}''';
      final r = importer.parse(raw);
      expect(r.messages, hasLength(1));
      expect(r.skippedEmpty, 1);
    });
  });

  group('网络错误中文映射', () {
    test('DNS 失败给出网络排查指引而非英文异常', () {
      final msg = ChatController.friendlyError(
        Exception("Failed host lookup: 'api.deepseek.com' (OS Error: No address associated with hostname, errno = 7)"),
      );
      expect(msg, contains('网络无法连接'));
      expect(msg, contains('api.deepseek.com'));
      expect(msg, isNot(contains('DioException')));
    });

    test('401 提示 Key 无效', () {
      expect(ChatController.friendlyError(Exception('401 Unauthorized')), contains('API Key'));
    });

    test('超时提示网络', () {
      expect(ChatController.friendlyError(Exception('connection timed out')), contains('超时'));
    });

    test('400 提示附件类型而非原始 Dio 异常', () {
      final msg = ChatController.friendlyError(
        Exception('DioException [bad response]: status code of 400'),
      );
      expect(msg, contains('附件'));
      expect(msg, isNot(contains('DioException')));
    });

    test('图片不被模型支持 → 中文可操作提示（V4 Pro 实测 400）', () {
      final dioErr = DioException(
        requestOptions: RequestOptions(path: '/chat/completions'),
        response: Response(
          requestOptions: RequestOptions(path: '/chat/completions'),
          statusCode: 400,
          data: {
            'error': {
              'message':
                  "messages[52].content[1].images are not supported by this model (request id: abc)",
            },
          },
        ),
      );
      final msg = ChatController.friendlyError(dioErr);
      expect(msg, contains('不支持识别图片'));
      expect(msg, contains('新对话'));
      expect(msg, isNot(contains('images are not supported')));
    });

    test('无效模型名 → 中文提示换模型', () {
      final dioErr = DioException(
        requestOptions: RequestOptions(path: '/chat/completions'),
        response: Response(
          requestOptions: RequestOptions(path: '/chat/completions'),
          statusCode: 400,
          data: {
            'error': {
              'message':
                  'The supported API model names are deepseek-flash, deepseek-v4-pro, but you passed deepseek-pro.',
            },
          },
        ),
      );
      final msg = ChatController.friendlyError(dioErr);
      expect(msg, contains('模型'));
      expect(msg, contains('设置'));
      expect(msg, isNot(contains('supported API model names')));
    });
  });

  group('文件上传 purpose 选择', () {
    String purposeFor(String path) {
      final ext = path.split('.').last.toLowerCase();
      const imageExts = {'jpg', 'jpeg', 'png', 'gif', 'webp'};
      const docExts = {'pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx'};
      return imageExts.contains(ext)
          ? 'user_data'
          : docExts.contains(ext)
              ? 'text_recognition'
              : 'user_data';
    }

    test('图片用 user_data', () {
      expect(purposeFor('photo.png'), 'user_data');
      expect(purposeFor('a.JPG'), 'user_data');
    });

    test('文档用 text_recognition（否则 400）', () {
      expect(purposeFor('report.pdf'), 'text_recognition');
      expect(purposeFor('slides.pptx'), 'text_recognition');
    });

    test('文本用 user_data', () {
      expect(purposeFor('notes.txt'), 'user_data');
    });
  });
  group('对话导出', () {
    final conv = Conversation(
      id: 'conv-1',
      title: '测试会话',
      createdAt: DateTime.utc(2026, 11, 18, 9),
      updatedAt: DateTime.utc(2026, 11, 18, 10),
    );
    final messages = <ChatMessage>[
      ChatMessage.create(
        conversationId: 'conv-1',
        role: MessageRole.user,
        content: '你好',
        deviceId: 'devA',
      ),
      ChatMessage.create(
        conversationId: 'conv-1',
        role: MessageRole.assistant,
        content: '<thinking>\n先分析问题\n</thinking>\n这是回答',
        deviceId: 'devA',
      ),
    ];

    test('剥离思考段', () {
      expect(ConversationExporter.stripThinking('<thinking>a\nb</thinking>正文'), '正文');
      expect(
        ConversationExporter.extractThinking('<thinking>a\nb</thinking>正文'),
        'a\nb',
      );
    });

    test('JSON 导出可被导入器回读（闭环）', () {
      final json = ConversationExporter.render(
        conversation: conv,
        messages: messages,
        format: ExportFormat.json,
      );
      final parsed = DeepSeekJsonImporter().parse(json);
      expect(parsed.conversationId, 'conv-1');
      expect(parsed.title, '测试会话');
      expect(parsed.messages.length, 2);
      expect(parsed.messages.first.content, '你好');
    });

    test('关闭思考后 JSON 不再出现 thinking 段', () {
      final json = ConversationExporter.render(
        conversation: conv,
        messages: messages,
        format: ExportFormat.json,
        options: const ExportOptions(includeThinking: false),
      );
      expect(json.contains('<thinking>'), isFalse);
      expect(json.contains('这是回答'), isTrue);
    });

    test('Markdown 含标题与角色分段', () {
      final md = ConversationExporter.render(
        conversation: conv,
        messages: messages,
        format: ExportFormat.markdown,
      );
      expect(md.contains('# 测试会话'), isTrue);
      expect(md.contains('## 我'), isTrue);
      expect(md.contains('## AI'), isTrue);
      expect(md.contains('思考过程'), isTrue);
    });

    test('HTML 转义尖括号，避免内容被当标签', () {
      final html = ConversationExporter.render(
        conversation: conv,
        messages: messages,
        format: ExportFormat.html,
        options: const ExportOptions(includeThinking: false),
      );
      expect(html.contains('<!DOCTYPE html>'), isTrue);
      // 正文里若含 <script> 必须被转义
      final evil = ConversationExporter.render(
        conversation: conv,
        messages: [
          ChatMessage.create(
            conversationId: 'conv-1',
            role: MessageRole.user,
            content: '<script>alert(1)</script>',
            deviceId: 'devA',
          ),
        ],
        format: ExportFormat.html,
      );
      expect(evil.contains('<script>alert(1)</script>'), isFalse);
      expect(evil.contains('&lt;script&gt;'), isTrue);
    });

    test('纯文本含角色标签', () {
      final txt = ConversationExporter.render(
        conversation: conv,
        messages: messages,
        format: ExportFormat.text,
      );
      expect(txt.contains('【我】'), isTrue);
      expect(txt.contains('【AI】'), isTrue);
    });

    test('建议文件名含扩展名且无非法字符', () {
      final name = ConversationExporter.suggestedFileName(
        Conversation(
          id: 'x',
          title: 'a/b:c?d',
          createdAt: DateTime.utc(2026, 1, 1),
          updatedAt: DateTime.utc(2026, 1, 1),
        ),
        ExportFormat.markdown,
      );
      expect(name.endsWith('.md'), isTrue);
      expect(name.contains('/'), isFalse);
      expect(name.contains(':'), isFalse);
    });
  });

  group('会话设置真实落库', () {
    test('保存后能读回角色提示词与思考强度（Windows 端曾怀疑没存进去）', () async {
      sqfliteFfiInit();
      final db = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath);
      final store = await SqliteConversationStore.open(db);

      await store.saveSettings(ConversationSettings.forNew('c1').copyWith(
        systemPrompt: '你的物种是鲨鱼',
        thinkingEffort: 2,
        updatedAt: DateTime.now().toUtc(),
      ));

      final read = await store.getSettings('c1');
      expect(read.systemPrompt, '你的物种是鲨鱼');
      expect(read.thinkingEffort, 2);
      expect(read.reasoningEffort, 'max');

      await store.dispose();
      await db.close();
    });
  });

  _chunkTests();
}

// 分片函数必须保证：不丢、不重、每片不超限。
void _chunkTests() {
  group('同步分片', () {
    test('大列表被切成多片且顺序完整', () {
      final items = List<int>.generate(1000, (i) => i);
      final chunks = chunkByEstimatedSize<int>(
        items,
        (_) => 500,
        maxChars: 10000,
      );
      expect(chunks.length, greaterThan(1));
      for (final chunk in chunks) {
        expect(chunk.length * 500, lessThanOrEqualTo(10000));
      }
      expect(chunks.expand((c) => c).toList(), items);
    });

    test('单条超限也不会死循环（至少能发出去）', () {
      final chunks = chunkByEstimatedSize<int>([1, 2], (_) => 999999, maxChars: 1000);
      expect(chunks.length, 2);
    });
  });
}
