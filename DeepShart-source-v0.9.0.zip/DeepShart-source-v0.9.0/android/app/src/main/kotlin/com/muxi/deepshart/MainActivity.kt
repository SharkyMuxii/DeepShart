package com.muxi.deepshart

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
