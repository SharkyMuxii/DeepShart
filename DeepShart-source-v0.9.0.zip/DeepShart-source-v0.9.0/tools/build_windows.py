# target: tools/build_windows.py
# 职责：一键构建可运行的 Windows 版本——处理符号链接、libwebrtc 下载、编码补丁与运行时依赖复制。
#
# 背景（为什么需要这个脚本）：
# 1) 本机未开 Developer Mode，Flutter 无法用 symlink 链接插件 → 改用目录 junction。
# 2) flutter_webrtc 需从 GitHub 下载 libwebrtc，国内网络不通 → 走 ghproxy 镜像。
# 3) 中文代码页(936)下 MSVC 把插件源码里的 UTF-8 字符判为 C4819 错误 → 打 /utf-8 补丁。
# 4) VS 2026 Insiders 的 INSTALL 步骤想把文件写到 C:/Program Files（需管理员）→ 手动复制依赖。

import json
import os
import re
import shutil
import subprocess
import sys
import urllib.request
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FLUTTER = r"C:\flutter\flutter\bin\flutter.bat"
CMAKE = r"E:\CodingEnviroment\VSC\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe"
DEPS_FILE = os.path.join(ROOT, ".flutter-plugins-dependencies")
MIRROR = "https://ghproxy.net/https://github.com/"


def run(cmd, **kw):
    print(">>>", " ".join(cmd))
    return subprocess.run(cmd, cwd=ROOT, **kw)


def ensure_plugin_junctions():
    """用目录 junction 预建插件链接，绕开 Developer Mode 限制。"""
    if not os.path.exists(DEPS_FILE):
        print("跳过 junction：先运行 flutter pub get")
        return
    with open(DEPS_FILE, encoding="utf-8") as f:
        deps = json.load(f)
    linkdir = os.path.join(ROOT, "windows", "flutter", "ephemeral", ".plugin_symlinks")
    os.makedirs(linkdir, exist_ok=True)
    for p in deps.get("plugins", {}).get("windows", []):
        link = os.path.join(linkdir, p["name"])
        if os.path.exists(link):
            continue
        src = p["path"].rstrip("\\/")
        subprocess.run(["cmd", "/c", "mklink", "/J", link, src], check=False)


def ensure_libwebrtc():
    """下载并解压 libwebrtc 预编译库。"""
    base = os.path.join(ROOT, "windows", "flutter", "ephemeral", ".plugin_symlinks", "flutter_webrtc", "third_party")
    ini = os.path.join(base, "libwebrtc_version.ini")
    if not os.path.exists(ini):
        print("跳过 libwebrtc：flutter_webrtc 插件未就绪")
        return
    version = None
    for line in open(ini, encoding="utf-8"):
        if line.strip().startswith("binary_version"):
            version = line.split("=", 1)[1].strip()
    libdir = os.path.join(base, "libwebrtc")
    if os.path.isdir(libdir):
        print("libwebrtc 已存在，跳过下载")
        return
    os.makedirs(os.path.join(base, "downloads"), exist_ok=True)
    asset = "libwebrtc-win-x64-release.zip"
    url = MIRROR + f"webrtc-sdk/libwebrtc/releases/download/{version}/{asset}"
    zpath = os.path.join(base, "downloads", asset)
    print("下载 libwebrtc:", url)
    urllib.request.urlretrieve(url, zpath)
    with zipfile.ZipFile(zpath) as zf:
        zf.extractall(os.path.join(base, ".extract_tmp"))
    # 规范化：把 zip 里的单层目录提升为 libwebrtc/
    tmp = os.path.join(base, ".extract_tmp")
    entries = os.listdir(tmp)
    src = os.path.join(tmp, entries[0]) if len(entries) == 1 else tmp
    shutil.move(src, libdir)
    shutil.rmtree(tmp, ignore_errors=True)


def patch_encoding():
    """给 flutter_webrtc 的 CMake 目标加 /utf-8，消除 C4819。"""
    cmakelists = os.path.join(
        ROOT, "windows", "flutter", "ephemeral", ".plugin_symlinks",
        "flutter_webrtc", "windows", "CMakeLists.txt",
    )
    if not os.path.exists(cmakelists):
        return
    text = open(cmakelists, encoding="utf-8", errors="replace").read()
    if "/utf-8" in text:
        return
    marker = "target_compile_definitions(${PLUGIN_NAME} PRIVATE FLUTTER_PLUGIN_IMPL)"
    patch = marker + "\n\nif(MSVC)\n  target_compile_options(${PLUGIN_NAME} PRIVATE /utf-8 /wd4819)\nendif()"
    text = text.replace(marker, patch, 1)
    open(cmakelists, "w", encoding="utf-8").write(text)
    print("已打 UTF-8 编码补丁")


def copy_runtime():
    """把 INSTALL 步骤该复制的运行时依赖拷到 Release 目录。"""
    root = os.path.join(ROOT, "build", "windows", "x64")
    install = os.path.join(root, "cmake_install.cmake")
    if not os.path.exists(install):
        print("未找到 cmake_install.cmake，跳过")
        return
    release = os.path.join(root, "runner", "Release")
    os.makedirs(os.path.join(release, "data"), exist_ok=True)
    pat = re.compile(r'file\(INSTALL DESTINATION "([^"]+)"[^\n]*?FILES\s+((?:"[^"]+"(?:\s+)?)+)', re.S)
    seen = set()
    for m in pat.finditer(open(install, encoding="utf-8", errors="replace").read()):
        dest, files = m.group(1), re.findall(r'"([^"]+)"', m.group(2))
        target = os.path.join(release, "data") if dest.rstrip("/").endswith("/data") else release
        for src in files:
            if "Debug" in src or "Profile" in src:
                continue
            srcn = os.path.normpath(src.replace("/", os.sep))
            if not os.path.exists(srcn) or os.path.isdir(srcn):
                continue
            dst = os.path.join(target, os.path.basename(srcn))
            if (srcn, dst) in seen or os.path.abspath(srcn) == os.path.abspath(dst):
                continue
            seen.add((srcn, dst))
            shutil.copy2(srcn, dst)
    fa = os.path.join(ROOT, "build", "flutter_assets")
    if os.path.isdir(fa):
        dstfa = os.path.join(release, "data", "flutter_assets")
        if os.path.exists(dstfa):
            shutil.rmtree(dstfa)
        shutil.copytree(fa, dstfa)
    # 复制到干净的发布目录
    dist = os.path.join(ROOT, "dist", "DeepShart-windows")
    if os.path.exists(dist):
        shutil.rmtree(dist)
    shutil.copytree(release, dist)
    print("发布目录:", dist)


def main():
    ensure_plugin_junctions()
    ensure_libwebrtc()
    patch_encoding()
    # 构建；INSTALL 阶段因权限失败属预期，运行时依赖由 copy_runtime 补齐
    run([FLUTTER, "build", "windows", "--release"])
    copy_runtime()
    print("\n完成！运行: dist\\DeepShart-windows\\deepshart.exe")


if __name__ == "__main__":
    main()
