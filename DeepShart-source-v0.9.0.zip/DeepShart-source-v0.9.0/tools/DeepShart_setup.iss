; Inno Setup 脚本 —— DeepShart Windows 安装包
; 用户可选择安装位置（默认 Program Files\DeepShart，可改）。
; 编译：ISCC.exe tools\DeepShart_setup.iss
; 输出：dist\DeepShart-Setup.exe

#define MyAppName "DeepShart"
#define MyAppVersion "0.9.0"
#define MyAppPublisher "Muxi"
#define MyAppExeName "deepshart.exe"
#define MyAppURL "https://platform.deepseek.com"

[Setup]
; 用 GUID 保证升级/卸载时能识别到同一应用
AppId={{A7E4B3C1-5D62-4E8F-9B1A-2F3C4D5E6F70}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppUpdatesURL={#MyAppURL}
; 默认安装到 Program Files，但用户在"选择目标位置"页可任意修改
; 【关键】DisableDirPage 默认 auto，在 PrivilegesRequired=lowest 时会自动隐藏
; "选择安装位置"页。显式设 no，强制让用户自主选择安装路径。
DefaultDirName={autopf}\{#MyAppName}
DisableDirPage=no
DefaultGroupName={#MyAppName}
AllowNoIcons=yes
LicenseFile=
OutputDir=..\dist
OutputBaseFilename=DeepShart-Setup
SetupIconFile=..\DeepShart.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
; 允许普通用户安装到自己的目录（不强制管理员）
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
; 本机 Inno Setup 未附带中文语言包，使用内置英文（安装步骤仅 Next/Install/Finish）。
; 如需中文界面，把 ChineseSimplified.isl 放到本目录并取消下面这行注释：
; Name: "chinesesimplified"; MessagesFile: "ChineseSimplified.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
; 默认创建桌面快捷方式（用户要求）——去掉 unchecked 即为默认勾选。
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"

[Files]
; 主程序与全部运行时依赖（从 dist\DeepShart-windows 打包）
Source: "..\dist\DeepShart-windows\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\dist\DeepShart-windows\flutter_windows.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\dist\DeepShart-windows\file_selector_windows_plugin.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\dist\DeepShart-windows\flutter_webrtc_plugin.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\dist\DeepShart-windows\libwebrtc.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\dist\DeepShart-windows\url_launcher_windows_plugin.dll"; DestDir: "{app}"; Flags: ignoreversion
; data 目录含 app.so / icudtl.dat / flutter_assets（教程图片、字体资源都在这里）
; 【隐私红线】Excludes 主动排除任何对话数据库/备份，即便误放进 data 也不会被打进安装包。
Source: "..\dist\DeepShart-windows\data\*"; DestDir: "{app}\data"; Flags: ignoreversion recursesubdirs createallsubdirs; Excludes: "*.db,*.db-*,*.sqlite,*.sqlite3,*backups*"

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent
