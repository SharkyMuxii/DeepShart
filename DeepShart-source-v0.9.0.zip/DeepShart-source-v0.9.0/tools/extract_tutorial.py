"""把教程 docx 拆成「文字段落 + 图片」序列，图片导出到 assets/tutorial/。

用法：python tools/extract_tutorial.py <docx> <out_dir> <out_txt>
输出每一行形如：
  T|<段落文字>
  I|<图片相对路径>
"""
import os
import re
import shutil
import sys
import zipfile


def main() -> None:
    docx_path, out_dir, out_txt = sys.argv[1], sys.argv[2], sys.argv[3]
    os.makedirs(out_dir, exist_ok=True)

    with zipfile.ZipFile(docx_path) as z:
        names = z.namelist()
        media = [n for n in names if n.startswith("word/media/")]
        # 关系 id -> media 路径
        rels = {}
        if "word/_rels/document.xml.rels" in names:
            rel_xml = z.read("word/_rels/document.xml.rels").decode("utf-8", "ignore")
            for m in re.finditer(
                r'Id="([^"]+)"[^>]*Target="([^"]+)"', rel_xml
            ):
                rid, target = m.group(1), m.group(2)
                if "media/" in target:
                    rels[rid] = "word/" + target.split("media/")[-1].join(["media/", ""])

        # 按文档顺序导出图片，并建立原文件名 -> 新文件名
        ordered = []
        for path in media:
            ext = os.path.splitext(path)[1].lower() or ".png"
            new_name = f"tutorial_{len(ordered) + 1:02d}{ext}"
            with z.open(path) as src, open(os.path.join(out_dir, new_name), "wb") as dst:
                shutil.copyfileobj(src, dst)
            ordered.append((path, new_name))
        media_map = {path.split("media/")[-1]: new for path, new in ordered}

        doc = z.read("word/document.xml").decode("utf-8", "ignore")

    # 段落级切分：每个 <w:p> 是一段
    paragraphs = re.findall(r"<w:p[ >].*?</w:p>", doc, flags=re.S)
    lines = []
    for para in paragraphs:
        texts = re.findall(r"<w:t[^>]*>(.*?)</w:t>", para, flags=re.S)
        text = "".join(texts)
        text = (
            text.replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", '"')
            .replace("&apos;", "'")
        ).strip()

        embeds = re.findall(r'r:embed="([^"]+)"', para)
        if embeds:
            for rid in embeds:
                target = rels.get(rid)
                if target:
                    key = target.split("media/")[-1]
                    if key in media_map:
                        lines.append(f"I|{media_map[key]}")
        if text:
            lines.append(f"T|{text}")

    with open(out_txt, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print(f"paragraphs={len(paragraphs)} lines={len(lines)} images={len(ordered)}")


if __name__ == "__main__":
    main()
