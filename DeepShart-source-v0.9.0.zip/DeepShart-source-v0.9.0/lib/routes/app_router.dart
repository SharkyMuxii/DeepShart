// target: lib/routes/app_router.dart
// 职责：用 go_router 配置命名路由与平台分支；Windows 走 NavigationRail 外壳，Android 走 Drawer 外壳。

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../ui/android_shell.dart';
import '../ui/windows_shell.dart';

/// 路由路径常量，避免各外壳里硬编码字符串。
abstract final class AppRoutes {
  static const String home = '/';
  static const String conversation = '/conversation/:id';
}

/// 是否使用 Windows 宽屏外壳。Android 一律使用移动外壳。
bool get useDesktopShell => Platform.isWindows || Platform.isLinux || Platform.isMacOS;

GoRouter createRouter() => GoRouter(
      initialLocation: AppRoutes.home,
      debugLogDiagnostics: false,
      routes: [
        // 外壳自行管理会话选择与 ChatScreen 渲染；这里只保留一个占位子路由。
        ShellRoute(
          builder: (context, state, child) {
            return useDesktopShell
                ? const WindowsShell()
                : const AndroidShell();
          },
          routes: [
            GoRoute(
              path: AppRoutes.home,
              builder: (context, state) => const SizedBox.shrink(),
            ),
          ],
        ),
      ],
      errorBuilder: (context, state) => Scaffold(
        body: Center(child: Text('页面未找到: ${state.uri}')),
      ),
    );
