// target: lib/export/batch_export.dart
// 职责：把用户多选的多个会话批量导出为【单个 JSON 文件】。
// 复用 ConversationExporter 的 JSON 渲染（对齐 DeepSeek 导入结构），
// 每个会话一个对象，整体是一个数组——导出后仍可被本应用再次导入。

import 'dart:convert';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/models/chat_message.dart';
import '../data/store/conversation_store.dart';
import '../state/app_providers.dart';
import 'conversation_exporter.dart';

/// 批量导出：返回可直接写盘的 UTF-8 字节；[count] 为实际导出的会话数。
({Uint8List bytes, int count}) renderBatchExport({
  required List<Conversation> conversations,
  required Map<String, List<ChatMessage>> messagesByConv,
}) {
  final items = <dynamic>[];
  for (final conv in conversations) {
    final msgs = messagesByConv[conv.id] ?? const <ChatMessage>[];
    final rendered = ConversationExporter.render(
      conversation: conv,
      messages: msgs,
      format: ExportFormat.json,
    );
    // render 返回单个会话的 JSON（顶层数组）；合并进总数组。
    final decoded = jsonDecode(rendered);
    if (decoded is List) {
      items.addAll(decoded);
    } else {
      items.add(decoded);
    }
  }
  final text = const JsonEncoder.withIndent('  ').convert(items);
  return (bytes: Uint8List.fromList(utf8.encode(text)), count: items.length);
}

/// 把批量导出结果写到用户选的位置。返回保存路径；用户取消返回 null。
/// 桌面端 saveFile 会弹保存对话框；移动端部分文件管理器不支持 custom MIME，
/// 故失败时退化为 FileType.any 再试一次。
/// 给定一组会话 id，读取消息、渲染并保存为一个 JSON 文件。
/// 返回 (导出会话数, 保存路径)；用户取消保存时路径为 null。
Future<({int count, String? path})> exportConversationsByIds(
  WidgetRef ref,
  Set<String> ids,
) async {
  final convStore = await ref.read(conversationStoreProvider.future);
  final msgStore = await ref.read(messageStoreProvider.future);
  final chosen = <Conversation>[];
  for (final id in ids) {
    final c = await convStore.get(id);
    if (c != null) chosen.add(c);
  }
  final typed = <String, List<ChatMessage>>{
    for (final c in chosen) c.id: await msgStore.readAll(c.id),
  };
  final result = renderBatchExport(conversations: chosen, messagesByConv: typed);
  final path = await saveBatchExport(result.bytes);
  return (count: chosen.length, path: path);
}

Future<String?> saveBatchExport(Uint8List bytes) async {
  const name = 'deepshart-conversations.json';
  try {
    return await FilePicker.platform.saveFile(
      dialogTitle: '导出所选会话',
      fileName: name,
      type: FileType.custom,
      allowedExtensions: const <String>['json'],
      bytes: bytes,
    );
  } catch (_) {
    return await FilePicker.platform.saveFile(
      dialogTitle: '导出所选会话',
      fileName: name,
      type: FileType.any,
      bytes: bytes,
    );
  }
}
