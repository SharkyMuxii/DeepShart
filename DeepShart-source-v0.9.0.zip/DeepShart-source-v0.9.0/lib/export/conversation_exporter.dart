// target: lib/export/conversation_exporter.dart
// 职责：把单个会话的消息渲染成用户选定的导出格式（JSON / Markdown / 纯文本 / HTML）。
//
// 设计要点：
// 1. 纯函数、无 IO——渲染与落盘分离，便于单测断言每种格式的输出结构。
// 2. JSON 格式刻意对齐 DeepSeekJsonImporter 的解析结构（顶层数组 +
//    conversation_id/title/inserted_at/messages），保证"导出→再导入"闭环，
//    这样导出的文件既能给别的工具用，也能原样拿回来。
// 3. HTML 自带内联样式，脱离网络也能打开、可直接打印成 PDF。

import 'dart:convert';

import '../data/models/chat_message.dart';
import '../data/store/conversation_store.dart';

/// 可选导出格式。顺序即 UI 展示顺序。
enum ExportFormat {
  /// DeepSeek 兼容 JSON，可被本应用重新导入。
  json,

  /// Markdown，适合贴进笔记/文档。
  markdown,

  /// 纯文本，最通用、任何编辑器可读。
  text,

  /// 自包含 HTML，适合存档与打印。
  html,
}

extension ExportFormatInfo on ExportFormat {
  String get label => switch (this) {
        ExportFormat.json => 'JSON（可再次导入）',
        ExportFormat.markdown => 'Markdown（.md）',
        ExportFormat.text => '纯文本（.txt）',
        ExportFormat.html => '网页（.html）',
      };

  String get description => switch (this) {
        ExportFormat.json => '结构化数据，保留消息 ID 与时间，可被本应用或 DeepSeek 工具读写',
        ExportFormat.markdown => '带标题与角色分段，适合贴进笔记、文档、博客',
        ExportFormat.text => '最通用的纯文本对话记录，任何编辑器都能打开',
        ExportFormat.html => '单文件网页，自带排版，可离线打开或打印为 PDF',
      };

  String get extension => switch (this) {
        ExportFormat.json => 'json',
        ExportFormat.markdown => 'md',
        ExportFormat.text => 'txt',
        ExportFormat.html => 'html',
      };
}

/// 导出选项：由用户在导出面板里勾选。
class ExportOptions {
  /// 是否保留 AI 的思考过程（content 里的 `thinking` 段）。
  final bool includeThinking;

  /// 是否输出时间戳、设备、附件等元信息。
  final bool includeMetadata;

  const ExportOptions({
    this.includeThinking = true,
    this.includeMetadata = true,
  });

  ExportOptions copyWith({bool? includeThinking, bool? includeMetadata}) =>
      ExportOptions(
        includeThinking: includeThinking ?? this.includeThinking,
        includeMetadata: includeMetadata ?? this.includeMetadata,
      );
}

class ConversationExporter {
  const ConversationExporter._();

  /// `thinking` 标签包裹的段落。非贪婪匹配，跨行。
  static final RegExp _thinkingPattern =
      RegExp(r'<thinking>\s*([\s\S]*?)\s*</thinking>', multiLine: true);

  /// 从消息正文里剥掉思考段，返回干净正文。
  static String stripThinking(String content) =>
      content.replaceAll(_thinkingPattern, '').trim();

  /// 从消息正文里单独取出思考段（多条时按空行拼接）。
  static String extractThinking(String content) => _thinkingPattern
      .allMatches(content)
      .map((m) => (m.group(1) ?? '').trim())
      .where((s) => s.isNotEmpty)
      .join('\n\n');

  /// 渲染入口。返回最终要写入文件的完整字符串。
  static String render({
    required Conversation conversation,
    required List<ChatMessage> messages,
    required ExportFormat format,
    ExportOptions options = const ExportOptions(),
  }) {
    final visible = messages
        .where((m) => !m.deleted && m.role != MessageRole.system)
        .toList(growable: false);

    switch (format) {
      case ExportFormat.json:
        return _renderJson(conversation, visible, options);
      case ExportFormat.markdown:
        return _renderMarkdown(conversation, visible, options);
      case ExportFormat.text:
        return _renderText(conversation, visible, options);
      case ExportFormat.html:
        return _renderHtml(conversation, visible, options);
    }
  }

  /// 建议文件名：会话标题清洗后 + 时间戳，避免非法字符与重名覆盖。
  static String suggestedFileName(Conversation conversation, ExportFormat format) {
    final safe = conversation.title
        .replaceAll(RegExp(r'[\\/:*?"<>|\n\r\t]'), '_')
        .trim();
    final base = safe.isEmpty ? '对话' : safe;
    final d = conversation.updatedAt.toLocal();
    final stamp = '${d.year}'
        '${d.month.toString().padLeft(2, '0')}'
        '${d.day.toString().padLeft(2, '0')}-'
        '${d.hour.toString().padLeft(2, '0')}'
        '${d.minute.toString().padLeft(2, '0')}';
    return '$base-$stamp.${format.extension}';
  }

  // ---------------------------------------------------------------- JSON

  /// 结构对齐 DeepSeekJsonImporter：顶层数组，元素含会话信息与 messages。
  static String _renderJson(
    Conversation conversation,
    List<ChatMessage> messages,
    ExportOptions options,
  ) {
    final payload = <Map<String, dynamic>>[
      {
        'conversation_id': conversation.id,
        'title': conversation.title,
        'inserted_at': conversation.createdAt.toUtc().toIso8601String(),
        'updated_at': conversation.updatedAt.toUtc().toIso8601String(),
        'exported_at': DateTime.now().toUtc().toIso8601String(),
        'message_count': messages.length,
        'messages': messages.map((m) {
          final body = options.includeThinking ? m.content : stripThinking(m.content);
          return <String, dynamic>{
            'id': m.id,
            'role': switch (m.role) {
              MessageRole.user => 'user',
              MessageRole.assistant => 'assistant',
              MessageRole.system => 'system',
            },
            'content': body,
            'inserted_at': m.createdAt.toUtc().toIso8601String(),
            if (options.includeThinking && extractThinking(m.content).isNotEmpty)
              'reasoning_content': extractThinking(m.content),
            if (options.includeMetadata && m.attachments.isNotEmpty)
              'attachments': m.attachments
                  .map((a) => {
                        'type': a.type,
                        'location': a.location,
                        if (a.fileName != null) 'fileName': a.fileName,
                        if (a.mimeType != null) 'mimeType': a.mimeType,
                      })
                  .toList(),
          };
        }).toList(),
      },
    ];
    return const JsonEncoder.withIndent('  ').convert(payload);
  }

  // ------------------------------------------------------------ Markdown

  static String _renderMarkdown(
    Conversation conversation,
    List<ChatMessage> messages,
    ExportOptions options,
  ) {
    final b = StringBuffer();
    b.writeln('# ${conversation.title}');
    b.writeln();
    if (options.includeMetadata) {
      b.writeln('> 导出时间：${_fmtDateTime(DateTime.now())}  ');
      b.writeln('> 消息数：${messages.length}  ');
      b.writeln('> 会话创建于：${_fmtDateTime(conversation.createdAt.toLocal())}');
      b.writeln();
    }
    b.writeln('---');
    b.writeln();

    for (final m in messages) {
      final who = _roleLabel(m.role);
      b.writeln('## $who');
      if (options.includeMetadata) {
        b.writeln('_${_fmtDateTime(m.createdAt.toLocal())}_');
        b.writeln();
      }
      final body = options.includeThinking ? m.content : stripThinking(m.content);
      final thinking = options.includeThinking ? extractThinking(m.content) : '';
      if (thinking.isNotEmpty) {
        b.writeln('> **思考过程**');
        for (final line in thinking.split('\n')) {
          b.writeln('> $line');
        }
        b.writeln();
      }
      b.writeln(_quoteSafe(body));
      if (options.includeMetadata && m.attachments.isNotEmpty) {
        b.writeln();
        for (final a in m.attachments) {
          b.writeln('- 📎 ${a.fileName ?? a.location}');
        }
      }
      b.writeln();
      b.writeln('---');
      b.writeln();
    }
    return '${b.toString().trimRight()}\n';
  }

  // ---------------------------------------------------------------- Text

  static String _renderText(
    Conversation conversation,
    List<ChatMessage> messages,
    ExportOptions options,
  ) {
    final b = StringBuffer();
    b.writeln(conversation.title);
    b.writeln('=' * _displayWidth(conversation.title));
    b.writeln();
    if (options.includeMetadata) {
      b.writeln('导出时间：${_fmtDateTime(DateTime.now())}');
      b.writeln('消息数：${messages.length}');
      b.writeln('-' * 40);
      b.writeln();
    }
    for (final m in messages) {
      final stamp =
          options.includeMetadata ? ' [${_fmtDateTime(m.createdAt.toLocal())}]' : '';
      b.writeln('【${_roleLabel(m.role)}】$stamp');
      final body = options.includeThinking ? m.content : stripThinking(m.content);
      b.writeln(body);
      if (options.includeMetadata && m.attachments.isNotEmpty) {
        for (final a in m.attachments) {
          b.writeln('  (附件: ${a.fileName ?? a.location})');
        }
      }
      b.writeln();
    }
    return '${b.toString().trimRight()}\n';
  }

  // ---------------------------------------------------------------- HTML

  static String _renderHtml(
    Conversation conversation,
    List<ChatMessage> messages,
    ExportOptions options,
  ) {
    final b = StringBuffer();
    b.writeln('<!DOCTYPE html>');
    b.writeln('<html lang="zh-CN"><head><meta charset="utf-8">');
    b.writeln('<meta name="viewport" content="width=device-width, initial-scale=1">');
    b.writeln('<title>${_escapeHtml(conversation.title)}</title>');
    b.writeln('<style>');
    b.writeln('''
*{box-sizing:border-box}
body{margin:0;padding:32px 16px;background:#F7F9FC;color:#1A2233;
  font-family:"Segoe UI","Microsoft YaHei","PingFang SC",sans-serif;line-height:1.7}
.wrap{max-width:820px;margin:0 auto}
h1{font-size:22px;margin:0 0 8px}
.meta{color:#6B7688;font-size:13px;margin-bottom:24px}
.msg{background:#fff;border:1px solid #E3E8F0;border-radius:12px;
  padding:14px 16px;margin-bottom:12px}
.msg.user{border-left:4px solid #2E6BF6}
.msg.assistant{border-left:4px solid #10B981}
.who{font-size:13px;font-weight:600;color:#6B7688;margin-bottom:6px}
.body{white-space:pre-wrap;word-wrap:break-word}
.think{background:#F1F4F9;border-radius:8px;padding:10px 12px;margin-bottom:10px;
  color:#6B7688;font-size:13px;white-space:pre-wrap}
.think b{display:block;margin-bottom:4px;color:#6B7688}
.att{font-size:12px;color:#6B7688;margin-top:8px}
footer{color:#6B7688;font-size:12px;text-align:center;margin-top:32px}
@media print{body{background:#fff;padding:0}.msg{break-inside:avoid}}
''');
    b.writeln('</style></head><body><div class="wrap">');
    b.writeln('<h1>${_escapeHtml(conversation.title)}</h1>');
    b.writeln('<div class="meta">');
    if (options.includeMetadata) {
      b.writeln('导出时间：${_escapeHtml(_fmtDateTime(DateTime.now()))} · '
          '消息数：${messages.length}');
    }
    b.writeln('</div>');

    for (final m in messages) {
      final roleClass = m.role == MessageRole.user ? 'user' : 'assistant';
      b.writeln('<div class="msg $roleClass">');
      b.writeln('<div class="who">${_escapeHtml(_roleLabel(m.role))}'
          '${options.includeMetadata ? ' · ${_escapeHtml(_fmtDateTime(m.createdAt.toLocal()))}' : ''}'
          '</div>');
      final thinking = options.includeThinking ? extractThinking(m.content) : '';
      if (thinking.isNotEmpty) {
        b.writeln('<div class="think"><b>思考过程</b>${_escapeHtml(thinking)}</div>');
      }
      final body = options.includeThinking ? m.content : stripThinking(m.content);
      b.writeln('<div class="body">${_escapeHtml(body)}</div>');
      if (options.includeMetadata && m.attachments.isNotEmpty) {
        final names =
            m.attachments.map((a) => a.fileName ?? a.location).join('、');
        b.writeln('<div class="att">📎 ${_escapeHtml(names)}</div>');
      }
      b.writeln('</div>');
    }

    b.writeln('<footer>由 DeepShart 导出</footer>');
    b.writeln('</div></body></html>');
    return b.toString();
  }

  // ------------------------------------------------------------- helpers

  static String _roleLabel(MessageRole role) => switch (role) {
        MessageRole.user => '我',
        MessageRole.assistant => 'AI',
        MessageRole.system => '系统',
      };

  static String _fmtDateTime(DateTime dt) =>
      '${dt.year}-${_pad(dt.month)}-${_pad(dt.day)} ${_pad(dt.hour)}:${_pad(dt.minute)}';

  static String _pad(int v) => v.toString().padLeft(2, '0');

  /// Markdown 里以 # 或 > 开头的行会被误解析，行首加零宽处理不合适，
  /// 这里用转义反斜杠保持原样展示。
  static String _quoteSafe(String text) => text
      .split('\n')
      .map((line) =>
          RegExp(r'^\s*(#{1,6}\s|>\s|[-*+]\s|\d+\.\s)').hasMatch(line) ? '\\$line' : line)
      .join('\n');

  /// 粗略显示宽度：CJK 字符算 2 列，用于下划线长度。
  static int _displayWidth(String s) {
    var w = 0;
    for (final r in s.runes) {
      w += (r >= 0x1100 && r <= 0x115F) ||
              (r >= 0x2E80 && r <= 0xA4CF) ||
              (r >= 0xAC00 && r <= 0xD7A3) ||
              (r >= 0xF900 && r <= 0xFAFF) ||
              (r >= 0xFE30 && r <= 0xFE6F) ||
              (r >= 0xFF00 && r <= 0xFF60) ||
              (r >= 0xFFE0 && r <= 0xFFE6)
          ? 2
          : 1;
    }
    return w;
  }

  static String _escapeHtml(String s) => s
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
}
