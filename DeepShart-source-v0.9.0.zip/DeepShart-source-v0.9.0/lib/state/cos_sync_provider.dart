// target: lib/state/cos_sync_provider.dart
// 职责：COS 同步方案开关 + 高层编排（上传对话快照/备份、下载恢复、方案互斥）。

import 'dart:async';
import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';

import '../sync/backup_service.dart';
import '../sync/cos_sync_service.dart';
import '../sync/snapshot_merge_service.dart';
import '../sync/stale_file_gate.dart';
import '../sync/stale_sync_tracker.dart';
import '../sync/sync_policy.dart';
import 'app_providers.dart';

/// 同步方案：p2p（端对端直连，默认）/ cos（腾讯云 COS 中转）。
enum SyncMode { p2p, cos }

extension SyncModeX on SyncMode {
  String get wire => this == SyncMode.cos ? 'cos' : 'p2p';
  String get label => this == SyncMode.cos ? '腾讯云 COS' : 'P2P 直连';
}

const _kSyncMode = 'deepshart.sync_mode';

/// 当前同步方案。默认 P2P。
final syncModeProvider =
    StateProvider<SyncMode>((ref) => SyncMode.p2p);

/// 启动时从本机存储加载同步方案。由 bootstrap 调用一次。
Future<SyncMode> loadSyncMode(SharedPreferences prefs) async {
  final v = prefs.getString(_kSyncMode);
  return v == 'cos' ? SyncMode.cos : SyncMode.p2p;
}

Future<void> saveSyncMode(SharedPreferences prefs, SyncMode mode) async {
  await prefs.setString(_kSyncMode, mode.wire);
}

/// COS 同步服务实例。
final cosSyncServiceProvider = Provider<CosSyncService>((ref) {
  final prefs = ref.watch(sharedPrefsProvider).requireValue;
  return CosSyncService(prefs: prefs);
});

/// COS 同步编排：把底层服务与数据库/备份/设备名组合成可直接调用的高层动作。
final cosSyncCoordinatorProvider = Provider<CosSyncCoordinator>((ref) {
  return CosSyncCoordinator(ref: ref);
});

class CosSyncCoordinator {
  final Ref _ref;

  CosSyncCoordinator({required Ref ref}) : _ref = ref;

  CosSyncService get _service => _ref.read(cosSyncServiceProvider);

  Future<BackupService> get _backup => _ref.read(backupServiceProvider.future);

  Future<String> get _deviceName async {
    // 用户在 COS 设置里填的设备名优先；没填则回退本机全局设备名。
    final prefs = await _ref.read(sharedPrefsProvider.future);
    final custom = cosDeviceNameFromPrefs(prefs);
    if (custom.isNotEmpty) return custom;
    return (await _ref.read(localIdentityProvider.future)).deviceName;
  }

  /// 上传当前完整对话库快照到 COS（带设备名+时间标注）。
  /// 数据库处于 WAL 模式时用 VACUUM INTO 生成一致性快照，避免复制半截文件。
  Future<void> uploadSnapshot() async {
    final svc = _service;
    final deviceName = await _deviceName;
    final now = DateTime.now().toUtc();

    final tempDir = Directory.systemTemp;
    final tmpPath = p.join(tempDir.path, 'deepshart-cos-${now.millisecondsSinceEpoch}.db');
    final file = File(tmpPath);
    try {
      await _ref.read(databaseProvider.future).then((db) async {
        final escaped = tmpPath.replaceAll("'", "''");
        await BackupService.dbLock.run(() => db.execute("VACUUM INTO '$escaped'"));
      });
      await svc.uploadFile(tmpPath, svc.snapshotKey(deviceName, now));
      // 同时更新"最新快照"固定键，便于对端直接取最新。
      await svc.uploadFile(tmpPath, svc.latestSnapshotKey(deviceName));
      // 会话删除墓碑一并上传（本地+云端双写，防止已删会话被对端旧快照复活）。
      await _uploadTombstones(deviceName);
      // 历史快照容量上限：超限自动删最老的（用户要求）。
      await enforceHistoryQuota();
    } finally {
      if (await file.exists()) {
        try { await file.delete(); } catch (_) {}
      }
    }
  }

  /// 历史快照容量上限：统计云端带时间戳的快照体积，超限则按修改时间
  /// 从旧到新删除最老的，直到低于上限。latest / 墓碑 / 备份不在清理范围。
  Future<void> enforceHistoryQuota() async {
    try {
      final svc = _service;
      final quota = CosQuotaConfig.fromPrefs(svc.prefs).bytes;
      if (quota <= 0) return; // 0 视为不限制（或用户清空了输入）
      final objects = await svc.listObjects();
      // 只统计历史快照：deepshart/snapshots/<tag>/<tag>_时间戳.db（排除 latest_）。
      final history = objects
          .where((o) =>
              o.key.contains('/snapshots/') &&
              !p.basename(o.key).startsWith('latest_') &&
              o.key.endsWith('.db'))
          .toList();
      var total = history.fold<int>(0, (sum, o) => sum + o.size);
      if (total <= quota) return;
      // listObjects 已按修改时间倒序，倒着遍历即从最老开始删。
      for (var i = history.length - 1; i >= 0 && total > quota; i--) {
        final o = history[i];
        try {
          await svc.deleteObject(o.key);
          total -= o.size;
        } catch (_) {
          // 单个删除失败跳过，继续删下一个更老的。
        }
      }
    } catch (_) {
      // 清理失败不影响同步主流程。
    }
  }

  /// 上传本机会话删除墓碑到云端（供其他设备同步删除操作）。
  Future<void> _uploadTombstones(String deviceName) async {
    try {
      final store = await _ref.read(deletedConversationStoreProvider.future);
      final tombstones = await store.readAll();
      await _service.uploadTombstones(deviceName, tombstones);
    } catch (_) {
      // 墓碑上传失败不影响快照主流程；下次上传会重试。
    }
  }

  /// 检测疑似废弃的 latest 文件并分级提醒（软/硬弹窗）。
  /// 异步、fire-and-forget：弹窗等待用户不阻塞同步，期间该文件照常被同步。
  Future<void> checkStaleFiles(List<CosObject> objects) async {
    final svc = _service;
    final tracker = StaleSyncTracker(svc.prefs);
    final gate = _ref.read(staleFileGateProvider.notifier);
    final now = DateTime.now().toUtc();
    final latests = objects.where(
      (o) => o.key.contains('/snapshots/') && p.basename(o.key).startsWith('latest_'),
    );
    for (final o in latests) {
      try {
        final level = tracker.evaluate(o.deviceTag, o.lastModified, now: now);
        if (level == StaleLevel.none) continue;
        final choice = await gate.report(
          objectKey: o.key,
          deviceTag: o.deviceTag,
          level: level,
        );
        if (choice == StaleChoice.delete) {
          // 用户确认删除：删云端文件 + 清状态。
          try { await svc.deleteObject(o.key); } catch (_) {}
          await tracker.clear(o.deviceTag);
        } else {
          // 用户保留：软提示记一次否定；硬提示后仍保留则永久忽略。
          if (level == StaleLevel.hard) {
            await tracker.permanentIgnore(o.deviceTag);
          } else {
            await tracker.decline(o.deviceTag);
          }
        }
      } catch (_) {
        // 单个文件的提醒失败不影响其它文件与同步。
      }
    }
  }

  /// 拉取云端所有设备的墓碑文件，合并进本机墓碑表。
  /// 必须在合并快照【之前】调用——墓碑先生效，才能过滤掉快照里的已删会话。
  Future<void> mergeRemoteTombstones() async {
    try {
      final svc = _service;
      final objects = await svc.listObjects();
      final tombFiles = objects.where((o) => o.key.contains('/tombstones/') && o.key.endsWith('.json'));
      if (tombFiles.isEmpty) return;
      final store = await _ref.read(deletedConversationStoreProvider.future);
      for (final o in tombFiles) {
        final remote = await svc.downloadTombstones(o.key);
        await store.mergeRemote(remote);
      }
    } catch (_) {
      // 墓碑同步失败不阻断快照同步；下次同步重试。
    }
  }

  /// 把本地所有备份文件上传到 COS（按设备名+时间分类）。
  /// 返回成功上传的数量。已经上传过（同 objectKey）的会跳过，避免重复浪费流量。
  Future<int> uploadBackups() async {
    final svc = _service;
    final backup = await _backup;
    final deviceName = await _deviceName;
    final dir = await backup.backupDirectory;
    final files = dir
        .listSync()
        .whereType<File>()
        .where((f) => f.path.endsWith('.db'))
        .toList();
    if (files.isEmpty) return 0;

    final remote = await svc.listObjects();
    final remoteKeys = remote.map((o) => o.key).toSet();

    var uploaded = 0;
    for (final f in files) {
      final stat = await f.stat();
      final key = svc.backupKey(deviceName, stat.modified.toUtc(), 'backup');
      // 用文件大小+修改时间生成一个稳定 key，避免同一份备份重复上传。
      final stableKey = '${key.replaceAll('.db', '')}-${stat.size}-${stat.modified.millisecondsSinceEpoch}.db';
      if (remoteKeys.contains(stableKey)) continue;
      try {
        await svc.uploadFile(f.path, stableKey);
        uploaded++;
      } catch (_) {
        // 单个备份失败不中断整批。
      }
    }
    return uploaded;
  }

  static const _mergedKeyPrefix = 'deepshart.cos.merged.';

  /// 读全局默认同步行为（P2P/COS 共用）。正常同步直接按它静默执行、不弹窗。
  SyncPolicy get _behavior => _ref.read(syncBehaviorProvider);

  /// 按指定行为落地一次远端快照。
  Future<MergeReport> _applyPolicy(SyncPolicy policy, String objectKey) async {
    switch (policy) {
      case SyncPolicy.merge:
        return await mergeRemoteSnapshot(objectKey);
      case SyncPolicy.remoteWins:
        // 覆盖前先留一份本机备份（用户明确要求）。
        await _backupBeforeOverwrite();
        return await overwriteLocalWithRemote(objectKey);
      case SyncPolicy.localWins:
        // 覆盖前先留一份本机备份（用户明确要求）。
        await _backupBeforeOverwrite();
        await overwriteRemoteWithLocal();
        return const MergeReport(conversationsMerged: -1);
      case SyncPolicy.none:
        return const MergeReport(error: '同步已暂停（不同步）');
    }
  }

  /// 覆盖操作前先留一份本机备份，失败不影响主流程。
  Future<void> _backupBeforeOverwrite() async {
    try {
      final backup = await _backup;
      await backup.backupBeforeSync();
    } catch (_) {}
  }

  /// 统一的"同步一个远端快照"入口：
  /// - 正常：按全局默认行为静默执行，不弹窗；
  /// - none：跳过；
  /// - 合并过程抛错/无法完成：弹定夺窗（标注 COS + 错误详情），用户手动四选一后执行。
  Future<MergeReport> syncWithRemote(String objectKey, String sourceLabel) async {
    final behavior = _behavior;
    if (behavior == SyncPolicy.none) {
      return const MergeReport(error: '同步已暂停（不同步）');
    }
    try {
      final report = await _applyPolicy(behavior, objectKey);
      // 合并服务用 error 字段表示"无法完成"（如下载/打开快照失败），等同抛错。
      if (report.error != null && behavior != SyncPolicy.none) {
        final decision = await _ref.read(syncPolicyGateProvider.notifier).askOnError(
              sourceLabel,
              method: SyncMethod.cos,
              errorDetail: report.error!,
            );
        if (decision == SyncPolicy.none) {
          return MergeReport(error: '同步失败：${report.error}；你选择了暂停同步');
        }
        if (decision != behavior) return await _applyPolicy(decision, objectKey);
      }
      return report;
    } catch (e) {
      // 静默同步出错 → 弹定夺窗，标注 COS，用户手动选择后按其行为重试。
      final decision = await _ref.read(syncPolicyGateProvider.notifier).askOnError(
            sourceLabel,
            method: SyncMethod.cos,
            errorDetail: '$e',
          );
      if (decision == SyncPolicy.none) {
        return MergeReport(error: '同步失败：$e；你选择了暂停同步');
      }
      return await _applyPolicy(decision, objectKey);
    }
  }

  /// 以对端为准：下载远端整库快照，覆盖本机当前库。
  /// restore() 内部会先留一份安全备份，可按时间戳回溯。
  Future<MergeReport> overwriteLocalWithRemote(String objectKey) async {
    final svc = _service;
    final bytes = await svc.downloadBytes(objectKey);
    final tmp = p.join(
      Directory.systemTemp.path,
      'deepshart-overwrite-${DateTime.now().millisecondsSinceEpoch}.db',
    );
    final file = File(tmp);
    try {
      await file.writeAsBytes(bytes, flush: true);
      final backup = await _backup;
      await backup.restore(tmp);
      _invalidateData();
      return const MergeReport(conversationsMerged: -1); // -1 作为"整库已替换"的标记
    } finally {
      if (await file.exists()) {
        try { await file.delete(); } catch (_) {}
      }
    }
  }

  /// 以本机为准：把本机整库快照上传，覆盖云端该设备的 latest。
  /// 对端下次同步（拉取 latest）时会拿到这份，按它选的策略落地。
  Future<void> overwriteRemoteWithLocal() => uploadSnapshot();

  void _invalidateData() {
    _ref.invalidate(conversationsProvider);
  }

  /// 启动时自动同步云端最新版本（COS 模式专用）。
  ///
  /// 受"每次开启软件时自动同步"开关控制（三个自动开关之一）。
  /// 只处理每台设备的 latest 快照（避免把一堆历史快照重复合并）；用
  /// "对象 key|最后修改时间" 记录已同步版本，内容没变就跳过。
  /// 同步行为按全局默认静默执行；出错才由 syncWithRemote 弹定夺窗。
  Future<MergeReport> autoSyncOnStartup() async {
    final svc = _service;
    final auto = CosAutoSyncConfig.fromPrefs(svc.prefs);
    if (!auto.startupEnabled) {
      return const MergeReport(error: '未开启"启动时自动同步"，跳过');
    }
    return syncLatestSnapshots();
  }

  /// 拉取每台设备的最新快照并按全局行为同步（启动/定时/手动共用核心逻辑）。
  /// 不受单个自动开关限制，由调用方决定是否触发。
  Future<MergeReport> syncLatestSnapshots() async {
    final svc = _service;
    if (!svc.config.isComplete) {
      return const MergeReport(error: 'COS 未配置完整，跳过自动同步');
    }
    if (_behavior == SyncPolicy.none) {
      return const MergeReport(error: '同步已暂停（不同步）');
    }
    try {
      // 先同步墓碑，再合并快照——确保已删会话不会从对端快照里复活。
      await mergeRemoteTombstones();
      final objects = await svc.listObjects();
      // 废弃文件分级提醒：异步进行，弹窗不阻塞下面的同步流程。
      unawaited(checkStaleFiles(objects));
      // 跳过来源设备名与本机相同的 latest：自己的数据就在本机，不必下载回来合并。
      // 这样也顺带消掉了"上传后自己拉自己"的冗余。
      final myTag = svc.deviceTag(await _deviceName);
      final latests = objects.where(
        (o) => o.key.contains('/snapshots/') &&
            p.basename(o.key).startsWith('latest_') &&
            o.deviceTag != myTag,
      );
      if (latests.isEmpty) {
        return const MergeReport(error: '云端暂无其他设备的新快照，本机已是最新');
      }
      var total = const MergeReport();
      var attempted = 0;
      for (final o in latests) {
        // 版本号纳入大小 + 修改时间：仅靠 lastModified 时，若 COS 未返回时间
        // （解析为 null → 恒为 key|0），同步一次后会永远跳过对方的新快照。
        final hasTime = o.lastModified != null;
        final version = '${o.key}|${o.size}|${o.lastModified?.millisecondsSinceEpoch ?? 0}';
        final lastMerged = svc.prefs.getString('$_mergedKeyPrefix${o.deviceTag}');
        if (hasTime && lastMerged == version) continue; // 时间可靠且这版已同步过才跳过。
        attempted++;
        final report = await syncWithRemote(o.key, '云端快照 · ${o.deviceTag}');
        if (report.error == null) {
          await svc.prefs.setString('$_mergedKeyPrefix${o.deviceTag}', version);
          total = MergeReport(
            messagesMerged: total.messagesMerged + report.messagesMerged,
            messagesIgnored: total.messagesIgnored + report.messagesIgnored,
            conflicts: total.conflicts + report.conflicts,
            memoriesMerged: total.memoriesMerged + report.memoriesMerged,
            conversationsMerged: total.conversationsMerged + report.conversationsMerged,
          );
        }
      }
      // 有对端快照但全部因"版本未变"跳过，且本机确实没有新内容时，明确告知，
      // 不再伪装成"同步成功 0 条"让用户以为出了 bug。
      if (attempted == 0) {
        return const MergeReport(error: '各设备快照均无更新，本机已是最新');
      }
      return total;
    } catch (e) {
      return MergeReport(error: '自动同步失败：$e');
    }
  }

  /// 一键同步（两端顶部按钮共用）：先上传本机完整快照，再拉取合并各设备最新快照。
  /// 完整走一遍"提交自己的 + 下载对端的"，与 COS 自动同步同一套逻辑。
  /// 未配置完整或全局设为"不同步"时直接返回带 error 的报告，不做任何上传。
  Future<MergeReport> syncNow() async {
    final svc = _service;
    if (!svc.config.isComplete) {
      return const MergeReport(error: 'COS 未配置完整，请先在云同步设置里填写密钥');
    }
    if (_behavior == SyncPolicy.none) {
      return const MergeReport(error: '同步已暂停（不同步），请到全局设置打开同步');
    }
    try {
      await uploadSnapshot();
      return await syncLatestSnapshots();
    } catch (e) {
      return MergeReport(error: '一键同步失败：$e');
    }
  }

  /// 列出云端所有设备的最新快照与备份。
  Future<List<CosObject>> listRemote() => _service.listObjects();

  /// 从云端下载一个快照并【合并】进本地库（统一逻辑，与 P2P 一致）。
  /// - 单纯一方多聊（向量时钟 before/after）→ 自动合并；
  /// - 真·方向冲突（concurrent）→ 写入 ConflictRecord，复用现有裁决弹窗由用户选版本。
  Future<MergeReport> mergeRemoteSnapshot(String objectKey) async {
    final svc = _service;
    final bytes = await svc.downloadBytes(objectKey);
    final tmp = p.join(
      Directory.systemTemp.path,
      'deepshart-merge-${DateTime.now().millisecondsSinceEpoch}.db',
    );
    final file = File(tmp);
    try {
      await file.writeAsBytes(bytes, flush: true);
      final merger = await _ref.read(snapshotMergeServiceProvider.future);
      return await merger.mergeFromSnapshot(tmp);
    } finally {
      if (await file.exists()) {
        try { await file.delete(); } catch (_) {}
      }
    }
  }

  /// 从云端下载一个快照/备份到本地备份目录（持久保存，用户可在"备份"页自行恢复）。
  /// 刻意不自动覆盖当前库——恢复是破坏性操作，必须由用户在备份页显式确认。
  Future<String> downloadToBackups(String objectKey) async {
    final svc = _service;
    final bytes = await svc.downloadBytes(objectKey);
    final backup = await _backup;
    final dir = await backup.backupDirectory;
    var name = objectKey.split('/').last;
    if (!name.endsWith('.db')) name = '$name.db';
    var file = File(p.join(dir.path, 'cloud-$name'));
    var index = 1;
    while (await file.exists()) {
      file = File(p.join(dir.path, 'cloud-$name-${index++}'));
    }
    await file.writeAsBytes(bytes, flush: true);
    return file.path;
  }
}

/// COS 定时自动同步调度器（三个自动开关之一：每隔 N 分钟）。
///
/// 只负责按间隔触发 coordinator.syncLatestSnapshots()。开关/间隔每次由 provider
/// 重新读取，用户在设置页改动后调用 restart() 即刻生效；全局行为为"不同步"或
/// 非 COS 模式时，触发函数内部会自行跳过。
class CosAutoSyncScheduler {
  CosAutoSyncScheduler(this._ref);
  final Ref _ref;
  Timer? _timer;

  void start() => restart();

  void restart() {
    _timer?.cancel();
    _timer = null;
    // 每次定时触发时重新读取配置，避免闭包捕获旧值。
    _scheduleNext();
  }

  void _scheduleNext() {
    final svc = _ref.read(cosSyncServiceProvider);
    final auto = CosAutoSyncConfig.fromPrefs(svc.prefs);
    final mode = _ref.read(syncModeProvider);
    if (!auto.intervalEnabled || mode != SyncMode.cos) return;
    final minutes = auto.intervalMinutes.clamp(1, 1440);
    _timer = Timer.periodic(Duration(minutes: minutes), (_) {
      _trigger();
    });
  }

  Future<void> _trigger() async {
    try {
      final mode = _ref.read(syncModeProvider);
      final behavior = _ref.read(syncBehaviorProvider);
      if (mode != SyncMode.cos || behavior == SyncPolicy.none) return;
      final coord = _ref.read(cosSyncCoordinatorProvider);
      await coord.uploadSnapshot();
      await coord.syncLatestSnapshots();
    } catch (_) {
      // 定时同步失败静默，等下一个周期重试。
    }
  }

  void stop() {
    _timer?.cancel();
    _timer = null;
  }

  void dispose() => stop();
}

/// 全局单例调度器，由 bootstrap 启动一次。
final cosAutoSyncSchedulerProvider = Provider<CosAutoSyncScheduler>((ref) {
  final scheduler = CosAutoSyncScheduler(ref);
  ref.onDispose(() => scheduler.dispose());
  return scheduler;
});
