// target: lib/state/app_bootstrap.dart
// 职责：应用启动引导——首次运行创建默认会话、启动 P2P 同步引擎。

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/store/conversation_store.dart';
import '../sync/sync_policy.dart';
import 'app_providers.dart';
import 'chat_controller.dart';
import 'cos_sync_provider.dart';

/// 启动引导：读取时确保至少有一个会话，并尝试连接已配对设备。
/// UI 在 conversationsProvider 加载后自然展示，因此这里只做副作用。
final bootstrapProvider = FutureProvider<void>((ref) async {
  final convStore = await ref.read(conversationStoreProvider.future);
  final conversations = await convStore.watchAllStreamSource();
  if (conversations.isEmpty) {
    final id = newConversationId();
    await convStore.upsert(
      Conversation.create(id: id, title: '新对话'),
    );
  }

  // 加载同步方案（P2P / COS）。COS 模式下【绝不启动 P2P 引擎】，
  // 保证"选 COS 就彻底关闭 P2P"——两条链路互斥，不会同时连对端设备。
  final prefs = await ref.read(sharedPrefsProvider.future);
  final mode = await loadSyncMode(prefs);
  ref.read(syncModeProvider.notifier).state = mode;
  // 加载全局默认同步行为（四种并列，P2P/COS 共用）。
  final behavior = await loadSyncBehavior(prefs);
  ref.read(syncBehaviorProvider.notifier).state = behavior;

  if (mode == SyncMode.p2p) {
    // 仅 P2P 模式启动端对端引擎（失败静默，不影响离线使用）。
    // start() 内部串行排队，同步策略弹窗要等用户确认，故不 await 阻塞 bootstrap。
    try {
      final engine = await ref.read(syncEngineProvider.future);
      engine.start();
    } catch (_) {
      // 离线或尚无配对设备时忽略。
    }
  }
  if (mode == SyncMode.cos) {
    // COS 模式：启动定时同步调度器（"每隔 N 分钟"开关）。
    ref.read(cosAutoSyncSchedulerProvider).start();
    // 启动时自动同步（"每次开启软件"开关，内部判断）。失败静默。
    // 不 await——出错定夺窗要等用户协议确认后才弹出，绝不能让 bootstrap
    // 卡在 loading。后台执行，完成后自行刷新数据。
    final coordinator = ref.read(cosSyncCoordinatorProvider);
    coordinator.autoSyncOnStartup().then((_) {
      ref.invalidate(conversationsProvider);
    }).catchError((_) {});
  }
});
