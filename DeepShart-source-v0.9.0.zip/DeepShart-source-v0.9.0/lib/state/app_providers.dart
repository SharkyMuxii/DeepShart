// target: lib/state/app_providers.dart
// 职责：用 Riverpod 集中装配数据库、各 Store、P2P/AI 服务与 UI 消费的 Stream Provider。

import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../ai/ai_provider.dart';
import '../ai/deepseek_provider.dart';
import '../ai/memory_blacklist.dart';
import '../core/font_service.dart' show FontRecord, FontService;
import '../ai/model_catalog.dart';
import '../core/app_database.dart';
import '../data/models/chat_message.dart';
import '../data/models/compaction_view.dart';
import '../data/models/conflict_record.dart';
import '../data/models/important_memory.dart';
import '../data/models/conversation_settings.dart';
import '../data/models/session_summary.dart';
import '../data/store/compaction_view_store.dart';
import '../data/store/conversation_store.dart';
import '../data/store/deleted_conversation_store.dart';
import '../data/store/important_memory_store.dart';
import '../data/store/message_store.dart';
import '../sync/snapshot_merge_service.dart';
import '../sync/sync_policy.dart';
import '../data/store/paired_device_store.dart';
import '../ui/message_search.dart';
import '../sync/backup_service.dart';
import '../sync/pairing_service.dart';
import '../sync/sync_engine.dart';

/// 本地设备身份：持久化在 SharedPreferences，作为 CRDT 向量时钟的本地键。
final localIdentityProvider = FutureProvider<LocalIdentity>((ref) async {
  final prefs = await SharedPreferences.getInstance();
  var deviceId = prefs.getString('deepshart.device_id');
  if (deviceId == null) {
    deviceId = 'dev-${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}';
    await prefs.setString('deepshart.device_id', deviceId);
  }
  final saved = prefs.getString('deepshart.device_name');
  if (saved != null && saved.isNotEmpty) {
    return LocalIdentity(deviceId: deviceId, deviceName: saved);
  }
  // 首次生成默认设备名：Windows = Shardows + 4位随机数字；Android = Anrk + 4位随机数字。
  // 其余平台沿用旧格式。仅在用户没设过名字时生效，不覆盖已有名称。
  final rand = Random();
  final digits = List<int>.generate(4, (_) => rand.nextInt(10)).join();
  String prefix;
  if (Platform.isWindows) {
    prefix = 'Shardows';
  } else if (Platform.isAndroid) {
    prefix = 'Anrk';
  } else {
    final suffix = deviceId.length > 4 ? deviceId.substring(deviceId.length - 4) : deviceId;
    prefix = 'DeepShart ($suffix)';
  }
  final deviceName = Platform.isWindows || Platform.isAndroid ? '$prefix$digits' : prefix;
  await prefs.setString('deepshart.device_name', deviceName);
  return LocalIdentity(deviceId: deviceId, deviceName: deviceName);
});

final sharedPrefsProvider = FutureProvider<SharedPreferences>((ref) async {
  return SharedPreferences.getInstance();
});

final databaseProvider = FutureProvider((ref) => AppDatabase.open());

final messageStoreProvider = FutureProvider<MessageStore>((ref) async {
  final db = await ref.watch(databaseProvider.future);
  final identity = await ref.watch(localIdentityProvider.future);
  final store = await SqliteMessageStore.open(db, localDeviceId: identity.deviceId);
  // 启动时清掉"内容完全一致"的历史伪冲突：旧版本会把这种消息也记成冲突，
  // 一次同步能积几千条，用户打开就被满屏弹窗糊住。清理失败不影响正常使用。
  try {
    await store.pruneIdenticalConflicts();
  } catch (_) {
    // 忽略：宁可留着冲突，也不能因为清理失败让应用起不来。
  }
  ref.onDispose(() => store.dispose());
  return store;
});

final memoryStoreProvider = FutureProvider<ImportantMemoryStore>((ref) async {
  final db = await ref.watch(databaseProvider.future);
  final identity = await ref.watch(localIdentityProvider.future);
  final store = await SqliteImportantMemoryStore.open(db, localDeviceId: identity.deviceId);
  ref.onDispose(() => store.dispose());
  return store;
});

final conversationStoreProvider = FutureProvider<ConversationStore>((ref) async {
  final db = await ref.watch(databaseProvider.future);
  final store = await SqliteConversationStore.open(db);
  ref.onDispose(() => store.dispose());
  return store;
});

/// 会话删除墓碑表：删除会话时记录内部 ID，合并快照时据此过滤，防止死灰复燃。
final deletedConversationStoreProvider = FutureProvider<DeletedConversationStore>((ref) async {
  final db = await ref.watch(databaseProvider.future);
  await DeletedConversationStore.ensureTable(db);
  return DeletedConversationStore(db);
});

/// 统一快照合并服务（COS 与 P2P 共用同一套合并语义）。
final snapshotMergeServiceProvider = FutureProvider<SnapshotMergeService>((ref) async {
  final db = await ref.watch(databaseProvider.future);
  final messages = await ref.watch(messageStoreProvider.future);
  final memories = await ref.watch(memoryStoreProvider.future);
  final conversations = await ref.watch(conversationStoreProvider.future);
  final deleted = await ref.watch(deletedConversationStoreProvider.future);
  return SnapshotMergeService(
    db: db,
    messageStore: messages,
    memoryStore: memories,
    conversationStore: conversations,
    deletedStore: deleted,
  );
});

/// 压缩视图存储。压缩不再改消息表，产物全部落在这里。
final compactionViewStoreProvider = FutureProvider<CompactionViewStore>((ref) async {
  final db = await ref.watch(databaseProvider.future);
  final store = await SqliteCompactionViewStore.open(db);
  ref.onDispose(() => store.dispose());
  return store;
});

/// 某个会话当前的压缩视图（没有则为 null）。
final compactionViewProvider =
    FutureProvider.family<CompactionView?, String>((ref, conversationId) async {
  final store = await ref.watch(compactionViewStoreProvider.future);
  return store.get(conversationId);
});

final pairedDeviceStoreProvider = FutureProvider<PairedDeviceStore>((ref) async {
  return SharedPrefsPairedDeviceStore.create();
});

/// 已配对设备列表（配对成功后由外壳/PairingPanel 主动 invalidate 刷新）。
final pairedDevicesProvider = FutureProvider<List<PairedDevice>>((ref) async {
  final store = await ref.watch(pairedDeviceStoreProvider.future);
  return store.loadAll();
});

/// 全局默认模型。空/未设置时按 [kDefaultModelId] 处理。
const String kGlobalModelKey = 'deepshart.default_model';

/// 上一次成功拉到的模型 id 列表，作为离线缓存。
const String kCachedModelIdsKey = 'deepshart.cached_model_ids';

final globalModelProvider = FutureProvider<String>((ref) async {
  final prefs = await ref.watch(sharedPrefsProvider.future);
  final saved = (prefs.getString(kGlobalModelKey) ?? '').trim();
  return saved.isEmpty ? kDefaultModelId : saved;
});

/// 模型清单：优先实时拉 /models，失败则用缓存 + 内置表。
///
/// 为什么每次打开设置都要重拉：用户说"模型列表每次开启时实时获取"——
/// 新模型上线后不该等发版才能选到。失败不至于让下拉框变空，
/// 内置表兜底并标注哪些是"未识别窗口"的模型。
final modelCatalogProvider = FutureProvider<List<ModelInfo>>((ref) async {
  final prefs = await ref.watch(sharedPrefsProvider.future);
  final cached = prefs.getStringList(kCachedModelIdsKey) ?? const <String>[];
  var ids = cached;

  final ai = await ref.watch(aiProviderProvider.future);
  if (ai is DeepSeekProvider) {
    try {
      final remote = await ai.fetchModels();
      if (remote.isNotEmpty) {
        ids = remote;
        await prefs.setStringList(kCachedModelIdsKey, remote);
      }
    } catch (_) {
      // 离线 / Key 无效 / 网络抖动：静默回落到缓存，不打断设置页。
    }
  }
  return ModelCatalog.merge(ids);
});

/// AI Provider：API Key 或全局默认模型变化后由 saveApiKey / 设置页触发 invalidate 重建。
final aiProviderProvider = FutureProvider<AiProvider>((ref) async {
  final prefs = await ref.watch(sharedPrefsProvider.future);
  final apiKey = prefs.getString('deepshart.deepseek_api_key') ?? '';
  final model = ModelCatalog.canonicalize(await ref.watch(globalModelProvider.future));
  return DeepSeekProvider(apiKey: apiKey, model: model);
});

/// 指定模型的 Provider，供会话级模型覆盖使用。
///
/// 为什么不复用 [aiProviderProvider]：它是单例，一旦按会话切换模型就必须
/// 全局失效，会把其他会话的请求也打断。family 让每个模型各持一个实例，
/// 互不干扰（模型数量有限，不会造成实例膨胀）。
final aiProviderForModelProvider =
    FutureProvider.family<AiProvider, String>((ref, model) async {
  final prefs = await ref.watch(sharedPrefsProvider.future);
  final apiKey = prefs.getString('deepshart.deepseek_api_key') ?? '';
  final resolved = ModelCatalog.canonicalize(
    model.trim().isEmpty ? kDefaultModelId : model.trim(),
  );
  return DeepSeekProvider(apiKey: apiKey, model: resolved);
});

final pairingServiceProvider = FutureProvider<PairingService>((ref) async {
  final identity = await ref.watch(localIdentityProvider.future);
  final store = await ref.watch(pairedDeviceStoreProvider.future);
  final service = PairingService(local: identity, store: store);
  ref.onDispose(() => service.dispose());
  return service;
});

final backupServiceProvider = FutureProvider<BackupService>((ref) async {
  final db = await ref.watch(databaseProvider.future);
  final prefs = await ref.watch(sharedPrefsProvider.future);
  final identity = await ref.watch(localIdentityProvider.future);
  return BackupService(db: db, prefs: prefs, deviceName: identity.deviceName);
});

final syncEngineProvider = FutureProvider<SyncEngine>((ref) async {
  final store = await ref.watch(messageStoreProvider.future);
  final convStore = await ref.watch(conversationStoreProvider.future);
  final paired = await ref.watch(pairedDeviceStoreProvider.future);
  final identity = await ref.watch(localIdentityProvider.future);
  final viewStore = await ref.watch(compactionViewStoreProvider.future);
  final memoryStore = await ref.watch(memoryStoreProvider.future);
  final prefs = await ref.watch(sharedPrefsProvider.future);
  final backup = await ref.watch(backupServiceProvider.future);
  final engine = SyncEngine(
    store: store,
    conversationStore: convStore,
    pairedStore: paired,
    local: identity,
    viewStore: viewStore,
    memoryStore: memoryStore,
    prefs: prefs,
    deletedStore: await ref.watch(deletedConversationStoreProvider.future),
    // P2P 收到对端快照后，走与 COS 完全相同的合并服务（含墓碑过滤）。
    mergeSnapshotFromFile: (path) async {
      final merger = await ref.read(snapshotMergeServiceProvider.future);
      final report = await merger.mergeFromSnapshot(path);
      ref.invalidate(conversationsProvider);
      ref.invalidate(messagesProvider);
      return report;
    },
    backupService: backup,
    policyGate: ref.read(syncPolicyGateProvider.notifier),
    // 正常同步读全局默认行为，静默执行不弹窗。
    readBehavior: () => ref.read(syncBehaviorProvider),
    // 覆盖前先留一份本机备份（用户明确要求）。
    backupBeforeOverwrite: () async {
      try { await backup.backupBeforeSync(); } catch (_) {}
    },
    // 出错定夺后，把用户选的行为写回全局默认。
    applyErrorDecision: (policy) async {
      final p = await ref.read(sharedPrefsProvider.future);
      await saveSyncBehavior(p, policy);
      ref.read(syncBehaviorProvider.notifier).state = policy;
    },
    onOverwriteApplied: () {
      ref.invalidate(conversationsProvider);
      ref.invalidate(messagesProvider);
    },
  );
  ref.onDispose(() => engine.dispose());
  return engine;
});

/// 各配对设备的同步状态汇总（按 deviceId 取最新一条）。
///
/// 为什么放在 provider 而不是让 UI 直接订阅 engine.statuses：
/// engine 的流是广播流且只在 start() 之后才有事件，UI 重建（比如切换页面）
/// 会丢掉历史状态。这里做一层"状态表"，重连后 UI 仍能看到上一次的结论。
final syncStatusesProvider = StreamProvider<List<PeerSyncState>>((ref) async* {
  final engine = await ref.watch(syncEngineProvider.future);
  final latest = <String, PeerSyncState>{};
  yield const <PeerSyncState>[];
  await for (final s in engine.statuses) {
    latest[s.deviceId] = s;
    yield latest.values.toList(growable: false);
  }
});

/// 当前会话 id。
final currentConversationIdProvider = StateProvider<String>((ref) => '');

/// 未发送的附件草稿（按会话隔离）。
///
/// 提升为全局状态的原因：上传附件的动作是异步的，且选图/拍照时 App 可能经历
/// 会话切换。若草稿只存在 ChatScreen 的 State 里，一旦因为"空白对话自动删除"
/// 把当前会话切走，附件就会丢失或被挂到错误的会话上（用户实测：文件被上传到
/// 没被保存的原对话）。shell 判定空白对话能否删除时，会读取本 provider——
/// 有草稿的会话一律视为"非空"，绝不自动删除。
@immutable
class DraftAttachment {
  final String path;
  final String name;
  const DraftAttachment(this.path, this.name);

  @override
  bool operator ==(Object other) =>
      other is DraftAttachment && other.path == path && other.name == name;

  @override
  int get hashCode => Object.hash(path, name);
}

/// 每个会话未发送的附件草稿。key = conversationId。
final draftAttachmentsProvider =
    StateProvider.family<List<DraftAttachment>, String>((ref, conversationId) {
  return <DraftAttachment>[];
});

/// 当前是否处于"正在发送/上传附件"中（全局，按会话）。
/// shell 切走会话时若该会话仍在上传，会跳过空白删除，避免文件发到半个被删的会话。
final sendingInProgressProvider =
    StateProvider.family<bool, String>((ref, conversationId) => false);

/// 会话列表流。
final conversationsProvider = StreamProvider<List<Conversation>>((ref) async* {
  final store = await ref.watch(conversationStoreProvider.future);
  yield* store.watchAll();
});

/// 跨会话消息正文搜索（关键词 -> 按会话分组的命中，越早越靠后）。
/// 只在有关键词时才查库，空关键词返回空列表。
final messageSearchProvider = FutureProvider.family<List<SearchGroup>, String>((ref, query) async {
  final keyword = query.trim();
  if (keyword.isEmpty) return const <SearchGroup>[];
  final store = await ref.watch(messageStoreProvider.future);
  final convStore = await ref.watch(conversationStoreProvider.future);
  final hits = await store.searchAcrossConversations(keyword);
  final conversations = await convStore.watchAllStreamSource();
  final titles = <String, String>{
    for (final c in conversations) c.id: c.title,
  };
  return MessageSearch.group(hits, keyword: keyword, titles: titles);
});

/// 会话内消息流。
final messagesProvider =
    StreamProvider.family<List<ChatMessage>, String>((ref, conversationId) async* {
  final store = await ref.watch(messageStoreProvider.future);
  yield* store.watchAll(conversationId);
});

/// 全局冲突流。
final conflictsProvider = StreamProvider<List<ConflictRecord>>((ref) async* {
  final store = await ref.watch(messageStoreProvider.future);
  yield* store.watchConflicts();
});

/// 记忆点流。
final memoriesProvider =
    StreamProvider.family<List<ImportantMemory>, String>((ref, conversationId) async* {
  final store = await ref.watch(memoryStoreProvider.future);
  yield* store.watchAll(conversationId);
});

/// 会话设置。
final settingsProvider =
    FutureProvider.family<ConversationSettings, String>((ref, conversationId) async {
  final store = await ref.watch(conversationStoreProvider.future);
  return store.getSettings(conversationId);
});

/// 外观设置：主题模式（system/light/dark）与 UI 强调色（色值字符串，null=默认）。
const String kThemeModeKey = 'deepshart.theme_mode';
const String kAccentColorKey = 'deepshart.accent_color';

final themeModeProvider = FutureProvider<ThemeMode>((ref) async {
  final prefs = await ref.watch(sharedPrefsProvider.future);
  return switch (prefs.getString(kThemeModeKey)) {
    'light' => ThemeMode.light,
    'dark' => ThemeMode.dark,
    _ => ThemeMode.system,
  };
});

final accentColorProvider = FutureProvider<Color?>((ref) async {
  final prefs = await ref.watch(sharedPrefsProvider.future);
  final value = prefs.getInt(kAccentColorKey);
  return value == null ? null : Color(value);
});

/// 自定义字体配置键：AI / 用户 / UI 三类，值为 FontRecord 的 JSON。
const String kFontAiKey = 'deepshart.font_ai';
const String kFontUserKey = 'deepshart.font_user';
const String kFontUiKey = 'deepshart.font_ui';

Future<FontRecord?> _readFontPref(SharedPreferences prefs, String key) async {
  final raw = prefs.getString(key);
  if (raw == null || raw.isEmpty) return null;
  try {
    final map = jsonDecode(raw) as Map<String, dynamic>;
    final record = FontRecord(
      family: map['family'] as String,
      path: map['path'] as String,
      label: map['label'] as String,
    );
    // 重启后字体需要重新注册进运行时，之后 UI 自然刷新。
    await FontService.loadSavedFont(record);
    return record;
  } catch (_) {
    return null;
  }
}

String encodeFontRecord(FontRecord r) => jsonEncode(<String, dynamic>{
      'family': r.family,
      'path': r.path,
      'label': r.label,
    });

final fontAiProvider = FutureProvider<FontRecord?>((ref) async {
  final prefs = await ref.watch(sharedPrefsProvider.future);
  return _readFontPref(prefs, kFontAiKey);
});
final fontUserProvider = FutureProvider<FontRecord?>((ref) async {
  final prefs = await ref.watch(sharedPrefsProvider.future);
  return _readFontPref(prefs, kFontUserKey);
});
final fontUiProvider = FutureProvider<FontRecord?>((ref) async {
  final prefs = await ref.watch(sharedPrefsProvider.future);
  return _readFontPref(prefs, kFontUiKey);
});

/// UI 字体的字族名（供 app.dart 设置全局主题）。
final uiFontFamilyProvider = FutureProvider<String?>((ref) async {
  final record = await ref.watch(fontUiProvider.future);
  return record?.family;
});

/// 聊天渲染上限：一次只渲染最近 N 条，往上翻到顶再加 N 条，防止长对话卡死。
const String kChatRenderLimitKey = 'deepshart.chat_render_limit';

final chatRenderLimitProvider = FutureProvider<int>((ref) async {
  final prefs = await ref.watch(sharedPrefsProvider.future);
  return prefs.getInt(kChatRenderLimitKey) ?? 20;
});

/// 记忆点黑名单（全局，字符串原文，关键词用 ||| 分隔）。
const String kMemoryBlacklistKey = 'deepshart.memory_blacklist';

final memoryBlacklistRawProvider = FutureProvider<String>((ref) async {
  final prefs = await ref.watch(sharedPrefsProvider.future);
  return prefs.getString(kMemoryBlacklistKey) ?? '';
});

/// 解析后的黑名单关键词列表（同步读，供发送/提取时过滤）。
List<String> memoryBlacklist(Ref ref) =>
    MemoryBlacklist.parse(ref.read(memoryBlacklistRawProvider).value ?? '');

/// 全局默认角色提示词的存储键。
///
/// 为什么需要"全局"这一层：角色提示词是按会话存的，换一个会话就会回到默认人格，
/// 用户很容易以为"我明明设置过角色，为什么不生效"。全局提示词作为兜底，
/// 会话级提示词则用于单个会话的覆盖，两者语义明确、可预期。
const String kGlobalRolePromptKey = 'deepshart.global_system_prompt';

final globalRolePromptProvider = FutureProvider<String>((ref) async {
  final prefs = await ref.watch(sharedPrefsProvider.future);
  return (prefs.getString(kGlobalRolePromptKey) ?? '').trim();
});

/// DeepSeek 账户余额。未配置 Key 或非 DeepSeek 服务时返回 null。
///
/// 余额是"会变的数字"，不适合长期缓存：UI 每次露出都会走 provider，
/// 点刷新用 invalidate 重新拉一次，避免显示几十年前的余额。
final balanceProvider = FutureProvider<AccountBalance?>((ref) async {
  final ai = await ref.watch(aiProviderProvider.future);
  if (ai is! DeepSeekProvider) return null;
  final prefs = await ref.watch(sharedPrefsProvider.future);
  if ((prefs.getString('deepshart.deepseek_api_key') ?? '').isEmpty) return null;
  return ai.fetchBalance();
});

/// 会话摘要。
final summaryProvider =
    FutureProvider.family<SessionSummary?, String>((ref, conversationId) async {
  final store = await ref.watch(conversationStoreProvider.future);
  return store.getSummary(conversationId);
});
