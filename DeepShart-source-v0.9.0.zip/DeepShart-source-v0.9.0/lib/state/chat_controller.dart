// target: lib/state/chat_controller.dart
// 职责：聊天业务控制器——发送消息到 AI、持久化消息、管理 API Key 与会话设置、记忆点提取。

import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

import '../ai/ai_provider.dart';
import '../ai/citation_codec.dart';
import '../ai/context_budget.dart';
import '../ai/deepseek_provider.dart';
import '../ai/memory_blacklist.dart';
import '../ai/memory_indexer.dart';
import '../core/conversation_file_store.dart';
import '../data/models/chat_message.dart';
import '../data/models/conversation_settings.dart';
import '../data/models/important_memory.dart';
import '../data/store/conversation_store.dart';
import '../data/store/important_memory_store.dart';
import '../data/store/message_store.dart';
import '../sync/pairing_service.dart';
import 'app_providers.dart';
import 'cos_sync_provider.dart';

/// 单个会话的 UI 状态。
class ChatState {
  final bool sending;
  final String? error;

  /// 正在流式生成的思考过程（逐块累积）。
  final String? thinkingPreview;

  /// 正在流式生成的正文（逐块累积）。非空时 UI 显示"进行中"气泡，
  /// 生成完成后一次性落库并清空这里。
  final String? streamingAnswer;

  /// 上一轮实际发送的上下文用量。UI 用它回答"这次到底花了多少"。
  final BudgetReport? lastBudget;

  const ChatState({
    this.sending = false,
    this.error,
    this.thinkingPreview,
    this.streamingAnswer,
    this.lastBudget,
  });

  ChatState copyWith({
    bool? sending,
    String? error,
    bool clearError = false,
    String? thinkingPreview,
    bool clearThinking = false,
    String? streamingAnswer,
    bool clearStreaming = false,
    BudgetReport? lastBudget,
  }) =>
      ChatState(
        sending: sending ?? this.sending,
        error: clearError ? null : (error ?? this.error),
        thinkingPreview: clearThinking ? null : (thinkingPreview ?? this.thinkingPreview),
        streamingAnswer: clearStreaming ? null : (streamingAnswer ?? this.streamingAnswer),
        lastBudget: lastBudget ?? this.lastBudget,
      );
}

/// 按思考强度给出的输出上限建议值。
///
/// 思考模式下 reasoning token 与正文共享 max_tokens（官方口径如此），
/// 极限档的思维链本身就可能上万 token，给小了会出现"思考完了没正文"。
int suggestedMaxOutputTokens(int thinkingEffort) => switch (thinkingEffort.clamp(0, 2)) {
      0 => 4096,
      1 => 8192,
      _ => 16384,
    };

/// 把记忆点拼成一段 system 文本。放在请求最前面，内容稳定、利于前缀缓存。
String _formatMemoryBlock(List<ImportantMemory> memories) {
  final buffer = StringBuffer('【重要记忆（长期有效，需遵守）】');
  for (final m in memories) {
    buffer.write('\n- ${m.summary}');
  }
  return buffer.toString();
}

/// 每个会话一个控制器实例（family + autoDispose）。
class ChatController extends AutoDisposeFamilyNotifier<ChatState, String> {
  late String _conversationId;

  @override
  ChatState build(String conversationId) {
    _conversationId = conversationId;
    return const ChatState();
  }

  Future<MessageStore> get _store => ref.read(messageStoreProvider.future);
  Future<ConversationStore> get _convStore => ref.read(conversationStoreProvider.future);
  Future<AiProvider> get _ai => ref.read(aiProviderProvider.future);
  Future<LocalIdentity> get _identity => ref.read(localIdentityProvider.future);
  Future<ImportantMemoryStore> get _memoryStore => ref.read(memoryStoreProvider.future);

  /// 按"会话级模型 → 全局默认模型"解析出本轮要用的 Provider。
  ///
  /// 为什么不在 UI 层解析：模型是请求参数的一部分，必须在真正发请求的地方
  /// 决定；放到 UI 会导致"设置里显示 Pro、实际请求用 Flash"这类不可见的错配。
  Future<AiProvider> _resolveAi(ConversationSettings settings) async {
    final model = (settings.model ?? '').trim();
    if (model.isEmpty) return ref.read(aiProviderProvider.future);
    return ref.read(aiProviderForModelProvider(model).future);
  }

  /// 收集本次请求要带的记忆点。
  ///
  /// 记忆同步的语义是「读取」不是「合并」：开启后把其他开启者会话的记忆点
  /// 一并读进来参与排序，各会话的数据本身仍独立存储，不会写回对方的库。
  /// 这样用户既能让"人设"跨话题生效，又不会因为共享而污染单个会话。
  Future<List<ImportantMemory>> _loadContextMemories(
    ConversationSettings settings,
  ) async {
    final store = await _memoryStore;
    final own = await store.readAll(state0());
    if (!settings.memorySync) return own;

    final convStore = await _convStore;
    final conversations = await convStore.watchAllStreamSource();
    // 归一化编码：null / 空 / 大小写差异都归到同一公共池。
    String norm(String? code) => (code ?? '').trim().toUpperCase();
    final myCode = norm(settings.memoryCode);
    final shared = <ImportantMemory>[];
    for (final conv in conversations) {
      if (conv.id == state0()) continue;
      final other = await convStore.getSettings(conv.id);
      if (!other.memorySync) continue;
      // 编码不同不共享：只有相同 4 位编码（或都留空）的会话才互通记忆库。
      if (norm(other.memoryCode) != myCode) continue;
      shared.addAll(await store.readAll(conv.id));
    }
    if (shared.isEmpty) return own;
    return <ImportantMemory>[...own, ...shared];
  }

  /// 发送消息主流程：
  /// 1. 用户消息落库
  /// 2. 读取会话设置（system prompt / temperature）
  /// 3. 组装历史上下文调 AI（带思考/搜索开关）
  /// 4. 助手回复落库（思考内容与正文分离存储于 content 前缀）
  /// 5. 旁路提取重要记忆点
  Future<void> send(
    String text, {
    required bool thinkingEnabled,
    required bool searchEnabled,
    List<String> filePaths = const <String>[],
  }) async {
    if (text.trim().isEmpty && filePaths.isEmpty) return;
    state = state.copyWith(sending: true, clearError: true);

    try {
      final identity = await _identity;
      final store = await _store;
      final convStore = await _convStore;
      final settings = await convStore.getSettings(state0());
      final ai = await _resolveAi(settings);
      // 角色提示词解析顺序：会话级 → 全局默认 → 不注入。
      // 之前只读会话级，换到没有单独设置过的会话（例如刚导入的会话）就会
      // 悄悄退回模型默认人格，用户会以为"设置没生效"。
      final globalPrompt = await ref.read(globalRolePromptProvider.future);
      final localPrompt = settings.systemPrompt?.trim() ?? '';
      final effectivePrompt = localPrompt.isNotEmpty
          ? localPrompt
          : (globalPrompt.isNotEmpty ? globalPrompt : null);

      // 关键：先把本地文件逐个上传到 AI 服务，拿到服务端 file_id。
      // 直接把本地路径当 file_id 发给 /chat/completions 会被服务端以 400 拒绝。
      final uploadedIds = <String>[];
      // 保留每个附件的完整信息，供气泡/文件列表显示（此前只存 file_id，
      // 导致用户提交后既看不到附件、也无法确认是否上传成功）。
      final savedAttachments = <MessageAttachment>[];
      if (filePaths.isNotEmpty) {
        if (!ai.supportsFileUpload) {
          throw StateError('${ai.displayName} 不支持文件上传');
        }
        for (final path in filePaths) {
          try {
            final uploaded = await ai.uploadFile(path);
            uploadedIds.add(uploaded.fileId);
            final ext = path.split('.').last.toLowerCase();
            const imageExts = {'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'heic'};
            savedAttachments.add(MessageAttachment(
              type: imageExts.contains(ext) ? 'image' : 'file',
              // location 存服务端 file_id，保证同步/历史语义一致。
              location: uploaded.fileId,
              fileName: uploaded.fileName,
              mimeType: uploaded.mimeType,
              localPath: path,
            ));
          } catch (e) {
            // 带上文件名，便于用户判断是哪一个附件出的问题。
            final name = path.split(RegExp(r'[/\\]')).last;
            throw StateError('附件「$name」上传失败：${friendlyError(e)}');
          }
        }      }

      final userMsg = ChatMessage.create(
        conversationId: state0(),
        role: MessageRole.user,
        content: text.trim(),
        deviceId: identity.deviceId,
        attachments: savedAttachments,
      );
      await store.insertOrMerge(userMsg);
      await convStore.touch(state0());

      // 已发送附件的归档副本：复制一份到会话私有目录，供全局「文件管理」统一管理。
      // fire-and-forget，失败静默——绝不影响对话发送主流程。对话气泡仍用 localPath 打开原件。
      if (savedAttachments.isNotEmpty) {
        final convIdForArchive = state0();
        unawaited(() async {
          for (final a in savedAttachments) {
            final src = a.localPath;
            if (src == null || src.isEmpty) continue;
            await ConversationFileStore.archive(
              conversationId: convIdForArchive,
              sourcePath: src,
              displayName: a.fileName,
            );
          }
        }());
      }

      final viewStore = await ref.read(compactionViewStoreProvider.future);
      final compactionView = await viewStore.get(state0());
      final raw = await store.readAll(state0());
      // 压缩以"视图"形式作用在发送层：折叠的段用摘要替代、截断的用片段替代，
      // 库里原文一条不动。这一步是纯内存变换，不写任何数据。
      final all = compactionView == null ? raw : compactionView.materialize(raw);
      final nonSystem =
          all.where((m) => m.role != MessageRole.system).toList(growable: false);
      // 当前提问按 id 精确取：并发/重试场景下"最后一条"未必就是刚插入的这条。
      final current = nonSystem.firstWhere(
        (m) => m.id == userMsg.id,
        orElse: () => userMsg,
      );
      final earlier =
          nonSystem.where((m) => m.id != userMsg.id).toList(growable: false);

      // 记忆点：本会话全量；开启记忆共享时并上其他开启者的记忆点（只读不合并）。
      var contextMemories = await _loadContextMemories(settings);
      final modelId = (settings.model ?? '').trim().isEmpty
          ? await ref.read(globalModelProvider.future)
          : settings.model!.trim();

      // 滑窗锚点存在 prefs：它是本机缓存性质的状态，不必同步给对端。
      final prefs = await ref.read(sharedPrefsProvider.future);
      final anchorKey = 'deepshart.slide_anchor.${state0()}';
      final slideAnchor = prefs.getString(anchorKey);

      // ---- 记忆索引 ----
      // 用户问到"之前的事"时：先看上下文里已有的记忆是否覆盖问题关键词；
      // 若没覆盖（很可能相关记忆因上下文上限被裁掉了），自动提取关键词搜索
      // 全部记忆库（含共享库），把命中的记忆补进上下文后重新计算预算。
      if (MemoryIndexer.looksLikeMemoryQuery(text)) {
        final keywords = MemoryIndexer.extractKeywords(text);
        final inContextSummaries =
            contextMemories.map((m) => m.summary).toList(growable: false);
        if (keywords.isNotEmpty &&
            !MemoryIndexer.contextCovers(inContextSummaries, keywords)) {
          try {
            final memStore = await _memoryStore;
            final found = await memStore.searchAcrossConversations(keywords);
            if (found.isNotEmpty) {
              // 去重合并：已有的 id 不重复加，避免同一条记忆占两份预算。
              final existingIds = contextMemories.map((m) => m.id).toSet();
              final extra = found.where((m) => !existingIds.contains(m.id));
              contextMemories = <ImportantMemory>[...contextMemories, ...extra];
            }
          } catch (_) {
            // 索引检索失败不影响主流程：大不了这次没补到记忆。
          }
        }
      }

      final budget = ContextBudget.fit(
        history: earlier,
        current: current,
        memories: contextMemories,
        settings: settings,
        modelId: modelId,
        systemPrompt: effectivePrompt,
        slideAnchorId: slideAnchor,
      );
      final nextAnchor = budget.report.nextAnchorId;
      if (nextAnchor != null) {
        await prefs.setString(anchorKey, nextAnchor);
      }
      state = state.copyWith(lastBudget: budget.report);

      // 黑名单：命中的历史/当前消息不把原文提交给大模型（替换为占位），
      // 但保留这条消息本身以维持问答配对，库里原文也不动。
      final blacklist = memoryBlacklist(ref);
      String sanitize(String text) => MemoryBlacklist.matches(text, blacklist)
          ? '[该内容已被用户加入隐私黑名单，不予提供]'
          : text;

      final aiMessages = <AiMessage>[
        // 记忆点作为独立 system 放在最前：位置固定、内容稳定，
        // 既不会打断角色提示词，也能持续吃到前缀缓存。
        if (budget.memories.isNotEmpty)
          AiMessage(role: 'system', content: _formatMemoryBlock(budget.memories)),
        for (final m in budget.history)
          AiMessage(
            role: m.role == MessageRole.assistant ? 'assistant' : 'user',
            // 思考过程只用于本地展示，不回放给模型：
            // 既浪费 token，也会让模型把旧推理当成"自己说过的话"，
            // 进而压过当前角色提示词。
            content: sanitize(_stripThinking(m.content)),
            // 历史消息只回放文字，不再重复附带文件：
            //  1) 文件在首次提问时已被模型读过，历史里重带纯属浪费 token/费用；
            //  2) 旧消息里的图片 file_id 会被不支持图片的模型（如 V4 Pro）判 400
            //     ——这正是"messages[].images are not supported"的根因。
            // 当前这条新消息的附件仍在下面单独带上，不影响本次提问。
            fileIds: const <String>[],
          ),
        AiMessage(
          role: 'user',
          content: sanitize(_stripThinking(current.content)),
          fileIds: uploadedIds,
        ),
      ];

      final options = AiRequestOptions(
        thinkingEnabled: thinkingEnabled,
        searchEnabled: searchEnabled,
        temperature: settings.temperature,
        systemPrompt: effectivePrompt,
        reasoningEffort: settings.reasoningEffort,
        maxOutputTokens:
            settings.maxOutputTokens ?? suggestedMaxOutputTokens(settings.thinkingEffort),
      );

      // 流式接收：思考与正文逐块累积到 state，UI 实时浮现"进行中"气泡。
      // 关键：绝不在每个 chunk 写库（会把 SQLite 刷爆），结束才一次性落库。
      final answerBuf = StringBuffer();
      final thinkingBuf = StringBuffer();
      List<AiCitation> citations = const <AiCitation>[];
      await for (final chunk in ai.sendMessageStream(aiMessages, options: options)) {
        switch (chunk) {
          case ThinkingChunk(:final delta):
            thinkingBuf.write(delta);
            state = state.copyWith(thinkingPreview: thinkingBuf.toString());
          case AnswerChunk(:final delta):
            answerBuf.write(delta);
            state = state.copyWith(streamingAnswer: answerBuf.toString());
          case CitationsChunk(citations: final refs):
            citations = refs;
        }
      }

      final finalAnswer = answerBuf.toString();
      // 思考与引用以结构化标记写入 content，UI 按标记分区渲染。
      final buffer = StringBuffer();
      if (thinkingBuf.isNotEmpty) {
        buffer.writeln('<thinking>\n${thinkingBuf.toString()}\n</thinking>');
      }
      buffer.write(CitationCodec.encode(finalAnswer, citations));

      final assistantMsg = ChatMessage.create(
        conversationId: state0(),
        role: MessageRole.assistant,
        content: buffer.toString(),
        deviceId: identity.deviceId,
      );
      await store.insertOrMerge(assistantMsg);
      await convStore.touch(state0());

      // 旁路：重要记忆点提取（失败不影响主流程）。
      // 关键：必须检查 autoMemory——此前无条件调用，用户关掉自动提取后
      // 仍在每轮偷偷多发一次 AI 请求（额外烧钱且违背设置）。
      if (settings.autoMemory) {
        unawaited(_extractMemory(text, finalAnswer, identity.deviceId));
      }

      // COS 自动同步（三个开关之一：每 N 条对话）：仅 COS 模式且开启该开关时计数。
      // 到数后先上传本机快照，再拉取合并各设备最新快照（完整同步）。
      // 旁路执行、失败静默——绝不让云同步问题打断对话主流程。
      try {
        final isCos = ref.read(syncModeProvider) == SyncMode.cos;
        if (isCos) {
          final shouldSync = await ref.read(cosSyncServiceProvider).tickRound(cosModeEnabled: true);
          if (shouldSync) {
            final coord = ref.read(cosSyncCoordinatorProvider);
            unawaited(() async {
              try {
                await coord.uploadSnapshot();
                await coord.syncLatestSnapshots();
              } catch (_) {
                // 自动同步失败静默，不影响对话。
              }
            }());
          }
        }
      } catch (_) {
        // 同步计数失败不影响对话。
      }

      // 落库完成后清空流式临时态，UI 切换到正常消息气泡。
      state = state.copyWith(
        sending: false,
        clearError: true,
        clearThinking: true,
        clearStreaming: true,
      );
    } catch (e) {
      // 出错/断线：清掉半截流式内容，不能在库里/界面上留个残缺气泡。
      state = state.copyWith(
        sending: false,
        error: friendlyError(e),
        clearThinking: true,
        clearStreaming: true,
      );
    }
  }

  /// 去掉 <thinking>…</thinking> 段与引用编码块，只留纯正文给模型回放。
  /// 引用编码是 base64，喂给模型既浪费 token 又毫无意义。
  static String _stripThinking(String content) {
    var text = content;
    if (text.contains('<thinking>')) {
      text = text.replaceAll(RegExp(r'<thinking>\n?[\s\S]*?\n?</thinking>'), '');
    }
    text = CitationCodec.strip(text);
    return text.trim();
  }

  /// 把底层网络异常翻译成中文指引，避免把 Dio 的英文原始异常直接甩给用户。
  static String friendlyError(Object e) {
    final text = e.toString().toLowerCase();

    // 优先透出服务端原话：400 的原因很多（格式/模型不支持/文件不可解析），
    // 一律映射成"附件类型不支持"会把真正原因藏起来，反而更难排查。
    final serverMessage = _serverMessage(e);

    if (text.contains('failed host lookup') ||
        text.contains('no address associated') ||
        text.contains('socketexception')) {
      return '网络无法连接：手机解析不了 api.deepseek.com。\n'
          '请检查：① 手机是否联网 ② 切换到 Wi-Fi 或流量重试 ③ 部分网络需关闭 VPN/代理。';
    }
    if (text.contains('connection timed out') || text.contains('timeout')) {
      return '网络连接超时，请检查网络后重试。';
    }
    // 服务端英文原话先翻译成中文（失败则保留原文，绝不因为翻译丢信息）。
    final translated = _translateServerMessage(serverMessage);
    final lowered = (serverMessage ?? '').toLowerCase();

    // 图片不被模型支持：这是 V4 Pro 等模型的典型 400，必须给出可操作的解法。
    if (lowered.contains('images are not supported') ||
        lowered.contains('image') && lowered.contains('not supported') ||
        lowered.contains('does not support image')) {
      return '当前模型不支持识别图片，但这次对话的历史里带着图片/文件，服务端拒绝了请求。\n'
          '解决办法：① 换回支持图片的模型（如 DeepSeek Flash），或 '
          '② 开一个新对话不带图片重新问，或 ③ 把带图的那条消息撤回后重试。\n'
          '（本次请求被拒绝，未产生回答）';
    }

    // 模型名无效：给出明确指引，别让用户对着英文模型名发呆。
    if (lowered.contains('supported api model names') ||
        lowered.contains('model') && lowered.contains('not found') ||
        lowered.contains('invalid model')) {
      return '选择的模型已被服务端下线或名称无效。\n'
          '请到「设置 → 默认模型」重新选择一个当前可用的模型（应用已自动过滤失效项），'
          '会话设置里如果单独指定过模型也要一并改掉。';
    }

    // 上下文超限是"配置问题"而不是"格式问题"，必须单独识别并给出可执行的建议，
    // 否则用户只会看到一句含糊的 400，不知道该改哪里。
    if (text.contains('context') &&
            (text.contains('length') || text.contains('window') || text.contains('too long')) ||
        lowered.contains('maximum context') ||
        lowered.contains('context length')) {
      return '输入超出了模型能接收的长度。\n'
          '请到「会话设置 → 上下文上限」调低一档（例如从 512K 降到 256K），'
          '或先手动压缩这个对话再重试。\n'
          '（本次没有生成回答，未计费）';
    }
    if (text.contains('status code of 400') || text.contains('400')) {
      return translated != null
          ? '请求被服务端拒绝（400）：$translated'
          : '请求被服务端拒绝（400）：请求格式或附件不受支持，请检查文件类型与大小。';
    }
    if (text.contains('401') || text.contains('unauthorized')) {
      return 'API Key 无效或已过期，请到全局设置重新填写。';
    }
    if (text.contains('402') || text.contains('insufficient')) {
      return 'DeepSeek 账户余额不足，请充值后重试。';
    }
    if (text.contains('413')) {
      return '文件太大，服务端拒绝接收（413）。图片上限 64MiB，文档 100MiB，文本 32MiB。';
    }
    if (text.contains('429')) {
      return '请求过于频繁，请稍后再试。';
    }
    if (text.contains('500') || text.contains('502') || text.contains('503')) {
      return 'DeepSeek 服务暂时不可用，请稍后重试。';
    }
    // 兜底：其他未识别的失败也尽量显示中文前缀。
    return translated != null ? '发送失败：$translated' : '发送失败：${serverMessage ?? e}';
  }

  /// 把 DeepSeek 服务端常见的英文错误文案翻译成中文。
  /// 采用"关键词包含"匹配而非整句相等——服务端文案会带 request id、 varying 细节。
  /// 无法识别的原文原样返回（不丢信息），由调用方决定怎么呈现。
  static String? _translateServerMessage(String? message) {
    if (message == null || message.trim().isEmpty) return null;
    final m = message.toLowerCase();

    if (m.contains('images are not supported') ||
        (m.contains('image') && m.contains('not supported'))) {
      return '当前模型不支持图片：历史对话里的图片无法随消息一起提交。请换支持图片的模型，或新开一个不带图片的对话。';
    }
    if (m.contains('supported api model names') ||
        (m.contains('model') && m.contains('you passed'))) {
      // 提取服务端给出的可用模型名，帮用户直接看到该选什么。
      final names = RegExp(r'are ([^,]+(?:,[^,]+)*), but you passed', caseSensitive: false)
          .firstMatch(message);
      final suffix = names != null ? '（可用：${names.group(1)}）' : '';
      return '模型名无效或已下线$suffix。请到设置里重新选择可用模型。';
    }
    if (m.contains('maximum context') || m.contains('context length') ||
        (m.contains('context') && m.contains('exceed'))) {
      return '输入超出模型上下文上限，请调低"上下文上限"或压缩对话后重试。';
    }
    if (m.contains('insufficient balance') || m.contains('insufficient')) {
      return '账户余额不足，请充值后重试。';
    }
    if (m.contains('rate limit') || m.contains('too many requests')) {
      return '请求过于频繁，请稍后再试。';
    }
    if (m.contains('invalid api key') || m.contains('unauthorized') ||
        m.contains('authentication')) {
      return 'API Key 无效或无权限，请到全局设置重新填写。';
    }
    if (m.contains('file') && m.contains('not supported') ||
        m.contains('unsupported file')) {
      return '附件格式不受支持，请换用 PDF、Word、图片或纯文本文件。';
    }
    if (m.contains('file too large') || m.contains('too large')) {
      return '文件过大，服务端拒绝接收。';
    }
    // 未识别：原样返回（不翻译成中文，但不丢信息）。
    return message;
  }

  /// 从 DioException 的响应体里取出服务端错误文案。
  /// OpenAI 风格是 {"error":{"message":"..."}}，也兼容 {"message":"..."} 与纯文本。
  static String? _serverMessage(Object e) {
    if (e is! DioException) return null;
    final data = e.response?.data;
    if (data == null) return null;
    if (data is Map) {
      final err = data['error'];
      if (err is Map && err['message'] != null) return err['message'].toString();
      if (data['message'] != null) return data['message'].toString();
      if (err != null) return err.toString();
      return null;
    }
    final raw = data.toString().trim();
    if (raw.isEmpty) return null;
    // interceptor 已把 ResponseBody 读成字符串；这里若是 JSON 再剥一层
    // error.message，避免把整坨 JSON 拍到用户脸上。
    if (raw.startsWith('{')) {
      try {
        final decoded = jsonDecode(raw) as Map<String, dynamic>;
        final err = decoded['error'];
        if (err is Map && err['message'] != null) return err['message'].toString();
        if (decoded['message'] != null) return decoded['message'].toString();
      } catch (_) {}
    }
    return raw.length > 300 ? '${raw.substring(0, 300)}…' : raw;
  }

  Future<void> _extractMemory(String userText, String answer, String deviceId) async {
    try {
      final ai = await _ai;
      if (ai is! DeepSeekProvider) return;
      final extractor = MemoryExtractor(ai);
      final extraction = await extractor.extract(
        conversationId: state0(),
        userMessage: userText,
        assistantReply: answer,
      );
      if (extraction == null || !extraction.isImportant) return;

      // 黑名单：命中任一关键词的内容不进记忆点。
      final blacklist = memoryBlacklist(ref);
      if (MemoryBlacklist.matches(extraction.summary, blacklist) ||
          MemoryBlacklist.matches(userText, blacklist)) {
        return;
      }

      final memoryStore = await _memoryStore;
      final existing = await memoryStore.readAll(state0());
      final key = MemoryBlacklist.normalize(extraction.summary);
      final prior = existing.where((m) => MemoryBlacklist.normalize(m.summary) == key).firstOrNull;
      if (prior != null) {
        // 反复被提取 → 加权（回忆越多记得越牢），edit() 会 tick 时钟确保写入。
        await memoryStore.insertOrMerge(prior.edit(
          editingDeviceId: deviceId,
          newReextractCount: prior.reextractCount + 1,
        ));
        return;
      }
      await memoryStore.insertOrMerge(ImportantMemory.create(
        conversationId: state0(),
        summary: extraction.summary,
        tags: extraction.tags,
        importance: extraction.importance,
        deviceId: deviceId,
      ));
    } catch (_) {
      // 旁路失败静默
    }
  }

  /// 当前会话 id（在 build 时由 family 参数注入）。
  String state0() => _conversationId;

  /// 撤回一条消息：软删除该消息及其之后的全部消息，并返回被撤回的正文。
  ///
  /// 为什么返回正文：撤回的语义是"这句话我要重写"，正文必须回到输入框，
  /// 否则用户还得手动翻记录复制一遍，等于没撤回。
  /// 删除用软删除（tombstone + 时钟 tick），这样对端同步后也会隐藏，
  /// 不会出现"撤回的消息自己长回来"。
  Future<({String content, int removed})?> recall(String messageId) async {
    try {
      final store = await _store;
      final identity = await _identity;
      final all = await store.readAll(state0());
      ChatMessage? target;
      for (final m in all) {
        if (m.id == messageId) {
          target = m;
          break;
        }
      }
      if (target == null) return null;
      final removed = await store.retractFrom(state0(), messageId, identity.deviceId);
      await (await _convStore).touch(state0());
      return (content: target.content, removed: removed);
    } catch (e) {
      state = state.copyWith(error: '撤回失败：$e');
      return null;
    }
  }

  /// 删除单条消息（不同于撤回：只删这一条，不放回输入框，不动后续消息）。
  Future<bool> deleteSingleMessage(String messageId) async {
    try {
      final store = await _store;
      final identity = await _identity;
      final ok = await store.deleteSingle(state0(), messageId, identity.deviceId);
      if (ok) await (await _convStore).touch(state0());
      return ok;
    } catch (e) {
      state = state.copyWith(error: '删除失败：$e');
      return false;
    }
  }

  /// 批量删除单条消息（多选删除）：逐条走 store.deleteSingle，保证软删除+时钟同步。
  /// 返回实际删除的条数。
  Future<int> deleteMessages(Set<String> messageIds) async {
    try {
      final store = await _store;
      final identity = await _identity;
      var deleted = 0;
      for (final id in messageIds) {
        if (await store.deleteSingle(state0(), id, identity.deviceId)) deleted++;
      }
      if (deleted > 0) await (await _convStore).touch(state0());
      return deleted;
    } catch (e) {
      state = state.copyWith(error: '批量删除失败：$e');
      return 0;
    }
  }

  /// 批量删除消息附件：key = 消息 id，value = 要移除的附件 location(file_id) 集合。
  /// 走 touch + insertOrMerge，保证向量时钟递增、删除动作能同步到已配对设备。
  /// 返回实际删除的附件数量。
  Future<int> removeAttachments(Map<String, Set<String>> byMessage) async {
    try {
      final store = await _store;
      final identity = await _identity;
      var removed = 0;
      for (final entry in byMessage.entries) {
        final all = await store.readAll(state0());
        ChatMessage? target;
        for (final m in all) {
          if (m.id == entry.key) { target = m; break; }
        }
        if (target == null) continue;
        final kept = target.attachments
            .where((a) => !entry.value.contains(a.location))
            .toList(growable: false);
        final deletedCount = target.attachments.length - kept.length;
        if (deletedCount <= 0) continue;
        final updated = target.touch(identity.deviceId, newAttachments: kept);
        await store.insertOrMerge(updated);
        removed += deletedCount;
      }
      if (removed > 0) await (await _convStore).touch(state0());
      return removed;
    } catch (e) {
      state = state.copyWith(error: '删除附件失败：$e');
      return 0;
    }
  }

  Future<void> clearError() async => state = state.copyWith(clearError: true);
}

final chatControllerProvider = NotifierProvider.autoDispose
    .family<ChatController, ChatState, String>(ChatController.new);

/// 当前是否配置了 API Key。设置页据此提示用户。
final apiKeyConfiguredProvider = FutureProvider<bool>((ref) async {
  final prefs = await SharedPreferences.getInstance();
  return (prefs.getString('deepshart.deepseek_api_key') ?? '').isNotEmpty;
});

/// 保存 API Key 并让 aiProviderProvider 失效重建。
Future<void> saveApiKey(WidgetRef ref, String key) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('deepshart.deepseek_api_key', key.trim());
  ref.invalidate(aiProviderProvider);
  ref.invalidate(apiKeyConfiguredProvider);
}

/// 生成一个新会话 id。
///
/// 格式 conv-YYYYMMDDHHMMSS-UUID：
/// - 内嵌创建时间（年月日时分秒），肉眼可读、便于在设置页显示、肉眼避免撞车；
/// - 尾部仍保留 UUID 保证全局唯一（同一秒内建多个也不重复）。
String newConversationId() {
  final n = DateTime.now();
  String two(int v) => v.toString().padLeft(2, '0');
  final stamp = '${n.year}${two(n.month)}${two(n.day)}'
      '${two(n.hour)}${two(n.minute)}${two(n.second)}';
  return 'conv-$stamp-${const Uuid().v4()}';
}
