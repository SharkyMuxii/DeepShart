// target: lib/state/compression_controller.dart
// 职责：上下文压缩的 UI 状态——token 占用估算、压缩程度配置保存、手动/自动压缩执行。

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/models/conversation_settings.dart';
import '../import/context_compressor.dart';
import 'app_providers.dart';

class CompressionState {
  final bool compressing;
  final String? message;
  final int estimatedTokens;

  const CompressionState({
    this.compressing = false,
    this.message,
    this.estimatedTokens = 0,
  });

  CompressionState copyWith({
    bool? compressing,
    String? message,
    bool clearMessage = false,
    int? estimatedTokens,
  }) =>
      CompressionState(
        compressing: compressing ?? this.compressing,
        message: clearMessage ? null : (message ?? this.message),
        estimatedTokens: estimatedTokens ?? this.estimatedTokens,
      );
}

class CompressionController extends AutoDisposeFamilyNotifier<CompressionState, String> {
  late String _conversationId;

  @override
  CompressionState build(String conversationId) {
    _conversationId = conversationId;
    return const CompressionState();
  }

  /// 当前会话"实际会发出去"的 token 占用。
  ///
  /// 必须应用到压缩视图：库里原文一直全在，直接统计全量会得到"压缩后没省"
  /// 的错误结论（这正是上一版"报了省 8 万、界面没变"的根因）。
  Future<int> estimateTokens() async {
    final store = await ref.read(messageStoreProvider.future);
    final viewStore = await ref.read(compactionViewStoreProvider.future);
    final msgs = await store.readAll(_conversationId);
    final view = await viewStore.get(_conversationId);
    final effective = view == null ? msgs : view.materialize(msgs);
    final tokens = TokenEstimator.estimateMessages(effective);
    state = state.copyWith(estimatedTokens: tokens);
    return tokens;
  }

  /// 保存压缩程度设置（阈值 / 上下文上限 / 保留最近条数 / 开关）。
  Future<void> saveSettings(ConversationSettings settings) async {
    final store = await ref.read(conversationStoreProvider.future);
    await store.saveSettings(settings);
    ref.invalidate(settingsProvider(_conversationId));
  }

  /// 撤销压缩：删掉视图，原文立刻全部回来。
  Future<String> undo() async {
    final store = await ref.read(compactionViewStoreProvider.future);
    await store.delete(_conversationId);
    ref.invalidate(compactionViewProvider(_conversationId));
    await estimateTokens();
    return '已撤销压缩，全部原文已恢复';
  }

  /// 手动执行压缩。返回人类可读结果说明。
  ///
  /// 与旧实现的根本区别：不再改库。压缩只产出一份"视图"（哪些消息折叠、
  /// 哪些截断、摘要是什么），原文一条不动，用户随时可展开或一键撤销。
  Future<String> compressNow() async {
    state = state.copyWith(compressing: true, clearMessage: true);
    try {
      // 门禁：有未裁决冲突时禁止压缩。
      // 否则压缩基于的"历史"本身还没定稿，压完再裁决会出现"摘要描述的是
      // 已被丢弃的版本"，比不压更糟。
      final msgStore = await ref.read(messageStoreProvider.future);
      final pendingConflicts = await msgStore.watchConflicts().first;
      if (pendingConflicts.isNotEmpty) {
        final reason = '有 ${pendingConflicts.length} 处冲突尚未裁决，'
            '请先在顶部横幅里整体裁决，再压缩。';
        state = state.copyWith(compressing: false, message: reason);
        return reason;
      }

      final ai = await ref.read(aiProviderProvider.future);
      final identity = await ref.read(localIdentityProvider.future);
      final convStore = await ref.read(conversationStoreProvider.future);
      final memoryStore = await ref.read(memoryStoreProvider.future);
      final settings = await convStore.getSettings(_conversationId);
      final messages = await msgStore.readAll(_conversationId);
      // 被用户标记为重要记忆的内容一律不压：压缩的意义是省 token，不是删记忆。
      final memories = await memoryStore.watchAll(_conversationId).first;

      final compressor = ContextCompressor(provider: ai, store: msgStore);
      final outcome = await compressor.compress(
        conversationId: _conversationId,
        messages: messages,
        settings: settings,
        localDeviceId: identity.deviceId,
        memories: memories,
      );

      if (outcome.skipped || outcome.view == null) {
        final reason = outcome.skipReason ?? '没有可压缩的内容';
        state = state.copyWith(
          compressing: false,
          message: reason,
          estimatedTokens: outcome.beforeTokens,
        );
        return reason;
      }

      final viewStore = await ref.read(compactionViewStoreProvider.future);
      await viewStore.save(outcome.view!);

      // 以"应用视图后的真实消息集合"统计，与发送层口径一致。
      final effective = outcome.view!.materialize(messages);
      final after = TokenEstimator.estimateMessages(effective);
      final before = outcome.beforeTokens;
      final saved = before - after;

      final buffer = StringBuffer()
        ..write('压缩完成：$before → $after tokens')
        ..write(saved > 0 ? '（省 $saved）' : '（未减少，请调整档位或比例）')
        ..write(' · 折叠 ${outcome.deletedCount} 条')
        ..write(' / 截成片段 ${outcome.truncatedCount} 条')
        ..write(' · 原样保留最新 ${outcome.tailKeptCount} 条、最老 ${outcome.headKeptCount} 条');
      if (outcome.memoryProtectedCount > 0) {
        buffer.write('、记忆点 ${outcome.memoryProtectedCount} 条');
      }
      buffer.write('。原文全部保留，可随时撤销。');

      ref.invalidate(compactionViewProvider(_conversationId));
      ref.invalidate(messagesProvider(_conversationId));
      final result = buffer.toString();
      state = state.copyWith(
        compressing: false,
        message: result,
        estimatedTokens: after,
      );
      return result;
    } catch (e) {
      final msg = '压缩失败：$e';
      state = state.copyWith(compressing: false, message: msg);
      return msg;
    }
  }

  void clearMessage() => state = state.copyWith(clearMessage: true);
}

final compressionControllerProvider = NotifierProvider.autoDispose
    .family<CompressionController, CompressionState, String>(
  CompressionController.new,
);
