// target: lib/dev/pairing_selftest.dart
// 职责：命令行自检——在没有用户点击的情况下跑一遍配对建连，
//       用于确认 Windows 上"点按钮卡死闪退"是否仍然存在。
//
// 用法（仅开发/排障）：设置环境变量 DEEPSHART_SELFTEST=pair 后启动桌面端，
// 日志会以 [SELFTEST] 前缀输出到标准输出，结束后自动退出。

import 'dart:io';

import '../data/store/paired_device_store.dart';
import '../sync/pairing_service.dart';

class PairingSelfTest {
  PairingSelfTest._();

  static Future<void> run() async {
    // GUI 子系统的 Windows app 没有控制台，stdout 看不到；
    // 同时写一份文件，崩溃后也能从最后一行定位卡在哪一步。
    final logFile = File(
      '${Directory.systemTemp.path}${Platform.pathSeparator}deepshart_pairing_selftest.log',
    );
    if (logFile.existsSync()) logFile.deleteSync();

    void log(String message) {
      final line = '[SELFTEST] ${DateTime.now().toIso8601String()} $message';
      stdout.writeln(line);
      try {
        logFile.writeAsStringSync('$line\n', mode: FileMode.append, flush: true);
      } catch (_) {
        // 日志写不进去也不能影响自检本身。
      }
    }

    try {
      // 等 UI/插件注册完成再动 WebRTC，避免与启动阶段抢资源。
      await Future<void>.delayed(const Duration(seconds: 3));

      log('probing signaling');
      final probe = await PairingService.probeSignaling();
      log('probe => ${probe ?? 'ok'}');

      final service = PairingService(
        local: const LocalIdentity(deviceId: 'selftest-device', deviceName: 'SelfTest'),
        store: _NoopPairedDeviceStore(),
      );
      service.states.listen((state) {
        final detail = state is PairingRejected ? state.reason : '';
        log('state => ${state.runtimeType} $detail');
      });

      log('generateCode');
      await service.generateCode();
      await Future<void>.delayed(const Duration(seconds: 5));

      // 这一步会真正创建 RTCPeerConnection —— 历史上崩溃就发生在点击这里之后。
      log('enterCode (creates RTCPeerConnection)');
      await service.enterCode('000000');
      await Future<void>.delayed(const Duration(seconds: 20));

      log('done, no crash');
      await service.dispose();
      exit(0);
    } catch (e, st) {
      log('exception: $e\n$st');
      exit(1);
    }
  }
}

/// 自检不能污染真实的已配对列表。
class _NoopPairedDeviceStore implements PairedDeviceStore {
  @override
  Future<List<PairedDevice>> loadAll() async => const <PairedDevice>[];

  @override
  Future<void> upsert(PairedDevice device) async {}

  @override
  Future<void> remove(String deviceId) async {}
}
