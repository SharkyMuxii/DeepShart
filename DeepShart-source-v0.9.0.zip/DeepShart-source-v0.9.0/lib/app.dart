// target: lib/app.dart
// 职责：应用根组件——根据主题模式/强调色/字体配置 Material 主题，Riverpod 作用域、启动引导与路由。

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'core/palette.dart';
import 'core/theme.dart';
import 'routes/app_router.dart';
import 'state/app_bootstrap.dart';
import 'state/app_providers.dart';
import 'ui/agreement_gate.dart';
import 'ui/stale_file_dialog.dart';
import 'ui/sync_policy_dialog.dart';

/// GoRouter 是长生命周期对象，用顶层单例创建一次即可，避免 rebuild 时重复实例化。
final GoRouter _appRouter = createRouter();

class DeepShartApp extends ConsumerWidget {
  const DeepShartApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final bootstrap = ref.watch(bootstrapProvider);
    final mode = ref.watch(themeModeProvider).value ?? ThemeMode.system;
    final accent = ref.watch(accentColorProvider).value;
    final font = ref.watch(uiFontFamilyProvider).value;

    // system 模式跟随平台亮度；light/dark 强制指定。
    final platformBright = MediaQuery.platformBrightnessOf(context);
    final isDark = mode == ThemeMode.dark ||
        (mode == ThemeMode.system && platformBright == Brightness.dark);

    // 选基础色板，若有自定义强调色则覆盖 primary 三件套。
    final base = isDark ? kDarkPalette : kLightPalette;
    final palette = accent == null
        ? base
        : AppPalette(
            primary: accent,
            primaryDark: accent,
            primarySoft: isDark
                ? accent.withValues(alpha: 0.22)
                : accent.withValues(alpha: 0.12),
            background: base.background,
            surface: base.surface,
            outline: base.outline,
            textPrimary: base.textPrimary,
            textSecondary: base.textSecondary,
            danger: base.danger,
            brightness: base.brightness,
            // 锚点金色不随自定义强调色变化，沿用基础色板的金色系。
            anchorSurface: base.anchorSurface,
            anchorBorder: base.anchorBorder,
            anchorText: base.anchorText,
            anchorAccent: base.anchorAccent,
          );

    // 同步给全局 AppColors getter —— 必须在构建子树之前设置。
    AppRuntime.palette = palette;
    AppRuntime.fontFamily = font;

    final theme = AppTheme.build(palette);

    return MaterialApp.router(
      title: 'DeepShart',
      debugShowCheckedModeBanner: false,
      // 中文本地化：让文本选择菜单(Copy/Paste/Select all)显示为中文。
      locale: const Locale('zh', 'CN'),
      supportedLocales: const [
        Locale('zh', 'CN'),
        Locale('zh'),
        Locale('en'),
      ],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: theme,
      darkTheme: AppTheme.build(kDarkPalette),
      themeMode: mode,
      routerConfig: _appRouter,
      builder: (context, child) {
        // 引导期间显示轻量遮罩，完成后展示真实 UI。
        // 顶层常驻：用户协议门控 + 同步策略弹窗宿主，后台请求能立即弹出。
        final content = bootstrap.isLoading
            ? Directionality(
                textDirection: TextDirection.ltr,
                child: ColoredBox(
                  color: palette.background,
                  child: Center(child: CircularProgressIndicator()),
                ),
              )
            : (child ?? const SizedBox.shrink());
        return Stack(
          children: [
            content,
            const AgreementGate(),
            const SyncPolicyDialogHost(),
            const StaleFileDialogHost(),
          ],
        );
      },
    );
  }
}
