// target: lib/ui/font_picker_row.dart
// 职责：可复用的字体选择行——显示当前字体、提供"上传字体"与"恢复系统字体"。

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/font_service.dart';
import '../core/theme.dart';
import 'app_toast.dart';

class FontPickerRow extends ConsumerStatefulWidget {
  final String label;

  /// 当前选中的字体记录（null = 系统字体）。由父级提供，便于会话级覆盖。
  final FontRecord? current;

  /// 选中新字体（null = 恢复系统字体）时回调。父级负责持久化。
  final ValueChanged<FontRecord?> onChanged;

  const FontPickerRow({
    super.key,
    required this.label,
    required this.current,
    required this.onChanged,
  });

  @override
  ConsumerState<FontPickerRow> createState() => _FontPickerRowState();
}

class _FontPickerRowState extends ConsumerState<FontPickerRow> {
  bool _busy = false;

  Future<void> _pick() async {
    setState(() => _busy = true);
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['ttf', 'otf'],
        withData: false,
      );
      final path = result?.files.single.path;
      if (path == null) {
        if (mounted) setState(() => _busy = false);
        return;
      }
      final record = await FontService.importFont(path);
      widget.onChanged(record);
      if (mounted) showAppToast(context, '已应用字体：${record.label}');
    } catch (e) {
      if (mounted) showAppToast(context, '字体加载失败：$e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => ListTile(
        contentPadding: EdgeInsets.zero,
        leading: Icon(Icons.font_download, size: 20, color: AppColors.primary),
        title: Text(widget.label, style: const TextStyle(fontSize: 13)),
        subtitle: Text(
          widget.current?.label ?? '系统字体（默认）',
          style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
        ),
        trailing: _busy
            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
            : Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (widget.current != null)
                    IconButton(
                      icon: const Icon(Icons.restart_alt, size: 18),
                      tooltip: '恢复系统字体',
                      onPressed: () => widget.onChanged(null),
                    ),
                  TextButton(
                    onPressed: _pick,
                    child: const Text('上传', style: TextStyle(fontSize: 12)),
                  ),
                ],
              ),
      );
}
