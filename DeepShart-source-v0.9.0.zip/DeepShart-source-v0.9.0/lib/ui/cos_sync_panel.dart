// target: lib/ui/cos_sync_panel.dart
// 职责：腾讯云 COS 同步界面——同步方案切换、密钥配置（本机存储）、连接测试、
//       手动上传对话快照/备份、云端对象列表与下载。COS 模式下替代 P2P 配对界面。

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/theme.dart';
import '../sync/cos_sync_service.dart';
import 'app_toast.dart';
import 'cos_setup_tutorial.dart';
import '../state/app_providers.dart';
import '../state/cos_sync_provider.dart';

class CosSyncPanel extends ConsumerStatefulWidget {
  /// 是否显示顶部关闭按钮。push 出来的全屏页需要（默认 true），
  /// Windows 侧栏内嵌时传 false（用侧栏切换即可）。
  final bool showCloseButton;
  const CosSyncPanel({super.key, this.showCloseButton = true});

  @override
  ConsumerState<CosSyncPanel> createState() => _CosSyncPanelState();
}

class _CosSyncPanelState extends ConsumerState<CosSyncPanel> {
  final _secretId = TextEditingController();
  final _secretKey = TextEditingController();
  final _bucket = TextEditingController();
  final _region = TextEditingController(text: 'ap-guangzhou');
  final _deviceName = TextEditingController();
  bool _obscureKey = true;
  bool _busy = false;
  String? _testResult;
  List<CosObject> _remote = const <CosObject>[];
  bool _loaded = false;

  // 三个互不冲突的自动同步开关。
  final _intervalMinutes = TextEditingController();
  final _roundsCount = TextEditingController();
  bool _intervalEnabled = true;
  bool _roundsEnabled = false;
  bool _startupEnabled = true;

  // 历史版本容量上限。
  final _quotaValue = TextEditingController();
  String _quotaUnit = 'mb';

  // 云端文件多选（按 objectKey）。_deleteConfirmSuppressed 为进程级：本次启动勾选后不再弹确认。
  final Set<String> _selectedRemote = <String>{};
  static bool _deleteConfirmSuppressed = false;

  bool get _remoteMulti => _selectedRemote.isNotEmpty;

  /// 单个切换选中。点文件只影响这一个，绝不再"一点就全选到那里"。
  void _toggleRemote(int index) {
    final key = _remote[index].key;
    _update(() {
      if (_selectedRemote.contains(key)) {
        _selectedRemote.remove(key);
      } else {
        _selectedRemote.add(key);
      }
    });
  }

  /// 判定线"多选到此处"：由点击第 index 行【下方的分割线】触发，
  /// 选中"第一个已选文件 → 该文件"之间的全部。点文件本身不会走这里。
  void _rangeSelectTo(int index) {
    if (_selectedRemote.isEmpty || index < 0 || index >= _remote.length) return;
    int? first;
    for (var i = 0; i < _remote.length; i++) {
      if (_selectedRemote.contains(_remote[i].key)) { first = i; break; }
    }
    if (first == null) return;
    final lo = first < index ? first : index;
    final hi = first < index ? index : first;
    _update(() {
      for (var i = lo; i <= hi; i++) {
        _selectedRemote.add(_remote[i].key);
      }
    });
  }

  /// 多选态下可点击的分割线：点它触发"多选到此处"判定线。
  Widget _rangeDivider(int index, {required String tooltip}) {
    return Tooltip(
      message: tooltip,
      child: SizedBox(
        height: 16,
        child: Center(
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => _rangeSelectTo(index),
            child: Container(
              height: 18,
              color: Colors.transparent,
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Divider(height: 1, thickness: 1, color: AppColors.primary.withValues(alpha: 0.6)),
            ),
          ),
        ),
      ),
    );
  }

  void _update(VoidCallback fn) {
    if (mounted) setState(fn);
  }

  void _clearRemoteSelection() => _update(() => _selectedRemote.clear());

  @override
  void initState() {
    super.initState();
    final svc = ref.read(cosSyncServiceProvider);
    final cfg = svc.config;
    _secretId.text = cfg.secretId;
    _secretKey.text = cfg.secretKey;
    _bucket.text = cfg.bucket;
    _region.text = cfg.region;
    _deviceName.text = cosDeviceNameFromPrefs(svc.prefs);
    final auto = CosAutoSyncConfig.fromPrefs(svc.prefs);
    _intervalEnabled = auto.intervalEnabled;
    _intervalMinutes.text = '${auto.intervalMinutes}';
    _roundsEnabled = auto.roundsEnabled;
    _roundsCount.text = '${auto.rounds}';
    _startupEnabled = auto.startupEnabled;
    final quota = CosQuotaConfig.fromPrefs(svc.prefs);
    _quotaValue.text = '${quota.value}';
    // pb 已下线（上限锁 1TB）：老数据里的 pb 归一到 tb，避免下拉框 value 找不到。
    _quotaUnit = quota.unit == 'pb' ? 'tb' : quota.unit;
    if (cfg.isComplete) {
      // 配置完整时进页面就自动拉一次云端列表，避免"一直在加载/空白"。
      WidgetsBinding.instance.addPostFrameCallback((_) => _refreshRemote());
    }
  }

  @override
  void dispose() {
    _secretId.dispose();
    _secretKey.dispose();
    _bucket.dispose();
    _region.dispose();
    _deviceName.dispose();
    _intervalMinutes.dispose();
    _roundsCount.dispose();
    _quotaValue.dispose();
    super.dispose();
  }

  Future<void> _saveConfig() async {
    final prefs = await ref.read(sharedPrefsProvider.future);
    final cfg = CosConfig(
      secretId: _secretId.text.trim(),
      secretKey: _secretKey.text.trim(),
      bucket: _bucket.text.trim(),
      region: _region.text.trim().isEmpty ? 'ap-guangzhou' : _region.text.trim(),
    );
    await cfg.save(prefs);
    await saveCosDeviceName(prefs, _deviceName.text.trim());
    if (mounted) showAppToast(context, 'COS 配置已保存到本机');
  }

  /// 保存三个自动同步开关并让定时调度器立即按新配置重启。
  Future<void> _saveAutoSync() async {
    final prefs = await ref.read(sharedPrefsProvider.future);
    final cfg = CosAutoSyncConfig(
      intervalEnabled: _intervalEnabled,
      intervalMinutes: int.tryParse(_intervalMinutes.text.trim()) ?? 30,
      roundsEnabled: _roundsEnabled,
      rounds: int.tryParse(_roundsCount.text.trim()) ?? 5,
      startupEnabled: _startupEnabled,
    );
    await cfg.save(prefs);
    // 定时调度器重新读取间隔开关；三个开关互不冲突，各自独立生效。
    ref.read(cosAutoSyncSchedulerProvider).restart();
    if (mounted) showAppToast(context, '自动同步设置已保存');
  }

  /// 保存历史版本容量上限，并立即按新上限清理一次云端旧快照。
  Future<void> _saveQuota() async {
    final prefs = await ref.read(sharedPrefsProvider.future);
    final cfg = CosQuotaConfig(
      value: double.tryParse(_quotaValue.text.trim()) ?? 500,
      unit: _quotaUnit,
    );
    await cfg.save(prefs);
    if (cfg.bytes > 0) {
      await ref.read(cosSyncCoordinatorProvider).enforceHistoryQuota();
    }
    if (mounted) {
      showAppToast(context, cfg.bytes == 0
          ? '历史版本容量已设为不限制'
          : '历史版本容量已保存，超限的旧快照已清理');
    }
  }

  Future<void> _test() async {
    await _saveConfig();
    setState(() { _busy = true; _testResult = null; });
    final (ok, msg) = await ref.read(cosSyncServiceProvider).testConnection();
    if (mounted) setState(() { _busy = false; _testResult = msg; });
  }

  Future<void> _uploadSnapshot() async {
    setState(() => _busy = true);
    try {
      await ref.read(cosSyncCoordinatorProvider).uploadSnapshot();
      if (mounted) showAppToast(context, '对话快照已上传到 COS');
    } catch (e) {
      if (mounted) showAppToast(context, '上传失败：$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _uploadBackups() async {
    setState(() => _busy = true);
    try {
      final n = await ref.read(cosSyncCoordinatorProvider).uploadBackups();
      if (mounted) showAppToast(context, '已上传 $n 个备份到 COS');
    } catch (e) {
      if (mounted) showAppToast(context, '备份上传失败：$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _refreshRemote() async {
    setState(() { _busy = true; });
    try {
      // 20 秒超时：网络不通/密钥错时不能让界面永远转圈（用户实测"一直加载"）。
      final list = await ref
          .read(cosSyncCoordinatorProvider)
          .listRemote()
          .timeout(const Duration(seconds: 20));
      if (mounted) setState(() { _remote = list; _loaded = true; _selectedRemote.clear(); });
    } catch (e) {
      if (mounted) {
        setState(() => _loaded = true); // 失败也算"加载完"，避免状态卡住
        showAppToast(context, '读取云端列表失败（可重试）：$e');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _merge(CosObject o) async {
    setState(() => _busy = true);
    try {
      final report = await ref.read(cosSyncCoordinatorProvider).syncWithRemote(o.key, '云端快照 · ${o.deviceTag}');
      if (report.error != null) {
        if (mounted) showAppToast(context, report.error!);
        return;
      }
      if (mounted) {
        showAppToast(context, report.summary);
        // 合并后刷新会话/消息流，让新内容立刻出现。
        ref.invalidate(conversationsProvider);
      }
    } catch (e) {
      if (mounted) showAppToast(context, '合并失败：$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  /// 删除确认弹窗。勾选"本次启动不再显示"后置进程级标记，关软件前都不再弹。
  Future<bool> _confirmDeleteRemote(int count) async {
    if (_deleteConfirmSuppressed) return true;
    var suppress = false;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('删除云端文件'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('确定要删除选中的 $count 个云端文件吗？此操作不可撤销。'),
              const SizedBox(height: 10),
              Row(
                children: [
                  SizedBox(
                    width: 20,
                    height: 20,
                    child: Checkbox(
                      value: suppress,
                      onChanged: (v) => setS(() => suppress = v ?? false),
                    ),
                  ),
                  const SizedBox(width: 4),
                  const Text('本次启动不再显示', style: TextStyle(fontSize: 12)),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
              onPressed: () {
                if (suppress) _deleteConfirmSuppressed = true;
                Navigator.pop(ctx, true);
              },
              child: const Text('确认删除'),
            ),
          ],
        ),
      ),
    );
    return ok ?? false;
  }

  /// 删除单个（非多选态下的删除按钮）。
  Future<void> _deleteSingle(CosObject o) async {
    final ok = await _confirmDeleteRemote(1);
    if (!ok || !mounted) return;
    setState(() => _busy = true);
    try {
      await ref.read(cosSyncServiceProvider).deleteObject(o.key);
      await _refreshRemote();
      if (mounted) showAppToast(context, '已删除云端文件');
    } catch (e) {
      if (mounted) showAppToast(context, '删除失败：$e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  /// 批量删除所选。
  Future<void> _deleteSelected() async {
    if (_selectedRemote.isEmpty) return;
    final count = _selectedRemote.length;
    final ok = await _confirmDeleteRemote(count);
    if (!ok || !mounted) return;
    final keys = Set<String>.from(_selectedRemote);
    setState(() => _busy = true);
    var deleted = 0;
    try {
      final svc = ref.read(cosSyncServiceProvider);
      for (final key in keys) {
        try { await svc.deleteObject(key); deleted++; } catch (_) {}
      }
      _clearRemoteSelection();
      await _refreshRemote();
      if (mounted) showAppToast(context, '已删除 $deleted 个云端文件');
    } catch (e) {
      if (mounted) showAppToast(context, '删除失败：$e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _downloadAsBackup(CosObject o) async {
    setState(() => _busy = true);
    try {
      await ref.read(cosSyncCoordinatorProvider).downloadToBackups(o.key);
      if (mounted) showAppToast(context, '已下载到本地备份，可在「备份」页查看');
    } catch (e) {
      if (mounted) showAppToast(context, '下载失败：$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final mode = ref.watch(syncModeProvider);
    // 电脑用右键进入多选，手机/平板用长按——避免电脑上长按不顺手。
    final isDesktop = switch (Theme.of(context).platform) {
      TargetPlatform.windows || TargetPlatform.macOS || TargetPlatform.linux => true,
      _ => false,
    };
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: widget.showCloseButton
          ? AppBar(
              title: const Text('云同步'),
              centerTitle: true,
              automaticallyImplyLeading: false,
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                tooltip: '返回',
                onPressed: () => Navigator.of(context).pop(),
              ),
              actions: [
                IconButton(
                  icon: const Icon(Icons.close),
                  tooltip: '关闭',
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ],
            )
          : null,
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (!widget.showCloseButton)
            Text('云同步', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
          const SizedBox(height: 4),
          Text('当前方案：${mode.label}。切换方案请到「全局设置 → 同步方案」。',
              style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.primarySoft,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text('启用 COS 时 P2P 配对与直连已彻底关闭，本页即替代配对界面；反之亦然。',
                style: TextStyle(fontSize: 12, color: AppColors.textPrimary)),
          ),
          const Divider(height: 28),

          if (mode == SyncMode.cos) ...[
            const CosSetupTutorial(),
            const SizedBox(height: 20),
            Text('COS 配置', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
            const SizedBox(height: 4),
            Text('密钥只保存在本机，不会写入安装包或上传到任何第三方。请用你自己的腾讯云密钥。',
                style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
            const SizedBox(height: 12),
            TextField(
              controller: _secretId,
              decoration: const InputDecoration(labelText: 'SecretId', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _secretKey,
              obscureText: _obscureKey,
              decoration: InputDecoration(
                labelText: 'SecretKey',
                border: const OutlineInputBorder(),
                suffixIcon: IconButton(
                  icon: Icon(_obscureKey ? Icons.visibility : Icons.visibility_off),
                  onPressed: () => setState(() => _obscureKey = !_obscureKey),
                ),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _bucket,
              decoration: const InputDecoration(labelText: 'Bucket 名称（如 xxx-1234567890）', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _region,
              decoration: const InputDecoration(labelText: 'Region（如 ap-guangzhou）', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _deviceName,
              decoration: const InputDecoration(
                labelText: '设备名称（上传文件用它标注来源，如"我的手机"）',
                helperText: '留空则用系统默认设备名',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                FilledButton.icon(
                  icon: const Icon(Icons.link),
                  label: const Text('测试'),
                  onPressed: _busy ? null : _test,
                ),
                const SizedBox(width: 10),
                OutlinedButton.icon(
                  icon: const Icon(Icons.save_outlined),
                  label: const Text('保存'),
                  onPressed: _busy ? null : _saveConfig,
                ),
              ],
            ),
            if (_testResult != null)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text(_testResult!,
                    style: TextStyle(fontSize: 12, color: AppColors.textPrimary)),
              ),
            const SizedBox(height: 16),
            // 历史版本容量上限：输入框填数字 + 选择框选单位。
            Text('历史版本容量上限',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
            const SizedBox(height: 4),
            Text('默认 500MB，最大 1TB。超出后自动删除最老的快照版本。填 0 表示不限制。',
                style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
            const SizedBox(height: 2),
            Text('填写数值请勿大于您的腾讯云服务最大储存数值（超过 1TB 将按 1TB 处理）。',
                style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
            const SizedBox(height: 8),
            // Wrap：窄屏时"保存上限"按钮自动换到下一行，不再被挤出屏幕。
            Wrap(
              spacing: 10,
              runSpacing: 8,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                SizedBox(
                  width: 110,
                  child: TextField(
                    controller: _quotaValue,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                        isDense: true, contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                        border: OutlineInputBorder(), labelText: '数值'),
                  ),
                ),
                DropdownButton<String>(
                  value: _quotaUnit,
                  onChanged: (v) => setState(() => _quotaUnit = v ?? 'mb'),
                  items: const [
                    DropdownMenuItem(value: 'kb', child: Text('KB')),
                    DropdownMenuItem(value: 'mb', child: Text('MB')),
                    DropdownMenuItem(value: 'tb', child: Text('TB')),
                  ],
                ),
                OutlinedButton.icon(
                  icon: const Icon(Icons.save_outlined, size: 16),
                  label: const Text('保存上限'),
                  onPressed: _busy ? null : _saveQuota,
                ),
              ],
            ),
            const Divider(height: 28),

            // 三个互不冲突的自动同步开关。
            Text('自动同步', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
            const SizedBox(height: 4),
            Text('三个开关互不冲突，可任意组合。全局同步行为在「全局设置 → 默认同步行为」中配置。',
                style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
            const SizedBox(height: 10),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('每隔一段时间自动同步'),
              subtitle: Row(
                children: [
                  const Text('每 '),
                  SizedBox(
                    width: 56,
                    child: TextField(
                      controller: _intervalMinutes,
                      keyboardType: TextInputType.number,
                      textAlign: TextAlign.center,
                      decoration: const InputDecoration(
                          isDense: true, contentPadding: EdgeInsets.symmetric(vertical: 6)),
                    ),
                  ),
                  const Text(' 分钟一次'),
                ],
              ),
              value: _intervalEnabled,
              onChanged: (v) => setState(() => _intervalEnabled = v),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('每发送若干条对话自动同步'),
              subtitle: Row(
                children: [
                  const Text('每 '),
                  SizedBox(
                    width: 56,
                    child: TextField(
                      controller: _roundsCount,
                      keyboardType: TextInputType.number,
                      textAlign: TextAlign.center,
                      decoration: const InputDecoration(
                          isDense: true, contentPadding: EdgeInsets.symmetric(vertical: 6)),
                    ),
                  ),
                  const Text(' 条对话一次'),
                ],
              ),
              value: _roundsEnabled,
              onChanged: (v) => setState(() => _roundsEnabled = v),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('每次开启软件时自动同步'),
              subtitle: const Text('打开应用时拉取各设备最新快照'),
              value: _startupEnabled,
              onChanged: (v) => setState(() => _startupEnabled = v),
            ),
            const SizedBox(height: 4),
            Align(
              alignment: Alignment.centerLeft,
              child: FilledButton.tonalIcon(
                icon: const Icon(Icons.save_outlined, size: 16),
                label: const Text('保存自动同步设置'),
                onPressed: _saveAutoSync,
              ),
            ),
            const Divider(height: 28),

            Text('手动同步', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
            const SizedBox(height: 4),
            Text('也可随时手动上传快照、上传备份或刷新云端列表。',
                style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                FilledButton.icon(
                  icon: const Icon(Icons.cloud_upload_outlined),
                  label: const Text('上传对话快照'),
                  onPressed: _busy ? null : _uploadSnapshot,
                ),
                OutlinedButton.icon(
                  icon: const Icon(Icons.backup_outlined),
                  label: const Text('上传备份'),
                  onPressed: _busy ? null : _uploadBackups,
                ),
                OutlinedButton.icon(
                  icon: const Icon(Icons.refresh),
                  label: const Text('刷新云端列表'),
                  onPressed: _busy ? null : _refreshRemote,
                ),
              ],
            ),
            if (_busy) const Padding(
              padding: EdgeInsets.only(top: 12),
              child: LinearProgressIndicator(),
            ),
            const Divider(height: 28),

            Row(
              children: [
                Text('云端文件', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                const Spacer(),
                // 多选前的删除入口（点一下进入多选：勾选第一个文件即可）。
                if (_remote.isNotEmpty && !_remoteMulti)
                  TextButton.icon(
                    icon: const Icon(Icons.delete_outline, size: 16),
                    label: const Text('删除'),
                    onPressed: _busy ? null : () {
                      _update(() => _selectedRemote.add(_remote.first.key));
                    },
                  ),
              ],
            ),
            const SizedBox(height: 8),
            if (!_loaded)
              Text('点"刷新云端列表"查看已上传的快照与备份。',
                  style: TextStyle(fontSize: 12, color: AppColors.textSecondary))
            else if (_remote.isEmpty)
              Text('云端暂无文件。',
                  style: TextStyle(fontSize: 12, color: AppColors.textSecondary))
            else
              Column(
                children: _remote.asMap().entries.map((entry) {
                  final index = entry.key;
                  final o = entry.value;
                  final checked = _selectedRemote.contains(o.key);
                  // 第一条文件【上方】的分割线：多选态可点，用于"多选到此处"（选到第一条）。
                  final topLine = _remoteMulti && !_busy
                      ? _rangeDivider(0, tooltip: '多选到第一条')
                      : const Divider(height: 1);
                  return Column(
                    children: [
                      topLine,
                      InkWell(
                        // 手机长按进入多选；电脑用右键（见 onSecondaryTapDown）。
                        onLongPress: isDesktop || _busy ? null : () => _toggleRemote(index),
                        onSecondaryTapDown: isDesktop && !_busy
                            ? (_) => _toggleRemote(index)
                            : null,
                        // 多选态点文件只切换这一个，不再"一点就全选到那里"。
                        onTap: _remoteMulti && !_busy ? () => _toggleRemote(index) : null,
                        child: Row(
                          children: [
                            // 多选态：勾选圈；非多选态：文件图标。都是固定宽度。
                            SizedBox(
                              width: 30,
                              child: _remoteMulti
                                  ? Icon(
                                      checked ? Icons.check_box : Icons.check_box_outline_blank,
                                      color: AppColors.primary, size: 20)
                                  : Icon(
                                      o.key.contains('/snapshots/') ? ICONS_SNAPSHOT : ICONS_BACKUP,
                                      color: AppColors.primary, size: 20),
                            ),
                            // 文件名用 Expanded + ellipsis：再长也不会把操作列挤出屏幕。
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(o.deviceTag,
                                      style: TextStyle(fontSize: 13, color: AppColors.textPrimary),
                                      maxLines: 1, overflow: TextOverflow.ellipsis),
                                  Text(
                                    '${o.fileName} · ${(o.size / 1024).toStringAsFixed(1)} KB',
                                    style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                                    maxLines: 1, overflow: TextOverflow.ellipsis),
                                ],
                              ),
                            ),
                            // 操作列固定宽度，不受文件名长度影响。
                            SizedBox(
                              width: _remoteMulti ? 0 : 108,
                              child: _remoteMulti
                                  ? null
                                  : Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        IconButton(
                                          icon: Icon(Icons.merge_type, size: 20, color: AppColors.primary),
                                          tooltip: '按全局默认同步行为合并到本地',
                                          onPressed: _busy ? null : () => _merge(o),
                                        ),
                                        IconButton(
                                          icon: const Icon(Icons.download_outlined, size: 20),
                                          tooltip: '仅下载到本地备份（不合并）',
                                          onPressed: _busy ? null : () => _downloadAsBackup(o),
                                        ),
                                        IconButton(
                                          icon: Icon(Icons.delete_outline, size: 20, color: AppColors.danger),
                                          tooltip: '删除这个云端文件',
                                          onPressed: _busy ? null : () => _deleteSingle(o),
                                        ),
                                      ],
                                    ),
                            ),
                          ],
                        ),
                      ),
                      // 每条文件【下方】的分割线：多选态可点，"多选到此处"（选到这一条）。
                      _remoteMulti && !_busy
                          ? _rangeDivider(index, tooltip: '多选到此处')
                          : const Divider(height: 1),
                    ],
                  );
                }).toList(),
              ),
            // 多选底部固定栏：全选/取消多选并列第一行，删除第二行——避免窄屏挤出。
            if (_remoteMulti)
              Container(
                margin: const EdgeInsets.only(top: 8),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                decoration: BoxDecoration(
                  color: AppColors.primarySoft,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        TextButton(
                          onPressed: () => _update(() =>
                              _selectedRemote.addAll(_remote.map((x) => x.key))),
                          child: const Text('全选'),
                        ),
                        TextButton(onPressed: _clearRemoteSelection, child: const Text('取消多选')),
                        const Spacer(),
                        Text('已选 ${_selectedRemote.length} 项',
                            style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                      ],
                    ),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        icon: const Icon(Icons.delete_outline, size: 16),
                        label: Text('删除所选 ${_selectedRemote.length} 个'),
                        style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
                        onPressed: _busy ? null : _deleteSelected,
                      ),
                    ),
                  ],
                ),
              ),
          ] else
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text('P2P 模式下请使用"配对"页面连接另一台设备。切换为 COS 后可使用云同步。',
                  style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            ),
        ],
      ),
    );
  }
}

// 用常量避免每次重建都创建 IconData。
const ICONS_SNAPSHOT = Icons.storage_rounded;
const ICONS_BACKUP = Icons.settings_backup_restore;
