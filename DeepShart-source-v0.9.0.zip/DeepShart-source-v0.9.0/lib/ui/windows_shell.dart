// target: lib/ui/windows_shell.dart
// 职责：Windows 宽屏外壳——NavigationRail + 真实会话列表 + 配对面板；列表项支持右键菜单。

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/app_info.dart';
import '../core/theme.dart';
import '../data/store/conversation_store.dart';
import '../export/batch_export.dart';
import '../state/app_providers.dart';
import '../state/chat_controller.dart';
import '../state/cos_sync_provider.dart';
import 'chat_screen.dart';
import 'cos_sync_panel.dart';
import 'app_toast.dart';
import 'balance_widget.dart';
import 'conversation_list.dart';
import 'export_sheet.dart';
import 'global_settings_sheet.dart';
import 'import_sheet.dart';
import 'pairing_panel.dart';
import 'scroll_to_bottom_button.dart';
import 'search_results_view.dart';

class WindowsShell extends ConsumerStatefulWidget {
  /// 路由传入的占位 child；本外壳按选中的会话自行渲染 ChatScreen。
  final Widget? child;

  const WindowsShell({super.key, this.child});

  @override
  ConsumerState<WindowsShell> createState() => _WindowsShellState();
}

class _WindowsShellState extends ConsumerState<WindowsShell> {
  int _railIndex = 0;
  String? _selectedId;
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  final ScrollController _listScrollController = ScrollController();
  bool _listMultiSelect = false; // 多选时抬高滚动按钮，避免与底部操作栏重叠。
  bool _syncing = false; // 一键同步进行中，防连点。
  bool _startupHandled = false; // 启动时的空对话检测只做一次，避免 build 里重复创建。

  /// 会话列表顶部的一键同步按钮：COS 下同步，P2P 下切到配对页。
  Future<void> _oneTapSync() async {
    if (_syncing) return;
    setState(() => _syncing = true);
    try {
      final report = await ref.read(cosSyncCoordinatorProvider).syncNow();
      ref.invalidate(conversationsProvider);
      if (!mounted) return;
      if (report.error != null) {
        showAppToast(context, report.error!);
      } else {
        showAppToast(context, '同步完成 · ${report.summary}');
      }
    } catch (e) {
      if (mounted) showAppToast(context, '同步失败：$e');
    } finally {
      if (mounted && _syncing) setState(() => _syncing = false);
    }
  }

  /// 搜索跳转目标：会话 id + 消息 id。设置后切换会话并让 ChatScreen 定位。
  String? _jumpConversationId;
  String? _jumpMessageId;

  void _jumpToMessage(String conversationId, String messageId) {
    _jumpConversationId = conversationId;
    _jumpMessageId = messageId;
    _selectedId = conversationId;
    ref.read(currentConversationIdProvider.notifier).state = conversationId;
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _searchController.dispose();
    _listScrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final conversationsAsync = ref.watch(conversationsProvider);
    final conversations = conversationsAsync.value ?? <Conversation>[];
    final isCos = ref.watch(syncModeProvider) == SyncMode.cos;
    final syncLabel = isCos ? '云同步' : '配对';

    // 启动时对话选中（只做一次）：草稿会话优先（保护"选完文件回来"的修复），
    // 否则打开一个空白新对话；若一个空对话都没有，自动新建并跳转。
    if (_selectedId == null && !_startupHandled && conversationsAsync.hasValue) {
      _startupHandled = true;
      final withDraft = conversations.where(
        (c) => ref.read(draftAttachmentsProvider(c.id)).isNotEmpty,
      );
      final blank = conversations.where((c) => c.title.startsWith('新对话')).firstOrNull;
      if (withDraft.isNotEmpty) {
        _selectedId = withDraft.first.id;
        ref.read(currentConversationIdProvider.notifier).state = _selectedId!;
      } else if (blank != null) {
        _selectedId = blank.id;
        ref.read(currentConversationIdProvider.notifier).state = _selectedId!;
      } else {
        // 没有任何空对话：自动创建一个并跳转。build 里不能同步 await，unawaited 走起。
        unawaited(_createConversation());
      }
    }

    return Scaffold(
      body: Row(
        children: [
          NavigationRail(
            selectedIndex: _railIndex,
            onDestinationSelected: (i) => setState(() => _railIndex = i),
            labelType: NavigationRailLabelType.all,
            leading: Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: Tooltip(
                message: '${AppInfo.name}\n${AppInfo.tagline}',
                child: Image.asset(
                  'assets/icons/shark_small.png',
                  width: 34,
                  height: 34,
                  filterQuality: FilterQuality.high,
                ),
              ),
            ),
            destinations: [
              NavigationRailDestination(
                icon: Icon(Icons.chat_bubble_outline),
                selectedIcon: Icon(Icons.chat_bubble),
                label: Text('会话'),
              ),
              NavigationRailDestination(
                icon: Icon(isCos ? Icons.cloud_outlined : Icons.link_off),
                selectedIcon: Icon(isCos ? Icons.cloud : Icons.link),
                label: Text(syncLabel),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.settings_outlined),
                selectedIcon: Icon(Icons.settings),
                label: Text('设置'),
              ),
            ],
            trailing: Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // 余额放在侧栏底部（全局设置下方），点一下刷新。
                  const RailBalance(),
                  const SizedBox(height: 6),
                  Text(
                    AppInfo.author,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.textSecondary, fontSize: 10),
                  ),
                  Text(
                    AppInfo.version,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.textSecondary, fontSize: 9),
                  ),
                ],
              ),
            ),
          ),
          VerticalDivider(width: 1, color: AppColors.outline),
          SizedBox(
            width: 280,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Text(['会话', syncLabel, '设置'][_railIndex],
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      const Spacer(),
                      if (_railIndex == 0) ...[
                        // 导入按钮左边：COS 下一键同步，P2P 下为配对（切到配对页）。
                        isCos
                            ? IconButton(
                                icon: _syncing
                                    ? const SizedBox(
                                        width: 20, height: 20,
                                        child: CircularProgressIndicator(strokeWidth: 2))
                                    : const Icon(Icons.cloud_sync_outlined, size: 20),
                                tooltip: '一键同步',
                                onPressed: _syncing ? null : _oneTapSync,
                              )
                            : IconButton(
                                icon: const Icon(Icons.link, size: 20),
                                tooltip: '配对',
                                onPressed: () => setState(() => _railIndex = 1),
                              ),
                        IconButton(
                          icon: const Icon(Icons.file_upload, size: 20),
                          tooltip: '导入对话',
                          onPressed: _showImport,
                        ),
                        IconButton(
                          icon: const Icon(Icons.add),
                          tooltip: '新建会话',
                          onPressed: _createConversation,
                        ),
                      ],
                    ],
                  ),
                ),
                if (_railIndex == 0)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                    child: TextField(
                      controller: _searchController,
                      decoration: const InputDecoration(
                        hintText: '搜索会话…',
                        prefixIcon: Icon(Icons.search, size: 18),
                        isDense: true,
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                      ),
                      style: const TextStyle(fontSize: 12),
                      onChanged: (v) => setState(() => _searchQuery = v.trim().toLowerCase()),
                    ),
                  ),
                Expanded(
                  child: _railIndex == 0
                      ? Stack(
                          children: [
                            _searchQuery.isNotEmpty
                                ? SearchResultsView(
                                    query: _searchQuery,
                                    onJump: _jumpToMessage,
                                  )
                                : conversationsAsync.when(
                              loading: () => const Center(child: CircularProgressIndicator()),
                              error: (e, _) => Center(child: Text('加载失败: $e')),
                              data: (list) => ConversationListContent(
                                  scrollController: _listScrollController,
                                  conversations: list
                                      .map((c) => ConversationItem(
                                            id: c.id,
                                            title: c.title,
                                            updatedAt: c.updatedAt,
                                            pinned: c.pinned,
                                          ))
                                      .toList(),
                                  selectedId: _selectedId,
                                  onTap: (item) => _switchConversation(item.id),
                                  onShowActions: _handleActions,
                                  onActionSelected: (item, action) => _runAction(item, action),
                                  onBatchDelete: _batchDeleteConversations,
                                  onBatchExport: _batchExportConversations,
                                  onMultiSelectChanged: (v) => setState(() => _listMultiSelect = v),
                                ),
                            ),
                            ScrollToBottomButton(
                              controller: _listScrollController,
                              direction: ScrollJumpDirection.both,
                              bottomOffset: _listMultiSelect ? 58 : 16,
                            ),
                          ],
                        )
                      : _railIndex == 1
                          // COS 模式下用 COS 面板替代 P2P 配对界面（两者互斥）。
                          ? (ref.watch(syncModeProvider) == SyncMode.cos
                              ? const CosSyncPanel(showCloseButton: false)
                              : const PairingPanel())
                          : const _WindowsGlobalSettings(),
                ),
              ],
            ),
          ),
          VerticalDivider(width: 1, color: AppColors.outline),
          Expanded(
            child: _selectedId != null
                ? ChatScreen(
                    key: ValueKey('$_selectedId-${_jumpMessageId ?? ''}'),
                    conversationId: _selectedId!,
                    jumpToMessageId: _selectedId == _jumpConversationId ? _jumpMessageId : null,
                  )
                : Center(
                    child: Text('请选择或新建一个会话',
                        style: TextStyle(color: AppColors.textSecondary)),
                  ),
          ),
        ],
      ),
    );
  }

  Future<void> _createConversation() async {
    final store = await ref.read(conversationStoreProvider.future);
    final id = newConversationId();
    final now = DateTime.now();
    final conv = Conversation.create(id: id, title: '新对话 ${now.month}/${now.day}');
    await store.upsert(conv);
    ref.invalidate(conversationsProvider);
    _selectedId = id;
    ref.read(currentConversationIdProvider.notifier).state = id;
    if (mounted) setState(() {});
  }

  /// 切换会话：切走时若当前是"空白新对话"（一条消息都没有），就顺手删掉，
  /// 避免对话列表堆一坨"新对话 新对话 新对话"（用户明确要求）。
  Future<void> _switchConversation(String newId) async {
    final previous = _selectedId;
    if (previous != null && previous != newId) {
      final store = await ref.read(conversationStoreProvider.future);
      final conv = await store.get(previous);
      if (conv != null && conv.title.startsWith('新对话')) {
        // 有未发送附件草稿或正在上传时，绝不当空白对话删除——
        // 否则选完图切走会把附件连同会话一起删掉，文件被发到错误的地方。
        final hasDraft = ref.read(draftAttachmentsProvider(previous)).isNotEmpty;
        final isSending = ref.read(sendingInProgressProvider(previous));
        final messages = await (await ref.read(messageStoreProvider.future)).readAll(previous);
        if (messages.isEmpty && !hasDraft && !isSending) {
          await store.delete(previous);
          ref.invalidate(conversationsProvider);
        }
      }
    }
    _selectedId = newId;
    ref.read(currentConversationIdProvider.notifier).state = newId;
    if (mounted) setState(() {});
  }

  void _handleActions(ConversationItem item, Offset position) {
    // details.globalPosition 已经是全局坐标，showMenu 的 position 也是相对 overlay 的
    // 全局坐标——之前又叠加了一次 RenderBox 原点，菜单会飘到屏幕外。
    showMenu<String>(
      context: context,
      position: RelativeRect.fromLTRB(
        position.dx,
        position.dy,
        position.dx + 1,
        position.dy + 1,
      ),
      items: [
        PopupMenuItem(
          value: 'pin',
          child: Row(
            children: [
              Icon(item.pinned ? Icons.push_pin : Icons.push_pin_outlined,
                  size: 16, color: AppColors.primary),
              const SizedBox(width: 8),
              Text(item.pinned ? '取消置顶' : '置顶'),
            ],
          ),
        ),
        const PopupMenuItem(value: 'rename', child: Text('备注')),
        const PopupMenuItem(value: 'export', child: Text('导出对话')),
        PopupMenuItem(
          value: 'delete',
          child: Text('删除', style: TextStyle(color: AppColors.danger)),
        ),
      ],
    ).then((value) {
      if (!mounted || value == null) return;
      _runAction(item, value);
    });
  }

  Future<void> _runAction(ConversationItem item, String action) async {
    final store = await ref.read(conversationStoreProvider.future);
    if (!mounted) return;

    if (action == 'pin') {
      final conv = await store.get(item.id);
      if (conv != null) {
        await store.upsert(conv.copyWith(pinned: !conv.pinned));
        ref.invalidate(conversationsProvider);
      }
      return;
    }

    if (action == 'export') {
      _showExport(item.id);
      return;
    }

    if (action == 'rename') {
      final newTitle = await showRenameDialog(context, item.title);
      if (newTitle != null && newTitle.isNotEmpty) {
        final conv = await store.get(item.id);
        if (conv != null) {
          await store.upsert(conv.copyWith(title: newTitle));
          ref.invalidate(conversationsProvider);
        }
      }
      return;
    }

    if (action == 'delete') {
      final confirmed = await showDeleteConfirmDialog(context, item.title);
      if (!confirmed) return;
      await store.delete(item.id);
      ref.invalidate(conversationsProvider);
      if (_selectedId == item.id) {
        setState(() => _selectedId = null);
      }
      if (mounted) {
        showAppToast(context, '已删除会话「${item.title}」');
      }
    }
  }

  /// 多选批量删除会话。
  Future<void> _batchDeleteConversations(Set<String> ids) async {
    final store = await ref.read(conversationStoreProvider.future);
    for (final id in ids) {
      await store.delete(id);
    }
    ref.invalidate(conversationsProvider);
    if (_selectedId != null && ids.contains(_selectedId)) {
      setState(() => _selectedId = null);
    }
    if (mounted) showAppToast(context, '已删除 ${ids.length} 个会话');
  }

  /// 批量导出所选会话为单个 JSON 文件。
  Future<void> _batchExportConversations(Set<String> ids) async {
    try {
      final result = await exportConversationsByIds(ref, ids);
      if (!mounted || result.path == null) return;
      showAppToast(context, '已导出 ${result.count} 个会话到：${result.path}',
          duration: const Duration(seconds: 5));
    } catch (e) {
      if (mounted) showAppToast(context, '导出失败：$e');
    }
  }

  void _showImport() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => const ImportSheet(),
    );
  }

  void _showExport(String conversationId) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => ExportSheet(conversationId: conversationId),
    );
  }
}

/// Windows 侧边栏内嵌的全局设置面板。
class _WindowsGlobalSettings extends StatelessWidget {
  const _WindowsGlobalSettings();

  @override
  Widget build(BuildContext context) => GlobalSettingsSheet.content();
}
