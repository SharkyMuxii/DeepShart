// target: lib/ui/conversation_list.dart
// 职责：共享的对话列表内容组件——两平台共用列表渲染，手势容器由各自外壳提供。
// 支持长按/右键进入多选批量删除；每条会话显示最后更新时间。

import 'package:flutter/material.dart';

import '../core/theme.dart';

@immutable
class ConversationItem {
  final String id;
  final String title;
  final String? lastMessage;
  final DateTime? updatedAt;
  final bool pinned;

  const ConversationItem({
    required this.id,
    required this.title,
    this.lastMessage,
    this.updatedAt,
    this.pinned = false,
  });
}

/// 把时间格式化成简短标签：今天显示 HH:mm，昨天显示"昨天"，更早显示 M/d。
String formatConversationTime(DateTime? t) {
  if (t == null) return '';
  final local = t.toLocal();
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);
  final day = DateTime(local.year, local.month, local.day);
  final hhmm = '${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';
  if (day == today) return hhmm;
  if (day == today.subtract(const Duration(days: 1))) return '昨天';
  return '${local.month}/${local.day}';
}

/// 对话列表内容。不含导航外壳——右键（Windows）/长按（Android）由手势触发。
class ConversationListContent extends StatefulWidget {
  final List<ConversationItem> conversations;
  final String? selectedId;
  final ValueChanged<ConversationItem> onTap;

  /// 由外壳注入：传入 item 与触发位置，弹出对应平台的菜单/BottomSheet。
  /// 多选模式下不会调用（改为切换选中）。
  final void Function(ConversationItem item, Offset position) onShowActions;

  /// 桌面端的"⋮"按钮选择结果（rename / pin / export / delete）。
  final void Function(ConversationItem item, String action)? onActionSelected;

  /// 批量删除回调：外壳执行实际删除并刷新列表。返回后组件退出多选模式。
  final Future<void> Function(Set<String> ids)? onBatchDelete;

  /// 批量导出回调：外壳把所有选中会话导出为一个文件。
  final Future<void> Function(Set<String> ids)? onBatchExport;

  /// 多选状态变化通知：外壳据此关闭"一键到顶/到底"悬浮按钮，避免与底部操作栏重叠。
  final void Function(bool multiSelect)? onMultiSelectChanged;

  /// 由外壳传入的滚动控制器，供"一键到底"悬浮按钮使用。
  final ScrollController? scrollController;

  const ConversationListContent({
    super.key,
    required this.conversations,
    this.selectedId,
    required this.onTap,
    required this.onShowActions,
    this.onActionSelected,
    this.onBatchDelete,
    this.onBatchExport,
    this.onMultiSelectChanged,
    this.scrollController,
  });

  @override
  State<ConversationListContent> createState() => _ConversationListContentState();
}

class _ConversationListContentState extends State<ConversationListContent> {
  final Set<String> _selected = <String>{};
  bool get _multiSelect => _selected.isNotEmpty;

  /// 修改选中态后统一同步给外壳（外壳据此开关滚动按钮，防重叠）。
  void _update(void Function() fn) {
    if (!mounted) return;
    setState(fn);
    widget.onMultiSelectChanged?.call(_multiSelect);
  }

  void _handleLongPress(ConversationItem item, Offset position) {
    if (widget.onBatchDelete == null) {
      widget.onShowActions(item, position);
      return;
    }
    _update(() {
      if (_selected.contains(item.id)) {
        _selected.remove(item.id);
      } else {
        _selected.add(item.id);
      }
    });
  }

  void _clear() => _update(() => _selected.clear());

  Future<void> _confirmBatchDelete() async {
    final count = _selected.length;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('删除 $count 个会话？'),
        content: const Text('这些会话及其聊天记录会被删除，此操作不可撤销。'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('取消')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('删除'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final ids = Set<String>.from(_selected);
    await widget.onBatchDelete?.call(ids);
    if (mounted) _clear();
  }

  /// 判定线：选中"第一个被选中的项 → 当前 index"之间的全部会话。
  void _selectRangeTo(int index) {
    if (_selected.isEmpty) {
      _update(() => _selected.add(widget.conversations[index].id));
      return;
    }
    // 找第一个已选项在列表中的位置。
    int? first;
    for (var i = 0; i < widget.conversations.length; i++) {
      if (_selected.contains(widget.conversations[i].id)) { first = i; break; }
    }
    if (first == null) {
      _update(() => _selected.add(widget.conversations[index].id));
      return;
    }
    final lo = first < index ? first : index;
    final hi = first < index ? index : first;
    _update(() {
      for (var i = lo; i <= hi; i++) {
        _selected.add(widget.conversations[i].id);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (widget.conversations.isEmpty && !_multiSelect) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text('暂无会话，点击 + 新建',
              style: TextStyle(color: AppColors.textSecondary)),
        ),
      );
    }
    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            controller: widget.scrollController,
            itemCount: widget.conversations.length,
            itemBuilder: (context, index) {
              final item = widget.conversations[index];
              final selected = item.id == widget.selectedId;
              final checked = _selected.contains(item.id);
              return Column(
                children: [
              GestureDetector(
                // 关键：Windows 上右键必须用 onSecondaryTapDown 才能拿到位置。
                onSecondaryTapDown: (details) =>
                    _handleLongPress(item, details.globalPosition),
                onLongPressStart: (details) =>
                    _handleLongPress(item, details.globalPosition),
                child: ListTile(
                  selected: selected || checked,
                  selectedTileColor: checked ? AppColors.primarySoft : null,
                  leading: _multiSelect
                      ? Icon(
                          checked ? Icons.check_box : Icons.check_box_outline_blank,
                          color: AppColors.primary,
                          size: 20,
                        )
                      : null,
                  title: Row(
                    children: [
                      if (item.pinned)
                        Padding(
                          padding: const EdgeInsets.only(right: 4),
                          child: Icon(Icons.push_pin, size: 13, color: AppColors.primary),
                        ),
                      Expanded(
                        child: Text(
                          item.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontWeight: selected ? FontWeight.w600 : FontWeight.normal,
                            color: AppColors.textPrimary,
                          ),
                        ),
                      ),
                      // 时间标注：显示最后一条消息/会话更新时间。
                      if (item.updatedAt != null)
                        Text(
                          formatConversationTime(item.updatedAt),
                          style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                        ),
                    ],
                  ),
                  subtitle: item.lastMessage == null
                      ? null
                      : Text(
                          item.lastMessage!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(color: AppColors.textSecondary, fontSize: 12),
                        ),
                  onTap: () {
                    if (_multiSelect) {
                      _update(() {
                        if (_selected.contains(item.id)) {
                          _selected.remove(item.id);
                        } else {
                          _selected.add(item.id);
                        }
                      });
                    } else {
                      widget.onTap(item);
                    }
                  },
                  trailing: (!_multiSelect && widget.onActionSelected != null)
                      ? PopupMenuButton<String>(
                          icon: Icon(Icons.more_vert, size: 18, color: AppColors.textSecondary),
                          tooltip: '会话操作',
                          onSelected: (value) => widget.onActionSelected!(item, value),
                          itemBuilder: (context) => [
                            PopupMenuItem(
                              value: 'pin',
                              child: Row(
                                children: [
                                  Icon(item.pinned ? Icons.push_pin : Icons.push_pin_outlined,
                                      size: 16, color: AppColors.primary),
                                  const SizedBox(width: 8),
                                  Text(item.pinned ? '取消置顶' : '置顶'),
                                ],
                              ),
                            ),
                            const PopupMenuItem(value: 'rename', child: Text('备注')),
                            const PopupMenuItem(value: 'export', child: Text('导出对话')),
                            PopupMenuItem(
                              value: 'delete',
                              child: Text('删除', style: TextStyle(color: AppColors.danger)),
                            ),
                          ],
                        )
                      : null,
                ),
              ),
              // 判定线：多选时每条下方一条可点细线，点击即选中"首个选中项 → 本条"的连续区间。
              // 参考微信/QQ 多选聊天记录的"选至此"，此线位于列表项内部，
              // 不与一键到顶/到底悬浮按钮重叠。
              if (_multiSelect)
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => _selectRangeTo(index),
                  child: Container(
                    height: 14,
                    color: Colors.transparent,
                    alignment: Alignment.center,
                    child: Container(
                      height: 2,
                      margin: const EdgeInsets.symmetric(horizontal: 16),
                      color: AppColors.primary.withValues(alpha: checked ? 0.7 : 0.28),
                    ),
                  ),
                ),
                ],
              );
            },
          ),
        ),
        // 多选底部固定栏：取消 / 全选 / 复制 / 删除。
        // 放在 Expanded 之外，故不会与列表内的滚动悬浮按钮重叠。
        if (_multiSelect)
          Container(
            decoration: BoxDecoration(
              color: AppColors.surface,
              border: Border(top: BorderSide(color: AppColors.outline)),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
            child: SafeArea(
              top: false,
              // 固定两行布局：窄侧栏（~250px）也能完整显示所有操作按钮。
              // 之前用 Row 不换行，导出/删除被挤出屏幕（用户实测反馈）。
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      // 全选 + 取消多选并列，放在第一行最前面（用户要求）。
                      TextButton(
                        onPressed: () => _update(() {
                          _selected.addAll(widget.conversations.map((c) => c.id));
                        }),
                        child: const Text('全选'),
                      ),
                      TextButton.icon(
                        icon: const Icon(Icons.close, size: 16),
                        label: const Text('取消多选'),
                        onPressed: _clear,
                      ),
                      const Spacer(),
                      Text('已选 $_selected.length 项',
                          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600,
                              color: AppColors.textPrimary)),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 38,
                          child: FilledButton.tonalIcon(
                            icon: const Icon(Icons.file_download_outlined, size: 16),
                            label: const Text('导出所选', style: TextStyle(fontSize: 12)),
                            onPressed: _selected.isEmpty || widget.onBatchExport == null
                                ? null
                                : () => widget.onBatchExport!(Set<String>.from(_selected)),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: SizedBox(
                          height: 38,
                          child: FilledButton.tonalIcon(
                            icon: const Icon(Icons.delete_outline, size: 16),
                            label: const Text('删除所选', style: TextStyle(fontSize: 12)),
                            style: FilledButton.styleFrom(foregroundColor: AppColors.danger),
                            onPressed: _selected.isEmpty ? null : _confirmBatchDelete,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

/// 重命名对话框，两平台共用。
Future<String?> showRenameDialog(BuildContext context, String currentTitle) =>
    showDialog<String>(
      context: context,
      builder: (context) {
        final controller = TextEditingController(text: currentTitle);
        return AlertDialog(
          title: const Text('重命名会话'),
          content: TextField(
            controller: controller,
            autofocus: true,
            decoration: const InputDecoration(labelText: '会话标题'),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('取消')),
            FilledButton(
              onPressed: () => Navigator.pop(context, controller.text.trim()),
              child: const Text('保存'),
            ),
          ],
        );
      },
    );

/// 删除确认对话框——文案包含对话标题。
Future<bool> showDeleteConfirmDialog(BuildContext context, String title) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('删除会话'),
      content: Text('确定要删除会话「$title」吗？此操作不可撤销。'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('取消')),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
          onPressed: () => Navigator.pop(context, true),
          child: const Text('删除'),
        ),
      ],
    ),
  );
  return result ?? false;
}
