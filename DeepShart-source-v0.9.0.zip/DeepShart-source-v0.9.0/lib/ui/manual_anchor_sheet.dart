// target: lib/ui/manual_anchor_sheet.dart
// 职责：让用户标注"一段AI说的话"和"一段人说的话"，作为确定【角色标记】和
// 【时间格式】的锚点。相比让大模型猜整篇格式，用户亲手标的正文前紧邻的那串
// （如 【AI】[2026-11-19 19:44]）就是最可靠的分段信号。
//
// 双端可用设计（电脑 + 手机）：
//  - 方式一（主）：两个可编辑输入框，用户把那两段话【粘贴/直接输入】进去。
//    手机端长按粘贴、电脑端复制粘贴都可靠，是主要路径。
//  - 方式二（辅助）：上方预览区提供 SelectableText + 导航按钮，电脑端可拖选后
//    一键填入；手机端拖选难用时直接用方式一即可。
//  - 提交时用标注文本在原文里定位（indexOf），取其前面紧邻的"标记头"。

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/theme.dart';

/// 用户手动标注的结果。
@immutable
class ManualAnchors {
  /// 参与标注的原文片段（最多前 10000 字符）。
  final String excerpt;

  /// 用户标注的 AI 正文（纯正文）。
  final String aiSample;

  /// 用户标注的人（用户）正文（纯正文）。
  final String humanSample;

  /// AI 样本在 excerpt 中的起点。
  final int aiStart;

  /// 人样本在 excerpt 中的起点。
  final int humanStart;

  /// AI 样本前紧邻的串（角色标记 + 时间戳），如 "【AI】[2026-11-19 19:44]"。
  final String aiHead;

  /// 人样本前紧邻的串，如 "【我】[2026-11-19 19:44]"。
  final String humanHead;

  const ManualAnchors({
    required this.excerpt,
    required this.aiSample,
    required this.humanSample,
    required this.aiStart,
    required this.humanStart,
    required this.aiHead,
    required this.humanHead,
  });

  bool get isValid => aiSample.trim().isNotEmpty && humanSample.trim().isNotEmpty;
}

/// 从原文 [excerpt] 里定位 [sample]，取其前紧邻的标记头。
/// 供窗口与测试复用——返回 null 表示 sample 在原文里找不到。
ManualAnchors? buildManualAnchors({
  required String excerpt,
  required String aiSample,
  required String humanSample,
}) {
  final ai = aiSample.trim();
  final human = humanSample.trim();
  if (ai.isEmpty || human.isEmpty) return null;
  final aiStart = excerpt.indexOf(ai);
  final humanStart = excerpt.indexOf(human);
  if (aiStart < 0 || humanStart < 0) return null;
  return ManualAnchors(
    excerpt: excerpt,
    aiSample: ai,
    humanSample: human,
    aiStart: aiStart,
    humanStart: humanStart,
    aiHead: _headAt(excerpt, aiStart),
    humanHead: _headAt(excerpt, humanStart),
  );
}

/// 取正文 [start] 前紧邻的"标记头"（角色标记 + 时间戳）。
/// 支持两种排版：标记与正文同行、标记独占上一行。
String _headAt(String text, int start) {
  var lineStart = start;
  while (lineStart > 0 && text[lineStart - 1] != '\n') {
    lineStart--;
  }
  final sameLine = text.substring(lineStart, start).trim();
  // 标记行通常很短；过长说明这是正文中间，往上找真正的标记行。
  if (sameLine.isNotEmpty && sameLine.length <= 30) return sameLine;

  var end = lineStart;
  while (end > 0) {
    final prevEnd = end - 1;
    var prevStart = prevEnd;
    while (prevStart > 0 && text[prevStart - 1] != '\n') {
      prevStart--;
    }
    final line = text.substring(prevStart, prevEnd).trim();
    if (line.isNotEmpty) return line;
    end = prevStart;
  }
  return '';
}

/// 弹出手动标注窗口，返回用户标注结果；用户取消返回 null。
Future<ManualAnchors?> showManualAnchorSheet(
  BuildContext context, {
  required String excerpt,
}) {
  return Navigator.of(context).push<ManualAnchors>(
    MaterialPageRoute<ManualAnchors>(
      fullscreenDialog: true,
      builder: (_) => ManualAnchorSheet(excerpt: excerpt),
    ),
  );
}

class ManualAnchorSheet extends StatefulWidget {
  final String excerpt;
  const ManualAnchorSheet({super.key, required this.excerpt});

  @override
  State<ManualAnchorSheet> createState() => _ManualAnchorSheetState();
}

class _ManualAnchorSheetState extends State<ManualAnchorSheet> {
  static const int _maxChars = 10000;

  late final String _text;
  final TextEditingController _aiController = TextEditingController();
  final TextEditingController _humanController = TextEditingController();
  final ScrollController _previewController = ScrollController();

  TextSelection? _selection;

  @override
  void initState() {
    super.initState();
    _text = widget.excerpt.length > _maxChars
        ? widget.excerpt.substring(0, _maxChars)
        : widget.excerpt;
  }

  @override
  void dispose() {
    _aiController.dispose();
    _humanController.dispose();
    _previewController.dispose();
    super.dispose();
  }

  String get _selectedText {
    final sel = _selection;
    if (sel == null || !sel.isValid || sel.start >= sel.end) return '';
    return _text.substring(sel.start, sel.end).trim();
  }

  void _fillAi() {
    final s = _selectedText;
    if (s.isEmpty) {
      _hint('请先在上方文字里拖选一段');
      return;
    }
    _aiController.text = s;
  }

  void _fillHuman() {
    final s = _selectedText;
    if (s.isEmpty) {
      _hint('请先在上方文字里拖选一段');
      return;
    }
    _humanController.text = s;
  }

  void _hint(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), duration: const Duration(seconds: 2)),
    );
  }

  void _copyPreview() {
    Clipboard.setData(ClipboardData(text: _text));
    _hint('已复制全部文字，可粘贴到下方输入框');
  }

  void _finish() {
    final anchors = buildManualAnchors(
      excerpt: _text,
      aiSample: _aiController.text,
      humanSample: _humanController.text,
    );
    if (anchors == null) {
      _hint('两段都要标注，且文字必须能在上方原文里找到（可直接粘贴原文片段）');
      return;
    }
    Navigator.of(context).pop(anchors);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        title: const Text('手动标注角色'),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // 强调说明。
            Container(
              margin: const EdgeInsets.fromLTRB(16, 12, 16, 6),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFEBEE),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFFFCDD2)),
              ),
              child: const Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.priority_high, size: 18, color: Color(0xFFC62828)),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      '请在下方标出【一段 AI 说的话】和【一段你说的话】。'
                      '只填说的话本身，不要把角色名（如「我」「AI」）和时间戳写进去！'
                      '系统会看你标的内容前面紧邻的标记，自动学会区分角色和时间。'
                      '电脑可拖选后点"填入"，手机可直接长按粘贴或手动输入。',
                      style: TextStyle(fontSize: 12, height: 1.5, color: Color(0xFFB71C1C)),
                    ),
                  ),
                ],
              ),
            ),
            // 原文预览区。
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Text('原文预览（前 ${_text.length} 字）',
                      style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                  const Spacer(),
                  TextButton.icon(
                    onPressed: _copyPreview,
                    icon: const Icon(Icons.copy_all, size: 14),
                    label: const Text('复制全部', style: TextStyle(fontSize: 11)),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 130,
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 16),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.background,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColors.outline),
                ),
                child: SingleChildScrollView(
                  controller: _previewController,
                  child: SelectableText(
                    _text,
                    style: TextStyle(fontSize: 12, height: 1.5, color: AppColors.textPrimary),
                    onSelectionChanged: (selection, cause) {
                      setState(() => _selection = selection);
                    },
                  ),
                ),
              ),
            ),
            // 电脑端拖选快捷填入。
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 6, 16, 2),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _fillAi,
                      icon: const Icon(Icons.arrow_downward, size: 14),
                      label: const Text('将选中内容填入下方「AI 说的话」中',
                          style: TextStyle(fontSize: 11)),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _fillHuman,
                      icon: const Icon(Icons.arrow_downward, size: 14),
                      label: const Text('将选中内容填入下方「用户（我）说的话」中',
                          style: TextStyle(fontSize: 11)),
                    ),
                  ),
                ],
              ),
            ),
            // 两个标注输入框（主输入方式，双端可靠）。
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                child: Column(
                  children: [
                    _buildInput(
                      controller: _aiController,
                      label: '① AI 说的话（粘贴一段它的回复）',
                      hint: '例：(*突然停住*) 你好呀',
                      color: const Color(0xFF1565C0),
                    ),
                    const SizedBox(height: 10),
                    _buildInput(
                      controller: _humanController,
                      label: '② 你说的话（粘贴一段你的发言）',
                      hint: '例：不会的小鱼，我会记得你的',
                      color: const Color(0xFF2E7D32),
                    ),
                  ],
                ),
              ),
            ),
            // 提交按钮。
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
              child: SizedBox(
                width: double.infinity,
                height: 46,
                child: FilledButton.icon(
                  icon: const Icon(Icons.check_circle),
                  label: const Text('两段都标好了，开始识别'),
                  onPressed: _finish,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInput({
    required TextEditingController controller,
    required String label,
    required String hint,
    required Color color,
  }) {
    return TextField(
      controller: controller,
      maxLines: 3,
      style: const TextStyle(fontSize: 13, height: 1.5),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(fontSize: 12, color: color),
        hintText: hint,
        hintStyle: TextStyle(fontSize: 12, color: AppColors.textSecondary),
        filled: true,
        fillColor: AppColors.background,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: color, width: 1.5),
        ),
      ),
    );
  }
}
