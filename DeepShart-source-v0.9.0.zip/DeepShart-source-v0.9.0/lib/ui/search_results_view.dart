// target: lib/ui/search_results_view.dart
// 职责：跨会话搜索结果列表——按会话分组、默认折叠，展开后每次只显示一条命中，
//       点"下一条"继续浏览。点命中项跳转对应会话并定位到那条消息。
//
// 用户要求：
//   - 时间点越早的搜索结果排越后（分组与组内都已按时间倒序）。
//   - 每个会话的结果默认折叠；不折叠时每个对话只显示一个结果。

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/theme.dart';
import '../state/app_providers.dart';
import 'message_search.dart';

/// [onJump] 回调：跳到某会话的某条消息。
class SearchResultsView extends ConsumerStatefulWidget {
  final String query;
  final void Function(String conversationId, String messageId) onJump;

  const SearchResultsView({
    super.key,
    required this.query,
    required this.onJump,
  });

  @override
  ConsumerState<SearchResultsView> createState() => _SearchResultsViewState();
}

class _SearchResultsViewState extends ConsumerState<SearchResultsView> {
  /// 展开的会话集合（默认全折叠）。
  final Set<String> _expanded = <String>{};

  /// 每个会话当前显示到第几条命中（默认第 0 条）。
  final Map<String, int> _hitIndex = <String, int>{};

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(messageSearchProvider(widget.query));
    return async.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('搜索失败: $e',
          style: TextStyle(color: AppColors.danger))),
      data: (groups) {
        if (groups.isEmpty) {
          return Center(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text('没有找到匹配的消息',
                  style: TextStyle(color: AppColors.textSecondary)),
            ),
          );
        }
        final total = groups.fold<int>(0, (s, g) => s + g.hits.length);
        return ListView.builder(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 16),
          itemCount: groups.length + 1,
          itemBuilder: (context, index) {
            if (index == 0) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Text('找到 $total 条结果 · ${groups.length} 个会话',
                    style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
              );
            }
            return _GroupCard(
              group: groups[index - 1],
              expanded: _expanded.contains(groups[index - 1].conversationId),
              hitIndex: _hitIndex[groups[index - 1].conversationId] ?? 0,
              onToggle: () => setState(() {
                final id = groups[index - 1].conversationId;
                if (!_expanded.add(id)) _expanded.remove(id);
              }),
              onNext: () => setState(() {
                final id = groups[index - 1].conversationId;
                final max = groups[index - 1].hits.length - 1;
                _hitIndex[id] = ((_hitIndex[id] ?? 0) + 1).clamp(0, max);
              }),
              onPrev: () => setState(() {
                final id = groups[index - 1].conversationId;
                _hitIndex[id] = ((_hitIndex[id] ?? 0) - 1).clamp(0, 999);
              }),
              onJump: widget.onJump,
            );
          },
        );
      },
    );
  }
}

class _GroupCard extends StatelessWidget {
  final SearchGroup group;
  final bool expanded;
  final int hitIndex;
  final VoidCallback onToggle;
  final VoidCallback onNext;
  final VoidCallback onPrev;
  final void Function(String conversationId, String messageId) onJump;

  const _GroupCard({
    required this.group,
    required this.expanded,
    required this.hitIndex,
    required this.onToggle,
    required this.onNext,
    required this.onPrev,
    required this.onJump,
  });

  @override
  Widget build(BuildContext context) {
    final hit = group.hits[hitIndex.clamp(0, group.hits.length - 1)];
    final time = hit.message.createdAt.toLocal();
    String two(int v) => v.toString().padLeft(2, '0');
    final timeLabel = '${two(time.month)}-${two(time.day)} ${two(time.hour)}:${two(time.minute)}';

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 会话标题行：点击折叠/展开。
          InkWell(
            onTap: onToggle,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              child: Row(
                children: [
                  Icon(Icons.forum_outlined, size: 16, color: AppColors.primary),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(group.conversationTitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                  ),
                  Text('${group.hits.length} 条',
                      style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                  Icon(expanded ? Icons.expand_less : Icons.expand_more,
                      size: 18, color: AppColors.textSecondary),
                ],
              ),
            ),
          ),
          if (expanded) ...[
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(timeLabel,
                          style: TextStyle(fontSize: 10, color: AppColors.textSecondary)),
                      const Spacer(),
                      Text('${hitIndex + 1}/${group.hits.length}',
                          style: TextStyle(fontSize: 10, color: AppColors.textSecondary)),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(hit.snippet,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 12, height: 1.5)),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_upward, size: 16),
                        tooltip: '上一条',
                        onPressed: hitIndex > 0 ? onPrev : null,
                      ),
                      IconButton(
                        icon: const Icon(Icons.arrow_downward, size: 16),
                        tooltip: '下一条',
                        onPressed: hitIndex < group.hits.length - 1 ? onNext : null,
                      ),
                      TextButton.icon(
                        icon: const Icon(Icons.open_in_new, size: 14),
                        label: const Text('跳转', style: TextStyle(fontSize: 12)),
                        onPressed: () =>
                            onJump(group.conversationId, hit.message.id),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
