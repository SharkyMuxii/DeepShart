// target: lib/ui/chat_screen.dart
// 职责：共享聊天内容区——真实消息流、发送消息到 AI、思考/引用分区渲染、能力开关、设置与冲突裁决入口。

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';

import '../ai/ai_provider.dart' show AiCitation;
import '../ai/citation_codec.dart';
import 'attachment_browser_sheet.dart';
import '../ai/context_budget.dart' show BudgetReport;
import '../core/theme.dart';
import 'app_toast.dart';
import 'scroll_to_bottom_button.dart';
import '../data/models/chat_message.dart';
import '../data/models/conflict_record.dart';
import '../data/store/message_store.dart' show ConflictMergeStrategy;
import '../state/app_providers.dart';
import '../state/chat_controller.dart';
import 'compression_sheet.dart';
import 'conflict_resolution_sheet.dart';
import 'global_settings_sheet.dart';
import 'markdown_view.dart';
import 'settings_sheet.dart';

/// 聊天内容区。Windows 与 Android 外壳都把它作为 child 复用。
class ChatScreen extends ConsumerStatefulWidget {
  final String conversationId;

  /// 从搜索结果跳转时要定位的消息 id。命中消息可能在 20 条渲染窗口之外，
  /// 此时会自动扩展 _visibleCount 把它纳入窗口并滚动到它。
  final String? jumpToMessageId;

  const ChatScreen({
    super.key,
    required this.conversationId,
    this.jumpToMessageId,
  });

  @override
  ConsumerState<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends ConsumerState<ChatScreen> {
  final TextEditingController _inputController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _inputFocus = FocusNode();

  /// 桌面端（Windows/macOS/Linux）右键由气泡接管进多选，禁系统菜单；
  /// 手机端保留系统选择菜单，方便选中文字后复制。
  bool get _isDesktop => Platform.isWindows || Platform.isMacOS || Platform.isLinux;

  /// 消息多选：右键（电脑）/长按（手机）气泡进入。选中消息 id 集合。
  final Set<String> _selectedMessageIds = <String>{};
  bool get _messageMultiSelect => _selectedMessageIds.isNotEmpty;
  void _clearMessageSelection() => setState(() => _selectedMessageIds.clear());

  /// 附件草稿存在全局 provider（按会话隔离），不再放 State 里。
  /// 这样选图/拍照期间若发生会话切换，附件不会丢、也不会挂到错误的会话。
  List<DraftAttachment> get _attachments =>
      ref.read(draftAttachmentsProvider(widget.conversationId));

  void _setAttachments(List<DraftAttachment> list) {
    ref.read(draftAttachmentsProvider(widget.conversationId).notifier).state = list;
  }

  void _addAttachment(DraftAttachment a) {
    final next = List<DraftAttachment>.from(_attachments)..add(a);
    _setAttachments(next);
  }

  bool _thinkingEnabled = false;
  bool _searchEnabled = false;

  /// 渲染上限：一次只画最近 N 条，往上翻到顶再加一屏，防止长对话把界面拖死。
  /// 具体值从全局设置读（默认 20），加载后初始化一次。
  int _visibleCount = 20;
  bool _renderLimitLoaded = false;
  bool _loadingMore = false;
  String? _jumpHandled;
  final GlobalKey _jumpTargetKey = GlobalKey();

  /// 是否展开被压缩折叠的原文。
  ///
  /// 折叠只是"本次不发给模型"，原文一直在库里。默认收起（视觉上体现压缩确实
  /// 生效了），点一下就能看到全部原文——这正是"不偷偷篡改记忆"的可见证据。
  bool _showFolded = false;

  /// 冲突弹窗的防抖定时器。
  ///
  /// 为什么必须防抖：一次同步产生的冲突是逐条落库的，冲突流会连续推送几千次。
  /// 如果每次变化都弹窗，就会堆几千个模态框——界面直接卡死（用户实测）。
  Timer? _conflictDebounce;

  /// 是否已有裁决弹窗在显示，避免叠第二层。
  bool _conflictSheetOpen = false;

  /// 用户选了"稍后再说"后，在冲突清零之前不再自动打扰，只保留顶部横幅。
  bool _conflictAutoSuppressed = false;

  @override
  void initState() {
    super.initState();
    // 往上翻到顶时加载更多（默认每次再加一屏，由全局设置决定上限）。
    _scrollController.addListener(() {
      if (_loadingMore || !_scrollController.hasClients) return;
      if (_scrollController.position.pixels <= 40 &&
          _scrollController.position.extentBefore <= 0) {
        // 已经到顶，且还有更早的消息没显示。
        if (_allMessageCount > _visibleCount) {
          _loadMore();
        }
      }
    });
  }

  /// 完整消息数（含折叠隐藏的），由 build 时更新，供"加载更多"判断。
  int _allMessageCount = 0;

  /// 上一帧的流式正文长度，用于检测新内容到达时自动滚到底。
  int _lastStreamingLength = 0;

  @override
  void didUpdateWidget(ChatScreen old) {
    super.didUpdateWidget(old);
    // 流式生成中：每次正文变长就滚到底，让新字始终可见。
    final current = ref.read(chatControllerProvider(widget.conversationId)).streamingAnswer?.length ?? 0;
    if (current > _lastStreamingLength && current > 0) {
      _lastStreamingLength = current;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scrollController.hasClients) {
          _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
        }
      });
    }
    if (current == 0) _lastStreamingLength = 0;
  }

  void _loadMore() {
    _loadingMore = true;
    final before = _visibleCount;
    _visibleCount = (_visibleCount + 20).clamp(0, _allMessageCount);
    // 保持当前滚动位置：加载后列表变长，视觉上不应跳动。
    final offset = _scrollController.hasClients ? _scrollController.offset : 0;
    setState(() {});
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.jumpTo(offset + 20 * 72); // 粗略每条 72px，抵消顶部新增高度
      }
      _loadingMore = false;
    });
    assert(before <= _visibleCount);
  }

  @override
  void dispose() {
    _conflictDebounce?.cancel();
    _inputController.dispose();
    _scrollController.dispose();
    _inputFocus.dispose();
    super.dispose();
  }

  /// 从会话设置的 FontRecord JSON 里取出字族名。
  static String? _decodeFontFamily(String? raw) {
    if (raw == null || raw.isEmpty) return null;
    try {
      final map = jsonDecode(raw) as Map<String, dynamic>;
      return map['family'] as String?;
    } catch (_) {
      return null;
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final messagesAsync = ref.watch(messagesProvider(widget.conversationId));
    final conflictsAsync = ref.watch(conflictsProvider);
    final chatState = ref.watch(chatControllerProvider(widget.conversationId));
    final compactionViewAsync = ref.watch(compactionViewProvider(widget.conversationId));
    final aiAsync = ref.watch(aiProviderProvider);
    final renderLimitAsync = ref.watch(chatRenderLimitProvider);

    // 字体：会话级设置优先，否则用全局；都为空则系统字体（null）。
    final globalAiFont = ref.watch(fontAiProvider).value;
    final globalUserFont = ref.watch(fontUserProvider).value;
    final settings = ref.watch(settingsProvider(widget.conversationId)).value;
    String? aiFontFamily = globalAiFont?.family;
    String? userFontFamily = globalUserFont?.family;
    if (settings != null) {
      final convAi = _decodeFontFamily(settings.aiFont);
      final convUser = _decodeFontFamily(settings.userFont);
      if (convAi != null) aiFontFamily = convAi;
      if (convUser != null) userFontFamily = convUser;
    }
    if (!_renderLimitLoaded) {
      renderLimitAsync.whenData((limit) {
        _visibleCount = limit.clamp(5, 500);
        _renderLimitLoaded = true;
      });
    }
    // 响应式读取：保存 API Key 后 saveApiKey 会 invalidate 该 provider，
    // 这里会立即重建，避免"填了 Key 仍提示未配置、点发送还弹设置"的陈旧状态问题。
    final providerReady = ref.watch(apiKeyConfiguredProvider).value ?? false;
    final supportsThinking = aiAsync.value?.supportsThinking ?? false;
    final supportsSearch = aiAsync.value?.supportsSearch ?? false;
    final supportsFiles = aiAsync.value?.supportsFileUpload ?? false;
    final isMobile = Platform.isAndroid || Platform.isIOS;

    final pendingConflicts = conflictsAsync.value
            ?.where((c) => c.status == ConflictStatus.pending)
            .toList() ??
        const <ConflictRecord>[];

    // 同步产生冲突时主动弹一次"整体裁决"窗口：之前只有顶部横幅，用户很容易错过，
    // 结果两边数据一直"没同步"。但一次同步上千条差异时绝不能逐条弹（会卡死），
    // 所以这里只做一件事：等这一轮冲突落库结束，弹唯一一个窗口。
    _syncConflictAutoPrompt(pendingConflicts);

    return Column(
      children: [
        ConflictBanner(
          conflictCount: pendingConflicts.length,
          onTap: () => _openConflictResolution(pendingConflicts),
        ),
        if (!providerReady) _buildApiKeyHint(),
        Expanded(
          child: messagesAsync.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, _) => Center(child: Text('加载失败: $e')),
            data: (rawMessages) {
              if (rawMessages.isEmpty) {
                return Center(
                  child: Text('开始一段新对话', style: TextStyle(color: AppColors.textSecondary)),
                );
              }
              // 被压缩折叠的消息默认收起（发送时不带它们，界面上也不该显得还在）。
              // 点横幅可展开——"原文一条没少"这件事必须是能看见的，否则用户
              // 没法相信压缩只是折叠而不是删除。
              final view = compactionViewAsync.asData?.value;
              final folded = view?.foldedIds ?? const <String>{};
              final hidden = folded.isEmpty || _showFolded
                  ? 0
                  : rawMessages.where((m) => folded.contains(m.id)).length;
              final allVisible = hidden == 0
                  ? rawMessages
                  : rawMessages.where((m) => !folded.contains(m.id)).toList(growable: false);

              // 渲染上限：只画最近 _visibleCount 条，更早的往上翻到顶再加载。
              // 数据库里全量都在、发给模型也按预算裁剪，这里只是"画多少"的UI层限制。
              _allMessageCount = allVisible.length;

              // 搜索跳转定位：目标消息若在渲染窗口之外，自动扩展 _visibleCount
              // 把它纳入（设为窗口最后一条），否则"跳过去却看不到"会让人以为坏了。
              final jumpId = widget.jumpToMessageId;
              if (jumpId != null && jumpId != _jumpHandled) {
                final targetIndex = allVisible.indexWhere((m) => m.id == jumpId);
                if (targetIndex >= 0) {
                  final fromEnd = allVisible.length - targetIndex;
                  if (_visibleCount < fromEnd) {
                    _visibleCount = fromEnd;
                  }
                  _jumpHandled = jumpId;
                  // 用 post frame 等列表按新窗口重建后，用 GlobalKey 精确定位到目标气泡。
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    final ctx = _jumpTargetKey.currentContext;
                    if (ctx != null) {
                      Scrollable.ensureVisible(
                        ctx,
                        alignment: 0.3,
                        duration: const Duration(milliseconds: 300),
                      );
                    }
                  });
                } else {
                  // 目标不在当前可见集（可能被折叠隐藏），标记已处理避免死循环。
                  _jumpHandled = jumpId;
                }
              }

              final start2 = (allVisible.length - _visibleCount).clamp(0, allVisible.length);
              final messages = allVisible.sublist(start2);
              final hasOlder = start2 > 0;

              // 有跳转目标、或正处于多选时不自动滚到底，否则会覆盖定位/把用户刚选的
              // 消息顶走（用户实测：手机长按多选后自动跳到最底下）。
              if (jumpId == null && !_messageMultiSelect) {
                _scrollToBottom();
              }
              // SelectionArea：桌面端可以直接用鼠标拖选、Ctrl+C 复制多段内容；
              // 每条气泡另有"复制"按钮，手机端点一下就行，不依赖长按选择。
              return Stack(
                children: [
                  SelectionArea(
                    // 手机端保留系统选择菜单（中文，已加 zh_CN 本地化）——用户选中文字后
                    // 需要"复制"手柄；桌面端右键由气泡接管进多选，禁掉 Copy/Select all 菜单。
                    contextMenuBuilder: _isDesktop
                        ? (context, editableTextState) => const SizedBox.shrink()
                        : null,
                    child: ListView.builder(
                      controller: _scrollController,
                      padding: const EdgeInsets.all(16),
                      itemCount: messages.length +
                          (folded.isEmpty ? 0 : 1) +
                          (hasOlder ? 1 : 0) +
                          (chatState.streamingAnswer != null ? 1 : 0),
                      itemBuilder: (context, index) {
                        int cursor = 0;
                        // 流式进行中气泡放在最后一项。
                        if (chatState.streamingAnswer != null &&
                            index == messages.length +
                                (folded.isEmpty ? 0 : 1) +
                                (hasOlder ? 1 : 0)) {
                          return _StreamingBubble(
                            thinking: chatState.thinkingPreview ?? '',
                            answer: chatState.streamingAnswer ?? '',
                            fontFamily: aiFontFamily,
                          );
                        }
                        if (hasOlder && index == cursor++) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            child: Center(
                              child: TextButton.icon(
                                icon: const Icon(Icons.expand_less, size: 16),
                                label: Text('加载更早的 ${start2} 条'),
                                onPressed: _loadingMore ? null : _loadMore,
                              ),
                            ),
                          );
                        }
                        if (folded.isNotEmpty && index == cursor++) {
                          return _buildFoldBanner(folded.length);
                        }
                        final message = messages[index - cursor];
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            MessageBubble(
                              key: message.id == jumpId ? _jumpTargetKey : null,
                              message: message,
                              onCopy: () => _copyMessage(message),
                              onRecall: message.role == MessageRole.user
                                  ? () => _confirmRecall(message, messages)
                                  : null,
                              onTogglePin: () => _togglePin(message),
                              onDelete: () => _confirmDeleteSingle(message),
                              onEnterMultiSelect: () => _enterMessageMultiSelect(message),
                              selected: _selectedMessageIds.contains(message.id),
                              multiSelect: _messageMultiSelect,
                              fontFamily: message.role == MessageRole.user
                                  ? userFontFamily
                                  : aiFontFamily,
                            ),
                            // 判定线（"截取到这里"）：多选时每条消息下方一条可点区域，
                            // 点它选中"首个选中项 → 本条"的连续区间（微信/QQ 选至此）。
                            // 点击热区加大到 34px，手机上才点得到；中间画一条带端点的虚线示意。
                            if (_messageMultiSelect)
                              GestureDetector(
                                behavior: HitTestBehavior.opaque,
                                onTap: () => _selectMessageRangeTo(message, messages),
                                child: SizedBox(
                                  height: 34,
                                  child: Center(
                                    child: Row(
                                      children: [
                                        const SizedBox(width: 20),
                                        Container(
                                          width: 6,
                                          height: 6,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: AppColors.primary.withValues(alpha: 0.55),
                                          ),
                                        ),
                                        Expanded(
                                          child: Container(
                                            height: 1.5,
                                            color: AppColors.primary.withValues(alpha: 0.32),
                                          ),
                                        ),
                                        Container(
                                          width: 6,
                                          height: 6,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: AppColors.primary.withValues(alpha: 0.55),
                                          ),
                                        ),
                                        const SizedBox(width: 20),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                          ],
                        );
                      },
                    ),
                  ),
                  // 一键到顶/到底：顺滑动方向浮现，停住/反向淡出，不遮挡界面。
                  ScrollToBottomButton(
                    controller: _scrollController,
                    direction: ScrollJumpDirection.both,
                    bottomOffset: _messageMultiSelect ? 60 : 16,
                  ),
                  // 消息多选底部固定栏：取消 / 已选数 / 全选 / 复制 / 删除。
                  if (_messageMultiSelect)
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: Container(
                        decoration: BoxDecoration(
                          color: AppColors.surface,
                          border: Border(top: BorderSide(color: AppColors.outline)),
                        ),
                        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
                        child: Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.close, size: 20),
                              tooltip: '取消多选',
                              onPressed: _clearMessageSelection,
                            ),
                            Text('已选 ${_selectedMessageIds.length}',
                                style: TextStyle(fontSize: 13, color: AppColors.textPrimary)),
                            const Spacer(),
                            TextButton(
                              onPressed: () => setState(() {
                                _selectedMessageIds.addAll(messages.map((m) => m.id));
                              }),
                              child: const Text('全选'),
                            ),
                            IconButton(
                              icon: const Icon(Icons.copy_outlined, size: 20),
                              tooltip: '复制所选',
                              onPressed: () => _copySelectedMessages(messages),
                            ),
                            IconButton(
                              icon: Icon(Icons.delete_outline, size: 20, color: AppColors.danger),
                              tooltip: '删除所选',
                              onPressed: _confirmDeleteSelectedMessages,
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        ),
        if (chatState.error != null)
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFFFFEBEE),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.error_outline, size: 16, color: AppColors.danger),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    chatState.error!,
                    style: TextStyle(color: AppColors.danger, fontSize: 12, height: 1.4),
                  ),
                ),
              ],
            ),
          ),
        if (chatState.sending) const LinearProgressIndicator(minHeight: 2),
        // 待发送附件统一收进「文件列表」管理（见文件列表按钮上的数量角标），
        // 不再在输入框上方平铺一排 chip——电脑上那排没法滑动删除。
        // 用量条：让"这次到底发了多少"可见。之前全量闷发，用户只能从余额
        // 变化去猜，既不可控也不可信。
        if (chatState.lastBudget != null) _buildBudgetHint(chatState.lastBudget!),
        _buildInputArea(
          supportsThinking: supportsThinking,
          supportsSearch: supportsSearch,
          supportsFiles: supportsFiles,
          sending: chatState.sending,
          isMobile: isMobile,
        ),
      ],
    );
  }

  /// 折叠区间横幅：明确告诉用户"这些消息被折叠了、原文还在、可以展开"。
  Widget _buildFoldBanner(int foldedCount) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: AppColors.primarySoft,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            Icon(Icons.compress, size: 14, color: AppColors.primary),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                _showFolded
                    ? '正在显示 $foldedCount 条已折叠消息（本次发送不会包含它们）'
                    : '$foldedCount 条消息已折叠为摘要（原文保留，本次不发送）',
                style: TextStyle(fontSize: 11, color: AppColors.primary, height: 1.4),
              ),
            ),
            TextButton(
              onPressed: () => setState(() => _showFolded = !_showFolded),
              child: Text(_showFolded ? '收起' : '展开原文',
                  style: const TextStyle(fontSize: 11)),
            ),
          ],
        ),
      );

  Widget _buildBudgetHint(BudgetReport report) => Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
        child: Row(
          children: [
            Icon(Icons.data_usage, size: 12, color: AppColors.textSecondary),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                report.summary,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 10, color: AppColors.textSecondary),
              ),
            ),
          ],
        ),
      );

  Widget _buildApiKeyHint() => Container(
        color: const Color(0xFFFFF4E5),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(
          children: [
            const Icon(Icons.key_off, size: 18, color: Color(0xFFB25E00)),
            const SizedBox(width: 8),
            const Expanded(
              child: Text('尚未配置 DeepSeek API Key，消息无法发送',
                  style: TextStyle(fontSize: 12, color: Color(0xFF8A4A00))),
            ),
            TextButton(onPressed: _openGlobalSettings, child: const Text('去设置')),
          ],
        ),
      );

  Widget _buildInputArea({
    required bool supportsThinking,
    required bool supportsSearch,
    required bool supportsFiles,
    required bool sending,
    required bool isMobile,
  }) {
    final draftCount = ref.watch(draftAttachmentsProvider(widget.conversationId)).length;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border(top: BorderSide(color: AppColors.outline)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              if (supportsThinking)
                _ToggleChip(icon: Icons.psychology_outlined, label: '深度思考',
                    enabled: _thinkingEnabled,
                    onTap: () => setState(() => _thinkingEnabled = !_thinkingEnabled)),
              if (supportsThinking) const SizedBox(width: 8),
              if (supportsSearch)
                _ToggleChip(icon: Icons.public, label: '联网搜索',
                    enabled: _searchEnabled,
                    onTap: () => setState(() => _searchEnabled = !_searchEnabled)),
              if (supportsFiles) const SizedBox(width: 8),
              if (supportsFiles)
                IconButton(icon: const Icon(Icons.attach_file), tooltip: '添加文件', onPressed: _pickAttachment),
              // 文件列表：管理本会话【即将发送】的附件，角标显示待发送数量。
              IconButton(
                icon: Badge(
                  isLabelVisible: draftCount > 0,
                  label: Text('$draftCount'),
                  child: const Icon(Icons.folder_open_outlined),
                ),
                tooltip: '文件列表（待发送 $draftCount 个）',
                onPressed: _openAttachmentBrowser,
              ),
              const Spacer(),
              // 全局设置（API Key / 设备名）与会话设置（提示词 / 摘要 / 记忆点）分开入口。
              IconButton(
                icon: const Icon(Icons.tune),
                tooltip: '会话设置',
                onPressed: _openSettings,
              ),
              IconButton(
                icon: const Icon(Icons.compress),
                tooltip: '上下文压缩',
                onPressed: _openCompression,
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: TextField(
                  controller: _inputController,
                  focusNode: _inputFocus,
                  decoration: InputDecoration(
                    // 手机端没有物理键盘，不显示 Enter / Shift+Enter 这类桌面快捷键提示。
                    hintText: isMobile ? '点击输入对话' : '输入消息…',
                    border: const OutlineInputBorder(),
                    isDense: true,
                  ),
                  maxLines: isMobile ? 3 : 4,
                  minLines: 1,
                  enabled: !sending,
                  textInputAction: isMobile ? TextInputAction.newline : TextInputAction.send,
                  onSubmitted: isMobile ? null : (_) => _send(),
                ),
              ),
              const SizedBox(width: 8),
              FilledButton(
                onPressed: sending ? null : _send,
                child: sending
                    ? const SizedBox(width: 18, height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.send),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// 附件来源：手机提供 拍照 / 相册 / 文件（任意格式）三选；桌面直接开文件选择器。
  Future<void> _pickAttachment() async {
    String? path;
    String? name;
    final isMobile = Platform.isAndroid || Platform.isIOS;

    if (isMobile) {
      final choice = await showModalBottomSheet<String>(
        context: context,
        builder: (context) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.camera_alt),
                title: const Text('拍照'),
                onTap: () => Navigator.pop(context, 'camera'),
              ),
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: const Text('相册'),
                onTap: () => Navigator.pop(context, 'gallery'),
              ),
              ListTile(
                leading: const Icon(Icons.insert_drive_file),
                title: const Text('文件（PDF / Word / 文本等任意格式）'),
                onTap: () => Navigator.pop(context, 'file'),
              ),
            ],
          ),
        ),
      );
      if (choice == null) return;
      if (choice == 'file') {
        final result = await FilePicker.platform.pickFiles(
          type: FileType.any,
          allowMultiple: true,
        );
        if (result != null && mounted) {
          final next = List<DraftAttachment>.from(_attachments);
          for (final f in result.files.where((f) => f.path != null)) {
            next.add(DraftAttachment(f.path!, f.name));
          }
          _setAttachments(next);
        }
        return;
      }
      final image = await ImagePicker().pickImage(
        source: choice == 'camera' ? ImageSource.camera : ImageSource.gallery,
      );
      path = image?.path;
      name = image?.name;
    } else {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.any,
        allowMultiple: true,
      );
      if (result != null && mounted) {
        final next = List<DraftAttachment>.from(_attachments);
        for (final f in result.files.where((f) => f.path != null)) {
          next.add(DraftAttachment(f.path!, f.name));
        }
        _setAttachments(next);
      }
      return;
    }
    if (path != null) {
      final pickedPath = path;
      if (mounted) {
        _addAttachment(DraftAttachment(pickedPath, name ?? '附件'));
      }
    }
  }

  Future<void> _send() async {
    final text = _inputController.text.trim();
    if (text.isEmpty && _attachments.isEmpty) return;
    // 从 provider 实时读取，而不是缓存的布尔字段。
    final providerReady = await ref.read(apiKeyConfiguredProvider.future);
    if (!providerReady) {
      _openGlobalSettings();
      return;
    }
    final convId = widget.conversationId;
    final fileIds = _attachments.map((a) => a.path).toList();
    // 发送失败要能把草稿还回来：上传附件动辄要重选一次文件，
    // 失败就把输入和附件清空会让用户没法直接重试。
    final draftText = text;
    final draftAttachments = List<DraftAttachment>.from(_attachments);
    _inputController.clear();
    _setAttachments(<DraftAttachment>[]);

    // 发送/上传期间打标记：shell 看到标记就不会把本会话当空白对话删掉。
    // 这修掉了"选了附件→切出→对话被判定无内容删除→文件发到错误会话"的 bug。
    final sendingNotifier = ref.read(sendingInProgressProvider(convId).notifier);
    sendingNotifier.state = true;
    try {
      await ref.read(chatControllerProvider(convId).notifier).send(
            text,
            thinkingEnabled: _thinkingEnabled,
            searchEnabled: _searchEnabled,
            filePaths: fileIds,
          );
    } finally {
      sendingNotifier.state = false;
    }
    if (!mounted) return;
    final failed = ref.read(chatControllerProvider(convId)).error != null;
    if (failed) {
      _inputController.text = draftText;
      _setAttachments(draftAttachments);
    }
  }

  /// 右键/长按气泡：进入多选并选中/取消该条。
  void _enterMessageMultiSelect(ChatMessage message) {
    setState(() {
      if (_selectedMessageIds.contains(message.id)) {
        _selectedMessageIds.remove(message.id);
      } else {
        _selectedMessageIds.add(message.id);
      }
    });
  }

  /// 判定线：选中"第一个选中项 → 目标消息"之间的连续区间（微信/QQ 式"选至此"）。
  void _selectMessageRangeTo(ChatMessage target, List<ChatMessage> visible) {
    if (_selectedMessageIds.isEmpty) {
      setState(() => _selectedMessageIds.add(target.id));
      return;
    }
    int? first;
    for (var i = 0; i < visible.length; i++) {
      if (_selectedMessageIds.contains(visible[i].id)) { first = i; break; }
    }
    int? last;
    for (var i = 0; i < visible.length; i++) {
      if (visible[i].id == target.id) { last = i; break; }
    }
    if (first == null || last == null) {
      setState(() => _selectedMessageIds.add(target.id));
      return;
    }
    final lo = first < last ? first : last;
    final hi = first < last ? last : first;
    setState(() {
      for (var i = lo; i <= hi; i++) {
        _selectedMessageIds.add(visible[i].id);
      }
    });
  }

  /// 批量复制选中消息（按时间顺序拼接纯文本）。
  Future<void> _copySelectedMessages(List<ChatMessage> visible) async {
    final chosen = visible.where((m) => _selectedMessageIds.contains(m.id));
    final text = chosen.map(messagePlainText).where((s) => s.isNotEmpty).join('\n\n');
    if (text.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: text));
    if (mounted) showAppToast(context, '已复制 ${_selectedMessageIds.length} 条消息', duration: const Duration(seconds: 1));
  }

  /// 批量删除选中消息，二次确认。
  Future<void> _confirmDeleteSelectedMessages() async {
    final count = _selectedMessageIds.length;
    if (count == 0) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('删除 $count 条消息？'),
        content: const Text('只删除选中的消息，不可撤销（会同步到已配对设备）。'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('取消')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('删除'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final ids = Set<String>.from(_selectedMessageIds);
    final deleted = await ref.read(chatControllerProvider(widget.conversationId).notifier)
        .deleteMessages(ids);
    if (mounted) {
      showAppToast(context, '已删除 $deleted 条消息');
      _clearMessageSelection();
    }
  }

  Future<void> _copyMessage(ChatMessage message) async {
    final text = messagePlainText(message);
    if (text.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: text));
    if (!mounted) return;
    showAppToast(context, '复制成功', duration: Duration(seconds: 1));
  }

  /// 切换锚点。锚点 = "这条必须记住"，在上下文裁剪时优先保留。
  ///
  /// 必须走 touch：pinned 是同步字段，不 tick 时钟的话对端会判 equal 而忽略，
  /// 表现为"在这台设了锚点，另一台看不到"。
  Future<void> _togglePin(ChatMessage message) async {
    try {
      final store = await ref.read(messageStoreProvider.future);
      final identity = await ref.read(localIdentityProvider.future);
      final next = !message.pinned;
      await store.insertOrMerge(
        message.touch(identity.deviceId, newPinned: next),
      );
      if (!mounted) return;
      showAppToast(
        context,
        next
            ? '已成功标记消息为重要锚点'
            : '已取消标记消息为重要锚点',
        duration: const Duration(seconds: 2),
      );
    } catch (e) {
      if (mounted) showAppToast(context, '设置锚点失败：$e');
    }
  }

  /// 删除单条：只隐藏这一条，不动其他消息、不放回输入框（与撤回不同）。
  /// 长按气泡触发，弹二次确认防止误删。
  Future<void> _confirmDeleteSingle(ChatMessage message) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.delete_outline, color: AppColors.danger),
            const SizedBox(width: 8),
            const Text('删除这条消息？'),
          ],
        ),
        content: SizedBox(
          width: 400,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('只会删除这一条，后面的消息都保留，原文也不会放回输入框。',
                  style: TextStyle(fontSize: 13, height: 1.5)),
              const SizedBox(height: 8),
              Text(
                messagePlainText(message),
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 12, color: AppColors.textSecondary, height: 1.5),
              ),
              const SizedBox(height: 8),
              Text('删除会同步到已配对的另一台设备。',
                  style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('取消'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('删除'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    final ok = await ref
        .read(chatControllerProvider(widget.conversationId).notifier)
        .deleteSingleMessage(message.id);
    if (!mounted) return;
    showAppToast(context, ok ? '已删除这一条' : '删除失败：消息可能已不存在');
  }

  /// 撤回：删除该条及其之后的全部消息，并把原文放回输入框。
  ///
  /// 这是不可撤销的破坏性操作，因此要求用户先勾选"我明白"才允许点确认，
  /// 弹窗里逐条列出会发生什么（删几条、是否同步、原文去哪）。
  Future<void> _confirmRecall(ChatMessage message, List<ChatMessage> all) async {
    final index = all.indexWhere((m) => m.id == message.id);
    final removeCount = index < 0 ? 1 : all.length - index;
    var understood = false;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setLocal) => AlertDialog(
          title: Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: AppColors.danger),
              SizedBox(width: 8),
              Text('撤回并删除消息'),
            ],
          ),
          content: SizedBox(
            width: 420,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('你要撤回的是这条消息：', style: TextStyle(fontSize: 12)),
                const SizedBox(height: 6),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.background,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    messagePlainText(message),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, height: 1.5),
                  ),
                ),
                const SizedBox(height: 12),
                const Text('确认后立即发生，且无法撤销：',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                _recallBullet('删除这条消息以及它之后的 $removeCount 条消息（包括 AI 的回复）'),
                _recallBullet('删除会同步到已配对设备，对端也会一起消失'),
                _recallBullet('这条消息的原文会放回输入框，方便修改后重新发送'),
                CheckboxListTile(
                  value: understood,
                  onChanged: (v) => setLocal(() => understood = v ?? false),
                  controlAffinity: ListTileControlAffinity.leading,
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  title: const Text('我明白，删除后无法恢复', style: TextStyle(fontSize: 13)),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('取消'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
              onPressed: understood
                  ? () => Navigator.pop(dialogContext, true)
                  : null,
              child: Text('确认撤回并删除 $removeCount 条'),
            ),
          ],
        ),
      ),
    );

    if (confirmed != true || !mounted) return;
    final result = await ref
        .read(chatControllerProvider(widget.conversationId).notifier)
        .recall(message.id);
    if (!mounted) return;
    if (result == null) {
      showAppToast(context, '撤回失败：消息可能已被删除');
      return;
    }
    setState(() => _inputController.text = result.content);
    _setAttachments(<DraftAttachment>[]);
    _inputController.selection =
        TextSelection.collapsed(offset: _inputController.text.length);
    _inputFocus.requestFocus();
    showAppToast(context, '已撤回 ${result.removed} 条消息，原文已放回输入框');
  }

  Widget _recallBullet(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 4),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('• ', style: TextStyle(color: AppColors.danger, fontSize: 13)),
            Expanded(
              child: Text(text,
                  style: TextStyle(fontSize: 12, height: 1.45, color: AppColors.danger)),
            ),
          ],
        ),
      );

  /// 等冲突落库稳定后再弹一次窗口。
  ///
  /// 冲突数量在同步过程中会从 0 一路涨到几千，每次变化都重置定时器；
  /// 只有 1.2 秒内没有新增冲突（说明这一轮同步收完了）才真正弹窗。
  void _syncConflictAutoPrompt(List<ConflictRecord> pending) {
    if (pending.isEmpty) {
      _conflictDebounce?.cancel();
      _conflictDebounce = null;
      _conflictAutoSuppressed = false;
      return;
    }
    if (_conflictSheetOpen || _conflictAutoSuppressed) return;

    _conflictDebounce?.cancel();
    _conflictDebounce = Timer(const Duration(milliseconds: 1200), () {
      if (!mounted || _conflictSheetOpen) return;
      final latest = ref
              .read(conflictsProvider)
              .value
              ?.where((c) => c.status == ConflictStatus.pending)
              .toList() ??
          const <ConflictRecord>[];
      if (latest.isNotEmpty) _openConflictResolution(latest);
    });
  }

  /// 打开"整体裁决"弹窗。同一时刻只允许一个，防止模态框叠加把界面拖死。
  Future<void> _openConflictResolution(List<ConflictRecord> conflicts) async {
    if (_conflictSheetOpen || conflicts.isEmpty || !mounted) return;
    _conflictSheetOpen = true;
    _conflictDebounce?.cancel();
    _conflictDebounce = null;

    final total = conflicts.length;
    try {
      await showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (sheetContext) => ConflictResolutionSheet(
          conflicts: conflicts,
          onResolveAll: (strategy) async {
            final store = await ref.read(messageStoreProvider.future);
            final applied = await store.resolveConflictsBulk(strategy: strategy);
            if (mounted) {
              final what = switch (strategy) {
                ConflictMergeStrategy.local => '本机',
                ConflictMergeStrategy.remote => '对端',
                ConflictMergeStrategy.merge => '双方（按时间合并）',
              };
              showAppToast(context, '已按"$what"处理 $applied 处差异');
            }
            return applied;
          },
          // "稍后再说"只是关窗：冲突记录保留，顶部横幅一直可点开。
          onDeferAll: () async {
            if (mounted) _conflictAutoSuppressed = true;
          },
        ),
      );
    } finally {
      _conflictSheetOpen = false;
      if (mounted) {
        final stillPending = ref
                .read(conflictsProvider)
                .value
                ?.any((c) => c.status == ConflictStatus.pending) ??
            false;
        // 关窗后还有没裁决的（用户点了"稍后"），就别再自动弹，等他自己点横幅。
        if (stillPending && total > 0) _conflictAutoSuppressed = true;
      }
    }
  }

  void _openSettings() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => ConversationSettingsSheet(conversationId: widget.conversationId),
    );
  }

  void _openAttachmentBrowser() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => AttachmentBrowserSheet(conversationId: widget.conversationId),
    );
  }

  void _openGlobalSettings() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => const GlobalSettingsSheet(),
    );
  }

  void _openCompression() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => CompressionSheet(conversationId: widget.conversationId),
    );
  }
}

class _ToggleChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool enabled;
  final VoidCallback onTap;
  const _ToggleChip({
    required this.icon, required this.label, required this.enabled, required this.onTap,
  });

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: enabled ? AppColors.primarySoft : Colors.transparent,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: enabled ? AppColors.primary : AppColors.outline),
          ),
          child: Row(
            children: [
              Icon(icon, size: 16,
                  color: enabled ? AppColors.primary : AppColors.textSecondary),
              const SizedBox(width: 4),
              Text(label,
                  style: TextStyle(
                    fontSize: 12,
                    color: enabled ? AppColors.primary : AppColors.textSecondary,
                  )),
            ],
          ),
        ),
      );
}

/// 消息时间标签：今天显示 HH:mm，昨天显示"昨天 HH:mm"，更早显示 M/d HH:mm。
/// 每条消息用自己的 createdAt，因此用户发出时间与 AI 回答时间各自独立显示。
String _formatMessageTime(DateTime createdAt) {
  final t = createdAt.toLocal();
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);
  final day = DateTime(t.year, t.month, t.day);
  final hhmm = '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
  if (day == today) return hhmm;
  if (day == today.subtract(const Duration(days: 1))) return '昨天 $hhmm';
  return '${t.month}/${t.day} $hhmm';
}

/// 消息的可复制纯文本：去掉 `<thinking>` 段（那是过程稿，不是用户想复制的内容），
/// 保留正文与 [引用] 行。
String messagePlainText(ChatMessage message) {
  var text = message.content;
  if (message.role == MessageRole.assistant) {
    final match = RegExp(r'<thinking>\n?[\s\S]*?\n?</thinking>').firstMatch(text);
    if (match != null) {
      text = text.replaceFirst(match.group(0)!, '');
    }
    // 去掉引用编码块——复制/回放不应带上那串 base64。
    text = CitationCodec.strip(text);
  }
  return text.trim();
}

/// 打开引用来源链接；失败时静默（不让底部面板因浏览器缺失而崩溃）。
Future<void> _openCitationUrl(String url) async {
  final uri = Uri.tryParse(url);
  if (uri == null) return;
  try {
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  } catch (_) {}
}

/// 消息气泡：解析 thinking 标记与 [引用] 分区渲染，并提供复制/撤回/锚点操作。
class MessageBubble extends StatelessWidget {
  final ChatMessage message;
  final VoidCallback onCopy;
  final VoidCallback? onRecall;

  /// 切换"锚点"状态。锚点消息会在上下文裁剪时被优先保留，
  /// 与位置无关——这是解决"设定藏在对话中间"的唯一可靠手段。
  final VoidCallback? onTogglePin;

  /// 删除单条（操作行按钮触发，长按已不再触发删除）。
  final VoidCallback? onDelete;

  /// 右键/长按气泡进入多选（手机端长按、电脑端右键）。null 表示不支持。
  final VoidCallback? onEnterMultiSelect;

  /// 多选状态：是否被选中、是否处于多选模式。由父级管理。
  final bool selected;
  final bool multiSelect;

  /// 本气泡正文使用的字体族（null = 系统默认）。用户与 AI 可不同。
  final String? fontFamily;

  const MessageBubble({
    super.key,
    required this.message,
    required this.onCopy,
    this.onRecall,
    this.onTogglePin,
    this.onDelete,
    this.onEnterMultiSelect,
    this.selected = false,
    this.multiSelect = false,
    this.fontFamily,
  });

  @override
  Widget build(BuildContext context) {
    final isUser = message.role == MessageRole.user;
    final isAssistant = message.role == MessageRole.assistant;
    String thinking = '';
    String answer = message.content;
    List<AiCitation> citations = const <AiCitation>[];

    if (isAssistant) {
      final tMatch =
          RegExp(r'<thinking>\n?([\s\S]*?)\n?</thinking>').firstMatch(message.content);
      if (tMatch != null) {
        thinking = tMatch.group(1) ?? '';
        answer = message.content.replaceFirst(tMatch.group(0)!, '').trim();
      }
      // 解码结构化引用；正文按 start_index 插入 〔n〕 角标。
      final decoded = CitationCodec.decode(answer);
      answer = decoded.body;
      citations = decoded.citations;
      if (citations.isNotEmpty) {
        answer = CitationCodec.withInlineMarkers(answer, citations);
      }
    }

    // 锚点消息：整条气泡切换为金色系（背景/边框/正文/操作区一致）。
    final pinned = message.pinned;
    final actionColor = pinned
        ? AppColors.anchorAccent
        : (isUser ? Colors.white70 : AppColors.textSecondary);
    final bubbleColor = pinned
        ? AppColors.anchorSurface
        : (isUser ? AppColors.primary : AppColors.surface);
    final bodyTextColor = pinned ? AppColors.anchorText : AppColors.textPrimary;

    // 用父级实际可用宽度算气泡上限，而不是屏幕宽度：
    // 桌面端左侧有 85px 导航栏 + 280px 会话列表，聊天区比屏幕窄得多，
    // 按 0.82×屏幕宽 会让气泡超出聊天区，右侧文字被直接裁掉。
    return LayoutBuilder(
      builder: (context, constraints) => Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: constraints.maxWidth * 0.86),
        // 多选时在气泡对角显示勾选框：AI 消息在右下、用户消息在左下。
        // 用 Stack 叠加，勾选框不影响气泡本身布局。
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            GestureDetector(
          onLongPress: onEnterMultiSelect,
          onSecondaryTapDown: onEnterMultiSelect == null ? null : (_) => onEnterMultiSelect!(),
          child: Container(
          margin: const EdgeInsets.symmetric(vertical: 6),
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 6),
          decoration: BoxDecoration(
            color: bubbleColor,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: selected
                  ? AppColors.primary
                  : (pinned ? AppColors.anchorBorder : (isUser ? Colors.transparent : AppColors.outline)),
              width: selected ? 2.5 : (pinned ? 1.6 : 1),
            ),
            boxShadow: pinned
                ? [BoxShadow(color: AppColors.anchorBorder.withValues(alpha: 0.25), blurRadius: 8)]
                : null,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (thinking.isNotEmpty) ...[
                _ThinkingBlock(content: thinking, pinned: pinned),
                const SizedBox(height: 10),
              ],
              // 本条消息携带的附件：图片显示缩略图、文件显示卡片。
              // 让"提交成功了没"一眼可见，点击可预览/打开。
              if (message.attachments.isNotEmpty) ...[
                _AttachmentGallery(
                  attachments: message.attachments,
                  isUser: isUser,
                  pinned: pinned,
                ),
                const SizedBox(height: 8),
              ],
              // AI 回复走 Markdown 渲染：加粗/斜体/标题/列表/代码/表格不再裸露 ** 和 #。
              if (isAssistant)
                answer.isEmpty
                    ? const SizedBox.shrink()
                    : MarkdownView(
                        data: answer,
                        baseStyle: TextStyle(
                          color: bodyTextColor,
                          fontSize: 14,
                          height: 1.5,
                          fontFamily: fontFamily,
                        ),
                        onCitationTap: citations.isEmpty
                            ? null
                            : (n) {
                                final idx = n - 1;
                                if (idx >= 0 && idx < citations.length) {
                                  final url = citations[idx].url;
                                  if (url.isNotEmpty) _openCitationUrl(url);
                                }
                              },
                      )
              else
                Text(
                  message.content,
                  style: TextStyle(
                      color: pinned ? AppColors.anchorText : Colors.white,
                      fontSize: 14, height: 1.5, fontFamily: fontFamily),
                ),
              if (citations.isNotEmpty) ...[
                const SizedBox(height: 10),
                const Divider(height: 1),
                const SizedBox(height: 6),
                Text('搜索引用', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                ...citations.asMap().entries.map((entry) {
                  final n = entry.key + 1;
                  final c = entry.value;
                  final hasUrl = c.url.isNotEmpty;
                  return Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: GestureDetector(
                      onTap: hasUrl ? () => _openCitationUrl(c.url) : null,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: const EdgeInsets.only(top: 1, right: 6),
                            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                            decoration: BoxDecoration(
                              color: AppColors.primary.withValues(alpha: 0.14),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text('$n',
                                style: TextStyle(
                                    fontSize: 10,
                                    color: AppColors.primary,
                                    fontWeight: FontWeight.w700)),
                          ),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  c.title.isEmpty ? c.url : c.title,
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: hasUrl ? AppColors.primary : AppColors.textPrimary,
                                    decoration: hasUrl ? TextDecoration.underline : null,
                                  ),
                                ),
                                if (c.snippet != null && c.snippet!.isNotEmpty)
                                  Padding(
                                    padding: const EdgeInsets.only(top: 2),
                                    child: Text(
                                      c.snippet!,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                          fontSize: 10, color: AppColors.textSecondary),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
              ],
              const SizedBox(height: 2),
              // 操作行常驻（不是 hover 才出现），手机端也能直接点。
              // 左侧标注本条消息的发出/回答时间，右侧为操作按钮。
              Row(
                children: [
                  Text(
                    _formatMessageTime(message.createdAt),
                    style: TextStyle(
                      fontSize: 10,
                      color: pinned
                          ? AppColors.anchorText.withValues(alpha: 0.75)
                          : (isUser ? Colors.white70 : AppColors.textSecondary),
                    ),
                  ),
                  const Spacer(),
                  _BubbleAction(
                    icon: Icons.copy_rounded,
                    label: '复制',
                    color: actionColor,
                    onTap: onCopy,
                  ),
                  if (onRecall != null)
                    _BubbleAction(
                      icon: Icons.undo_rounded,
                      label: '撤回',
                      color: actionColor,
                      onTap: onRecall!,
                    ),
                  // 删除挪到撤回旁边并列（长按不再触发删除）。
                  if (onDelete != null)
                    _BubbleAction(
                      icon: Icons.delete_outline,
                      label: '删除',
                      color: actionColor,
                      onTap: onDelete!,
                    ),
                  if (onTogglePin != null)
                    _BubbleAction(
                      icon: message.pinned ? Icons.push_pin : Icons.push_pin_outlined,
                      label: message.pinned ? '取消锚点' : '设为锚点',
                      color: message.pinned ? AppColors.anchorAccent : actionColor,
                      onTap: onTogglePin!,
                    ),
                ],
              ),
            ],
          ),
        ),
          ),
          // 多选勾选框：AI 消息在气泡右下、用户消息在气泡左下。
          if (multiSelect)
            Positioned(
              right: isUser ? null : -6,
              left: isUser ? -6 : null,
              bottom: -6,
              child: GestureDetector(
                onTap: onEnterMultiSelect,
                child: Container(
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(
                    color: selected ? AppColors.primary : AppColors.surface,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: selected ? AppColors.primary : AppColors.outline,
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.15),
                        blurRadius: 4,
                      ),
                    ],
                  ),
                  child: selected
                      ? const Icon(Icons.check, size: 15, color: Colors.white)
                      : null,
                ),
              ),
            ),
          ],
        ),
      ),
      ),
    );
  }
}

class _BubbleAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _BubbleAction({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => Tooltip(
        message: label,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Padding(
            // 只留图标，紧凑排列，避免按钮太多被挤出屏幕。
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
            child: Icon(icon, size: 15, color: color),
          ),
        ),
      );
}

class _ThinkingBlock extends StatefulWidget {
  final String content;
  final bool pinned;
  const _ThinkingBlock({required this.content, this.pinned = false});
  @override
  State<_ThinkingBlock> createState() => _ThinkingBlockState();
}

class _ThinkingBlockState extends State<_ThinkingBlock> {
  bool _expanded = false;
  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          color: widget.pinned
              ? AppColors.anchorAccent.withValues(alpha: 0.14)
              : (AppColors.isDark ? AppColors.surface : const Color(0xFFF4F6FA)),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            InkWell(
              onTap: () => setState(() => _expanded = !_expanded),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                child: Row(
                  children: [
                    Icon(Icons.psychology, size: 14,
                        color: widget.pinned ? AppColors.anchorAccent : AppColors.primary),
                    const SizedBox(width: 6),
                    Text('深度思考',
                        style: TextStyle(
                            fontSize: 12,
                            color: widget.pinned ? AppColors.anchorAccent : AppColors.primary)),
                    const Spacer(),
                    Icon(_expanded ? Icons.expand_less : Icons.expand_more, size: 16),
                  ],
                ),
              ),
            ),
            if (_expanded)
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
                child: Text(widget.content,
                    style: TextStyle(fontSize: 12, color: AppColors.textSecondary, height: 1.5)),
              ),
          ],
        ),
      );
}

/// 流式生成中的气泡：显示已累积的思考与正文，末尾带闪烁光标。
/// 生成完成后由 controller 一次性落库，这个临时气泡随即被正式消息替换。
class _StreamingBubble extends StatelessWidget {
  final String thinking;
  final String answer;
  final String? fontFamily;

  const _StreamingBubble({
    required this.thinking,
    required this.answer,
    this.fontFamily,
  });

  @override
  Widget build(BuildContext context) => Align(
        alignment: Alignment.centerLeft,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 620),
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 6),
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.primary.withValues(alpha: 0.4)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (thinking.isNotEmpty) ...[
                  Row(
                    children: [
                      Icon(Icons.psychology, size: 13, color: AppColors.primary),
                      const SizedBox(width: 5),
                      Text('深度思考中…',
                          style: TextStyle(fontSize: 11, color: AppColors.primary)),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    thinking.length > 300 ? '…${thinking.substring(thinking.length - 300)}' : thinking,
                    maxLines: 4,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 11, color: AppColors.textSecondary, height: 1.5, fontFamily: fontFamily),
                  ),
                  const SizedBox(height: 8),
                  const Divider(height: 1),
                  const SizedBox(height: 8),
                ],
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(
                        answer.isEmpty ? '正在生成…' : answer,
                        style: TextStyle(
                            fontSize: 14, color: AppColors.textPrimary, height: 1.5, fontFamily: fontFamily),
                      ),
                    ),
                    // 闪烁光标：透明度和动画同步，制造"打字中"的感觉。
                    const _BlinkingCursor(),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
}

class _BlinkingCursor extends StatefulWidget {
  const _BlinkingCursor();

  @override
  State<_BlinkingCursor> createState() => _BlinkingCursorState();
}

class _BlinkingCursorState extends State<_BlinkingCursor>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => FadeTransition(
        opacity: _controller,
        child: Padding(
          padding: const EdgeInsets.only(left: 2, top: 2),
          child: Container(
            width: 2,
            height: 16,
            color: AppColors.primary,
          ),
        ),
      );
}

/// 消息气泡内的附件画廊：图片显示缩略图，其它文件显示图标+文件名。
///
/// 设计要点：
/// - location 是服务端 file_id，localPath 才是本机可打开文件。若同步到另一台
///   设备导致 localPath 不存在，则只显示文件名、点击给出友好提示，不崩溃。
/// - 附件是"已提交成功"的可视凭证——上传失败的消息根本不会落库，
///   因此这里显示的附件即代表上传成功。
class _AttachmentGallery extends StatelessWidget {
  final List<MessageAttachment> attachments;
  final bool isUser;
  final bool pinned;

  const _AttachmentGallery({
    required this.attachments,
    required this.isUser,
    this.pinned = false,
  });

  Future<void> _openAttachment(BuildContext context, MessageAttachment a) async {
    final path = a.localPath;
    if (path == null || path.isEmpty || !File(path).existsSync()) {
      if (context.mounted) {
        showAppToast(context, '附件原件不在本机（可能来自另一台设备的同步），仅显示文件名');
      }
      return;
    }
    if (a.isImage && context.mounted) {
      await showDialog<void>(
        context: context,
        builder: (_) => Dialog(
          backgroundColor: Colors.transparent,
          child: GestureDetector(
            onTap: () => Navigator.pop(context),
            child: InteractiveViewer(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(File(path), fit: BoxFit.contain),
              ),
            ),
          ),
        ),
      );
      return;
    }
    final uri = Uri.file(path);
    try {
      final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!ok && context.mounted) showAppToast(context, '没有找到可以打开此文件的应用');
    } catch (_) {
      if (context.mounted) showAppToast(context, '无法打开此文件');
    }
  }

  @override
  Widget build(BuildContext context) {
    final images = attachments.where((a) => a.isImage).toList();
    final files = attachments.where((a) => !a.isImage).toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (images.isNotEmpty)
          SizedBox(
            height: 84,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: images.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                final a = images[i];
                final path = a.localPath;
                final exists = path != null && path.isNotEmpty && File(path).existsSync();
                return GestureDetector(
                  onTap: () => _openAttachment(context, a),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: exists
                        ? Image.file(File(path),
                            width: 84, height: 84, fit: BoxFit.cover)
                        : Container(
                            width: 84,
                            height: 84,
                            color: AppColors.primarySoft,
                            child: Icon(Icons.image_outlined,
                                color: AppColors.primary, size: 30),
                          ),
                  ),
                );
              },
            ),
          ),
        if (files.isNotEmpty)
          ...files.map((a) => Padding(
                padding: const EdgeInsets.only(top: 6),
                child: GestureDetector(
                  onTap: () => _openAttachment(context, a),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(
                      color: isUser
                          ? Colors.white.withValues(alpha: 0.16)
                          : (pinned ? AppColors.anchorSurface : AppColors.primarySoft),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: isUser
                            ? Colors.white30
                            : AppColors.outline.withValues(alpha: 0.6),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.insert_drive_file_outlined,
                            size: 18,
                            color: isUser ? Colors.white : AppColors.primary),
                        const SizedBox(width: 8),
                        ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 180),
                          child: Text(
                            a.fileName ?? '附件',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 12,
                              color: isUser ? Colors.white : AppColors.textPrimary,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              )),
      ],
    );
  }
}
