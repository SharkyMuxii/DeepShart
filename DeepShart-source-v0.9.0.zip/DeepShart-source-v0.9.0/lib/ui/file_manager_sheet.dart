// target: lib/ui/file_manager_sheet.dart
// 职责：全局「文件管理」——统一管理【已发送】文件的归档副本。
// 两级结构：先列会话（标注名下文件总大小），点开才展开该会话的文件；
// 文件列表支持多选、多选截止线、删除。只删归档副本，绝不动用户原始文件。
// 明确不设容量上限、不做滚动自动删除。

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/conversation_file_store.dart';
import '../core/theme.dart';
import '../data/store/conversation_store.dart';
import '../state/app_providers.dart';
import 'app_toast.dart';

/// 人类可读的体积。
String _fmtSize(int bytes) {
  if (bytes < 1024) return '$bytes B';
  if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
  return '${(bytes / 1024 / 1024).toStringAsFixed(1)} MB';
}

/// 全局文件管理入口页（会话列表级）。
class FileManagerSheet extends ConsumerStatefulWidget {
  const FileManagerSheet({super.key});

  @override
  ConsumerState<FileManagerSheet> createState() => _FileManagerSheetState();
}

class _FileManagerSheetState extends ConsumerState<FileManagerSheet> {
  Map<String, List<ArchivedFile>> _byConv = const {};
  Map<String, Conversation> _convMap = const {};
  bool _loading = true;
  bool _archiving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    // 会话标题映射。
    final convs = await ref.read(conversationsProvider.future).catchError((_) => <Conversation>[]);
    final convMap = <String, Conversation>{for (final c in convs) c.id: c};
    // 历史补归档：把老消息里仍存在的原件复制一份进归档目录（幂等，已存在则跳过）。
    if (mounted) setState(() => _archiving = true);
    await _archiveHistorical();
    // 扫描归档目录。
    final scanned = await ConversationFileStore.scanAll();
    if (mounted) {
      setState(() {
        _convMap = convMap;
        _byConv = scanned;
        _archiving = false;
        _loading = false;
      });
    }
  }

  /// 历史补归档：只做一次。用 prefs 标记，避免每次打开都重扫历史——
  /// 否则用户手动删掉的副本会在下次打开时被"补"回来，看起来像越删越多。
  static const _backfillKey = 'deepshart.conv_files.backfilled_v1';

  Future<void> _archiveHistorical() async {
    try {
      final prefs = await ref.read(sharedPrefsProvider.future);
      if (prefs.getBool(_backfillKey) == true) return;
      final store = await ref.read(messageStoreProvider.future);
      final msgs = await store.readAllAcrossConversations();
      for (final m in msgs) {
        for (final a in m.attachments) {
          final src = a.localPath;
          if (src == null || src.isEmpty) continue;
          await ConversationFileStore.archive(
            conversationId: m.conversationId,
            sourcePath: src,
            displayName: a.fileName,
          );
        }
      }
      await prefs.setBool(_backfillKey, true);
    } catch (_) {}
  }

  String _titleOf(String convId) => _convMap[convId]?.title ?? '已删除的会话';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        title: const Text('文件管理'),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          tooltip: '返回',
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: '刷新',
            onPressed: _loading ? null : _load,
          ),
        ],
      ),
      body: _loading
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const CircularProgressIndicator(),
                  if (_archiving) ...[
                    const SizedBox(height: 14),
                    Text('正在整理历史文件…',
                        style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                  ],
                ],
              ),
            )
          : _byConv.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(
                      '还没有已发送的文件。\n发送带附件的消息后，这里会按会话归档管理。',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppColors.textSecondary),
                    ),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemCount: _byConv.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, i) {
                    final convId = _byConv.keys.toList()[i];
                    final files = _byConv[convId]!;
                    final size = ConversationFileStore.totalSize(files);
                    return Card(
                      color: AppColors.surface,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: BorderSide(color: AppColors.outline),
                      ),
                      child: ListTile(
                        leading: Icon(Icons.folder_outlined, color: AppColors.primary, size: 26),
                        title: Text(_titleOf(convId),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 14, color: AppColors.textPrimary)),
                        subtitle: Text(
                          '${files.length} 个文件 · ${_fmtSize(size)}',
                          style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                        ),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () async {
                          await Navigator.push<void>(
                            context,
                            MaterialPageRoute<void>(
                              builder: (_) => ConversationFilesPage(
                                conversationId: convId,
                                title: _titleOf(convId),
                                files: files,
                              ),
                            ),
                          );
                          // 从文件页返回后刷新（可能删了文件）。
                          if (mounted) await _load();
                        },
                      ),
                    );
                  },
                ),
    );
  }

}

/// 某个会话的文件列表级：多选、截止线、删除。
class ConversationFilesPage extends ConsumerStatefulWidget {
  final String conversationId;
  final String title;
  final List<ArchivedFile> files;
  const ConversationFilesPage({
    super.key,
    required this.conversationId,
    required this.title,
    required this.files,
  });

  @override
  ConsumerState<ConversationFilesPage> createState() => _ConversationFilesPageState();
}

class _ConversationFilesPageState extends ConsumerState<ConversationFilesPage> {
  final Set<String> _selected = <String>{};
  bool get _multi => _selected.isNotEmpty;

  /// 单个切换选中：点文件只影响这一个，不再"一点就全选到那里"。
  void _toggle(int index) {
    final path = widget.files[index].path;
    setState(() {
      if (_selected.contains(path)) {
        _selected.remove(path);
      } else {
        _selected.add(path);
      }
    });
  }

  /// 判定线"多选到此处"：点击文件之间的分割线触发，选到该 index 为止。
  void _rangeSelectTo(int index) {
    if (_selected.isEmpty || index < 0 || index >= widget.files.length) return;
    int? first;
    for (var i = 0; i < widget.files.length; i++) {
      if (_selected.contains(widget.files[i].path)) { first = i; break; }
    }
    if (first == null) return;
    final lo = first < index ? first : index;
    final hi = first < index ? index : first;
    setState(() {
      for (var i = lo; i <= hi; i++) {
        _selected.add(widget.files[i].path);
      }
    });
  }

  void _clear() => setState(() => _selected.clear());

  void _selectAll() => setState(() {
        _selected.addAll(widget.files.map((f) => f.path));
      });

  Future<void> _deleteSelected() async {
    final count = _selected.length;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('删除 $count 个归档文件？'),
        content: const Text(
          '仅删除本应用保存的文件副本，不会影响你原始位置的文件，也不影响对话记录。\n此操作不可撤销。',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('确认删除'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final n = await ConversationFileStore.deleteAll(_selected);
    if (mounted) {
      showAppToast(context, '已删除 $n 个归档文件');
      Navigator.pop(context); // 返回会话列表页（上层会刷新）
    }
  }

  @override
  Widget build(BuildContext context) {
    // 电脑用右键进入多选，手机/平板用长按。
    final isDesktop = switch (Theme.of(context).platform) {
      TargetPlatform.windows || TargetPlatform.macOS || TargetPlatform.linux => true,
      _ => false,
    };
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        title: Text(_multi ? '已选 ${_selected.length} 项' : widget.title),
        centerTitle: true,
        leading: _multi
            ? IconButton(icon: const Icon(Icons.close), tooltip: '取消多选', onPressed: _clear)
            : IconButton(
                icon: const Icon(Icons.arrow_back),
                tooltip: '返回',
                onPressed: () => Navigator.pop(context),
              ),
        automaticallyImplyLeading: false,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(
              _multi
                  ? '点文件可勾选/取消 · 点文件之间的分割线可连续多选 · 点右上角删除'
                  : '${isDesktop ? '右键' : '长按'}文件进入多选',
              style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
            ),
          ),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
              itemCount: widget.files.length,
              separatorBuilder: (context, idx) {
                // 多选态：文件之间的分割线可点击 = "多选到此处"（选到第 idx 条为止）。
                if (_multi) {
                  return Tooltip(
                    message: '多选到此处',
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => _rangeSelectTo(idx),
                      child: Container(
                        height: 18,
                        color: Colors.transparent,
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Divider(
                            height: 1, thickness: 1,
                            color: AppColors.primary.withValues(alpha: 0.6)),
                      ),
                    ),
                  );
                }
                return const SizedBox(height: 6);
              },
              itemBuilder: (context, i) {
                final f = widget.files[i];
                final isSel = _selected.contains(f.path);
                return GestureDetector(
                  onLongPress: isDesktop ? null : () => _toggle(i),
                  onSecondaryTapDown: isDesktop ? (_) => _toggle(i) : null,
                  onTap: _multi ? () => _toggle(i) : null,
                  child: Card(
                    color: AppColors.surface,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                      side: BorderSide(
                        color: isSel ? AppColors.primary : AppColors.outline,
                        width: isSel ? 2 : 1,
                      ),
                    ),
                    child: ListTile(
                      leading: Icon(
                        isSel ? Icons.check_circle : Icons.insert_drive_file_outlined,
                        color: isSel ? AppColors.primary : AppColors.textSecondary,
                      ),
                      title: Text(f.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 13, color: AppColors.textPrimary)),
                      subtitle: Text(
                        '${_fmtSize(f.size)} · 副本',
                        style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          // 多选底部固定栏：全选/取消并列一行，删除单独一行——避免窄屏挤出。
          if (_multi)
            SafeArea(
              child: Container(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  border: Border(top: BorderSide(color: AppColors.outline)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            icon: const Icon(Icons.select_all, size: 16),
                            label: const Text('全选'),
                            onPressed: _selectAll,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton.icon(
                            icon: const Icon(Icons.close, size: 16),
                            label: const Text('取消多选'),
                            onPressed: _clear,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        icon: const Icon(Icons.delete_outline, size: 16),
                        label: Text('删除所选（${_selected.length}）'),
                        style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
                        onPressed: _deleteSelected,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
