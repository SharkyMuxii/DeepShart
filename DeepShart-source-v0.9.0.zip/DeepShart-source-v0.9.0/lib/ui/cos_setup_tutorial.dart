// target: lib/ui/cos_setup_tutorial.dart
// 职责：腾讯云 COS 密钥获取图文教程，放在 COS 配置页最上方。
// 内容来自用户提供的《腾讯云教程.docx》，已裁掉浏览器顶栏与私人浏览记录、
// 遮挡密钥/余额等隐私。URL 可点击直接跳转。

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/theme.dart';
import 'cos_tutorial_data.dart';

/// 可折叠的 COS 教程区块。默认收起（用户点开才看，避免一进页面就刷屏）。
class CosSetupTutorial extends StatefulWidget {
  const CosSetupTutorial({super.key});

  @override
  State<CosSetupTutorial> createState() => _CosSetupTutorialState();
}

class _CosSetupTutorialState extends State<CosSetupTutorial> {
  bool _expanded = false;

  Future<void> _openUrl(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null) return;
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.outline),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // 标题栏（可点折叠）
          InkWell(
            onTap: () => setState(() => _expanded = !_expanded),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(10)),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Icon(Icons.menu_book, size: 18, color: AppColors.primary),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text('申请腾讯云 COS 教程（图文，点开查看）',
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: AppColors.textPrimary)),
                  ),
                  Icon(_expanded ? Icons.expand_less : Icons.expand_more,
                      color: AppColors.textSecondary),
                ],
              ),
            ),
          ),
          if (_expanded) ...[
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // 顶部醒目风险提示
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFEBEE),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: const Color(0xFFFFCDD2)),
                    ),
                    child: const Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(Icons.warning_amber, size: 16, color: Color(0xFFC62828)),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            '密钥等于你腾讯云账户的钥匙：只能自己填、自己保管，绝不要发给任何人。'
                            '泄露会造成数据被窃、余额被刷。教程里所有密钥截图均已打码。',
                            style: TextStyle(fontSize: 11, height: 1.5, color: Color(0xFFB71C1C)),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  // 逐段渲染教程
                  for (final step in kCosTutorialSteps) _buildStep(step),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildStep(TutorialStep step) {
    final isHeader =
        step.kind == TutorialStepKind.header || step.text.endsWith('：');
    final widgets = <Widget>[];

    if (step.text.isNotEmpty) {
      if (step.kind == TutorialStepKind.url) {
        // 可点击链接
        widgets.add(Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: InkWell(
            onTap: () => _openUrl(step.text),
            child: Text(
              step.text,
              style: TextStyle(
                fontSize: 12,
                color: AppColors.primary,
                decoration: TextDecoration.underline,
              ),
            ),
          ),
        ));
      } else {
        widgets.add(Padding(
          padding: EdgeInsets.only(
              top: isHeader ? 10 : 3, bottom: step.images.isEmpty ? 4 : 2),
          child: Text(
            step.text,
            style: TextStyle(
              fontSize: isHeader ? 13 : 12,
              fontWeight: isHeader ? FontWeight.w700 : FontWeight.normal,
              height: 1.5,
              color: isHeader ? AppColors.primary : AppColors.textPrimary,
            ),
          ),
        ));
      }
    }

    for (final img in step.images) {
      widgets.add(Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: Image.asset(
            img,
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) => Container(
              padding: const EdgeInsets.all(8),
              color: AppColors.surface,
              child: Text('图片缺失：$img',
                  style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
            ),
          ),
        ),
      ));
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: widgets,
    );
  }
}
