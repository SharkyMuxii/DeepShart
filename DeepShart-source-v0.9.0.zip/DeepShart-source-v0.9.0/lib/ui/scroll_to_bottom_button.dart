// target: lib/ui/scroll_to_bottom_button.dart
// 职责：智能"一键到底/到顶"悬浮按钮——顺着滑动方向浮现，停住或反向立刻淡出，
//       平时完全不遮挡界面。供聊天正文、会话列表、设置页复用。
//
// 用户要求（原话）：
//   底部按钮：「只有在向下滑动时出现，一旦停住或者向上了就立刻淡出消失，不要遮挡界面」
//   顶部按钮：「逻辑和一键直达底部相同」（即向上滑出现、停住或向下滑淡出）

import 'package:flutter/material.dart';

import '../core/theme.dart';

enum ScrollJumpDirection { bottom, top, both }

class ScrollToBottomButton extends StatefulWidget {
  final ScrollController controller;

  /// 显示哪些按钮：底部 / 顶部 / 两者。聊天页用 both，列表/设置用 bottom。
  final ScrollJumpDirection direction;

  /// 距离边缘多少像素内就认为"已到边"，此时对应按钮不显示。
  final double edgeThreshold;

  /// 为 false 时完全不显示。
  final bool enabled;

  /// 底部按钮距离底部的偏移。多选栏出现时调大，避免与底部操作栏重叠。
  final double bottomOffset;

  const ScrollToBottomButton({
    super.key,
    required this.controller,
    this.direction = ScrollJumpDirection.bottom,
    this.edgeThreshold = 120,
    this.enabled = true,
    this.bottomOffset = 16,
  });

  @override
  State<ScrollToBottomButton> createState() => _ScrollToBottomButtonState();
}

class _ScrollToBottomButtonState extends State<ScrollToBottomButton> {
  bool _showBottom = false;
  bool _showTop = false;
  double _lastOffset = 0;
  DateTime _lastScrollAt = DateTime.now();
  bool _programmaticScroll = false;

  @override
  void initState() {
    super.initState();
    _lastOffset = widget.controller.hasClients ? widget.controller.offset : 0;
    widget.controller.addListener(_onScroll);
  }

  @override
  void didUpdateWidget(ScrollToBottomButton old) {
    super.didUpdateWidget(old);
    if (old.controller != widget.controller) {
      old.controller.removeListener(_onScroll);
      widget.controller.addListener(_onScroll);
      _lastOffset = widget.controller.hasClients ? widget.controller.offset : 0;
    }
  }

  void _onScroll() {
    if (!widget.controller.hasClients) return;
    // 禁用时（如多选栏出现）不显示任何按钮，避免重叠。
    if (!widget.enabled) {
      if (_showBottom || _showTop) setState(() { _showBottom = false; _showTop = false; });
      return;
    }
    // 程序触发的滚动（点击按钮后自动滚动）不应触发方向判断。
    if (_programmaticScroll) return;

    final offset = widget.controller.offset;
    final delta = offset - _lastOffset;
    _lastOffset = offset;
    _lastScrollAt = DateTime.now();

    if (!mounted) return;
    final atBottom = widget.controller.position.extentAfter < widget.edgeThreshold;
    final atTop = offset < widget.edgeThreshold;

    // 向下滑（delta>2）且不在底部 → 显示"到底"；反向立刻隐藏。
    final wantBottom = widget.direction != ScrollJumpDirection.top &&
        delta > 2 &&
        !atBottom;
    // 向上滑（delta<-2）且不在顶部 → 显示"到顶"；反向立刻隐藏。
    final wantTop = widget.direction != ScrollJumpDirection.bottom &&
        delta < -2 &&
        !atTop;

    if (wantBottom != _showBottom || wantTop != _showTop) {
      setState(() {
        _showBottom = wantBottom;
        _showTop = wantTop;
      });
    }

    // 停住 400ms 自动淡出——"一旦停住就消失"。
    Future<void>.delayed(const Duration(milliseconds: 450), () {
      if (!mounted) return;
      if (DateTime.now().difference(_lastScrollAt) >= const Duration(milliseconds: 400) &&
          (_showBottom || _showTop)) {
        setState(() {
          _showBottom = false;
          _showTop = false;
        });
      }
    });
  }

  Future<void> _jump(bool toBottom) async {
    if (!widget.controller.hasClients) return;
    _programmaticScroll = true;
    setState(() {
      _showBottom = false;
      _showTop = false;
    });
    await widget.controller.animateTo(
      toBottom ? widget.controller.position.maxScrollExtent : 0,
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeOut,
    );
    _programmaticScroll = false;
    _lastOffset = widget.controller.offset;
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onScroll);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => IgnorePointer(
        ignoring: !widget.enabled || (!_showBottom && !_showTop),
        child: Stack(
          children: [
            // 到顶按钮：顶部居中。
            AnimatedOpacity(
              opacity: _showTop ? 1 : 0,
              duration: const Duration(milliseconds: 180),
              child: Align(
                alignment: Alignment.topCenter,
                child: Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: FloatingActionButton.small(
                    heroTag: 'scroll_to_top_${widget.controller.hashCode}',
                    tooltip: '一键到顶',
                    backgroundColor: AppColors.primary,
                    foregroundColor: Colors.white,
                    onPressed: _showTop ? () => _jump(false) : null,
                    child: const Icon(Icons.keyboard_arrow_up, size: 22),
                  ),
                ),
              ),
            ),
            // 到底按钮：底部居中。
            AnimatedOpacity(
              opacity: _showBottom ? 1 : 0,
              duration: const Duration(milliseconds: 180),
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                  padding: EdgeInsets.only(bottom: widget.bottomOffset),
                  child: FloatingActionButton.small(
                    heroTag: 'scroll_to_bottom_${widget.controller.hashCode}',
                    tooltip: '一键到底',
                    backgroundColor: AppColors.primary,
                    foregroundColor: Colors.white,
                    onPressed: _showBottom ? () => _jump(true) : null,
                    child: const Icon(Icons.keyboard_arrow_down, size: 22),
                  ),
                ),
              ),
            ),
          ],
        ),
      );
}
