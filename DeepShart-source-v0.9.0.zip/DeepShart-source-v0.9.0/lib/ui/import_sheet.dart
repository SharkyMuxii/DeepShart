// target: lib/ui/import_sheet.dart
// 职责：对话导入面板——选文件→解析预览→用户选择是否压缩/是否提取记忆点→提交入库。

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:file_picker/file_picker.dart';
import 'package:uuid/uuid.dart';

import '../ai/memory_batch_extractor.dart';
import '../core/theme.dart';
import 'app_toast.dart';
import '../data/models/chat_message.dart';
import '../data/models/compaction_view.dart';
import '../data/store/conversation_store.dart';
import '../import/context_compressor.dart';
import '../import/format_analyzer.dart';
import '../import/spec_based_importer.dart';
import '../import/import_orchestrator.dart';
import '../import/import_to_memory.dart';
import '../state/app_providers.dart';
import '../state/chat_controller.dart';
import 'manual_anchor_sheet.dart';

class ImportSheet extends ConsumerStatefulWidget {
  const ImportSheet({super.key});

  @override
  ConsumerState<ImportSheet> createState() => _ImportSheetState();
}

class _ImportSheetState extends ConsumerState<ImportSheet> {
  String? _fileName;
  List<ChatMessage>? _messages;
  ParseResult? _parsed;
  String? _convId;
  String? _title;
  String? _status;
  bool _busy = false;
  bool _doCompress = false;
  bool _doMemory = false;

  /// 文本类导入的原文，供"重新手动标注"复用。
  String? _rawText;

  /// 用户未定夺、无法归类的行（锚点模式下）。
  List<String> _unassigned = const <String>[];

  /// 自动解析是否失败——失败时才醒目显示「手动标注」入口。
  bool _manualMode = false;

  /// 手动标注警告条是否展开（用户可手动展开，自动解析失败时默认展开）。
  bool _manualEntryExpanded = false;

  @override
  Widget build(BuildContext context) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.75,
        maxChildSize: 0.92,
        builder: (context, scrollController) => Scaffold(
          backgroundColor: AppColors.surface,
          appBar: AppBar(
            title: const Text('导入对话'),
            centerTitle: true,
            automaticallyImplyLeading: false,
            actions: [
              IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => Navigator.pop(context),
              ),
            ],
          ),
          body: ListView(
            controller: scrollController,
            padding: const EdgeInsets.all(16),
            children: [
              Text(
                '支持 DeepSeek 导出的 JSON，或普通文本对话记录。导入后可自主选择是否压缩上下文、是否提取记忆点。',
                style: TextStyle(fontSize: 12, color: AppColors.textSecondary, height: 1.5),
              ),
              const SizedBox(height: 10),
              // 费用提示：导入的新对话没有本地前缀缓存，前几次请求会重新
              // 提交完整上下文，token 消耗明显高于后续对话。
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF4E5),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: const Color(0xFFFFD9A8)),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.info_outline, size: 16, color: Color(0xFFB26A00)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        '费用提醒：导入后的前几次对话会消耗较多余额——新对话没有上下文缓存，'
                        '服务端需要重新处理整段历史。建议先观察前几轮的 token 用量再继续长聊。',
                        style: const TextStyle(
                            fontSize: 12, height: 1.5, color: Color(0xFF8A5A00)),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              _FilePickerCard(
                fileName: _fileName,
                onPick: _pickFile,
              ),
              const SizedBox(height: 12),
              if (_status != null)
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.primarySoft,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(_status!, style: const TextStyle(fontSize: 12, height: 1.5)),
                ),
              const SizedBox(height: 12),
              if (_parsed != null &&
                  ((_messages?.isNotEmpty ?? false) || _rawText != null))
                _buildRoleConfirmCard(),
              if (_messages != null) ...[
                SwitchListTile(
                  value: _doCompress,
                  title: const Text('导入后压缩上下文'),
                  subtitle: const Text('把较早的历史折叠成摘要，节省 token'),
                  onChanged: (v) => setState(() => _doCompress = v),
                ),
                SwitchListTile(
                  value: _doMemory,
                  title: const Text('提取重要记忆点'),
                  subtitle: const Text('识别偏好/决策并存入记忆库'),
                  onChanged: (v) => setState(() => _doMemory = v),
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  icon: _busy
                      ? const SizedBox(width: 16, height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.download),
                  label: const Text('确认导入'),
                  onPressed: _busy ? null : _commit,
                ),
              ],
            ],
          ),
        ),
      );

  Future<void> _pickFile() async {
    // 用户要求：必须先接入正常工作的大模型 API 才允许导入。
    final ready = await ref.read(apiKeyConfiguredProvider.future);
    if (!ready) {
      if (mounted) {
        showAppToast(context, '请先到「全局设置」配置可用的大模型 API Key，再导入对话');
      }
      return;
    }
    // withData: true —— 直接拿字节，不依赖 path 能否被 File() 打开。
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['json', 'txt', 'md'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    final picked = result.files.single;
    setState(() {
      _fileName = picked.name;
      _status = '解析中…';
      _messages = null;
    });
    try {
      final store = await ref.read(messageStoreProvider.future);
      final identity = await ref.read(localIdentityProvider.future);
      final orchestrator = ImportOrchestrator(
        store: store,
        localDeviceId: identity.deviceId,
      );

      // 优先用字节；只有拿不到 bytes 时才退回按路径读取。
      ParseResult parsed;
      final bytes = picked.bytes;
      if (bytes != null && bytes.isNotEmpty) {
        parsed = orchestrator.parseBytes(bytes, fileName: picked.name);
      } else if (picked.path != null) {
        parsed = await orchestrator.parseFile(picked.path!);
      } else {
        setState(() => _status = '读取失败：文件选择器没有返回可读内容，请重新选择。');
        return;
      }

      var messages = parsed.deepSeek?.messages ?? parsed.plainText?.messages ?? const <ChatMessage>[];
      var convId = parsed.conversationId ?? const Uuid().v4();
      final title = parsed.deepSeek?.title ?? _fileName ?? '导入会话';
      final rawText = parsed.rawText;
      _rawText = rawText;
      _unassigned = const <String>[];

      // 文本类记录：默认【自动解析】（不让用户一上来就面对标注框，照顾小白）。
      // 只有自动解析失败/效果差时，才提示用「手动标注」兜底。
      _manualMode = false;
      if (parsed.deepSeek == null && rawText != null && rawText.trim().isNotEmpty) {
        setState(() => _status = '正在自动识别聊天记录排版…');
        ImportFormatSpec? spec;
        try {
          final ai = await ref.read(aiProviderProvider.future);
          spec = await ImportFormatAnalyzer(provider: ai).analyze(rawText);
        } catch (_) {
          spec = null;
        }
        var used = false;
        final autoSpec = spec;
        if (autoSpec != null) {
          final specResult = SpecBasedImporter().parse(
            rawText,
            spec: autoSpec,
            conversationId: convId,
          );
          if (specResult.isUsable) {
            messages = specResult.messages;
            _unassigned = specResult.unassigned;
            used = true;
            final note = autoSpec.note;
            setState(() => _status = '自动识别完成：解析出 ${messages.length} 条消息'
                '${note != null ? '（$note）' : ''}');
          }
        }
        if (!used) {
          // 自动解析失败 → 降级内置规则；提示用户"若不对再用手动标注"。
          final fallback = SpecBasedImporter().parse(
            rawText,
            spec: const ImportFormatSpec(),
            conversationId: convId,
          );
          messages = fallback.messages;
          _manualMode = true; // 醒目显示手动标注入口
          _manualEntryExpanded = true; // 自动失败，展开警告条提醒用户
          setState(() => _status = messages.isNotEmpty
              ? '自动识别效果不佳，已用内置规则临时解析出 ${messages.length} 条。'
                  '\n⚠ 若角色不对，请用下方红框里的「手动标注」修正后再导入。'
              : '自动识别失败。⚠ 请用下方红框里的「手动标注」标出两段话后再导入。');
        }
      }

      setState(() {
        _messages = messages;
        _parsed = parsed;
        _convId = convId;
        _title = title;
        if (messages.isEmpty) {
          _status = _status ?? '未解析出消息，请点「重新手动标注」再试。';
        }
      });
    } on FormatException catch (e) {
      setState(() => _status = '解析失败：${e.message}');
    } catch (e) {
      setState(() => _status = '解析失败：$e');
    }
  }

  /// 手动标注入口：醒目警告条，默认收起。
  /// 用户明确要求：默认用户是小白，标注入口只在需要时出现，且明确警告
  /// "标错会导致导入异常，仅在导入异常/角色不对时使用"。
  Widget _buildManualAnchorEntry() {
    final color = _manualMode ? const Color(0xFFC62828) : const Color(0xFFB26A00);
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: _manualMode ? const Color(0xFFFFEBEE) : AppColors.background,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: _manualMode ? const Color(0xFFFFCDD2) : AppColors.outline),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          InkWell(
            onTap: () => setState(() => _manualEntryExpanded = !_manualEntryExpanded),
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Icon(Icons.warning_amber, size: 18, color: color),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _manualMode ? '⚠ 自动识别失败，建议手动标注' : '导入异常时才用：手动标注',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: color),
                    ),
                  ),
                  Icon(_manualEntryExpanded ? Icons.expand_less : Icons.expand_more,
                      size: 18, color: AppColors.textSecondary),
                ],
              ),
            ),
          ),
          if (_manualEntryExpanded) ...[
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '手动标注用于自动识别出错时兜底：你标出一段 AI 说的话、一段你说的话，'
                    '系统据此学会角色和时间的标记格式。',
                    style: TextStyle(fontSize: 11, height: 1.5, color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '⚠ 注意：标注错误会导致导入异常！正常情况下请用自动识别，'
                    '只有当角色明显分错、或自动识别失败时才使用此功能。',
                    style: TextStyle(fontSize: 11, height: 1.5,
                        color: color, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerRight,
                    child: FilledButton.tonalIcon(
                      icon: const Icon(Icons.edit_note, size: 16),
                      label: const Text('手动标注'),
                      onPressed: _busy ? null : _remark,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  /// 手动标注卡片：取代原"核对/对调角色"定夺窗口。
  /// 只对文本类导入有意义（有原文可重新标注）；JSON 有明确 role 字段，不显示。
  Widget _buildRoleConfirmCard() {
    final messages = _messages ?? const <ChatMessage>[];
    // JSON 路径且没消息：无需显示（异常情况由 status 文案说明）。
    if (_rawText == null && messages.isEmpty) return const SizedBox.shrink();
    final userCount = messages.where((m) => m.role == MessageRole.user).length;
    final aiCount = messages.where((m) => m.role == MessageRole.assistant).length;
    final isText = _rawText != null;

    return Column(
      children: [
        Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF4E5),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: const Color(0xFFFFD8A8)),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.fact_check_outlined, size: 18, color: Color(0xFFB25E00)),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '角色：用户 $userCount 条 · AI $aiCount 条',
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      isText
                          ? '已自动识别角色。若发现角色不对（比如你说的话跑到了 AI 那边），'
                              '再用下面的「手动标注」修正。'
                          : 'JSON 文件按内部 role 字段判断说话人。',
                      style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.5),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        // 手动标注入口：带醒目警告，默认收起；自动解析失败时自动展开。
        if (isText)
          _buildManualAnchorEntry(),
        // 无法归类的行：逐条交用户定夺，绝不自行塞进某角色。
        if (_unassigned.isNotEmpty)
          Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFFFEBEE),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFFFFCDD2)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('以下 ${_unassigned.length} 行无法自动归类，请标注后再导入：',
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600,
                        color: Color(0xFFB71C1C))),
                const SizedBox(height: 6),
                ..._unassigned.take(10).map((line) => Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Text('· ${line.length > 80 ? '${line.substring(0, 80)}…' : line}',
                          style: const TextStyle(fontSize: 11, height: 1.4)),
                    )),
                if (_unassigned.length > 10)
                  Text('…还有 ${_unassigned.length - 10} 行',
                      style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerRight,
                  child: FilledButton.tonalIcon(
                    icon: const Icon(Icons.edit_note, size: 16),
                    label: const Text('重新标注以归类'),
                    onPressed: _busy ? null : _remark,
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  /// 基于用户标注的锚点得到排版 spec。
  /// 先让大模型解析两个标记头；模型失败则用确定性方法直接从标记头剥出角色标记
  /// （标记头是用户亲手框的，最可靠），最大限度避免"整段垮掉"。
  Future<ImportFormatSpec?> _specFromAnchors(ManualAnchors anchors) async {
    ImportFormatSpec? spec;
    try {
      final ai = await ref.read(aiProviderProvider.future);
      spec = await ImportFormatAnalyzer(provider: ai).analyzeWithAnchors(
        excerpt: anchors.excerpt,
        aiHead: anchors.aiHead,
        humanHead: anchors.humanHead,
        aiSample: anchors.aiSample,
        humanSample: anchors.humanSample,
      );
    } catch (_) {
      spec = null;
    }
    if (spec != null && spec.isValid) return spec;
    return specFromAnchorsDirectly(anchors.aiHead, anchors.humanHead);
  }

  /// 重新手动标注：重新弹标注窗 → 重新识别 → 重新解析。
  Future<void> _remark() async {
    final rawText = _rawText;
    if (rawText == null) return;
    final anchors = await showManualAnchorSheet(context, excerpt: rawText);
    if (anchors == null || !mounted) return;
    setState(() => _status = '正在根据你标注的标记重新识别…');
    try {
      final spec = await _specFromAnchors(anchors);
      if (spec == null) {
        setState(() => _status = '没能识别你标注的标记，请框选更典型的 AI 段和人说的话再试。');
        return;
      }
      final result = SpecBasedImporter().parse(
        rawText,
        spec: spec,
        conversationId: _convId ?? const Uuid().v4(),
      );
      setState(() {
        if (result.isUsable) {
          _messages = result.messages;
          _unassigned = result.unassigned;
          _manualMode = false; // 标注成功，取消警告状态
          _status = '已按你标注的标记重新识别：${result.messages.length} 条消息'
              '${result.hasUnassigned ? '（${result.unassigned.length} 行待定夺）' : ''}';
        } else {
          _status = '这次标注未能解析出消息，请框选更典型的 AI 段和人说的话再试。';
        }
      });
    } catch (e) {
      setState(() => _status = '重新识别失败：$e');
    }
  }

  Future<void> _commit() async {
    if (_messages == null || _messages!.isEmpty) return;
    // 压缩与记忆点提取都需要调用 AI；未配置 Key 时提前提示，避免导入中途失败。
    if (_doCompress || _doMemory) {
      final ready = await ref.read(apiKeyConfiguredProvider.future);
      if (!ready && mounted) {
        showAppToast(context, '压缩/记忆点需先配置 API Key，请到全局设置填写');
        return;
      }
    }
    setState(() => _busy = true);
    try {
      final store = await ref.read(messageStoreProvider.future);
      final identity = await ref.read(localIdentityProvider.future);
      final convStore = await ref.read(conversationStoreProvider.future);
      final orchestrator = ImportOrchestrator(
        store: store,
        localDeviceId: identity.deviceId,
      );

      // 导入是写库操作，动手前先留一份快照（失败不影响导入）。
      try {
        final backup = await ref.read(backupServiceProvider.future);
        await backup.backupBeforeImport();
      } catch (_) {
        // 备份是保险不是前提。
      }

      // 确保会话元数据存在
      final existing = await convStore.get(_convId!);
      if (existing == null) {
        await convStore.upsert(Conversation.create(id: _convId!, title: _title!));
      }

      var toImport = List<ChatMessage>.from(_messages!);
      CompactionView? pendingView;

      // 可选：压缩
      if (_doCompress) {
        final ai = await ref.read(aiProviderProvider.future);
        final compressor = ContextCompressor(provider: ai, store: store);
        final settings = await convStore.getSettings(_convId!);
        // 压缩现在是"只算视图、不改消息"：导入的每一条都会原样入库，
        // 折叠/截断只体现在之后发给模型的上下文里。因此不存在
        // "给还没入库的消息写墓碑导致导入变空白"的问题。
        final result = await compressor.compress(
          conversationId: _convId!,
          messages: toImport,
          settings: settings,
          localDeviceId: identity.deviceId,
        );
        if (!result.skipped) pendingView = result.view;
      }

      final outcome = await orchestrator.commitMessages(toImport);

      // 消息入库后再落视图：视图里的 id 必须与库内一致。
      if (pendingView != null) {
        final viewStore = await ref.read(compactionViewStoreProvider.future);
        await viewStore.save(pendingView);
        ref.invalidate(compactionViewProvider(_convId!));
      }

      // 导入即转标准记忆库（默认必做、确定性、不过 AI 提炼）：
      // 把每条导入对话原文转成记忆条目，后续会话可检索命中。原始导入文件不动。
      var memorySaved = 0;
      try {
        final memStore = await ref.read(memoryStoreProvider.future);
        final memOutcome = await ImportToMemory(
          memoryStore: memStore,
          deviceId: identity.deviceId,
        ).run(
          conversationId: _convId!,
          sourceLabel: _title ?? _fileName ?? '导入',
          messages: toImport,
        );
        memorySaved = memOutcome.saved;
      } catch (_) {
        // 转记忆失败不影响导入主流程；原始消息已安全入库。
      }

      // 可选：AI 提炼重要记忆点（增强项，与上面的全量转记忆并存）。
      if (_doMemory) {
        await _extractMemories(orchestrator, toImport, identity.deviceId);
      }

      ref.invalidate(conversationsProvider);
      ref.invalidate(messagesProvider(_convId!));
      ref.invalidate(memoriesProvider(_convId!));

      if (mounted) {
        Navigator.pop(context);
        showAppToast(context, '导入完成：${outcome.importedCount} 条消息'
                '，已存入 $memorySaved 条记忆'
                '${outcome.conflictCount > 0 ? '，${outcome.conflictCount} 条冲突待裁决' : ''}');
      }
    } catch (e) {
      if (mounted) setState(() => _status = '导入失败：$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  /// 导入后自动提取记忆点。
  ///
  /// 旧实现只抽样前 8 条用户消息，再让模型总结成一句"导入要点"——
  /// 对 1M token 的对话等于什么都没记住。现在改成按 20 轮一批全量提取，
  /// 既覆盖完整又不会一次把请求撑爆（超窗口会直接 400）。
  Future<void> _extractMemories(
    ImportOrchestrator orchestrator,
    List<ChatMessage> messages,
    String deviceId,
  ) async {
    final ai = await ref.read(aiProviderProvider.future);
    final memoryStore = await ref.read(memoryStoreProvider.future);
    final messageStore = await ref.read(messageStoreProvider.future);

    final extractor = MemoryBatchExtractor(
      provider: ai,
      messageStore: messageStore,
      memoryStore: memoryStore,
    );
    final pending = messages
        .where((m) => m.role != MessageRole.system)
        .toList(growable: false);
    if (pending.isEmpty) return;

    final estimate = extractor.estimate(pending);
    if (mounted) {
      setState(() => _status = '正在提取记忆点：${estimate.display}');
    }

    var done = 0;
    try {
      final outcome = await extractor.run(
        conversationId: _convId!,
        deviceId: deviceId,
        messages: pending,
        onProgress: (d, t) {
          done = d;
          if (mounted) {
            setState(() => _status = '正在提取记忆点：$d / $t 批');
          }
        },
      );
      if (mounted) {
        setState(() => _status = '记忆点：${outcome.saved} 个（$done 批）');
      }
    } catch (_) {
      // 记忆提取失败不影响导入主流程；用户可稍后在会话设置里点"补跑未提取"。
      if (mounted) {
        setState(() => _status = '记忆点提取未完成，可在会话设置里补跑');
      }
    }
  }
}

class _FilePickerCard extends StatelessWidget {
  final String? fileName;
  final VoidCallback onPick;

  const _FilePickerCard({required this.fileName, required this.onPick});

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onPick,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            border: Border.all(color: AppColors.outline),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Icon(Icons.file_upload, color: AppColors.primary, size: 28),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  fileName ?? '点击选择对话文件（.json / .txt / .md）',
                  style: TextStyle(
                    color: fileName == null ? AppColors.textSecondary : AppColors.textPrimary,
                    fontSize: 13,
                  ),
                ),
              ),
            ],
          ),
        ),
      );
}
