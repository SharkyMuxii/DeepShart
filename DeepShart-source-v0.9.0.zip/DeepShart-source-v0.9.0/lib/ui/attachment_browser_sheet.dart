// target: lib/ui/attachment_browser_sheet.dart
// 职责：会话文件列表——汇总当前会话【尚未发送的草稿附件】（输入框上方那排要发送的文件），
// 支持预览与长按/右键多选删除。已发送的附件留在对话气泡里，不在这里显示。

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/theme.dart';
import '../state/app_providers.dart';
import 'app_toast.dart';

/// 会话文件列表 BottomSheet（管理"即将发送"的草稿附件）。
class AttachmentBrowserSheet extends ConsumerStatefulWidget {
  final String conversationId;
  const AttachmentBrowserSheet({super.key, required this.conversationId});

  @override
  ConsumerState<AttachmentBrowserSheet> createState() => _AttachmentBrowserSheetState();
}

class _AttachmentBrowserSheetState extends ConsumerState<AttachmentBrowserSheet> {
  /// 多选模式：被选中的草稿附件下标集合。
  final Set<int> _selected = <int>{};
  bool get _multiSelect => _selected.isNotEmpty;

  void _toggle(int index) => setState(() {
        if (_selected.contains(index)) {
          _selected.remove(index);
        } else {
          _selected.add(index);
        }
      });

  void _clearSelection() => setState(() => _selected.clear());

  Future<void> _openFile(DraftAttachment a) async {
    final path = a.path;
    if (path.isEmpty || !File(path).existsSync()) {
      if (mounted) showAppToast(context, '附件原件不在本机，仅显示文件名');
      return;
    }
    try {
      final ok = await launchUrl(Uri.file(path), mode: LaunchMode.externalApplication);
      if (!ok && mounted) showAppToast(context, '没有找到可以打开此文件的应用');
    } catch (_) {
      if (mounted) showAppToast(context, '无法打开此文件');
    }
  }

  /// 从草稿里删除选中的附件（等价于取消这些"即将发送"的文件）。
  void _deleteSelected() {
    final drafts = ref.read(draftAttachmentsProvider(widget.conversationId));
    final removing = _selected.toList()..sort((a, b) => b.compareTo(a));
    final next = List<DraftAttachment>.from(drafts);
    for (final i in removing) {
      if (i >= 0 && i < next.length) next.removeAt(i);
    }
    ref.read(draftAttachmentsProvider(widget.conversationId).notifier).state = next;
    if (mounted) {
      showAppToast(context, '已移除 ${removing.length} 个待发送附件');
      _clearSelection();
    }
  }

  @override
  Widget build(BuildContext context) {
    final drafts = ref.watch(draftAttachmentsProvider(widget.conversationId));
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.8,
      maxChildSize: 0.95,
      builder: (context, scrollController) => Scaffold(
        backgroundColor: AppColors.surface,
        appBar: AppBar(
          title: Text(_multiSelect ? '已选 ${_selected.length} 项' : '文件列表'),
          centerTitle: true,
          automaticallyImplyLeading: !_multiSelect,
          leading: _multiSelect
              ? IconButton(icon: const Icon(Icons.close), onPressed: _clearSelection)
              : null,
          actions: [
            if (_multiSelect)
              IconButton(
                icon: const Icon(Icons.delete_outline, color: Colors.red),
                tooltip: '删除所选',
                onPressed: _deleteSelected,
              ),
          ],
        ),
        body: drafts.isEmpty
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text('还没有待发送的图片或文件。\n在对话里点「添加文件」选择的附件会出现在这里，发送后则留在对话中。',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppColors.textSecondary)),
                ),
              )
            : Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Text(
                      _multiSelect
                          ? '再次长按/右键可切换选中；点右上角删除'
                          : '这里是即将发送的文件 · 长按（电脑右键）可多选删除 · 点按可打开预览',
                      style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                    ),
                  ),
                  Expanded(
                    child: GridView.builder(
                      controller: scrollController,
                      padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
                      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                        maxCrossAxisExtent: 160,
                        mainAxisSpacing: 10,
                        crossAxisSpacing: 10,
                        childAspectRatio: 0.82,
                      ),
                      itemCount: drafts.length,
                      itemBuilder: (context, i) => _entryTile(context, i, drafts[i]),
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _entryTile(BuildContext context, int index, DraftAttachment a) {
    final isSel = _selected.contains(index);
    final path = a.path;
    final exists = path.isNotEmpty && File(path).existsSync();
    final isImage = _looksLikeImage(a.name);

    return GestureDetector(
      onTap: () => _multiSelect ? _toggle(index) : _openFile(a),
      onLongPress: () => _toggle(index),
      onSecondaryTapDown: (_) => _toggle(index),
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSel ? AppColors.primary : AppColors.outline,
            width: isSel ? 2 : 1,
          ),
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(
                  child: isImage && exists
                      ? Image.file(File(path), fit: BoxFit.cover)
                      : Container(
                          color: AppColors.primarySoft,
                          child: Center(
                            child: Icon(
                              isImage ? Icons.image_outlined : Icons.insert_drive_file_outlined,
                              size: 36,
                              color: AppColors.primary,
                            ),
                          ),
                        ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 5),
                  child: Text(a.name.isEmpty ? '附件' : a.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 11, color: AppColors.textPrimary)),
                ),
              ],
            ),
            if (isSel)
              Positioned(
                top: 4,
                right: 4,
                child: Icon(Icons.check_circle, color: AppColors.primary, size: 22),
              ),
          ],
        ),
      ),
    );
  }

  bool _looksLikeImage(String name) {
    final lower = name.toLowerCase();
    return ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.heic'].any(lower.endsWith);
  }
}
