// target: lib/ui/markdown_view.dart
// 职责：轻量 Markdown 渲染——识别标题、加粗/斜体/删除线/高亮、行内代码、代码块、
//       列表、引用、分隔线与表格，把模型输出按排版呈现，而不是裸露 ** 和 #。
//
// 为什么不用现成的 markdown 包：需求集中在聊天气泡内的常见语法，
// 自绘可以精确控制字号层级（"加大"）、颜色与选中行为，也不引入额外依赖。

import 'package:flutter/material.dart';
import 'package:flutter_math_fork/flutter_math.dart';

import '../core/theme.dart';

class MarkdownView extends StatelessWidget {
  final String data;
  final TextStyle baseStyle;

  /// 深色气泡（用户消息）里链接/代码需要更亮的配色。
  final bool onDark;

  /// 点击正文里的引用角标 〔n〕 时回调（n 为引用序号，从 1 开始）。
  /// 为 null 时角标仍显示为小数字，但不可点击。
  final void Function(int index)? onCitationTap;

  const MarkdownView({
    super.key,
    required this.data,
    required this.baseStyle,
    this.onDark = false,
    this.onCitationTap,
  });

  /// 代码块/引用/表格底色必须跟随主题：暗色模式下 textPrimary 是浅色，
  /// 若这里仍是浅灰 0xFFF1F3F7，浅字压浅底就完全看不清（用户截图实测）。
  Color get _codeBg {
    if (onDark) return Colors.white24;
    if (AppColors.isDark) return AppColors.primarySoft; // 深色主题下的代码块底
    return const Color(0xFFF1F3F7);
  }

  Color get _linkColor => onDark ? Colors.white : AppColors.primary;

  @override
  Widget build(BuildContext context) {
    final lines = data.replaceAll('\r\n', '\n').split('\n');
    final blocks = <Widget>[];
    var i = 0;

    while (i < lines.length) {
      final line = lines[i];
      final trimmed = line.trim();

      // 代码块
      if (trimmed.startsWith('```')) {
        final buffer = <String>[];
        i++;
        while (i < lines.length && !lines[i].trim().startsWith('```')) {
          buffer.add(lines[i]);
          i++;
        }
        i++; // 跳过结束的 ```
        blocks.add(_codeBlock(buffer.join('\n')));
        continue;
      }

      // 块级数学公式：\[ ... \] 或 $$ ... $$（可跨行，独占一块）。
      // DeepSeek 等模型默认用这两种定界符输出 LaTeX，必须整块交给公式渲染器，
      // 否则会像截图那样把 \frac、\lim 原样裸奔出来。
      final blockMath = _matchBlockMath(lines, i);
      if (blockMath != null) {
        blocks.add(_mathBlock(blockMath.expression, isDisplay: true));
        i = blockMath.nextIndex;
        continue;
      }

      if (trimmed.isEmpty) {
        i++;
        continue;
      }

      // 分隔线
      if (RegExp(r'^([-*_])\1{2,}$').hasMatch(trimmed.replaceAll(' ', ''))) {
        blocks.add(const Padding(
          padding: EdgeInsets.symmetric(vertical: 8),
          child: Divider(height: 1),
        ));
        i++;
        continue;
      }

      // 标题
      final heading = RegExp(r'^(#{1,4})\s+(.*)$').firstMatch(trimmed);
      if (heading != null) {
        final level = heading.group(1)!.length;
        final text = heading.group(2)!;
        const sizes = [21.0, 18.5, 16.5, 15.0];
        blocks.add(Padding(
          padding: EdgeInsets.only(top: i == 0 ? 0 : 10, bottom: 4),
          child: Text.rich(
            TextSpan(children: _inline(text, baseStyle.copyWith(
              fontSize: sizes[level - 1],
              fontWeight: FontWeight.w700,
              height: 1.35,
            ))),
          ),
        ));
        i++;
        continue;
      }

      // 表格：当前行含 | 且下一行是分隔行
      if (trimmed.contains('|') &&
          i + 1 < lines.length &&
          RegExp(r'^\s*\|?[\s:\-|]+\|[\s:\-|]*$').hasMatch(lines[i + 1])) {
        final table = <List<String>>[];
        table.add(_splitRow(trimmed));
        i += 2;
        while (i < lines.length && lines[i].trim().contains('|')) {
          table.add(_splitRow(lines[i].trim()));
          i++;
        }
        blocks.add(_tableView(table));
        continue;
      }

      // 引用
      if (trimmed.startsWith('>')) {
        final buffer = <String>[];
        while (i < lines.length && lines[i].trim().startsWith('>')) {
          buffer.add(lines[i].trim().replaceFirst(RegExp(r'^>\s?'), ''));
          i++;
        }
        blocks.add(Container(
          margin: const EdgeInsets.symmetric(vertical: 4),
          padding: const EdgeInsets.fromLTRB(10, 6, 8, 6),
          decoration: BoxDecoration(
            color: _codeBg,
            border: Border(
              left: BorderSide(
                color: AppColors.primary.withValues(alpha: 0.6),
                width: 3,
              ),
            ),
          ),
          child: Text.rich(TextSpan(
            children: _inline(buffer.join('\n'), baseStyle.copyWith(
              color: baseStyle.color ?? AppColors.textPrimary,
              height: 1.5,
            )),
          )),
        ));
        continue;
      }

      // 列表
      final bullet = RegExp(r'^(\s*)([-*+]|\d+\.)\s+(.*)$').firstMatch(line);
      if (bullet != null) {
        final indent = (bullet.group(1)?.length ?? 0);
        final marker = bullet.group(2)!;
        final content = bullet.group(3)!;
        blocks.add(Padding(
          padding: EdgeInsets.only(left: 4.0 + indent * 6, top: 1, bottom: 1),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                width: marker.endsWith('.') ? 22 : 14,
                child: Text(
                  marker.endsWith('.') ? marker : '•',
                  style: baseStyle.copyWith(height: 1.5),
                ),
              ),
              Expanded(
                child: Text.rich(TextSpan(
                  children: _inline(content, baseStyle.copyWith(height: 1.5)),
                )),
              ),
            ],
          ),
        ));
        i++;
        continue;
      }

      // 普通段落：连续非空行合并
      final buffer = <String>[line];
      i++;
      while (i < lines.length) {
        final next = lines[i];
        final nt = next.trim();
        if (nt.isEmpty ||
            nt.startsWith('```') ||
            nt.startsWith('#') ||
            nt.startsWith('>') ||
            RegExp(r'^(\s*)([-*+]|\d+\.)\s+').hasMatch(next) ||
            RegExp(r'^([-*_])\1{2,}$').hasMatch(nt.replaceAll(' ', ''))) {
          break;
        }
        buffer.add(next);
        i++;
      }
      blocks.add(Padding(
        padding: const EdgeInsets.only(bottom: 2),
        child: Text.rich(TextSpan(
          children: _inline(buffer.join('\n'), baseStyle.copyWith(height: 1.5)),
        )),
      ));
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: blocks,
    );
  }

  /// 匹配从 [start] 开始的块级公式。支持 \[...\] 与 $$...$$ 两种定界符。
  /// 返回表达式内容与消费到的下一行索引；不匹配返回 null。
  _BlockMath? _matchBlockMath(List<String> lines, int start) {
    final trimmed = lines[start].trim();
    final open = trimmed.startsWith(r'\[')
        ? r'\['
        : (trimmed.startsWith(r'$$') ? r'$$' : null);
    if (open == null) return null;
    final close = open == r'\[' ? r'\]' : r'$$';

    // 单行闭合：\[ x \] 或 $$x$$
    final afterOpen = trimmed.substring(open.length);
    final singleClose = afterOpen.indexOf(close);
    if (singleClose >= 0) {
      final expr = afterOpen.substring(0, singleClose).trim();
      return _BlockMath(expr.isEmpty ? '' : expr, start + 1);
    }

    // 多行：从下一行累积直到遇到闭合定界符。
    final buffer = <String>[if (afterOpen.trim().isNotEmpty) afterOpen.trim()];
    var i = start + 1;
    for (; i < lines.length; i++) {
      final line = lines[i];
      final ci = line.indexOf(close);
      if (ci >= 0) {
        final head = line.substring(0, ci).trim();
        if (head.isNotEmpty) buffer.add(head);
        i++;
        break;
      }
      buffer.add(line);
    }
    final expr = buffer.join('\n').trim();
    return _BlockMath(expr, i);
  }

  /// 提取文本中的所有行内公式，替换为占位符，返回替换后的文本与公式 Widget 列表。
  ///
  /// 支持的定界符：\(...\)（可嵌套 \(\(...\)\)）、双反斜杠 \\(...\\)、$...$。
  /// 用配平扫描而非正则，才能正确处理公式里的括号、下划线、星号。
  _MathExtract _extractInlineMath(String text) {
    final widgets = <int, Widget>{};
    final buffer = StringBuffer();
    var i = 0;
    var index = 0;

    int findClose(String s, int from, String open, String close) {
      // 从 from 开始找与 open 配对的 close，支持同种定界符嵌套。
      var depth = 1;
      var j = from;
      while (j < s.length) {
        if (s.startsWith(open, j)) {
          depth++;
          j += open.length;
          continue;
        }
        if (s.startsWith(close, j)) {
          depth--;
          if (depth == 0) return j;
          j += close.length;
          continue;
        }
        j++;
      }
      return -1;
    }

    while (i < text.length) {
      // 先归一化双反斜杠定界符 \\( 视为 \(，\\) 视为 \)。
      final doubleOpen = text.startsWith(r'\\(', i);
      final open = doubleOpen || text.startsWith(r'\(', i);
      final dollarOpen = !open && text[i] == r'$';

      if (open) {
        final openLen = doubleOpen ? 3 : 2;
        final close = doubleOpen ? r'\\)' : r'\)';
        final closeIdx = findClose(text, i + openLen, r'\(', close);
        if (closeIdx >= 0) {
          var expr = text.substring(i + openLen, closeIdx);
          // 去掉模型重复包裹的嵌套定界符：\(\(x\' = 1\) -> x' = 1
          expr = _unwrapMath(expr);
          final token = '$_mathTokenStart${index}${_mathTokenEnd}';
          widgets[index] = _mathBlock(expr, isDisplay: false);
          buffer.write(token);
          index++;
          i = closeIdx + close.length;
          continue;
        }
      } else if (dollarOpen) {
        // 行内 $...$（单个 $，排除块级 $$）
        if (i + 1 < text.length && text[i + 1] != r'$') {
          final closeIdx = text.indexOf(r'$', i + 1);
          if (closeIdx > i + 1 && text[closeIdx - 1] != r'\') {
            var expr = text.substring(i + 1, closeIdx);
            expr = _unwrapMath(expr);
            final token = '$_mathTokenStart${index}${_mathTokenEnd}';
            widgets[index] = _mathBlock(expr, isDisplay: false);
            buffer.write(token);
            index++;
            i = closeIdx + 1;
            continue;
          }
        }
      }
      buffer.write(text[i]);
      i++;
    }
    return _MathExtract(buffer.toString(), widgets);
  }

  /// 清掉模型重复包裹/散落的定界符，让 LaTeX 解析器拿到干净表达式。
  /// 例：\(\(A\)\) -> A；\(A\)' = B\) -> A' = B（截图里模型把定界符套乱了）。
  String _unwrapMath(String expr) {
    var s = expr.trim();
    var changed = true;
    while (changed) {
      changed = false;
      if (s.startsWith(r'\(') && s.endsWith(r'\)') && s.length >= 4) {
        s = s.substring(2, s.length - 2).trim();
        changed = true;
      }
    }
    // 清掉内部残留的定界符（模型套娃时散落在中间的 \( 与 \)）。
    s = s.replaceAll(r'\(', '').replaceAll(r'\)', '');
    s = s.replaceAll(r'\\(', '').replaceAll(r'\\)', '');
    if (s.length >= 2 && s.startsWith(r'$') && s.endsWith(r'$')) {
      s = s.substring(1, s.length - 1).trim();
    }
    return s.trim();
  }

  /// 渲染一段 LaTeX 公式为 Widget。解析失败时回退为原文，绝不因坏公式炸掉气泡。
  Widget _mathBlock(String expression, {required bool isDisplay}) {
    if (expression.isEmpty) return const SizedBox.shrink();
    final style = baseStyle.copyWith(
      fontSize: isDisplay ? (baseStyle.fontSize ?? 14) + 1 : baseStyle.fontSize,
      color: baseStyle.color ?? AppColors.textPrimary,
    );
    final math = Math.tex(
      expression,
      mathStyle: isDisplay ? MathStyle.display : MathStyle.text,
      textStyle: style,
      onErrorFallback: (_) => Text(expression, style: style),
    );
    if (!isDisplay) return math;
    // 块级公式居中 + 可横向滚动，避免长公式把气泡撑破。
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Center(
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: math,
        ),
      ),
    );
  }

  Widget _codeBlock(String code) => Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: _codeBg,
          borderRadius: BorderRadius.circular(8),
        ),
        child: SelectableText(
          code,
          style: TextStyle(
            fontFamily: 'Consolas',
            fontFamilyFallback: const ['Menlo', 'Courier New', 'monospace'],
            fontSize: 12.5,
            height: 1.45,
            color: onDark ? Colors.white : AppColors.textPrimary,
          ),
        ),
      );

  List<String> _splitRow(String line) => line
      .replaceAll(RegExp(r'^\s*\|'), '')
      .replaceAll(RegExp(r'\|\s*$'), '')
      .split('|')
      .map((e) => e.trim())
      .toList();

  Widget _tableView(List<List<String>> rows) {
    final columns = rows.fold<int>(0, (m, r) => r.length > m ? r.length : m);
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.outline),
        borderRadius: BorderRadius.circular(6),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: Table(
          border: TableBorder.all(color: AppColors.outline, width: 0.6),
          defaultColumnWidth: const IntrinsicColumnWidth(),
          children: [
            for (var r = 0; r < rows.length; r++)
              TableRow(
                decoration: BoxDecoration(
                  color: r == 0 ? _codeBg : null,
                ),
                children: [
                  for (var c = 0; c < columns; c++)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                      child: Text.rich(TextSpan(
                        children: _inline(
                          c < rows[r].length ? rows[r][c] : '',
                          baseStyle.copyWith(
                            height: 1.35,
                            fontWeight: r == 0 ? FontWeight.w600 : null,
                          ),
                        ),
                      )),
                    ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  /// 占位符前缀/后缀：用私有区字符，正常正文几乎不可能出现，避免和 Markdown 冲突。
  static const String _mathTokenStart = '\uE000';
  static const String _mathTokenEnd = '\uE001';

  /// 行内语法解析：**加粗**、*斜体*、***粗斜***、~~删除~~、==高亮==、`代码`、[文字](链接)、行内公式。
  ///
  /// 关键：先用 [_extractInlineMath] 把行内公式整体抠出来换成占位符，再跑 Markdown
  /// 正则。否则 LaTeX 里的下划线（\lim_{x\to\infty}）会被 `_..._` 斜体语法抢先匹配，
  /// 星号、花括号也会被误伤——这正是截图里"部分公式仍裸奔"的根因。
  List<InlineSpan> _inline(String text, TextStyle style) {
    final spans = <InlineSpan>[];
    final extracted = _extractInlineMath(text);
    text = extracted.text;
    final mathWidgets = extracted.widgets;

    final pattern = RegExp(
      // 占位符必须最先匹配；〔n〕是引用角标。
      r'(' + _mathTokenStart + r'\d+' + _mathTokenEnd +
          r'|\*\*\*[^*]+\*\*\*|\*\*[^*]+\*\*|__[^_\n]+__|\*[^*]+\*|_[^_\n]+_|~~[^~]+~~|==[^=]+==|`[^`\n]+`|\[[^\]\n]+\]\([^)\n]+\)|〔\d+〕)',
    );

    void addPlain(String value) {
      if (value.isEmpty) return;
      spans.add(TextSpan(text: value, style: style));
    }

    var last = 0;
    for (final match in pattern.allMatches(text)) {
      if (match.start > last) addPlain(text.substring(last, match.start));
      final token = match.group(0)!;
      // 公式占位符：还原为公式 Widget。
      if (token.startsWith(_mathTokenStart)) {
        final idx = int.parse(
          token.substring(_mathTokenStart.length, token.length - _mathTokenEnd.length),
        );
        final widget = mathWidgets[idx];
        if (widget != null) {
          spans.add(WidgetSpan(alignment: PlaceholderAlignment.middle, child: widget));
        }
        last = match.end;
        continue;
      }
      if (RegExp(r'^〔\d+〕$').hasMatch(token)) {
        // 引用角标：渲染成小圆徽章，点击回调到来源列表。
        final number = int.parse(token.substring(1, token.length - 1));
        spans.add(WidgetSpan(
          alignment: PlaceholderAlignment.middle,
          child: GestureDetector(
            onTap: onCitationTap == null ? null : () => onCitationTap!(number),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 2),
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
              decoration: BoxDecoration(
                color: AppColors.primary.withValues(alpha: onDark ? 0.5 : 0.14),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                '$number',
                style: style.copyWith(
                  color: onDark ? Colors.white : AppColors.primary,
                  fontSize: (style.fontSize ?? 14) - 3,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
        ));
      } else if (token.startsWith('***')) {
        // 中文用 FontStyle.italic 会被系统合成成很斜的伪斜体，观感差。
        // 改用加粗 + 主色区分强调，不再倾斜。
        spans.add(TextSpan(
          text: token.substring(3, token.length - 3),
          style: style.copyWith(fontWeight: FontWeight.w700, color: _linkColor),
        ));
      } else if (token.startsWith('**') || token.startsWith('__')) {
        spans.add(TextSpan(
          text: token.substring(2, token.length - 2),
          style: style.copyWith(fontWeight: FontWeight.w700),
        ));
      } else if (token.startsWith('~~')) {
        spans.add(TextSpan(
          text: token.substring(2, token.length - 2),
          style: style.copyWith(decoration: TextDecoration.lineThrough),
        ));
      } else if (token.startsWith('==')) {
        spans.add(TextSpan(
          text: token.substring(2, token.length - 2),
          style: style.copyWith(
            fontWeight: FontWeight.w600,
            backgroundColor: AppColors.primary.withValues(alpha: onDark ? 0.35 : 0.16),
          ),
        ));
      } else if (token.startsWith('`')) {
        spans.add(TextSpan(
          text: token.substring(1, token.length - 1),
          style: style.copyWith(
            fontFamily: 'Consolas',
            fontFamilyFallback: const ['Menlo', 'Courier New', 'monospace'],
            backgroundColor: _codeBg,
            fontSize: (style.fontSize ?? 14) - 0.5,
          ),
        ));
      } else if (token.startsWith('[')) {
        final link = RegExp(r'\[([^\]]+)\]\(([^)]+)\)').firstMatch(token);
        if (link != null) {
          final label = link.group(1)!;
          final url = link.group(2)!;
          spans.add(TextSpan(
            text: url == label ? label : '$label ($url)',
            style: style.copyWith(color: _linkColor, decoration: TextDecoration.underline),
          ));
        } else {
          addPlain(token);
        }
      } else if (token.startsWith('*') || token.startsWith('_')) {
        // 同上：中文伪斜体太斜，改成略微提亮 + 轻字重，保留"动作描写"的视觉区分但不倾斜。
        spans.add(TextSpan(
          text: token.substring(1, token.length - 1),
          style: style.copyWith(
            color: onDark ? const Color(0xFFB9C7D6) : const Color(0xFF5A6B7B),
            fontWeight: FontWeight.w500,
          ),
        ));
      } else {
        addPlain(token);
      }
      last = match.end;
    }
    if (last < text.length) addPlain(text.substring(last));
    return spans;
  }
}

/// 块级公式匹配结果。
@immutable
class _BlockMath {
  final String expression;
  final int nextIndex;
  const _BlockMath(this.expression, this.nextIndex);
}

/// 行内公式提取结果：替换掉公式后的文本 + 占位符索引到公式 Widget 的映射。
@immutable
class _MathExtract {
  final String text;
  final Map<int, Widget> widgets;
  const _MathExtract(this.text, this.widgets);
}
