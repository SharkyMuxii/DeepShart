// target: lib/ui/announcement_sheet.dart
// 职责：公告页。内容由开发者手动维护、固定写死——除非明确要求修改，否则不动。
// 开头贴作者个人主页与打赏码，之后是本版本亮点介绍。
// 只在全局设置里由用户主动点击打开，不启动时自动弹出。

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/app_info.dart';
import '../core/theme.dart';

/// 作者个人主页（公告最开头展示）。
const String kAuthorHomepage = 'https://b23.tv/xOYSRhB';

/// 公告正文（版本亮点）。除非用户明确要求修改，否则不要改动这里。
const List<String> kAnnouncementHighlights = [
  '双端同步，数据随身：支持「P2P 设备直连」与「腾讯云 COS 云同步」两种方案，'
      '全局设置里一键切换，切换后另一种彻底关闭，互不干扰。',
  '每次同步你说了算：同步前弹窗让你选「智能合并 / 以本机为准 / 以对端为准」。'
      '合并会把两边对话互补到一起，只有真正冲突的地方才请你裁决；覆盖则整库替换，清楚明了。',
  'P2P 更安全：只跟配对过的设备同步，一次只与一台设备通信，其余排队，避免并发出错。',
  '删除不再被偷偷同步：删除只影响本机，不会被自动同步抹掉别的设备上的对话——'
      '除非你明确选择「以对端为准」整库覆盖。',
  '对话与文件管理更顺手：会话、消息、记忆点、文件列表都支持多选批量操作，'
      '带「选至此」区间选择与一键到顶/到底；气泡显示发送时间，附件支持缩略图与文件卡片。',
  '隐私优先：COS 密钥由你自己填写、只存本机，不写进安装包，也不上传任何第三方；'
      '打包前会清除所有调试数据与对话记录。',
  '体验细节：消息弹窗统一在顶部显示、可左右划走；菜单全面中文化；'
      '启动需阅读并确认用户协议。',
];

/// 展示公告的按钮入口（供全局设置/外壳复用）。
class AnnouncementTile extends StatelessWidget {
  const AnnouncementTile({super.key});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(Icons.campaign_outlined, color: AppColors.primary, size: 22),
      title: Text('公告', style: TextStyle(fontSize: 14, color: AppColors.textPrimary)),
      subtitle: Text('作者主页 · 打赏 · 版本亮点',
          style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
      trailing: Icon(Icons.chevron_right, color: AppColors.textSecondary, size: 18),
      onTap: () => showAnnouncement(context),
    );
  }
}

void showAnnouncement(BuildContext context) {
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: AppColors.surface,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
    ),
    builder: (context) => DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.88,
      minChildSize: 0.5,
      maxChildSize: 0.96,
      builder: (context, scrollController) => _AnnouncementBody(controller: scrollController),
    ),
  );
}

class _AnnouncementBody extends StatelessWidget {
  final ScrollController controller;
  const _AnnouncementBody({required this.controller});

  void _close(BuildContext context) => Navigator.of(context).pop();

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        ListView(
          controller: controller,
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 96),
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.textSecondary.withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Icon(Icons.campaign, color: AppColors.primary, size: 24),
                const SizedBox(width: 8),
                Text('公告',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
              ],
            ),
            const SizedBox(height: 4),
            Text('${AppInfo.version} · 作者：${AppInfo.author}',
                style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
            const SizedBox(height: 16),

            // 作者主页（公告最开头）。
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.primarySoft,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.primary.withValues(alpha: 0.3)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('作者个人主页',
                      style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                  const SizedBox(height: 6),
                  InkWell(
                    onTap: () => _openUrl(kAuthorHomepage),
                    child: Row(
                      children: [
                        Icon(Icons.link, size: 16, color: AppColors.primary),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            '【Sharveloper的个人空间-哔哩哔哩】 $kAuthorHomepage',
                            style: TextStyle(
                              fontSize: 13,
                              color: AppColors.primary,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ),
                        Icon(Icons.open_in_new, size: 14, color: AppColors.primary),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // 打赏支持（作者提供的微信打赏码，公开收款码）。
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.outline),
              ),
              child: Column(
                children: [
                  Icon(Icons.favorite, color: AppColors.danger, size: 20),
                  const SizedBox(height: 8),
                  Text('支持一下作者',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                  const SizedBox(height: 6),
                  Text(
                    '做得这么好，被鲨鱼买杯咖啡呗～ 如果这款软件帮到了你，欢迎扫码请汐鱼学姐喝杯咖啡；'
                    '你的支持是我继续维护和更新的动力！',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12.5, height: 1.55, color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 14),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.asset(
                      'assets/donate/wechat_reward.png',
                      width: 240,
                      fit: BoxFit.contain,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text('汐鱼学姐 的赞赏码 · 微信扫一扫',
                      style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                ],
              ),
            ),
            const SizedBox(height: 20),

            Text('本版本亮点',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
            const SizedBox(height: 10),
            for (var i = 0; i < kAnnouncementHighlights.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 22,
                      height: 22,
                      decoration: BoxDecoration(
                        color: AppColors.primary,
                        borderRadius: BorderRadius.circular(11),
                      ),
                      child: Center(
                        child: Text('${i + 1}',
                            style: const TextStyle(fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold)),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(kAnnouncementHighlights[i],
                          style: TextStyle(fontSize: 13, height: 1.55, color: AppColors.textPrimary)),
                    ),
                  ],
                ),
              ),
          ],
        ),

        // 底部固定栏：显眼的大关闭按钮（无"不再显示"勾选，按版本自动记忆）。
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: Container(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 16),
            decoration: BoxDecoration(
              color: AppColors.surface,
              border: Border(top: BorderSide(color: AppColors.outline)),
            ),
            child: SizedBox(
              width: double.infinity,
              height: 46,
              child: FilledButton.icon(
                icon: const Icon(Icons.check_circle, size: 20),
                label: const Text('知道了', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                onPressed: () => _close(context),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null) return;
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {}
  }
}
