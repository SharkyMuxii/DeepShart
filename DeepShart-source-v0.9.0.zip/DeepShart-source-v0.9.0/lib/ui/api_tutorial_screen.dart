// target: lib/ui/api_tutorial_screen.dart
// 职责：应用内的 DeepSeek API 注册教程——照着点就能拿到能用的 API Key。
//
// 内容来源：用户提供的两份 Word 文档：
//   《DS教程-电脑版.docx》→ assets/tutorial/（电脑端展示）
//   《DS教程-手机版.docx》→ assets/tutorial_mobile/（手机端展示）
// 截图按原文顺序原样导出，文字做了口语化重写，目标是零基础也能走完。
// 平台分流：Android 显示手机版，桌面显示电脑版，各看各的、不混淆。

import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/theme.dart';
import 'app_toast.dart';

/// 一段教程步骤里的一个元素：一段文字，或一张截图。
class _TutorialEntry {
  final String? text;
  final String? image;
  final String? link;
  final bool isWarning;
  const _TutorialEntry.text(this.text)
      : image = null,
        link = null,
        isWarning = false;
  const _TutorialEntry.image(this.image)
      : text = null,
        link = null,
        isWarning = false;
  const _TutorialEntry.link(this.link)
      : text = null,
        image = null,
        isWarning = false;
  const _TutorialEntry.warning(this.text)
      : image = null,
        link = null,
        isWarning = true;
}

class _TutorialStep {
  final String index;
  final String title;
  final List<_TutorialEntry> entries;
  const _TutorialStep({required this.index, required this.title, required this.entries});
}

/// 教程内容：一份「标题 + 若干步骤」的纯数据，屏只是渲染它。
class _Tutorial {
  final String title;
  final List<_TutorialStep> steps;
  const _Tutorial({required this.title, required this.steps});
}

class ApiTutorialScreen extends StatelessWidget {
  const ApiTutorialScreen({super.key});

  static const String registerUrl = 'https://platform.deepseek.com/sign_in';

  static bool get _isAndroid => !kIsWeb && Platform.isAndroid;

  /// 一点即跳：用系统浏览器打开注册链接。手机端 externalApplication 会直接
  /// 拉起浏览器/应用，比"复制链接再粘贴"顺手得多。失败时回退为复制并提示。
  Future<void> _openLink(BuildContext context, String url) async {
    final uri = Uri.tryParse(url);
    if (uri != null) {
      try {
        final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
        if (ok) return;
      } catch (_) {}
    }
    // 打不开（没浏览器 / 被拦截）时退化为复制，保证用户仍能拿到链接。
    await Clipboard.setData(ClipboardData(text: url));
    if (context.mounted) {
      showAppToast(context, '无法直接打开，链接已复制，请粘贴到浏览器');
    }
  }

  Future<void> _copyUrl(BuildContext context) async {
    await Clipboard.setData(const ClipboardData(text: registerUrl));
    if (context.mounted) {
      showAppToast(context, '注册链接已复制，粘贴到浏览器打开即可');
    }
  }

  /// 电脑版教程（桌面端）。
  static const _Tutorial _desktop = _Tutorial(
    title: '四步拿到能用的 API Key',
    steps: [
      _TutorialStep(index: '一', title: '注册并完成实名认证', entries: [
        _TutorialEntry.text('打开注册页面，用手机号或邮箱注册并登录。'),
        _TutorialEntry.link(registerUrl),
        _TutorialEntry.image('assets/tutorial/tutorial_02.png'),
        _TutorialEntry.text('如果弹出"新手引导"或"绑定邮箱"之类的页面，建议直接点「跳过 / 稍后再填」，不影响使用。'),
        _TutorialEntry.image('assets/tutorial/tutorial_07.png'),
        _TutorialEntry.text('进入控制台后，点「去认证」。'),
        _TutorialEntry.image('assets/tutorial/tutorial_08.png'),
        _TutorialEntry.text('选择「个人实名认证」，按提示填完。没有实名认证就充不了值、也调不了接口。'),
        _TutorialEntry.image('assets/tutorial/tutorial_09.png'),
      ]),
      _TutorialStep(index: '二', title: '创建 API Key', entries: [
        _TutorialEntry.text('在左侧菜单点击「API keys」。'),
        _TutorialEntry.image('assets/tutorial/tutorial_10.png'),
        _TutorialEntry.text('点击「创建 API key」。'),
        _TutorialEntry.image('assets/tutorial/tutorial_11.png'),
        _TutorialEntry.text('随便起一个好记的名字（比如 DeepShart），点「创建」。'),
        _TutorialEntry.image('assets/tutorial/tutorial_12.png'),
        _TutorialEntry.text('创建成功后，点击「复制」——这串字符就是等会儿要填进软件的 API Key。'),
        _TutorialEntry.image('assets/tutorial/tutorial_13.png'),
        _TutorialEntry.warning('这串 Key 丢了就找不回来，只能重新申请一个——请立刻粘贴到软件里或存进密码管理器。'),
        _TutorialEntry.warning('这串 Key 一旦泄露，别人不需要你的密码就能直接花掉你账户里的余额。不要发群里、不要贴截图。'),
      ]),
      _TutorialStep(index: '三', title: '把 API Key 填进 DeepShart', entries: [
        _TutorialEntry.text('打开 DeepShart，进入「全局设置」页。'),
        _TutorialEntry.image('assets/tutorial/tutorial_14.png'),
        _TutorialEntry.text('把刚才复制的 Key 粘贴到「DeepSeek API Key」输入框，然后点「保存」。'
            '保存后可以点「测试连接」确认一下：显示"连接正常"就说明配置对了。'),
        _TutorialEntry.image('assets/tutorial/tutorial_03.png'),
        _TutorialEntry.text('注意：此时账户里还没有余额，直接聊天会提示余额不足——继续看下一步。'),
      ]),
      _TutorialStep(index: '四', title: '充值（不充值用不了）', entries: [
        _TutorialEntry.text('点击「充值」。'),
        _TutorialEntry.image('assets/tutorial/tutorial_04.png'),
        _TutorialEntry.text('点击「自定义充值」，自己填金额。'),
        _TutorialEntry.image('assets/tutorial/tutorial_05.png'),
        _TutorialEntry.text('选好金额完成支付即可。第一次用建议先充 10 元试试——足够聊很久，用完了随时再充。'),
        _TutorialEntry.image('assets/tutorial/tutorial_06.png'),
      ]),
    ],
  );

  /// 手机版教程（Android 端）。
  ///
  /// 注意：手机版 docx 里 tutorial_03 是一张电脑端截图（创建 Key 后的复制对话框），
  /// 与手机端操作不符，且「复制」这一步已由 tutorial_16 覆盖，故此处刻意跳过。
  static const _Tutorial _mobile = _Tutorial(
    title: '四步拿到能用的 API Key',
    steps: [
      _TutorialStep(index: '一', title: '注册并完成实名认证', entries: [
        _TutorialEntry.text('在手机浏览器打开下面的链接，用手机号注册并登录（未注册的手机号会自动注册）。'),
        _TutorialEntry.link(registerUrl),
        _TutorialEntry.image('assets/tutorial_mobile/tutorial_02.png'),
        _TutorialEntry.text('如果弹出"绑定邮箱"之类的弹窗，点「稍后再填」跳过即可，不影响使用。'),
        _TutorialEntry.image('assets/tutorial_mobile/tutorial_09.png'),
        _TutorialEntry.text('进入平台后，点右上角「去认证」。'),
        _TutorialEntry.image('assets/tutorial_mobile/tutorial_10.png'),
        _TutorialEntry.text('选择「个人实名认证」，填好姓名和证件号，点「提交认证」。不认证就充不了值、调不了接口。'),
        _TutorialEntry.image('assets/tutorial_mobile/tutorial_11.png'),
      ]),
      _TutorialStep(index: '二', title: '申请 API Key', entries: [
        _TutorialEntry.text('点左上角的菜单按钮（≡），展开侧边栏。'),
        _TutorialEntry.image('assets/tutorial_mobile/tutorial_12.png'),
        _TutorialEntry.text('在菜单里点「API keys」。'),
        _TutorialEntry.image('assets/tutorial_mobile/tutorial_13.png'),
        _TutorialEntry.text('点「创建 API key」。'),
        _TutorialEntry.image('assets/tutorial_mobile/tutorial_14.png'),
        _TutorialEntry.text('随便起一个好记的名字（比如 DeepShart），点「创建」。'),
        _TutorialEntry.image('assets/tutorial_mobile/tutorial_15.png'),
        _TutorialEntry.text('创建成功后，点「复制」——这串字符就是等会儿要填进软件的 API Key。'),
        _TutorialEntry.image('assets/tutorial_mobile/tutorial_16.png'),
        _TutorialEntry.warning('这串 Key 丢了就找不回来，只能重新申请一个——请立刻粘贴到软件里或存进密码管理器。'),
        _TutorialEntry.warning('这串 Key 一旦泄露，别人不需要你的密码就能直接花掉你账户里的余额。不要发群里、不要贴截图。'),
      ]),
      _TutorialStep(index: '三', title: '把 API Key 填进 DeepShart', entries: [
        _TutorialEntry.text('打开 DeepShart，点左上角的菜单按钮（☰），再点「全局设置」。'),
        _TutorialEntry.image('assets/tutorial_mobile/tutorial_04.png'),
        _TutorialEntry.image('assets/tutorial_mobile/tutorial_05.png'),
        _TutorialEntry.text('把刚才复制的 Key 粘贴到「DeepSeek API Key」输入框，然后点「保存」。'
            '保存后可以点「测试连接」确认：显示"连接正常"就说明配置对了。'),
        _TutorialEntry.image('assets/tutorial_mobile/tutorial_06.png'),
        _TutorialEntry.text('注意：此时账户里还没有余额，直接聊天会提示余额不足——继续看下一步。'),
      ]),
      _TutorialStep(index: '四', title: '充值（不充值用不了）', entries: [
        _TutorialEntry.text('回到平台，点左上角菜单按钮（≡），在菜单里点「充值」。'),
        _TutorialEntry.image('assets/tutorial_mobile/tutorial_12.png'),
        _TutorialEntry.text('点「自定义充值」，自己填金额。'),
        _TutorialEntry.image('assets/tutorial_mobile/tutorial_07.png'),
        _TutorialEntry.text('输入金额后点「去支付」。第一次用建议先充 10 元试试——足够聊很久，用完了随时再充。'),
        _TutorialEntry.image('assets/tutorial_mobile/tutorial_08.png'),
      ]),
    ],
  );

  @override
  Widget build(BuildContext context) {
    final tutorial = _isAndroid ? _mobile : _desktop;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('API 注册教程'),
        centerTitle: true,
        backgroundColor: AppColors.surface,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        children: [
          _HeroCard(
            title: tutorial.title,
            onOpenUrl: () => _openLink(context, registerUrl),
            onCopyUrl: () => _copyUrl(context),
          ),
          const SizedBox(height: 20),
          for (final step in tutorial.steps) ...[
            _StepTitle(index: step.index, title: step.title),
            _StepCard(
              entries: step.entries,
              onOpenLink: (url) => _openLink(context, url),
            ),
            const SizedBox(height: 20),
          ],
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.primarySoft,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Icon(Icons.check_circle, color: AppColors.primary, size: 20),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    '到这里就全部配置好了，回到对话页就能正常使用。',
                    style: TextStyle(fontSize: 13, color: AppColors.primary, height: 1.5),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Text(
            '提示：截图里的界面可能和你看到的略有差别（官网会改版），'
            '按「API keys / 创建 / 复制」这几个关键词找入口即可。',
            style: TextStyle(fontSize: 12, color: AppColors.textSecondary, height: 1.6),
          ),
        ],
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  final String title;
  final VoidCallback onOpenUrl;
  final VoidCallback onCopyUrl;
  const _HeroCard({
    required this.title,
    required this.onOpenUrl,
    required this.onCopyUrl,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.outline),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(
              '整个流程大约 5 分钟：注册 → 实名 → 创建 Key → 充值。'
              '没有 API Key，软件无法和模型通信；没有余额，请求会被拒绝。',
              style: TextStyle(fontSize: 14, color: AppColors.textSecondary, height: 1.6),
            ),
            const SizedBox(height: 12),
            // 主按钮：一点即跳系统浏览器。手机端这是最顺手的路径。
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                icon: const Icon(Icons.open_in_browser, size: 18),
                label: const Text('打开注册链接'),
                onPressed: onOpenUrl,
              ),
            ),
            const SizedBox(height: 6),
            // 次要按钮：万一外部浏览器打不开，还能复制。
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                icon: const Icon(Icons.copy, size: 16),
                label: const Text('复制链接（浏览器打不开时用）'),
                onPressed: onCopyUrl,
              ),
            ),
          ],
        ),
      );
}

class _StepTitle extends StatelessWidget {
  final String index;
  final String title;
  const _StepTitle({required this.index, required this.title});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8, left: 2),
        child: Row(
          children: [
            Container(
              width: 22,
              height: 22,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: AppColors.primary,
                shape: BoxShape.circle,
              ),
              child: Text(index,
                  style: const TextStyle(
                      fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(width: 8),
            Text(title,
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
          ],
        ),
      );
}

class _StepCard extends StatelessWidget {
  final List<_TutorialEntry> entries;
  final void Function(String url) onOpenLink;
  const _StepCard({required this.entries, required this.onOpenLink});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.outline),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (final entry in entries)
              if (entry.isWarning)
                _WarningLine(entry.text!)
              else if (entry.link != null)
                _LinkRow(url: entry.link!, onOpen: () => onOpenLink(entry.link!))
              else if (entry.image != null)
                _Shot(asset: entry.image!)
              else
                _Text(entry.text!),
          ],
        ),
      );
}

class _Text extends StatelessWidget {
  final String text;
  const _Text(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(text, style: const TextStyle(fontSize: 15, height: 1.65)),
      );
}

class _LinkRow extends StatelessWidget {
  final String url;
  final VoidCallback onOpen;
  const _LinkRow({required this.url, required this.onOpen});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        child: Material(
          color: AppColors.primarySoft,
          borderRadius: BorderRadius.circular(8),
          child: InkWell(
            onTap: onOpen, // 整行一点即跳。
            borderRadius: BorderRadius.circular(8),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              child: Row(
                children: [
                  Icon(Icons.open_in_new, size: 16, color: AppColors.primary),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(url,
                        style: TextStyle(
                            fontSize: 13, color: AppColors.primary,
                            decoration: TextDecoration.underline),
                        overflow: TextOverflow.ellipsis),
                  ),
                  const SizedBox(width: 6),
                  Icon(Icons.chevron_right, size: 18, color: AppColors.primary),
                ],
              ),
            ),
          ),
        ),
      );
}

class _WarningLine extends StatelessWidget {
  final String text;
  const _WarningLine(this.text);

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 6),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF4E5),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: const Color(0xFFFFD9A8)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.warning_amber_rounded,
                size: 15, color: Color(0xFFB26A00)),
            const SizedBox(width: 6),
            Expanded(
              child: Text('$text',
                  style: const TextStyle(
                      fontSize: 14, height: 1.6, color: Color(0xFF8A5A00))),
            ),
          ],
        ),
      );
}

/// 教程截图。点击可全屏放大——手机上图很小，必须能看清「点哪个按钮」。
class _Shot extends StatelessWidget {
  final String asset;
  const _Shot({required this.asset});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () => showDialog<void>(
          context: context,
          builder: (dialogContext) => Dialog(
            backgroundColor: Colors.black87,
            insetPadding: const EdgeInsets.all(12),
            child: InteractiveViewer(
              maxScale: 5,
              child: Image.asset(asset, fit: BoxFit.contain),
            ),
          ),
        ),
        child: Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: AppColors.outline),
          ),
          clipBehavior: Clip.antiAlias,
          // 列表里限制宽度与高度，避免整屏被一张长截图占满；
          // 点一下仍可全屏放大看清细节（见 onTap）。
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 280, maxHeight: 200),
            child: Image.asset(
              asset,
              fit: BoxFit.contain,
              // 图片缺失时不要炸掉整页教程：显示占位提示即可。
              errorBuilder: (_, __, ___) => Container(
                height: 120,
                alignment: Alignment.center,
                color: AppColors.background,
                child: Text('截图未找到',
                    style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
              ),
            ),
          ),
        ),
      );
}
