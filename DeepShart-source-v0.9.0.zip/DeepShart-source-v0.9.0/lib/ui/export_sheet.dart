// target: lib/ui/export_sheet.dart
// 职责：对话导出面板——选格式、选选项、落盘。渲染交给 ConversationExporter。

import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/theme.dart';
import 'app_toast.dart';
import '../data/models/chat_message.dart';
import '../data/store/conversation_store.dart';
import '../export/conversation_exporter.dart';
import '../state/app_providers.dart';

/// 导出面板。可直接嵌入 BottomSheet，也可作为独立页面内容。
class ExportSheet extends ConsumerStatefulWidget {
  final String conversationId;

  const ExportSheet({super.key, required this.conversationId});

  @override
  ConsumerState<ExportSheet> createState() => _ExportSheetState();
}

class _ExportSheetState extends ConsumerState<ExportSheet> {
  ExportFormat _format = ExportFormat.json;
  ExportOptions _options = const ExportOptions();
  bool _busy = false;

  Conversation? _conversation;
  List<ChatMessage> _messages = const <ChatMessage>[];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    try {
      final convStore = await ref.read(conversationStoreProvider.future);
      final msgStore = await ref.read(messageStoreProvider.future);
      final conv = await convStore.get(widget.conversationId);
      final msgs = await msgStore.readAll(widget.conversationId);
      if (!mounted) return;
      setState(() {
        _conversation = conv;
        _messages = msgs;
        _loading = false;
        if (conv == null) _error = '会话不存在，可能已被删除';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = '读取失败：$e';
      });
    }
  }

  /// 预览文本长度，帮用户在导出前判断体量。
  String get _sizeHint {
    if (_messages.isEmpty) return '暂无消息';
    final chars = _messages.fold<int>(0, (sum, m) => sum + m.content.length);
    final kb = (chars / 1024).toStringAsFixed(1);
    return '${_messages.length} 条消息 · 约 $kb 千字';
  }

  String get _renderedPreview {
    final conv = _conversation;
    if (conv == null) return '';
    return ConversationExporter.render(
      conversation: conv,
      messages: _messages,
      format: _format,
      options: _options,
    );
  }

  Future<void> _export() async {
    final conv = _conversation;
    if (conv == null || _busy) return;
    setState(() => _busy = true);
    try {
      final content = _renderedPreview;
      final bytes = utf8.encode(content);
      final fileName = ConversationExporter.suggestedFileName(conv, _format);

      String? savedPath;
      try {
        savedPath = await FilePicker.platform.saveFile(
          dialogTitle: '导出对话',
          fileName: fileName,
          type: FileType.custom,
          allowedExtensions: <String>[_format.extension],
          bytes: bytes,
        );
      } catch (_) {
        // 部分 Android 文件管理器不接受 custom MIME，退化为不限类型。
        savedPath = await FilePicker.platform.saveFile(
          dialogTitle: '导出对话',
          fileName: fileName,
          type: FileType.any,
          bytes: bytes,
        );
      }

      if (!mounted) return;
      setState(() => _busy = false);
      if (savedPath == null) return; // 用户取消
      if (!mounted) return;
      showAppToast(context, '已导出到：$savedPath', duration: Duration(seconds: 5));
      Navigator.maybePop(context);
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      showAppToast(context, '导出失败：$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.82,
      maxChildSize: 0.95,
      builder: (context, scrollController) => Scaffold(
        backgroundColor: AppColors.surface,
        appBar: AppBar(
          title: const Text('导出对话'),
          centerTitle: true,
          automaticallyImplyLeading: false,
          actions: [
            IconButton(
              icon: const Icon(Icons.close),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                controller: scrollController,
                padding: const EdgeInsets.all(16),
                children: [
                  if (_error != null)
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.danger.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(_error!,
                          style: TextStyle(color: AppColors.danger, fontSize: 13)),
                    ),
                  if (_conversation != null) ...[
                    Text(
                      _conversation!.title,
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary),
                    ),
                    const SizedBox(height: 4),
                    Text(_sizeHint,
                        style: TextStyle(
                            fontSize: 12, color: AppColors.textSecondary)),
                    const SizedBox(height: 20),
                    Text('选择格式',
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: AppColors.textPrimary)),
                    const SizedBox(height: 8),
                    _FormatSelector(
                      value: _format,
                      onChanged: (f) => setState(() => _format = f),
                    ),
                    const SizedBox(height: 20),
                    Text('导出内容',
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: AppColors.textPrimary)),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('包含思考过程', style: TextStyle(fontSize: 14)),
                      subtitle: const Text('关闭后只导出最终回复正文',
                          style: TextStyle(fontSize: 12)),
                      value: _options.includeThinking,
                      onChanged: (v) =>
                          setState(() => _options = _options.copyWith(includeThinking: v)),
                    ),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('包含时间与附件信息', style: TextStyle(fontSize: 14)),
                      subtitle: const Text('关闭后输出更精简的纯对话内容',
                          style: TextStyle(fontSize: 12)),
                      value: _options.includeMetadata,
                      onChanged: (v) =>
                          setState(() => _options = _options.copyWith(includeMetadata: v)),
                    ),
                    const SizedBox(height: 12),
                    _PreviewCard(text: _renderedPreview),
                    const SizedBox(height: 20),
                    FilledButton.icon(
                      icon: _busy
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.download, size: 18),
                      label: Text(_busy ? '正在导出…' : '导出为 .${_format.extension}'),
                      onPressed: _busy || _messages.isEmpty ? null : _export,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '导出为 JSON 时可被本应用或 DeepSeek 生态工具重新读取；其他格式用于阅读与存档。',
                      style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.5),
                    ),
                    const SizedBox(height: 24),
                  ],
                ],
              ),
      ),
    );
  }
}

class _FormatSelector extends StatelessWidget {
  final ExportFormat value;
  final ValueChanged<ExportFormat> onChanged;

  const _FormatSelector({required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: ExportFormat.values.map((f) {
        final selected = f == value;
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: InkWell(
            borderRadius: BorderRadius.circular(10),
            onTap: () => onChanged(f),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: selected ? AppColors.primarySoft : AppColors.surface,
                border: Border.all(
                  color: selected ? AppColors.primary : AppColors.outline,
                  width: selected ? 1.5 : 1,
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  Icon(
                    selected ? Icons.radio_button_checked : Icons.radio_button_unchecked,
                    size: 18,
                    color: selected ? AppColors.primary : AppColors.textSecondary,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          f.label,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: selected ? FontWeight.w600 : FontWeight.normal,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          f.description,
                          style: TextStyle(
                              fontSize: 11, color: AppColors.textSecondary, height: 1.4),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _PreviewCard extends StatelessWidget {
  final String text;

  const _PreviewCard({required this.text});

  @override
  Widget build(BuildContext context) {
    final preview = text.length > 600 ? '${text.substring(0, 600)}\n…' : text;
    return Container(
      width: double.infinity,
      constraints: const BoxConstraints(maxHeight: 200),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.background,
        border: Border.all(color: AppColors.outline),
        borderRadius: BorderRadius.circular(8),
      ),
      child: SingleChildScrollView(
        child: Text(
          preview.isEmpty ? '（暂无内容）' : preview,
          style: TextStyle(
            fontSize: 11,
            height: 1.5,
            fontFamily: 'Consolas',
            color: AppColors.textSecondary,
          ),
        ),
      ),
    );
  }
}
