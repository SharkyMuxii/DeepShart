// target: lib/ui/conflict_resolution_sheet.dart
// 职责：同步冲突的"整体裁决"UI——顶部横幅 + 一次性选择保留哪一台设备的版本。
//
// 设计变更（用户反馈驱动）：
//   旧实现是逐条左/右二选一。一次同步可能出现几千条差异（两台设备对同一批消息
//   各自 tick 过），逐条裁决既点不完，又会因为不断叠新的模态框把设备直接卡死。
//   现在语义改成：把所有差异当成一个整体，用户只需要回答一句
//   "这批内容整体用 A 设备（本机）的，还是用 B 设备（对端）的"。
//   逐条细节仍然展示（前几条样例 + 总数），但不再要求逐条点。

import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/models/conflict_record.dart';
import '../data/store/message_store.dart' show ConflictMergeStrategy;

/// 顶部横幅：有未裁决冲突时常驻，点开整体裁决弹窗。
class ConflictBanner extends StatelessWidget {
  final int conflictCount;
  final VoidCallback onTap;

  const ConflictBanner({
    super.key,
    required this.conflictCount,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    if (conflictCount == 0) return const SizedBox.shrink();
    return Material(
      color: const Color(0xFFFFF4E5),
      child: InkWell(
        onTap: onTap,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: const BoxDecoration(
            border: Border(bottom: BorderSide(color: Color(0xFFFFD591))),
          ),
          child: Row(
            children: [
              const Icon(Icons.warning_amber_rounded, color: Color(0xFFB25E00)),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  '有 $conflictCount 处内容两边不一致，点这里选择整体保留哪一边',
                  style: const TextStyle(
                      color: Color(0xFF8A4A00), fontWeight: FontWeight.w600),
                ),
              ),
              const Icon(Icons.chevron_right, color: Color(0xFFB25E00)),
            ],
          ),
        ),
      ),
    );
  }
}

/// 用户在弹窗里可能选的动作（三种策略 + 稍后处理）。
enum _BulkAction { local, remote, merge, defer }

/// 整体裁决弹窗。
class ConflictResolutionSheet extends StatefulWidget {
  final List<ConflictRecord> conflicts;

  /// 由调用方注入：按指定策略整体处理全部冲突，返回处理条数。
  final Future<int> Function(ConflictMergeStrategy strategy) onResolveAll;

  /// 稍后处理：保留冲突记录，不阻塞其他操作。
  final Future<void> Function() onDeferAll;

  const ConflictResolutionSheet({
    super.key,
    required this.conflicts,
    required this.onResolveAll,
    required this.onDeferAll,
  });

  @override
  State<ConflictResolutionSheet> createState() => _ConflictResolutionSheetState();
}

class _ConflictResolutionSheetState extends State<ConflictResolutionSheet> {
  bool _busy = false;
  String? _error;
  String _busyLabel = '';

  List<ConflictRecord> get _pending => widget.conflicts
      .where((c) => c.status == ConflictStatus.pending)
      .toList(growable: false);

  @override
  Widget build(BuildContext context) {
    final pending = _pending;
    if (pending.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.check_circle_outline, size: 42, color: Color(0xFF10B981)),
            SizedBox(height: 10),
            Text('冲突已全部处理完', style: TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      );
    }

    final total = pending.length;
    final conversationCount = pending.map((c) => c.conversationId).toSet().length;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.85,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 拖拽提示条
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(
                    color: AppColors.outline,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              Row(
                children: [
                  const Text('同步冲突',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(width: 8),
                  Text('$total 处',
                      style: const TextStyle(
                          fontSize: 13, color: Color(0xFFB25E00), fontWeight: FontWeight.w600)),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.close, size: 20),
                    tooltip: '稍后处理',
                    onPressed: _busy ? null : () => _decide(_BulkAction.defer),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                conversationCount > 1
                    ? '涉及 $conversationCount 个会话。这些内容两台设备都改过，'
                        '没必要一条条选——当成一个整体决定用哪一边就行。'
                    : '这些内容两台设备都改过，没必要一条条选——当成一个整体决定用哪一边就行。',
                style: TextStyle(
                    fontSize: 12, height: 1.5, color: AppColors.textSecondary),
              ),
              const SizedBox(height: 12),
              Flexible(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _ChoiceCard(
                        icon: Icons.phone_iphone,
                        label: '全部使用本机版本',
                        deviceId: pending.first.versionA.deviceId,
                        description: '舍弃对端的改动，本机内容原样保留',
                        enabled: !_busy,
                        onTap: () => _decide(_BulkAction.local),
                      ),
                      const SizedBox(height: 8),
                      _ChoiceCard(
                        icon: Icons.devices_other,
                        label: '全部使用对端版本',
                        deviceId: pending.first.versionB.deviceId,
                        description: '用同步过来的内容覆盖本机改动',
                        enabled: !_busy,
                        onTap: () => _decide(_BulkAction.remote),
                      ),
                      const SizedBox(height: 8),
                      _ChoiceCard(
                        icon: Icons.merge_type,
                        label: '保留双方（按时间合并）',
                        deviceId: pending.first.versionB.deviceId,
                        description: '两条都留下，按原时间穿插；信息不丢但可能出现重复',
                        enabled: !_busy,
                        onTap: () => _decide(_BulkAction.merge),
                      ),
                      const SizedBox(height: 14),
                      _DiffSection(conflicts: pending),
                    ],
                  ),
                ),
              ),
              if (_error != null) ...[
                const SizedBox(height: 10),
                Text(_error!, style: TextStyle(fontSize: 12, color: AppColors.danger)),
              ],
              if (_busy) ...[
                const SizedBox(height: 12),
                const LinearProgressIndicator(minHeight: 3),
                const SizedBox(height: 6),
                Text(_busyLabel,
                    style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
              ] else ...[
                const SizedBox(height: 10),
                TextButton(
                  onPressed: () => _decide(_BulkAction.defer),
                  child: const Text('稍后再说（保留冲突提示）'),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _decide(_BulkAction action) async {
    if (_busy) return;
    if (action == _BulkAction.defer) {
      setState(() => _busy = true);
      try {
        await widget.onDeferAll();
      } catch (_) {
        // 延后失败也不该挡住用户关窗，静默即可。
      }
      if (mounted) Navigator.pop(context);
      return;
    }

    final total = _pending.length;
    final strategy = switch (action) {
      _BulkAction.local => ConflictMergeStrategy.local,
      _BulkAction.remote => ConflictMergeStrategy.remote,
      _BulkAction.merge => ConflictMergeStrategy.merge,
      _BulkAction.defer => ConflictMergeStrategy.local,
    };
    setState(() {
      _busy = true;
      _error = null;
      _busyLabel = '正在应用 $total 条…';
    });

    try {
      final applied = await widget.onResolveAll(strategy);
      if (!mounted) return;
      Navigator.pop(context);
      debugPrint('[conflict] bulk resolved $applied / $total');
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = '应用失败：$e';
      });
    }
  }
}

/// 一张"整体选这边"的按钮卡片。
class _ChoiceCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String deviceId;
  final String description;
  final bool enabled;
  final VoidCallback onTap;

  const _ChoiceCard({
    required this.icon,
    required this.label,
    required this.deviceId,
    required this.description,
    required this.enabled,
    required this.onTap,
  });

  String get _shortId =>
      deviceId.length <= 8 ? deviceId : deviceId.substring(0, 8);

  @override
  Widget build(BuildContext context) => Material(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          onTap: enabled ? onTap : null,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.outline),
            ),
            child: Row(
              children: [
                Container(
                  width: 34,
                  height: 34,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: AppColors.primarySoft,
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: Icon(Icons.devices_other, size: 18, color: AppColors.primary),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(label,
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(height: 2),
                      Text('$description · ID $_shortId',
                          style: TextStyle(
                              fontSize: 11, color: AppColors.textSecondary)),
                    ],
                  ),
                ),
                Icon(Icons.chevron_right, color: AppColors.textSecondary),
              ],
            ),
          ),
        ),
      );
}

/// 差异样例：只列前几条，让用户确认"确实是我改的那批"，不强迫逐条点。
class _DiffSection extends StatelessWidget {
  final List<ConflictRecord> conflicts;

  const _DiffSection({required this.conflicts});

  static const int _previewLimit = 5;

  static String _preview(String text) {
    final flat = text
        .replaceAll('<thinking>', '')
        .replaceAll('</thinking>', '')
        .replaceAll('\n', ' ')
        .trim();
    if (flat.isEmpty) return '（空内容）';
    return flat.length <= 140 ? flat : '${flat.substring(0, 140)}…';
  }

  /// 找出 a、b 的最长公共前缀/后缀长度，用于把"不同的一段"高亮出来。
  /// 这是一阶近似（不做完整 LCS），但对"两台设备在某个位置开始聊岔了"的场景
  /// 足够直观——共同部分灰显、差异部分加粗高亮，用户一眼看出从哪开始不同。
  static (int, int) _commonEdges(String a, String b) {
    var pre = 0;
    final maxPre = a.length < b.length ? a.length : b.length;
    while (pre < maxPre && a[pre] == b[pre]) { pre++; }
    var suf = 0;
    final maxSuf = a.length - pre < b.length - pre
        ? (a.length - pre) : (b.length - pre);
    while (suf < maxSuf && a[a.length - 1 - suf] == b[b.length - 1 - suf]) { suf++; }
    return (pre, suf);
  }

  /// 把一段文本按 [与对端相同的部分 / 不同的部分] 拆成带样式的 spans。
  static List<InlineSpan> _diffSpans(String text, String other, Color diffColor) {
    final (pre, suf) = _commonEdges(text, other);
    final commonEnd = text.length - suf;
    final spans = <InlineSpan>[];
    if (pre > 0) {
      spans.add(TextSpan(
        text: text.substring(0, pre),
        style: const TextStyle(fontSize: 11, color: Color(0xFF9CA3AF)),
      ));
    }
    if (commonEnd > pre) {
      spans.add(TextSpan(
        text: text.substring(pre, commonEnd),
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: diffColor,
          backgroundColor: diffColor.withValues(alpha: 0.16),
        ),
      ));
    }
    if (suf > 0) {
      spans.add(TextSpan(
        text: text.substring(commonEnd),
        style: const TextStyle(fontSize: 11, color: Color(0xFF9CA3AF)),
      ));
    }
    return spans;
  }

  @override
  Widget build(BuildContext context) {
    final shown = conflicts.take(_previewLimit).toList(growable: false);
    final rest = conflicts.length - shown.length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('差异样例（共 ${conflicts.length} 处 · 高亮处为不同内容）',
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        for (final c in shown)
          Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.background,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.outline),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('本机（${c.versionA.deviceId}）：',
                    style: TextStyle(fontSize: 10, color: AppColors.textSecondary)),
                const SizedBox(height: 2),
                RichText(
                  text: TextSpan(
                    children: _diffSpans(
                      _preview(c.versionA.content),
                      _preview(c.versionB.content),
                      AppColors.primary,
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                Text('对端（${c.versionB.deviceId}）：',
                    style: TextStyle(fontSize: 10, color: AppColors.textSecondary)),
                const SizedBox(height: 2),
                RichText(
                  text: TextSpan(
                    children: _diffSpans(
                      _preview(c.versionB.content),
                      _preview(c.versionA.content),
                      AppColors.danger,
                    ),
                  ),
                ),
              ],
            ),
          ),
        if (rest > 0)
          Text(
            '还有 $rest 处未列出，会按你上面的选择一起处理。',
            style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
          ),
      ],
    );
  }
}
