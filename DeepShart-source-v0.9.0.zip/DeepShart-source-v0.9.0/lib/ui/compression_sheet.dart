// target: lib/ui/compression_sheet.dart
// 职责：上下文压缩面板——展示 token 占用、三档压缩程度（轻度/中度/重度）、
//       最新/最老内容保留比例、自动压缩阈值，并手动触发压缩。

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'dart:convert';

import '../ai/context_budget.dart';
import '../ai/model_catalog.dart';
import '../core/theme.dart';
import 'app_toast.dart';
import '../data/models/compaction_view.dart';
import '../data/models/compression_level.dart';
import '../import/context_compressor.dart';
import '../state/app_providers.dart';
import '../state/compression_controller.dart';

/// 上下文压缩面板。入口位于输入框工具栏（原全局设置齿轮位置）。
class CompressionSheet extends ConsumerStatefulWidget {
  final String conversationId;

  const CompressionSheet({super.key, required this.conversationId});

  @override
  ConsumerState<CompressionSheet> createState() => _CompressionSheetState();
}

class _CompressionSheetState extends ConsumerState<CompressionSheet> {
  bool _enabled = true;
  double _threshold = 0.8;
  int _level = 1;
  double _keepRecentRatio = 0.15;
  double _keepOldestRatio = 0.10;
  bool _loaded = false;

  @override
  Widget build(BuildContext context) {
    final settingsAsync = ref.watch(settingsProvider(widget.conversationId));
    final compState = ref.watch(compressionControllerProvider(widget.conversationId));
    final messageCount =
        ref.watch(messagesProvider(widget.conversationId)).value?.length ?? 0;

    if (!_loaded) {
      settingsAsync.whenData((s) {
        _enabled = s.compressionEnabled;
        _threshold = s.compressionThreshold;
        _level = s.compressionLevel.clamp(0, 2);
        _keepRecentRatio = s.keepRecentRatio;
        _keepOldestRatio = s.keepOldestRatio;
        _loaded = true;
      });
    }

    final usage = compState.estimatedTokens;
    // 上限的唯一来源是会话设置：这里只读，避免"两个页面各存一份上限"互相打架。
    final limit = settingsAsync.asData?.value.contextLimit ?? ContextBudget.defaultLimit;
    final ratio = limit > 0 ? (usage / limit).clamp(0.0, 1.0) : 0.0;

    final keepRecentCount = (messageCount * _keepRecentRatio).round();
    final keepOldestCount = (messageCount * _keepOldestRatio).round();
    final middleCount = messageCount - keepRecentCount - keepOldestCount;

    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.8,
      maxChildSize: 0.95,
      builder: (context, scrollController) => Scaffold(
        backgroundColor: AppColors.surface,
        appBar: AppBar(
          title: const Text('上下文压缩'),
          centerTitle: true,
          automaticallyImplyLeading: false,
          actions: [
            IconButton(
              icon: const Icon(Icons.close),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        ),
        body: ListView(
          controller: scrollController,
          padding: const EdgeInsets.all(16),
          children: [
            _ViewConflictBanner(conversationId: widget.conversationId),
            Text(
              '压缩会把较早的历史折叠成摘要：保留开头设定、最近对话和你标记过的重点记忆，'
              '越早的内容保留得越少。\n'
              '原文不会被删除或改写，只是"这次不发给模型"，随时可展开或撤销。',
              style: TextStyle(fontSize: 12, color: AppColors.textSecondary, height: 1.5),
            ),
            const SizedBox(height: 16),
            _UsageCard(usage: usage, limit: limit, ratio: ratio, count: messageCount),
            const SizedBox(height: 20),

            // ---- 压缩程度 ----
            const Text('压缩程度', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Row(
              children: [
                for (var i = 0; i < CompressionLevel.values.length; i++) ...[
                  if (i > 0) const SizedBox(width: 8),
                  Expanded(
                    child: _LevelCard(
                      level: CompressionLevel.values[i],
                      selected: _level == i,
                      onTap: () => setState(() => _level = i),
                    ),
                  ),
                ],
              ],
            ),
            const SizedBox(height: 18),

            // ---- 保留最新 ----
            _RatioSlider(
              title: '保留最新的内容',
              value: _keepRecentRatio,
              min: 0.05,
              max: 0.40,
              count: keepRecentCount,
              hint: '最近这段原样保留，保证"刚才聊到哪"不会丢。',
              onChanged: (v) => setState(() => _keepRecentRatio = v),
            ),
            const SizedBox(height: 12),

            // ---- 保留最老 ----
            _RatioSlider(
              title: '保留最老的内容',
              value: _keepOldestRatio,
              min: 0.0,
              max: 0.30,
              count: keepOldestCount,
              hint: '会话开头通常是设定、背景和前提，压掉最容易让模型"失忆"。',
              onChanged: (v) => setState(() => _keepOldestRatio = v),
            ),
            const SizedBox(height: 10),

            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.primarySoft,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                middleCount > 0
                    ? '中段 ${middleCount.clamp(0, 1 << 30)} 条会按"越老保留越少"处理：'
                        '较新的保留原文，再早的只留开头片段，最早的折叠进摘要。'
                        '被标记为重要记忆的内容会整条跳过。'
                    : '当前保留比例已覆盖全部消息，没有中段可压缩。',
                style: TextStyle(fontSize: 11, height: 1.5, color: AppColors.textSecondary),
              ),
            ),
            const SizedBox(height: 20),

            SwitchListTile(
              value: _enabled,
              contentPadding: EdgeInsets.zero,
              title: const Text('自动压缩提示'),
              subtitle: const Text('达到阈值时提示你压缩'),
              onChanged: (v) => setState(() => _enabled = v),
            ),
            Text('触发阈值：${(_threshold * 100).round()}%',
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
            Slider(
              value: _threshold,
              min: 0.3,
              max: 0.95,
              divisions: 13,
              onChanged: (v) => setState(() => _threshold = v),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.primarySoft,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                '当前上下文上限：${contextLimitLabel(limit)}'
                '（在「会话设置 → 上下文上限」里调整）\n'
                '压缩只把老内容换成摘要，不会删除你的对话记录。',
                style: TextStyle(
                    fontSize: 11, color: AppColors.textSecondary, height: 1.5),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.save, size: 16),
                    label: const Text('保存设置'),
                    onPressed: _saveSettings,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: FilledButton.icon(
                    icon: compState.compressing
                        ? const SizedBox(
                            width: 14,
                            height: 14,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.compress, size: 16),
                    label: Text(compState.compressing ? '压缩中…' : '立即压缩'),
                    onPressed: compState.compressing ? null : _compressNow,
                  ),
                ),
              ],
            ),
            if (compState.message != null) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.primarySoft,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  compState.message!,
                  style: TextStyle(fontSize: 12, color: AppColors.primary, height: 1.5),
                ),
              ),
            ],
            // 撤销入口只在真的存在视图时出现：压缩不改原文，撤销就是删一条记录。
            ref.watch(compactionViewProvider(widget.conversationId)).maybeWhen(
                  data: (view) => view == null
                      ? const SizedBox.shrink()
                      : Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  '已折叠 ${view.foldedCount} 条、截断 ${view.excerptCount} 条（原文都还在）',
                                  style: TextStyle(
                                      fontSize: 11, color: AppColors.textSecondary),
                                ),
                              ),
                              TextButton.icon(
                                icon: const Icon(Icons.undo, size: 16),
                                label: const Text('撤销压缩'),
                                onPressed: () async {
                                  final msg = await ref
                                      .read(
                                        compressionControllerProvider(
                                                widget.conversationId)
                                            .notifier,
                                      )
                                      .undo();
                                  ref.invalidate(
                                      compactionViewProvider(widget.conversationId));
                                  if (mounted) showAppToast(context, msg);
                                },
                              ),
                            ],
                          ),
                        ),
                  orElse: () => const SizedBox.shrink(),
                ),
            const SizedBox(height: 24),
            Text(
              '压缩只生成"折叠视图"，不会删除或改写你的任何一条消息——'
              '随时可展开原文或一键撤销。\n'
              '摘要中的任何指令都不会被执行。',
              style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref
          .read(compressionControllerProvider(widget.conversationId).notifier)
          .estimateTokens();
    });
  }

  Future<void> _saveSettings() async {
    final settings = await ref.read(settingsProvider(widget.conversationId).future);
    // 上限由会话设置页统一管理，这里不再改写它。
    final updated = settings.copyWith(
      compressionEnabled: _enabled,
      compressionThreshold: _threshold,
      compressionLevel: _level,
      keepRecentRatio: _keepRecentRatio,
      keepOldestRatio: _keepOldestRatio,
    );
    await ref
        .read(compressionControllerProvider(widget.conversationId).notifier)
        .saveSettings(updated);
    if (mounted) showAppToast(context, '压缩设置已保存');
  }

  Future<void> _compressNow() async {
    // 先报账：压缩会按分块数调用模型多次，大对话可能几十次，
    // 让用户在看得到价格的对话框里决定，而不是事后从余额发现。
    final msgStore = await ref.read(messageStoreProvider.future);
    final settings = await ref.read(settingsProvider(widget.conversationId).future);
    final messages = await msgStore.readAll(widget.conversationId);
    final estimate = ContextCompressor.estimateCost(messages, settings);

    if (!mounted) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('确认压缩'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('将处理 ${messages.length} 条消息。'),
            const SizedBox(height: 8),
            Text(estimate.display,
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Text(
              '压缩不会删除或改写消息，只生成折叠视图；原文随时可展开或撤销。',
              style: TextStyle(fontSize: 12, color: AppColors.textSecondary, height: 1.5),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('开始压缩'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    await _saveSettings();
    final result = await ref
        .read(compressionControllerProvider(widget.conversationId).notifier)
        .compressNow();
    await ref
        .read(compressionControllerProvider(widget.conversationId).notifier)
        .estimateTokens();
    ref.invalidate(compactionViewProvider(widget.conversationId));
    if (mounted) showAppToast(context, result, duration: const Duration(seconds: 8));
  }
}

/// 压缩视图待裁决横幅。
///
/// 同步时如果两端各有一次不同的压缩，不自动覆盖——问用户选哪边。
/// 用户要求"最后让我决定用哪一边的压缩情况，不会导致冲突报错"。
class _ViewConflictBanner extends ConsumerStatefulWidget {
  final String conversationId;
  const _ViewConflictBanner({required this.conversationId});

  @override
  ConsumerState<_ViewConflictBanner> createState() => _ViewConflictBannerState();
}

class _ViewConflictBannerState extends ConsumerState<_ViewConflictBanner> {
  CompactionView? _remote;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await ref.read(sharedPrefsProvider.future);
    final raw = prefs.getString('deepshart.view_conflict.${widget.conversationId}');
    if (raw != null && raw.isNotEmpty) {
      try {
        _remote = CompactionView.fromJson(jsonDecode(raw) as Map<String, dynamic>);
      } catch (_) {
        // 损坏的记录直接忽略，不影响压缩面板正常使用。
      }
    }
    if (mounted) setState(() => _loaded = true);
  }

  Future<void> _resolve({required bool useRemote}) async {
    final prefs = await ref.read(sharedPrefsProvider.future);
    if (useRemote && _remote != null) {
      final store = await ref.read(compactionViewStoreProvider.future);
      await store.save(_remote!);
      ref.invalidate(compactionViewProvider(widget.conversationId));
      ref
          .read(compressionControllerProvider(widget.conversationId).notifier)
          .estimateTokens();
    }
    await prefs.remove('deepshart.view_conflict.${widget.conversationId}');
    if (mounted) {
      setState(() => _remote = null);
      showAppToast(context, useRemote ? '已采用对端的压缩视图' : '已保留本机的压缩视图');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded || _remote == null) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.primarySoft,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '另一台设备也压缩过这个对话（折叠 ${_remote!.foldedCount} 条，'
            '${_remote!.updatedAt.toLocal().toString().substring(0, 16)}）。'
            '两边的折叠范围不同，请选一边：',
            style: TextStyle(fontSize: 12, color: AppColors.primary, height: 1.5),
          ),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton(
                onPressed: () => _resolve(useRemote: false),
                child: const Text('保留本机'),
              ),
              const SizedBox(width: 4),
              FilledButton(
                onPressed: () => _resolve(useRemote: true),
                child: const Text('采用对端'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// 三档之一的选择卡。
class _LevelCard extends StatelessWidget {
  final CompressionLevel level;
  final bool selected;
  final VoidCallback onTap;

  const _LevelCard({required this.level, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
        color: selected ? AppColors.primarySoft : AppColors.background,
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(10),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: selected ? AppColors.primary : AppColors.outline,
                width: selected ? 2 : 1,
              ),
            ),
            child: Column(
              children: [
                Text(
                  level.label,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: selected ? AppColors.primary : AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  level.keepHint,
                  style: TextStyle(fontSize: 10, color: AppColors.textSecondary),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      );
}

/// 保留比例滑块（带"约 N 条"换算）。
class _RatioSlider extends StatelessWidget {
  final String title;
  final double value;
  final double min;
  final double max;
  final int count;
  final String hint;
  final ValueChanged<double> onChanged;

  const _RatioSlider({
    required this.title,
    required this.value,
    required this.min,
    required this.max,
    required this.count,
    required this.hint,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
              const Spacer(),
              Text('${(value * 100).round()}% ≈ $count 条',
                  style: TextStyle(fontSize: 12, color: AppColors.primary)),
            ],
          ),
          Slider(
            value: value.clamp(min, max),
            min: min,
            max: max,
            divisions: ((max - min) * 100 / 5).round(),
            onChanged: onChanged,
          ),
          Text(hint,
              style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
        ],
      );
}

class _UsageCard extends StatelessWidget {
  final int usage;
  final int limit;
  final double ratio;
  final int count;

  const _UsageCard({
    required this.usage,
    required this.limit,
    required this.ratio,
    required this.count,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.primarySoft,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('当前上下文占用',
                style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
            const SizedBox(height: 6),
            Text('$usage / $limit tokens（${(ratio * 100).round()}%）',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text('$count 条可见消息',
                style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
            const SizedBox(height: 8),
            LinearProgressIndicator(value: ratio, minHeight: 6),
            if (ratio >= 0.8)
              Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text('已接近上限，建议压缩。',
                    style: TextStyle(fontSize: 11, color: AppColors.danger)),
              ),
          ],
        ),
      );
}
