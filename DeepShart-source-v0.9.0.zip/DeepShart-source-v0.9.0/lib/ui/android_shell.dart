// target: lib/ui/android_shell.dart
// 职责：Android 外壳——Drawer 承载真实会话列表，长按弹出 BottomSheet；配对入口；内容区共享 ChatScreen。

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/app_info.dart';
import '../core/theme.dart';
import '../data/store/conversation_store.dart';
import '../export/batch_export.dart';
import '../state/app_providers.dart';
import '../state/chat_controller.dart';
import '../state/cos_sync_provider.dart';
import 'chat_screen.dart';
import 'app_toast.dart';
import 'cos_sync_panel.dart';
import 'balance_widget.dart';
import 'conversation_list.dart';
import 'export_sheet.dart';
import 'global_settings_sheet.dart';
import 'import_sheet.dart';
import 'pairing_panel.dart';
import 'scroll_to_bottom_button.dart';
import 'search_results_view.dart';

class AndroidShell extends ConsumerStatefulWidget {
  final Widget? child;

  const AndroidShell({super.key, this.child});

  @override
  ConsumerState<AndroidShell> createState() => _AndroidShellState();
}

class _AndroidShellState extends ConsumerState<AndroidShell> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  String? _selectedId;
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  final ScrollController _listScrollController = ScrollController();
  bool _listMultiSelect = false; // 多选时关闭滚动悬浮按钮，避免与底部操作栏重叠。
  String? _jumpConversationId;
  String? _jumpMessageId;
  bool _syncing = false; // 一键同步进行中，防连点。
  bool _startupHandled = false; // 启动时的空对话检测只做一次，避免 build 里重复创建。

  /// 云端右上角按钮：COS 模式下改为一键同步（P2P 模式仍走配对面板）。
  Future<void> _oneTapSync() async {
    if (_syncing) return;
    setState(() => _syncing = true);
    try {
      final report = await ref.read(cosSyncCoordinatorProvider).syncNow();
      ref.invalidate(conversationsProvider);
      if (!mounted) return;
      if (report.error != null) {
        showAppToast(context, report.error!);
      } else {
        showAppToast(context, '同步完成 · ${report.summary}');
      }
    } catch (e) {
      if (mounted) showAppToast(context, '同步失败：$e');
    } finally {
      if (mounted && _syncing) setState(() => _syncing = false);
    }
  }

  void _jumpToMessage(String conversationId, String messageId) {
    _jumpConversationId = conversationId;
    _jumpMessageId = messageId;
    _selectedId = conversationId;
    ref.read(currentConversationIdProvider.notifier).state = conversationId;
    Navigator.pop(context); // 关掉抽屉
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _searchController.dispose();
    _listScrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final conversationsAsync = ref.watch(conversationsProvider);
    final conversations = conversationsAsync.value ?? <Conversation>[];

    // 启动时对话选中（只做一次）：草稿会话优先（保护"选完文件回来"的修复），
    // 否则打开一个空白新对话；若一个空对话都没有，自动新建并跳转。
    if (_selectedId == null && !_startupHandled && conversationsAsync.hasValue) {
      _startupHandled = true;
      final withDraft = conversations.where(
        (c) => ref.read(draftAttachmentsProvider(c.id)).isNotEmpty,
      );
      final blank = conversations.where((c) => c.title.startsWith('新对话')).firstOrNull;
      if (withDraft.isNotEmpty) {
        _selectedId = withDraft.first.id;
        ref.read(currentConversationIdProvider.notifier).state = _selectedId!;
      } else if (blank != null) {
        _selectedId = blank.id;
        ref.read(currentConversationIdProvider.notifier).state = _selectedId!;
      } else {
        unawaited(_createConversation());
      }
    }

    return Scaffold(
      key: _scaffoldKey,
      drawer: Drawer(
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Image.asset(
                      'assets/icons/shark_small.png',
                      width: 32,
                      height: 32,
                      filterQuality: FilterQuality.high,
                    ),
                    const SizedBox(width: 12),
                    const Text('DeepShart',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    const Spacer(),
                    IconButton(icon: const Icon(Icons.add), onPressed: _createConversation),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    TextButton.icon(
                      icon: const Icon(Icons.chat, size: 16),
                      label: const Text('会话'),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const SizedBox(width: 8),
                    TextButton.icon(
                      icon: Icon(ref.watch(syncModeProvider) == SyncMode.cos
                          ? Icons.cloud_outlined : Icons.link, size: 16),
                      label: Text(ref.watch(syncModeProvider) == SyncMode.cos ? '云同步' : '配对'),
                      onPressed: () {
                        Navigator.pop(context);
                        _showPairing();
                      },
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: TextField(
                  controller: _searchController,
                  decoration: const InputDecoration(
                    hintText: '搜索会话…',
                    prefixIcon: Icon(Icons.search, size: 18),
                    isDense: true,
                    border: OutlineInputBorder(),
                    contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                  ),
                  style: const TextStyle(fontSize: 12),
                  onChanged: (v) => setState(() => _searchQuery = v.trim().toLowerCase()),
                ),
              ),
              Expanded(
                child: Stack(
                  children: [
                    _searchQuery.isNotEmpty
                        ? SearchResultsView(query: _searchQuery, onJump: _jumpToMessage)
                        : conversationsAsync.when(
                      loading: () => const Center(child: CircularProgressIndicator()),
                      error: (e, _) => Center(child: Text('加载失败: $e')),
                      data: (list) => ConversationListContent(
                          scrollController: _listScrollController,
                          conversations: list
                              .map((c) => ConversationItem(
                                    id: c.id,
                                    title: c.title,
                                    updatedAt: c.updatedAt,
                                    pinned: c.pinned,
                                  ))
                              .toList(),
                          selectedId: _selectedId,
                          onTap: (item) {
                            _switchConversation(item.id);
                            Navigator.pop(context);
                          },
                          // 长按/右键已改为进入多选；单条菜单挪到每行"三个点"按钮。
                          onShowActions: (item, _) {},
                          onActionSelected: (item, action) => _runConversationAction(item, action),
                          onBatchDelete: _batchDeleteConversations,
                          onBatchExport: _batchExportConversations,
                          onMultiSelectChanged: (v) => setState(() => _listMultiSelect = v),
                        ),
                    ),
                    ScrollToBottomButton(
                      controller: _listScrollController,
                      direction: ScrollJumpDirection.both,
                      bottomOffset: _listMultiSelect ? 58 : 16,
                    ),
                  ],
                ),
              ),
              // 全局设置 / 对话导入入口挪到对话列表左下角；底部保留作者标注。
              ListTile(
                leading: Icon(Icons.file_upload, color: AppColors.textSecondary),
                title: Text('导入对话',
                    style: TextStyle(color: AppColors.textSecondary, fontSize: 14)),
                onTap: () {
                  Navigator.pop(context);
                  _showImport();
                },
              ),
              ListTile(
                leading: Icon(Icons.settings_outlined, color: AppColors.textSecondary),
                title: Text('全局设置',
                    style: TextStyle(color: AppColors.textSecondary, fontSize: 14)),
                onTap: () {
                  Navigator.pop(context);
                  _showGlobalSettings();
                },
              ),
              // 余额紧跟全局设置下方，和桌面端保持一致。
              const BalanceTile(),
              Padding(
                padding: EdgeInsets.only(left: 16, right: 16, bottom: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(AppInfo.author,
                        style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                    const SizedBox(height: 2),
                    Text(AppInfo.version,
                        style: TextStyle(color: AppColors.textSecondary, fontSize: 11)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () => _scaffoldKey.currentState?.openDrawer(),
        ),
        title: Text(_selectedTitle ?? AppInfo.name),
        centerTitle: true,
        actions: [
          // COS 模式：右上角按钮改为一键同步；P2P 模式保持原来的配对入口。
          ref.watch(syncModeProvider) == SyncMode.cos
              ? IconButton(
                  icon: _syncing
                      ? const SizedBox(
                          width: 20, height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.cloud_sync_outlined),
                  tooltip: '一键同步',
                  onPressed: _syncing ? null : _oneTapSync,
                )
              : IconButton(
                  icon: const Icon(Icons.link),
                  tooltip: '配对',
                  onPressed: _showPairing,
                ),
        ],
      ),
      body: _selectedId != null
          ? ChatScreen(
              key: ValueKey('$_selectedId-${_jumpMessageId ?? ''}'),
              conversationId: _selectedId!,
              jumpToMessageId: _selectedId == _jumpConversationId ? _jumpMessageId : null,
            )
          : Center(
              child: Text('请选择或新建一个会话',
                  style: TextStyle(color: AppColors.textSecondary)),
            ),
    );
  }

  String? get _selectedTitle {
    final list = ref.watch(conversationsProvider).value ?? <Conversation>[];
    if (_selectedId == null) return null;
    for (final c in list) {
      if (c.id == _selectedId) return c.title;
    }
    return null;
  }

  void _showPairing() {
    final isCos = ref.read(syncModeProvider) == SyncMode.cos;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => SizedBox(
        height: MediaQuery.of(context).size.height * 0.8,
        child: Scaffold(body: isCos ? const CosSyncPanel() : const PairingPanel()),
      ),
    );
  }

  void _showGlobalSettings() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => const GlobalSettingsSheet(),
    );
  }

  void _showImport() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => const ImportSheet(),
    );
  }

  void _showExport(String conversationId) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => ExportSheet(conversationId: conversationId),
    );
  }

  Future<void> _createConversation() async {
    final store = await ref.read(conversationStoreProvider.future);
    final id = newConversationId();
    final now = DateTime.now();
    await store.upsert(Conversation.create(id: id, title: '新对话 ${now.month}/${now.day}'));
    ref.invalidate(conversationsProvider);
    _selectedId = id;
    ref.read(currentConversationIdProvider.notifier).state = id;
    if (mounted) Navigator.pop(context);
  }

  /// 切走时删除空白新对话，避免列表堆一坨"新对话"。
  Future<void> _switchConversation(String newId) async {
    final previous = _selectedId;
    if (previous != null && previous != newId) {
      final store = await ref.read(conversationStoreProvider.future);
      final conv = await store.get(previous);
      if (conv != null && conv.title.startsWith('新对话')) {
        // 有未发送附件草稿或正在上传时，绝不当空白对话删除——
        // 否则选完图切走会把附件连同会话一起删掉，文件被发到错误的地方。
        final hasDraft = ref.read(draftAttachmentsProvider(previous)).isNotEmpty;
        final isSending = ref.read(sendingInProgressProvider(previous));
        final messages = await (await ref.read(messageStoreProvider.future)).readAll(previous);
        if (messages.isEmpty && !hasDraft && !isSending) {
          await store.delete(previous);
          ref.invalidate(conversationsProvider);
        }
      }
    }
    _selectedId = newId;
    ref.read(currentConversationIdProvider.notifier).state = newId;
    if (mounted) setState(() {});
  }

  /// 执行会话的单条操作（置顶/备注/导出/删除），供"三个点"按钮调用。
  Future<void> _runConversationAction(ConversationItem item, String action) async {
    if (action == 'export') {
      if (!context.mounted) return;
      _showExport(item.id);
      return;
    }
    final store = await ref.read(conversationStoreProvider.future);
    if (!context.mounted) return;
    if (action == 'pin') {
      final conv = await store.get(item.id);
      if (conv != null) {
        await store.upsert(conv.copyWith(pinned: !conv.pinned));
        ref.invalidate(conversationsProvider);
      }
      return;
    }
    if (action == 'rename') {
      final newTitle = await showRenameDialog(context, item.title);
      if (newTitle != null && newTitle.isNotEmpty) {
        final conv = await store.get(item.id);
        if (conv != null) {
          await store.upsert(conv.copyWith(title: newTitle));
          ref.invalidate(conversationsProvider);
        }
      }
    } else if (action == 'delete') {
      if (!context.mounted) return;
      final confirmed = await showDeleteConfirmDialog(context, item.title);
      if (confirmed) {
        await store.delete(item.id);
        ref.invalidate(conversationsProvider);
        if (_selectedId == item.id) setState(() => _selectedId = null);
      }
    }
  }

  /// 多选批量删除会话。
  Future<void> _batchDeleteConversations(Set<String> ids) async {
    final store = await ref.read(conversationStoreProvider.future);
    for (final id in ids) {
      await store.delete(id);
    }
    ref.invalidate(conversationsProvider);
    if (_selectedId != null && ids.contains(_selectedId)) {
      setState(() => _selectedId = null);
    }
  }

  /// 批量导出所选会话为单个 JSON 文件。
  Future<void> _batchExportConversations(Set<String> ids) async {
    try {
      final result = await exportConversationsByIds(ref, ids);
      if (!mounted || result.path == null) return;
      showAppToast(context, '已导出 ${result.count} 个会话到：${result.path}',
          duration: const Duration(seconds: 5));
    } catch (e) {
      if (mounted) showAppToast(context, '导出失败：$e');
    }
  }
}
