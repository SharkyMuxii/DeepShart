// target: lib/ui/settings_sheet.dart
// 职责：单会话设置面板——API Key、角色提示词、temperature、会话摘要、重要记忆点的真实读写 UI。

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../ai/ai_provider.dart';
import '../ai/memory_batch_extractor.dart';
import '../ai/memory_blacklist.dart';
import '../ai/memory_curator.dart';
import '../ai/model_catalog.dart';
import '../core/app_info.dart';
import '../core/font_service.dart';
import '../core/theme.dart';
import 'app_toast.dart';
import '../data/models/conversation_settings.dart';
import '../data/models/important_memory.dart';
import '../data/models/session_summary.dart';
import '../state/app_providers.dart';
import '../state/chat_controller.dart';
import 'export_sheet.dart';
import 'scroll_to_bottom_button.dart';


class ConversationSettingsSheet extends ConsumerStatefulWidget {
  final String conversationId;

  const ConversationSettingsSheet({super.key, required this.conversationId});

  @override
  ConsumerState<ConversationSettingsSheet> createState() =>
      _ConversationSettingsSheetState();
}

class _ConversationSettingsSheetState extends ConsumerState<ConversationSettingsSheet> {
  @override
  Widget build(BuildContext context) {
    final settingsAsync = ref.watch(settingsProvider(widget.conversationId));
    final summaryAsync = ref.watch(summaryProvider(widget.conversationId));
    final memoriesAsync = ref.watch(memoriesProvider(widget.conversationId));

    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.9,
      maxChildSize: 0.95,
      builder: (context, scrollController) => Scaffold(
        backgroundColor: AppColors.surface,
        appBar: AppBar(
          title: const Text('会话设置'),
          centerTitle: true,
          automaticallyImplyLeading: false,
          actions: [
            IconButton(
              icon: const Icon(Icons.close),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        ),
        body: Stack(
          children: [
            ListView(
          controller: scrollController,
          padding: const EdgeInsets.all(16),
          children: [
            settingsAsync.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => Text('设置加载失败: $e'),
              data: (settings) => _BehaviorSection(
                conversationId: widget.conversationId,
                settings: settings,
              ),
            ),
            const Divider(height: 32),
            _SummarySection(
              conversationId: widget.conversationId,
              summaryAsync: summaryAsync,
            ),
            const Divider(height: 32),
            _MemoriesSection(
              conversationId: widget.conversationId,
              memoriesAsync: memoriesAsync,
            ),
            const Divider(height: 32),
            // 导出入口：会话级操作放在这里，用户在当前对话里就能直接导出。
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.download_outlined, color: AppColors.primary),
              title: Text('导出此对话',
                  style: TextStyle(fontSize: 14, color: AppColors.textPrimary)),
              subtitle: const Text('选择 JSON / Markdown / 纯文本 / 网页格式',
                  style: TextStyle(fontSize: 12)),
              onTap: () {
                Navigator.pop(context);
                showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  builder: (_) => ExportSheet(conversationId: widget.conversationId),
                );
              },
            ),
            const SizedBox(height: 24),
            Text(
              AppInfo.author,
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textSecondary, fontSize: 12),
            ),
            const SizedBox(height: 4),
            Text(
              AppInfo.version,
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textSecondary, fontSize: 11),
            ),
          ],
            ),
            ScrollToBottomButton(controller: scrollController),
          ],
        ),
      ),
    );
  }
}

/// 行为设置：系统提示词 + temperature。
class _BehaviorSection extends ConsumerStatefulWidget {
  final String conversationId;
  final ConversationSettings settings;
  const _BehaviorSection({required this.conversationId, required this.settings});

  @override
  ConsumerState<_BehaviorSection> createState() => _BehaviorSectionState();
}

class _BehaviorSectionState extends ConsumerState<_BehaviorSection> {
  late TextEditingController _promptController;
  late double _temperature;
  late int _thinkingEffort;

  /// 本会话的模型 id；空字符串表示"跟随全局默认模型"。
  ///
  /// 为什么用哨兵空串而不是 null：DropdownButtonFormField 的 value 为 null
  /// 时会走 hint 而不是选中项，用户无法区分"跟随全局"和"没加载出来"。
  late String _model;

  /// 上下文上限；null 表示用默认值（64K）。
  int? _contextLimit;

  /// 输出上限；null 表示按思考强度自动取建议值。
  int? _maxOutputTokens;

  /// 会话级字体（FontRecord JSON），null 表示跟随全局。只调 AI / 用户，不含 UI。
  String? _aiFont;
  String? _userFont;

  @override
  void initState() {
    super.initState();
    _promptController = TextEditingController(text: widget.settings.systemPrompt ?? '');
    _temperature = widget.settings.temperature;
    _thinkingEffort = widget.settings.thinkingEffort;
    // 归一化旧模型名：老会话可能存着已失效的 deepseek-pro，
    // 不换算则下拉框 value 指向不存在的 item（显示失效名/断言崩溃）。
    _model = ModelCatalog.canonicalize(widget.settings.model ?? '');
    _contextLimit = widget.settings.contextLimit;
    _maxOutputTokens = widget.settings.maxOutputTokens;
    _aiFont = widget.settings.aiFont;
    _userFont = widget.settings.userFont;
  }

  @override
  void didUpdateWidget(_BehaviorSection old) {
    super.didUpdateWidget(old);
    if (old.settings.systemPrompt != widget.settings.systemPrompt) {
      _promptController.text = widget.settings.systemPrompt ?? '';
    }
    if (old.settings.temperature != widget.settings.temperature) {
      _temperature = widget.settings.temperature;
    }
    if (old.settings.thinkingEffort != widget.settings.thinkingEffort) {
      _thinkingEffort = widget.settings.thinkingEffort;
    }
    if (old.settings.model != widget.settings.model) {
      // 归一化旧模型名：老会话可能存着已失效的 deepseek-pro，
    // 不换算则下拉框 value 指向不存在的 item（显示失效名/断言崩溃）。
    _model = ModelCatalog.canonicalize(widget.settings.model ?? '');
    }
    if (old.settings.contextLimit != widget.settings.contextLimit) {
      _contextLimit = widget.settings.contextLimit;
    }
    if (old.settings.maxOutputTokens != widget.settings.maxOutputTokens) {
      _maxOutputTokens = widget.settings.maxOutputTokens;
    }
  }

  @override
  void dispose() {
    _promptController.dispose();
    super.dispose();
  }

  String _tempLabel(double t) {
    if (t <= 0.3) return '严谨 / 确定性（适合代码、数学、精确指令）';
    if (t <= 0.7) return '平衡（适合日常问答）';
    if (t <= 1.3) return '发散 / 有创造性（适合头脑风暴、写作）';
    return '高随机性（适合创意探索，但可能偏离规范）';
  }

  Future<void> _save() async {
    final store = await ref.read(conversationStoreProvider.future);
    final updated = widget.settings.copyWith(
      systemPrompt: _promptController.text.trim().isEmpty ? null : _promptController.text.trim(),
      temperature: _temperature,
      thinkingEffort: _thinkingEffort,
      clearSystemPrompt: _promptController.text.trim().isEmpty,
      // 空串 = 跟随全局，必须显式清空，否则 copyWith 会把旧值带回来。
      model: _model.isEmpty ? null : _model,
      clearModel: _model.isEmpty,
      contextLimit: _contextLimit,
      clearContextLimit: _contextLimit == null,
      maxOutputTokens: _maxOutputTokens,
      clearMaxOutputTokens: _maxOutputTokens == null,
      aiFont: _aiFont,
      clearAiFont: _aiFont == null,
      userFont: _userFont,
      clearUserFont: _userFont == null,
      updatedAt: DateTime.now().toUtc(),
    );
    await store.saveSettings(updated);
    ref.invalidate(settingsProvider(widget.conversationId));
    if (mounted) {
      showAppToast(context, '设置已保存，从下一轮对话生效');
    }
  }

  @override
  Widget build(BuildContext context) {
    final globalPrompt = ref.watch(globalRolePromptProvider).value ?? '';
    final globalModelId = ref.watch(globalModelProvider).asData?.value ?? kDefaultModelId;
    // 拉取失败时回落到内置表：下拉框不能因为一次网络抖动变空。
    final catalog = ref.watch(modelCatalogProvider).asData?.value ?? ModelCatalog.builtin;
    // 上限档位取决于"本会话最终会用的模型"，而不是全局模型——
    // 否则会话里选了小窗口模型，档位里却还留着 512K，一设就 400。
    final effectiveModel = _model.isEmpty ? globalModelId : _model;
    final tiers = ModelCatalog.tiersFor(effectiveModel);
    final modelWindow = ModelCatalog.windowFor(effectiveModel);
    final usingGlobal = _promptController.text.trim().isEmpty;
    return _Section(
        title: '角色提示词与灵活度',
        icon: Icons.tune,
        children: [
          TextField(
            controller: _promptController,
            maxLines: 4,
            onChanged: (_) => setState(() {}),
            decoration: const InputDecoration(
              labelText: '本会话角色提示词 (System Prompt)',
              hintText: '留空表示使用全局默认角色提示词',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 6),
          // 明确告诉用户"现在到底在用什么"，否则留空时会误以为设置丢了。
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.primarySoft,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              usingGlobal
                  ? (globalPrompt.isEmpty
                      ? '当前生效：未设置角色提示词，模型使用默认人格。可在「全局设置 → 默认角色提示词」统一设置。'
                      : '当前生效：全局默认角色提示词「${globalPrompt.length > 60 ? '${globalPrompt.substring(0, 60)}…' : globalPrompt}」')
                  : '当前生效：本会话专用角色提示词（覆盖全局默认）',
              style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.5),
            ),
          ),
          const SizedBox(height: 6),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton(
              onPressed: () => setState(() => _promptController.clear()),
              child: const Text('恢复默认（改用全局）'),
            ),
          ),
          const Divider(height: 28),
          Row(
            children: [
              const Text('灵活度 (temperature)', style: TextStyle(fontSize: 13)),
              const Spacer(),
              Text(_temperature.toStringAsFixed(1),
                  style: const TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
          Slider(
            value: _temperature,
            min: 0.0,
            max: 2.0,
            divisions: 20,
            onChanged: (v) => setState(() => _temperature = v),
          ),
          Text(_tempLabel(_temperature),
              style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
          const Divider(height: 28),
          Row(
            children: [
              Icon(Icons.psychology_outlined, size: 16, color: AppColors.primary),
              const SizedBox(width: 6),
              const Text('深度思考强度', style: TextStyle(fontSize: 13)),
              const Spacer(),
              Text(_effortLabel,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
            ],
          ),
          Slider(
            value: _thinkingEffort.toDouble(),
            min: 0,
            max: 2,
            divisions: 2,
            label: _effortLabel,
            onChanged: (v) => setState(() => _thinkingEffort = v.round()),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: ConversationSettings.effortLabels
                .map((label) => Text(label.split('（').first,
                    style: TextStyle(fontSize: 10, color: AppColors.textSecondary)))
                .toList(),
          ),
          const SizedBox(height: 6),
          Text(
            '低=更快更省，标准=默认，极限=最难问题（更慢、更耗 token）。'
            '只在打开输入框上方的「深度思考」时生效；思考模式下 temperature 不生效。',
            style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.5),
          ),
          const Divider(height: 28),
          Row(
            children: [
              Icon(Icons.memory, size: 16, color: AppColors.primary),
              const SizedBox(width: 6),
              const Text('模型', style: TextStyle(fontSize: 13)),
              const Spacer(),
              Text(
                _model.isEmpty ? '跟随全局' : '本会话专用',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 6),
          DropdownButtonFormField<String>(
            // value 必须存在于 items，否则 Flutter 断言失败。空串（跟随全局）
            // 永远在 items 里；其余失效 id 归一后若仍找不到则回退到空串。
            value: (_model.isEmpty || catalog.any((m) => m.id == _model)) ? _model : '',
            isExpanded: true,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              isDense: true,
            ),
            items: <DropdownMenuItem<String>>[
              DropdownMenuItem<String>(
                value: '',
                child: Text(
                  '跟随全局（$globalModelId · ${contextLimitLabel(ModelCatalog.windowFor(globalModelId))}）',
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              ...catalog.map((m) => DropdownMenuItem<String>(
                    value: m.id,
                    child: Text('${m.label} · ${m.windowLabel}',
                        overflow: TextOverflow.ellipsis),
                  )),
            ],
            onChanged: (value) => setState(() => _model = value ?? ''),
          ),
          const SizedBox(height: 6),
          Text(
            '不同模型的能力与窗口不同：会话级选择会覆盖全局默认。'
            '成本敏感的场景建议用 Flash，难任务再用 Pro。'
            '注意：更改模型后前几次对话会消耗较多余额（上下文缓存需重建），请留意 token 用量。',
            style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.5),
          ),
          const Divider(height: 28),
          Row(
            children: [
              Icon(Icons.straighten, size: 16, color: AppColors.primary),
              const SizedBox(width: 6),
              const Text('上下文上限', style: TextStyle(fontSize: 13)),
              const SizedBox(width: 4),
              Tooltip(
                message: '这是"这一次最多发给模型多少内容"的硬上限，'
                    '不会修改任何聊天记录。\n'
                    '设得越大，每轮重发的历史越多，输入费用越高；'
                    '超出上限的老消息本次不带，但仍留在记录里。\n'
                    '建议：日常聊天 64K 够用，长文档分析再调高。',
                child: Icon(Icons.info_outline,
                    size: 14, color: AppColors.textSecondary),
              ),
              const Spacer(),
              Text(
                _contextLimit == null ? '自动' : contextLimitLabel(_contextLimit!),
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 6),
          DropdownButtonFormField<String>(
            value: _contextLimit != null && tiers.contains(_contextLimit)
                ? '${_contextLimit!}'
                : '',
            isExpanded: true,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              isDense: true,
            ),
            items: <DropdownMenuItem<String>>[
              const DropdownMenuItem<String>(
                value: '',
                child: Text('自动（默认 64K）', overflow: TextOverflow.ellipsis),
              ),
              ...tiers.map((t) => DropdownMenuItem<String>(
                    value: '$t',
                    child: Text(
                      '${contextLimitLabel(t)} · 每次最多带这么多历史',
                      overflow: TextOverflow.ellipsis,
                    ),
                  )),
            ],
            onChanged: (value) => setState(() {
              _contextLimit = (value == null || value.isEmpty) ? null : int.parse(value);
            }),
          ),
          const SizedBox(height: 6),
          Text(
            '当前模型窗口 ${contextLimitLabel(modelWindow)}；'
            '${_contextLimit != null && !tiers.contains(_contextLimit) ? '原设置 ${contextLimitLabel(_contextLimit!)} 超出该模型，将按窗口上限执行。' : '高于窗口的档位已隐藏，避免请求被服务端拒绝。'}',
            style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.5),
          ),
          const Divider(height: 28),
          Row(
            children: [
              Icon(Icons.output, size: 16, color: AppColors.primary),
              const SizedBox(width: 6),
              const Text('单次回答上限', style: TextStyle(fontSize: 13)),
              const SizedBox(width: 4),
              Tooltip(
                message: '限制这一轮回答能写多长（max_tokens）。\n'
                    '思考模式下思维链与正文共用这个额度，'
                    '所以"极限思考"建议 16K 以上，否则可能思考完了正文被截断。\n'
                    '输出是单价最高的一项，不想写长文时调小更省钱。',
                child: Icon(Icons.info_outline,
                    size: 14, color: AppColors.textSecondary),
              ),
              const Spacer(),
              Text(
                _maxOutputTokens == null
                    ? '自动 ${suggestedMaxOutputTokens(_thinkingEffort)}'
                    : '${_maxOutputTokens!}',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 6),
          DropdownButtonFormField<String>(
            value: _maxOutputTokens == null ? '' : '${_maxOutputTokens!}',
            isExpanded: true,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              isDense: true,
            ),
            items: <DropdownMenuItem<String>>[
              DropdownMenuItem<String>(
                value: '',
                child: Text(
                  '自动（按思考强度：${suggestedMaxOutputTokens(_thinkingEffort)}）',
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              ...const <int>[4096, 8192, 16384, 32768].map((v) => DropdownMenuItem<String>(
                    value: '$v',
                    child: Text('$v token', overflow: TextOverflow.ellipsis),
                  )),
            ],
            onChanged: (value) => setState(() {
              _maxOutputTokens = (value == null || value.isEmpty) ? null : int.parse(value);
            }),
          ),
          const SizedBox(height: 10),
          // 会话级字体：只调 AI / 用户，且只影响本会话（不含 UI 字体）。
          const Text('会话字体（不影响其它会话）',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Text('留空表示跟随全局字体设置',
              style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
          FutureBuilder<List<FontRecord>>(
            future: FontService.listImported(),
            builder: (context, snap) {
              final fonts = snap.data ?? const <FontRecord>[];
              return Column(
                children: [
                  _convFontDropdown('AI 回复字体', _aiFont, fonts, (v) => setState(() => _aiFont = v)),
                  _convFontDropdown('用户消息字体', _userFont, fonts, (v) => setState(() => _userFont = v)),
                ],
              );
            },
          ),
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerRight,
            child: FilledButton.icon(
              icon: const Icon(Icons.save, size: 16),
              label: const Text('保存设置'),
              onPressed: _save,
            ),
          ),
        ],
      );
  }

  /// 会话字体下拉：选项为"跟随全局"+已导入字体；值存 FontRecord JSON。
  Widget _convFontDropdown(
    String label,
    String? currentJson,
    List<FontRecord> fonts,
    ValueChanged<String?> onChanged,
  ) {
    String? currentFamily;
    if (currentJson != null && currentJson.isNotEmpty) {
      try {
        currentFamily = (jsonDecode(currentJson) as Map<String, dynamic>)['family'] as String?;
      } catch (_) {}
    }
    // value 必须在 items 里，否则 Flutter 断言失败。
    final valid = currentFamily == null || fonts.any((f) => f.family == currentFamily);
    return DropdownButtonFormField<String>(
      value: valid ? currentFamily : null,
      isExpanded: true,
      decoration: InputDecoration(labelText: label, isDense: true),
      hint: Text(valid ? '跟随全局' : '跟随全局（原字体已失效）'),
      items: [
        const DropdownMenuItem<String>(value: null, child: Text('跟随全局')),
        ...fonts.map((f) => DropdownMenuItem<String>(
              value: f.family,
              child: Text(f.label, overflow: TextOverflow.ellipsis),
            )),
      ],
      onChanged: (family) {
        if (family == null) {
          onChanged(null);
        } else {
          final f = fonts.firstWhere((x) => x.family == family);
          onChanged(encodeFontRecord(f));
        }
      },
    );
  }

  String get _effortLabel => ConversationSettings.effortLabels[_thinkingEffort.clamp(0, 2)];
}

/// 会话摘要区：展示、生成、编辑。
class _SummarySection extends ConsumerWidget {
  final String conversationId;
  final AsyncValue<SessionSummary?> summaryAsync;
  const _SummarySection({required this.conversationId, required this.summaryAsync});

  Future<void> _generate(WidgetRef ref, BuildContext context) async {
    final ai = await ref.read(aiProviderProvider.future);
    final msgStore = await ref.read(messageStoreProvider.future);
    final messages = await msgStore.readAll(conversationId);
    if (messages.isEmpty) {
      showAppToast(context, '暂无消息可生成摘要');
      return;
    }
    final identity = await ref.read(localIdentityProvider.future);
    showAppToast(context, '摘要生成中…');
    try {
      final transcript = messages.map((m) => '${m.role.name}: ${m.content}').join('\n');
      final response = await ai.sendMessage([
        AiMessage(role: 'user', content: '$kSessionSummaryPrompt\n\n---\n$transcript'),
      ]);
      final summary = SessionSummary.create(
        conversationId: conversationId,
        summaryText: response.finalAnswer.trim(),
        sourceMessageCount: messages.length,
        deviceId: identity.deviceId,
      );
      final store = await ref.read(conversationStoreProvider.future);
      await store.saveSummary(summary);
      ref.invalidate(summaryProvider(conversationId));
      if (context.mounted) {
        showAppToast(context, '摘要已生成');
      }
    } catch (e) {
      if (context.mounted) {
        showAppToast(context, '生成失败: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) => _Section(
        title: '会话摘要',
        icon: Icons.summarize,
        actions: [
          TextButton.icon(
            icon: const Icon(Icons.auto_awesome, size: 16),
            label: const Text('生成摘要'),
            onPressed: () => _generate(ref, context),
          ),
        ],
        children: [
          summaryAsync.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, _) => Text('加载失败: $e'),
            data: (summary) {
              if (summary == null) {
                return Text('暂无摘要，点击"生成摘要"创建。',
                    style: TextStyle(color: AppColors.textSecondary));
              }
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    summary.summaryText,
                    style: const TextStyle(fontSize: 13, height: 1.5),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    summary.userEdited
                        ? '用户已编辑 · 覆盖 ${summary.sourceMessageCount} 条消息'
                        : '生成于 ${summary.generatedAt.toLocal()} · 覆盖 ${summary.sourceMessageCount} 条消息',
                    style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton.icon(
                      icon: const Icon(Icons.edit, size: 16),
                      label: const Text('编辑'),
                      onPressed: () => _editSummary(context, ref, summary),
                    ),
                  ),
                ],
              );
            },
          ),
        ],
      );

  Future<void> _editSummary(BuildContext context, WidgetRef ref, SessionSummary summary) async {
    final controller = TextEditingController(text: summary.summaryText);
    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('编辑摘要'),
        content: TextField(controller: controller, maxLines: 10),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('保存')),
        ],
      ),
    );
    if (saved == true) {
      final identity = await ref.read(localIdentityProvider.future);
      final edited = summary.edit(
        newText: controller.text.trim(),
        editingDeviceId: identity.deviceId,
      );
      final store = await ref.read(conversationStoreProvider.future);
      await store.saveSummary(edited);
      ref.invalidate(summaryProvider(conversationId));
    }
  }
}

/// 重要记忆点区：自动提取开关、跨会话共享开关、列表、手动添加、整理。
/// 记忆点黑名单：填入的关键词，命中的内容既不自动进记忆点，也不提交给大模型。
/// 多个关键词用 ||| 分隔（用户明确约定）。
class _MemoryBlacklistCard extends ConsumerStatefulWidget {
  const _MemoryBlacklistCard();

  @override
  ConsumerState<_MemoryBlacklistCard> createState() => _MemoryBlacklistCardState();
}

class _MemoryBlacklistCardState extends ConsumerState<_MemoryBlacklistCard> {
  late final TextEditingController _controller;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final prefs = await ref.read(sharedPrefsProvider.future);
    await prefs.setString(kMemoryBlacklistKey, _controller.text);
    ref.invalidate(memoryBlacklistRawProvider);
    if (mounted) {
      final count = MemoryBlacklist.parse(_controller.text).length;
      showAppToast(context, count == 0 ? '黑名单已清空' : '已保存 $count 个屏蔽关键词');
    }
  }

  @override
  Widget build(BuildContext context) {
    final rawAsync = ref.watch(memoryBlacklistRawProvider);
    if (!_loaded) {
      rawAsync.whenData((raw) {
        _controller.text = raw;
        _loaded = true;
      });
    }
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF4E5),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFFFD9A8)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.block, size: 15, color: Color(0xFFB26A00)),
              SizedBox(width: 6),
              Text('记忆点黑名单',
                  style: TextStyle(
                      fontSize: 12, fontWeight: FontWeight.w600, color: Color(0xFFB26A00))),
            ],
          ),
          const SizedBox(height: 6),
          TextField(
            controller: _controller,
            maxLines: 2,
            minLines: 1,
            decoration: const InputDecoration(
              hintText: '多个关键词用 ||| 隔开，例：前女友|||赌博|||某人',
              isDense: true,
              border: OutlineInputBorder(),
              contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            ),
            style: const TextStyle(fontSize: 12),
          ),
          const SizedBox(height: 4),
          const Text(
            '命中的内容不会被自动整理进记忆点，也不会在对话里发送大模型（发送时替换为占位，库中原文不动）。',
            style: TextStyle(fontSize: 10, color: Color(0xFF8A5A00), height: 1.5),
          ),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton(
              onPressed: _save,
              style: TextButton.styleFrom(
                minimumSize: const Size(0, 28),
                padding: const EdgeInsets.symmetric(horizontal: 8),
              ),
              child: const Text('保存黑名单', style: TextStyle(fontSize: 11)),
            ),
          ),
        ],
      ),
    );
  }
}

class _MemoriesSection extends ConsumerStatefulWidget {
  final String conversationId;
  final AsyncValue<List<ImportantMemory>> memoriesAsync;
  const _MemoriesSection({required this.conversationId, required this.memoriesAsync});

  @override
  ConsumerState<_MemoriesSection> createState() => _MemoriesSectionState();
}

class _MemoriesSectionState extends ConsumerState<_MemoriesSection> {
  bool _curating = false;

  /// 记忆点多选：长按（手机）/右键（桌面）进入，可批量删除。
  final Set<String> _selectedMemoryIds = <String>{};
  bool get _memoryMultiSelect => _selectedMemoryIds.isNotEmpty;

  void _toggleMemorySelection(String id) => setState(() {
        if (_selectedMemoryIds.contains(id)) {
          _selectedMemoryIds.remove(id);
        } else {
          _selectedMemoryIds.add(id);
        }
      });

  void _clearMemorySelection() => setState(() => _selectedMemoryIds.clear());

  Future<void> _confirmBatchDeleteMemories() async {
    final count = _selectedMemoryIds.length;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('删除 $count 条记忆点？'),
        content: const Text('这些记忆点会被永久删除（会同步到已配对设备），此操作不可撤销。'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('取消')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('删除'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final store = await ref.read(memoryStoreProvider.future);
    for (final id in _selectedMemoryIds) {
      await store.delete(id);
    }
    ref.invalidate(memoriesProvider(widget.conversationId));
    if (mounted) {
      showAppToast(context, '已删除 $count 条记忆点');
      _clearMemorySelection();
    }
  }

  Future<void> _patchSettings({
    bool? autoMemory,
    bool? memorySync,
    String? memoryCode,
    bool clearMemoryCode = false,
  }) async {
    final store = await ref.read(conversationStoreProvider.future);
    final settings = await store.getSettings(widget.conversationId);
    await store.saveSettings(settings.copyWith(
      autoMemory: autoMemory,
      memorySync: memorySync,
      memoryCode: memoryCode,
      clearMemoryCode: clearMemoryCode,
      updatedAt: DateTime.now().toUtc(),
    ));
    ref.invalidate(settingsProvider(widget.conversationId));
  }

  /// 记忆共享编码输入框：只允许 4 位字母数字，留空表示公共池。
  Widget _memoryCodeField(String? current) {
    final controller = TextEditingController(text: current ?? '');
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 4, 4, 8),
      child: Row(
        children: [
          Icon(Icons.key, size: 16, color: AppColors.textSecondary),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              controller: controller,
              decoration: const InputDecoration(
                labelText: '共享编码（4 位字母/数字）',
                hintText: '留空 = 公共池',
                helperText: '只有编码相同的会话才互相共享记忆',
                helperMaxLines: 1,
                isDense: true,
                counterText: '',
              ),
              maxLength: 4,
              textCapitalization: TextCapitalization.characters,
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9]')),
              ],
              onSubmitted: (_) => _commitCode(controller.text),
              onChanged: (v) {
                if (v.length == 4) _commitCode(v);
              },
            ),
          ),
          if ((current ?? '').isNotEmpty)
            IconButton(
              icon: const Icon(Icons.clear, size: 16),
              tooltip: '清空编码',
              onPressed: () => _patchSettings(clearMemoryCode: true),
            ),
        ],
      ),
    );
  }

  Future<void> _commitCode(String raw) async {
    final normalized = raw.trim().toUpperCase();
    if (normalized.isEmpty) {
      await _patchSettings(clearMemoryCode: true);
      return;
    }
    if (normalized.length != 4) return;
    await _patchSettings(memoryCode: normalized);
  }

  Future<void> _curate() async {
    final memories = widget.memoriesAsync.asData?.value ?? const <ImportantMemory>[];
    if (memories.isEmpty) {
      showAppToast(context, '暂无记忆点可整理');
      return;
    }

    final lockedCount = memories.where((m) => m.locked).length;
    final ai = await ref.read(aiProviderProvider.future);
    final store = await ref.read(memoryStoreProvider.future);
    final curator = MemoryCurator(provider: ai, store: store);
    var keepRatio = MemoryCurator.defaultKeepRatio;
    final estimate = curator.estimate(
      memories.where((m) => !m.locked).toList(),
      keepRatio: keepRatio,
    );

    if (!mounted) return;
    // 先报账再执行：整理是唯一会"批量改写记忆"的操作，用户必须知道花多少、改多少。
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) {
          final est = curator.estimate(memories, keepRatio: keepRatio);
          return AlertDialog(
            title: const Text('整理记忆点'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '当前 ${memories.length} 条'
                  '${lockedCount > 0 ? '（其中 $lockedCount 条已锁定，整理时会原样保留）' : ''}。'
                  '整理会删除语义重复的条目、合并同主题碎片，'
                  '并把总长度压到约 ${(keepRatio * 100).round()}%。',
                  style: const TextStyle(fontSize: 13, height: 1.5),
                ),
                const SizedBox(height: 12),
                const Text('压缩目标', style: TextStyle(fontSize: 12)),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 8,
                  children: <double>[0.3, 0.5, 0.7].map((r) {
                    return ChoiceChip(
                      label: Text('${(r * 100).round()}%'),
                      selected: keepRatio == r,
                      onSelected: (_) => setDialogState(() => keepRatio = r),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 12),
                Text(
                  est.display,
                  style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                ),
                const SizedBox(height: 6),
                Text(
                  '整理会向模型提交你的记忆点内容；不会改动聊天记录。',
                  style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: const Text('取消'),
              ),
              FilledButton(
                onPressed: () {
                  // 用最终选择的档位重算一次预估，保证"看到的就是要花的"。
                  Navigator.pop(dialogContext, true);
                },
                child: const Text('开始整理'),
              ),
            ],
          );
        },
      ),
    );
    if (confirmed != true) return;

    setState(() => _curating = true);
    // 整理可能跑几十秒，用不可关闭的遮罩避免用户重复点击造成重复计费。
    if (mounted) {
      showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (_) => const AlertDialog(
          content: Row(
            children: [
              SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
              SizedBox(width: 16),
              Expanded(child: Text('正在整理记忆点…')),
            ],
          ),
        ),
      );
    }

    try {
      final identity = await ref.read(localIdentityProvider.future);
      final outcome = await curator.curate(
        conversationId: widget.conversationId,
        deviceId: identity.deviceId,
        keepRatio: keepRatio,
      );
      ref.invalidate(memoriesProvider(widget.conversationId));
      if (mounted) {
        Navigator.of(context, rootNavigator: true).pop(); // 关掉遮罩
        showAppToast(
          context,
          '整理完成：${outcome.beforeCount} 条 → ${outcome.afterCount} 条，'
          '${outcome.beforeTokens} → ${outcome.afterTokens} token',
          duration: const Duration(seconds: 8),
        );
      }
    } catch (e) {
      if (mounted) {
        Navigator.of(context, rootNavigator: true).pop();
        showAppToast(context, '整理失败：$e');
      }
    } finally {
      if (mounted) setState(() => _curating = false);
    }
    // estimate 变量在上面用于对话框，这里保留以表明"先算账"的顺序。
    assert(estimate.inputTokens >= 0);
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsProvider(widget.conversationId)).asData?.value;
    final autoMemory = settings?.autoMemory ?? true;
    final memorySync = settings?.memorySync ?? false;
    final memoryCode = settings?.memoryCode;

    return _Section(
      title: '重要记忆点',
      icon: Icons.bookmark,
      actions: [
        TextButton.icon(
          icon: const Icon(Icons.add, size: 16),
          label: const Text('添加'),
          onPressed: () => _addMemory(context, ref),
        ),
      ],
      children: [
        const _MemoryBlacklistCard(),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          dense: true,
          title: const Text('自动提取记忆点', style: TextStyle(fontSize: 13)),
          subtitle: const Text('每轮对话后判断是否值得记住；重要偏好与决策会自动保留',
              style: TextStyle(fontSize: 11)),
          value: autoMemory,
          onChanged: (v) => _patchSettings(autoMemory: v),
        ),
        if (!autoMemory)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.primarySoft,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              '已关闭自动提取：之后只有你手动添加的内容会被记住。'
              '长对话里模型可能忘记早先说过的约定、称呼与禁忌，'
              '也可能在压缩后彻底失去早期上下文——建议仅在特别在意 token 成本时关闭。',
              style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.5),
            ),
          ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          dense: true,
          title: const Text('记忆同步（跨会话共享）', style: TextStyle(fontSize: 13)),
          subtitle: const Text('本会话会读取其他开启此开关的会话的记忆点；各会话数据仍各自独立',
              style: TextStyle(fontSize: 11)),
          value: memorySync,
          onChanged: (v) => _patchSettings(memorySync: v),
        ),
        if (memorySync) _memoryCodeField(memoryCode),
        const Divider(height: 20),
        widget.memoriesAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Text('加载失败: $e'),
          data: (memories) {
            if (memories.isEmpty && !_memoryMultiSelect) {
              return Text('暂无记忆点。重要偏好与决策会自动提取，也可手动添加。',
                  style: TextStyle(color: AppColors.textSecondary));
            }
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (_memoryMultiSelect)
                  Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.primarySoft,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.close, size: 18),
                          onPressed: _clearMemorySelection,
                        ),
                        Text('已选 $_selectedMemoryIds.length 条',
                            style: TextStyle(fontSize: 13, color: AppColors.textPrimary)),
                        const Spacer(),
                        IconButton(
                          icon: Icon(Icons.delete_outline, size: 18, color: AppColors.danger),
                          tooltip: '删除所选',
                          onPressed: _confirmBatchDeleteMemories,
                        ),
                      ],
                    ),
                  ),
                if (_memoryMultiSelect)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Text('点按可切换选中',
                        style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                  ),
                ...memories.map((m) => _MemoryTile(
                      memory: m,
                      ref: ref,
                      selected: _selectedMemoryIds.contains(m.id),
                      multiSelect: _memoryMultiSelect,
                      onToggleSelect: () => _toggleMemorySelection(m.id),
                    )),
              ],
            );
          },
        ),
        const SizedBox(height: 8),
        Wrap(
          alignment: WrapAlignment.end,
          spacing: 8,
          runSpacing: 8,
          children: [
            OutlinedButton.icon(
              icon: const Icon(Icons.playlist_add_check, size: 16),
              label: const Text('补跑未提取'),
              onPressed: _curating ? null : () => _batchExtract(full: false),
            ),
            OutlinedButton.icon(
              icon: const Icon(Icons.restart_alt, size: 16),
              label: const Text('全部重刷'),
              onPressed: _curating ? null : () => _batchExtract(full: true),
            ),
            OutlinedButton.icon(
              icon: _curating
                  ? const SizedBox(
                      width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.auto_fix_high, size: 16),
              label: const Text('整理记忆点'),
              onPressed: _curating ? null : _curate,
            ),
            // 红色危险按钮，放在最下方，需二次确认。
            TextButton.icon(
              icon: Icon(Icons.delete_forever, size: 16, color: AppColors.danger),
              label: Text('一键清空记忆点',
                  style: TextStyle(color: AppColors.danger, fontSize: 12)),
              onPressed: _curating ? null : _clearAll,
            ),
          ],
        ),
      ],
    );
  }

  /// 一键清空：必须二次确认（含输入"清空"二字的强确认），清空后不可撤销。
  Future<void> _clearAll() async {
    final memories = widget.memoriesAsync.asData?.value ?? const <ImportantMemory>[];
    if (memories.isEmpty) {
      showAppToast(context, '暂无记忆点可清空');
      return;
    }
    final controller = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('⚠ 清空全部记忆点'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '将永久删除本会话的 ${memories.length} 条记忆点（含已锁定的），此操作不可撤销。\n'
              '聊天记录不会被改动，但 AI 之后可能忘记你的偏好、称呼与约定。',
              style: const TextStyle(fontSize: 13, height: 1.5),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              decoration: const InputDecoration(
                labelText: '请输入「清空」二字确认',
                border: OutlineInputBorder(),
                isDense: true,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            onPressed: () => Navigator.pop(ctx, controller.text.trim() == '清空'),
            child: const Text('确认清空'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (confirmed != true) return;

    // 清空是破坏性操作，动手前先留一份快照（失败不影响清空结果）。
    try {
      final backup = await ref.read(backupServiceProvider.future);
      await backup.backup(reason: 'import');
    } catch (_) {}

    final store = await ref.read(memoryStoreProvider.future);
    final removed = await store.deleteAll(widget.conversationId);
    ref.invalidate(memoriesProvider(widget.conversationId));
    if (mounted) showAppToast(context, '已清空 $removed 条记忆点');
  }

  /// 批量提取记忆点。[full] 为 true 表示忽略游标全量重刷。
  ///
  /// 为什么要有游标：1M token 的对话动辄上千条消息，每次点都全量重跑
  /// 既慢又重复计费。游标让"补跑"只处理新增部分。
  Future<void> _batchExtract({required bool full}) async {
    final ai = await ref.read(aiProviderProvider.future);
    final msgStore = await ref.read(messageStoreProvider.future);
    final memStore = await ref.read(memoryStoreProvider.future);
    final identity = await ref.read(localIdentityProvider.future);
    final prefs = await ref.read(sharedPrefsProvider.future);

    final cursorKey = 'deepshart.memory_cursor.${widget.conversationId}';
    final sinceMs = full ? null : prefs.getInt(cursorKey);

    final extractor = MemoryBatchExtractor(
      provider: ai,
      messageStore: msgStore,
      memoryStore: memStore,
    );
    final pending = await extractor.pendingMessages(
      widget.conversationId,
      sinceMs: sinceMs,
    );
    if (pending.isEmpty) {
      if (mounted) {
        showAppToast(context, full ? '没有可重刷的消息' : '没有未提取的新消息');
      }
      return;
    }

    final estimate = extractor.estimate(pending);
    if (!mounted) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(full ? '全部重刷记忆点' : '补跑未提取的记忆点'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('待处理 ${pending.length} 条消息。'),
            const SizedBox(height: 8),
            Text(estimate.display,
                style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
            const SizedBox(height: 6),
            Text(
              full
                  ? '会重新评估全部消息，已有的重复记忆点会被跳过；'
                      '不删除你手动添加或编辑过的记忆点。'
                  : '只处理上次之后新增的消息，不会重复计费。',
              style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.5),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('开始'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _curating = true);

    var cancelRequested = false;
    var done = 0;
    var total = 0;
    StateSetter? dialogSetState;
    if (mounted) {
      showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (_) => StatefulBuilder(
          builder: (ctx, setDialogStateLocal) {
            dialogSetState = setDialogStateLocal;
            return AlertDialog(
              title: const Text('正在提取记忆点'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  LinearProgressIndicator(
                    value: total == 0 ? null : (done / total).clamp(0.0, 1.0),
                  ),
                  const SizedBox(height: 10),
                  Text('$done / $total 批'),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    cancelRequested = true;
                  },
                  child: const Text('取消'),
                ),
              ],
            );
          },
        ),
      );
    }

    try {
      final outcome = await extractor.run(
        conversationId: widget.conversationId,
        deviceId: identity.deviceId,
        messages: pending,
        blacklist: MemoryBlacklist.parse(
            ref.read(memoryBlacklistRawProvider).value ?? ''),
        onProgress: (d, t) {
          done = d;
          total = t;
          dialogSetState?.call(() {});
        },
        shouldCancel: () => cancelRequested,
      );

      // 游标推进到本批最后一条：取消时也推进，避免下次重复处理已完成的批。
      final lastMs = pending.last.createdAt.millisecondsSinceEpoch;
      await prefs.setInt(cursorKey, lastMs);
      ref.invalidate(memoriesProvider(widget.conversationId));

      if (mounted) {
        Navigator.of(context, rootNavigator: true).pop();
        showAppToast(context, outcome.display, duration: const Duration(seconds: 8));
      }
    } catch (e) {
      if (mounted) {
        Navigator.of(context, rootNavigator: true).pop();
        showAppToast(context, '提取失败：$e');
      }
    } finally {
      if (mounted) setState(() => _curating = false);
    }
  }

  Future<void> _addMemory(BuildContext context, WidgetRef ref) async {
    final summaryController = TextEditingController();
    final tagsController = TextEditingController();
    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('添加记忆点'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: summaryController, decoration: const InputDecoration(labelText: '内容')),
            const SizedBox(height: 8),
            TextField(controller: tagsController, decoration: const InputDecoration(labelText: '标签（逗号分隔）')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('添加')),
        ],
      ),
    );
    if (saved == true && summaryController.text.trim().isNotEmpty) {
      final identity = await ref.read(localIdentityProvider.future);
      final store = await ref.read(memoryStoreProvider.future);
      await store.insertOrMerge(ImportantMemory.create(
        conversationId: widget.conversationId,
        summary: summaryController.text.trim(),
        tags: tagsController.text.split(',').map((s) => s.trim()).where((s) => s.isNotEmpty).toList(),
        importance: 0.9,
        deviceId: identity.deviceId,
      ));
      ref.invalidate(memoriesProvider(widget.conversationId));
    }
  }
}

/// 单个标签：限宽 + 省略号，悬停/长按可看全文。
///
/// 为什么要限宽：标签是模型自动生成的，用户无法预期它有多长；
/// 一个 60 字的标签不设上限会把整行撑爆。
class _TagChip extends StatelessWidget {
  final String tag;
  const _TagChip({required this.tag});

  @override
  Widget build(BuildContext context) => ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 140),
        child: Tooltip(
          message: tag,
          child: Chip(
            label: Text(tag,
                style: const TextStyle(fontSize: 10),
                overflow: TextOverflow.ellipsis,
                maxLines: 1),
            visualDensity: VisualDensity.compact,
            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
            labelPadding: const EdgeInsets.symmetric(horizontal: 6),
          ),
        ),
      );
}

class _MemoryTile extends StatelessWidget {
  final ImportantMemory memory;
  final WidgetRef ref;

  /// 多选状态：由父级 section 管理。null onToggleSelect 表示不支持多选。
  final bool selected;
  final bool multiSelect;
  final VoidCallback? onToggleSelect;

  const _MemoryTile({
    required this.memory,
    required this.ref,
    this.selected = false,
    this.multiSelect = false,
    this.onToggleSelect,
  });

  /// 时间标注：大致时间。今天/昨天显示相对，更早显示日期。
  /// 用户明确要求"标签应标注大致时间，对功能和 AI 阅读都很重要"。
  String get _timeLabel {
    final local = memory.createdAt.toLocal();
    final now = DateTime.now();
    final diff = now.difference(local);
    String two(int v) => v.toString().padLeft(2, '0');
    if (diff.inHours < 1) return '刚刚';
    if (diff.inDays == 0) return '今天 ${two(local.hour)}:${two(local.minute)}';
    if (diff.inDays == 1) return '昨天';
    if (diff.inDays < 7) return '${diff.inDays} 天前';
    return '${local.year}-${two(local.month)}-${two(local.day)}';
  }

  @override
  Widget build(BuildContext context) => GestureDetector(
        onLongPress: onToggleSelect,
        onSecondaryTapDown: onToggleSelect == null ? null : (_) => onToggleSelect!(),
        child: Card(
          margin: const EdgeInsets.symmetric(vertical: 4),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: selected
                ? BorderSide(color: AppColors.primary, width: 2)
                : BorderSide.none,
          ),
          color: selected ? AppColors.primarySoft : null,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (multiSelect)
                    Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: Icon(
                        selected ? Icons.check_box : Icons.check_box_outline_blank,
                        size: 18,
                        color: AppColors.primary,
                      ),
                    ),
                  Expanded(
                    child: Text(memory.summary, style: const TextStyle(fontSize: 13)),
                  ),
                  if (memory.locked)
                    Padding(
                      padding: EdgeInsets.only(left: 6),
                      child: Icon(Icons.lock, size: 14, color: AppColors.primary),
                    ),
                ],
              ),
              const SizedBox(height: 8),
              // 标签必须是 Wrap 而不是 Row：Row 不换行，标签一多总宽就超出屏幕，
              // 后面的图标按钮会被直接挤到可视区外（用户实测截图）。
              Wrap(
                spacing: 6,
                runSpacing: 6,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  Chip(
                    label: Text('重要度 ${memory.importance.toStringAsFixed(1)}',
                        style: const TextStyle(fontSize: 10)),
                    visualDensity: VisualDensity.compact,
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  // 大致时间标签：让 AI 和用户都能判断这条记忆是何时建立的。
                  Chip(
                    avatar: Icon(Icons.schedule, size: 12, color: AppColors.textSecondary),
                    label: Text(_timeLabel, style: const TextStyle(fontSize: 10)),
                    visualDensity: VisualDensity.compact,
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  if (memory.reextractCount > 0)
                    Chip(
                      label: Text('回忆 ×${memory.reextractCount}',
                          style: const TextStyle(fontSize: 10)),
                      visualDensity: VisualDensity.compact,
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                  if (memory.importance < 0.7)
                    Tooltip(
                      message: '时间衰减后有效权重 ${memory.effectiveImportance().toStringAsFixed(2)}',
                      child: Chip(
                        label: Text('有效 ${memory.effectiveImportance().toStringAsFixed(2)}',
                            style: const TextStyle(fontSize: 10)),
                        visualDensity: VisualDensity.compact,
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                    ),
                  for (final tag in memory.tags) _TagChip(tag: tag),
                ],
              ),
              // 操作按钮独占一行、右对齐：无论标签多长都不可能把它挤出屏幕。
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  // 锁定按钮放在编辑按钮左边：锁定的记忆点不参加"一键整理"。
                  IconButton(
                    icon: Icon(
                      memory.locked ? Icons.lock : Icons.lock_open_outlined,
                      size: 16,
                      color: memory.locked ? AppColors.primary : null,
                    ),
                    tooltip: memory.locked ? '解锁（允许整理）' : '锁定（整理时跳过）',
                    visualDensity: VisualDensity.compact,
                    onPressed: () => _toggleLock(),
                  ),
                  IconButton(
                    icon: const Icon(Icons.edit, size: 16),
                    tooltip: '编辑',
                    visualDensity: VisualDensity.compact,
                    onPressed: () => _edit(context),
                  ),
                  IconButton(
                    icon: Icon(Icons.delete, size: 16, color: AppColors.danger),
                    tooltip: '删除',
                    visualDensity: VisualDensity.compact,
                    onPressed: () => _delete(),
                  ),
                ],
              ),
            ],
          ),
        ),
        ),
      );

  Future<void> _toggleLock() async {
    final identity = await ref.read(localIdentityProvider.future);
    final store = await ref.read(memoryStoreProvider.future);
    await store.insertOrMerge(memory.edit(
      editingDeviceId: identity.deviceId,
      newLocked: !memory.locked,
    ));
    ref.invalidate(memoriesProvider(memory.conversationId));
  }

  Future<void> _edit(BuildContext context) async {
    final summaryController = TextEditingController(text: memory.summary);
    final tagsController = TextEditingController(text: memory.tags.join(', '));
    final importance = ValueNotifier<double>(memory.importance);
    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('编辑记忆点'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(controller: summaryController, maxLines: 3),
              const SizedBox(height: 8),
              TextField(controller: tagsController,
                  decoration: const InputDecoration(labelText: '标签（逗号分隔）')),
              const SizedBox(height: 12),
              const Text('记忆点权重', style: TextStyle(fontSize: 12)),
              const SizedBox(height: 4),
              ValueListenableBuilder<double>(
                valueListenable: importance,
                builder: (context, value, _) => Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Slider(
                            value: value,
                            min: 0,
                            max: 1,
                            divisions: 20,
                            label: value.toStringAsFixed(2),
                            onChanged: (v) => importance.value = v,
                          ),
                        ),
                        Text(value.toStringAsFixed(2),
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                      ],
                    ),
                    Text(
                      value >= 0.85
                          ? '核心锚点：整理与衰减都会特别保护'
                          : value >= 0.7
                              ? '重要：仍会被整理，但不易被删'
                              : '次要：随时间衰减，优先被整理掉',
                      style: TextStyle(fontSize: 10, color: AppColors.textSecondary),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('保存')),
        ],
      ),
    );
    final chosenImportance = importance.value;
    importance.dispose();
    if (saved == true) {
      final identity = await ref.read(localIdentityProvider.future);
      final store = await ref.read(memoryStoreProvider.future);
      await store.insertOrMerge(memory.edit(
        editingDeviceId: identity.deviceId,
        newSummary: summaryController.text.trim(),
        newTags: tagsController.text.split(',').map((s) => s.trim()).where((s) => s.isNotEmpty).toList(),
        newImportance: chosenImportance,
      ));
      ref.invalidate(memoriesProvider(memory.conversationId));
    }
  }

  Future<void> _delete() async {
    final identity = await ref.read(localIdentityProvider.future);
    final store = await ref.read(memoryStoreProvider.future);
    await store.insertOrMerge(memory.edit(editingDeviceId: identity.deviceId, newDeleted: true));
    ref.invalidate(memoriesProvider(memory.conversationId));
  }
}

/// 设置分区。用户要求"不同功能设置每次打开默认折叠"——所以默认 _expanded=false，
/// 点标题行展开/收起。每次打开设置面板都是新实例，天然满足"每次默认折叠"。
class _Section extends StatefulWidget {
  final String title;
  final IconData icon;
  final List<Widget> children;
  final List<Widget>? actions;

  const _Section({
    required this.title,
    required this.icon,
    required this.children,
    this.actions,
  });

  @override
  State<_Section> createState() => _SectionState();
}

class _SectionState extends State<_Section> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            onTap: () => setState(() => _expanded = !_expanded),
            borderRadius: BorderRadius.circular(6),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(
                children: [
                  Icon(widget.icon, size: 18, color: AppColors.primary),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(widget.title,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  ),
                  // actions 放在标题行、折叠时也可点；点击不触发展开（InkWell 只包住行，
                  // 但这里 actions 是行的子 widget，需靠 GestureDetector 拦截）。
                  ...?widget.actions,
                  Icon(_expanded ? Icons.expand_less : Icons.expand_more,
                      size: 18, color: AppColors.textSecondary),
                ],
              ),
            ),
          ),
          if (_expanded) ...[
            const SizedBox(height: 12),
            ...widget.children,
          ],
        ],
      );
}
