// target: lib/ui/stale_file_dialog.dart
// 职责：疑似废弃同步文件的全局提醒宿主。放在 App 顶层 Stack 里直接渲染，
// 软提示普通样式，硬提示（二次）红色警示。用户选择回填 staleFileGate。

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/theme.dart';
import '../sync/stale_file_gate.dart';
import '../sync/stale_sync_tracker.dart';
import 'agreement_gate.dart';

class StaleFileDialogHost extends ConsumerStatefulWidget {
  const StaleFileDialogHost({super.key});

  @override
  ConsumerState<StaleFileDialogHost> createState() => _StaleFileDialogHostState();
}

class _StaleFileDialogHostState extends ConsumerState<StaleFileDialogHost> {
  bool _registered = false;
  late final StaleFileGate _gate;

  @override
  void initState() {
    super.initState();
    _gate = ref.read(staleFileGateProvider.notifier);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || _registered) return;
      _registered = true;
      _gate.registerUI();
    });
  }

  @override
  void dispose() {
    if (_registered) _gate.unregisterUI();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final req = ref.watch(staleFileGateProvider);
    final agreed = ref.watch(agreementAcceptedProvider).valueOrNull ?? false;
    if (req == null || !agreed) return const SizedBox.shrink();

    final hard = req.level == StaleLevel.hard;
    return Positioned.fill(
      child: Material(
        color: Colors.black54,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Card(
              color: AppColors.surface,
              elevation: 8,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          hard ? Icons.error : Icons.help_outline,
                          color: hard ? AppColors.danger : AppColors.primary,
                          size: 22,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            hard ? '极大概率已废弃' : '疑似已废弃的同步文件',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: hard ? AppColors.danger : AppColors.textPrimary,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      hard
                          ? '检测到极大概率已废弃的同步文件，是否忽略并删除？不删除可能导致同步功能紊乱！'
                          : '检测到疑似已废弃的同步文件，是否忽略并删除？',
                      style: TextStyle(
                        fontSize: 13,
                        height: 1.5,
                        color: hard ? AppColors.danger : AppColors.textPrimary,
                        fontWeight: hard ? FontWeight.w600 : FontWeight.normal,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text('来源设备：${req.deviceTag}',
                        style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                    const SizedBox(height: 18),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton(
                          onPressed: () => _gate.answer(StaleChoice.keep),
                          child: const Text('保留'),
                        ),
                        const SizedBox(width: 8),
                        FilledButton(
                          style: FilledButton.styleFrom(
                            backgroundColor: hard ? AppColors.danger : null,
                          ),
                          onPressed: () => _gate.answer(StaleChoice.delete),
                          child: const Text('忽略并删除'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
