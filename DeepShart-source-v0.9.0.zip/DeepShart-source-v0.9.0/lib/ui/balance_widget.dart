// target: lib/ui/balance_widget.dart
// 职责：在会话列表底部（全局设置下方）显示 DeepSeek 账户余额，支持点击刷新。

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/theme.dart';
import '../state/app_providers.dart';

/// DeepSeek 官方充值页。
const String kTopUpUrl = 'https://platform.deepseek.com/top_up';

Future<void> _openTopUp() async {
  final uri = Uri.tryParse(kTopUpUrl);
  if (uri == null) return;
  try {
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  } catch (_) {}
}

/// 侧栏窄条版本（Windows 的 NavigationRail 底部）。
class RailBalance extends ConsumerWidget {
  const RailBalance({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(balanceProvider);
    final (label, color) = switch (async) {
      AsyncData(:final value) when value == null => ('未配置', AppColors.textSecondary),
      AsyncData(:final value) => (value!.display, value.available ? AppColors.textPrimary : AppColors.danger),
      AsyncError() => ('重试', AppColors.danger),
      _ => ('…', AppColors.textSecondary),
    };

    return Tooltip(
      message: 'DeepSeek 账户余额（点击刷新）',
      child: InkWell(
        onTap: () => ref.invalidate(balanceProvider),
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('余额',
                  style: TextStyle(fontSize: 10, color: AppColors.textSecondary)),
              const SizedBox(height: 2),
              Text(
                label,
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: color),
              ),
              const SizedBox(height: 2),
              // 充值入口：余额标志下方的小按钮。
              InkWell(
                onTap: _openTopUp,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.add_card, size: 12, color: AppColors.primary),
                      const SizedBox(width: 2),
                      Text('充值',
                          style: TextStyle(fontSize: 10, color: AppColors.primary)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// 列表条目版本（Android 抽屉、全局设置下方）。
class BalanceTile extends ConsumerWidget {
  const BalanceTile({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(balanceProvider);

    final Widget trailing;
    final String title;
    String? subtitle;
    switch (async) {
      case AsyncData(:final value) when value == null:
        title = '余额';
        subtitle = '配置 API Key 后可查询';
        trailing = const SizedBox.shrink();
      case AsyncData(:final value):
        title = value!.display;
        subtitle = value.available ? 'DeepSeek 账户余额' : '余额不足或账户不可用';
        trailing = IconButton(
          icon: const Icon(Icons.refresh, size: 18),
          tooltip: '刷新余额',
          onPressed: () => ref.invalidate(balanceProvider),
        );
      case AsyncError(:final error):
        title = '余额获取失败';
        subtitle = '$error';
        trailing = IconButton(
          icon: const Icon(Icons.refresh, size: 18),
          onPressed: () => ref.invalidate(balanceProvider),
        );
      default:
        title = '余额加载中…';
        trailing = const SizedBox(
          width: 16,
          height: 16,
          child: CircularProgressIndicator(strokeWidth: 2),
        );
    }

    return ListTile(
      leading: Icon(Icons.account_balance_wallet_outlined,
          color: AppColors.textSecondary),
      title: Text(title, style: TextStyle(color: AppColors.textPrimary, fontSize: 14)),
      subtitle: subtitle == null
          ? null
          : Text(
              subtitle,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
            ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // 充值入口（余额标志下新增的小窗口按钮）。
          IconButton(
            icon: Icon(Icons.add_card, size: 18, color: AppColors.primary),
            tooltip: '前往 DeepSeek 充值',
            onPressed: _openTopUp,
          ),
          trailing,
        ],
      ),
    );
  }
}
