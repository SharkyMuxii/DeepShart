// target: lib/ui/sync_policy_dialog.dart
// 职责：同步【出错定夺】弹窗的全局宿主。挂在 App 顶层，监听 syncPolicyGateProvider；
// 仅在静默同步失败时弹出，标注出错的同步方式（P2P/COS）和错误详情，让用户四选一。
//
// 用 Stack 直接渲染，不用 showDialog / OverlayEntry：
// MaterialApp.router 的 builder 位于 Router 之上、Overlay 之下，这里 context
// 没有 Overlay，弹 OverlayEntry 会静默失败（曾导致"同步无限转"）。

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/theme.dart';
import '../sync/sync_policy.dart';
import 'agreement_gate.dart';

/// 常驻 App 顶层的出错定夺弹窗宿主。放在 Stack 里直接渲染，不依赖 Overlay。
class SyncPolicyDialogHost extends ConsumerStatefulWidget {
  const SyncPolicyDialogHost({super.key});

  @override
  ConsumerState<SyncPolicyDialogHost> createState() => _SyncPolicyDialogHostState();
}

class _SyncPolicyDialogHostState extends ConsumerState<SyncPolicyDialogHost> {
  bool _registered = false;
  // 在 initState 里缓存 notifier：dispose 时 ref 已失效，不能再 ref.read。
  late final SyncPolicyGate _gate;

  @override
  void initState() {
    super.initState();
    _gate = ref.read(syncPolicyGateProvider.notifier);
    // 宿主常驻，挂载后即可注册 UI，让出错定夺请求能被推到 state。
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || _registered) return;
      _registered = true;
      _gate.registerUI();
    });
  }

  @override
  void dispose() {
    if (_registered) {
      _gate.unregisterUI();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final req = ref.watch(syncPolicyGateProvider);
    final agreed = ref.watch(agreementAcceptedProvider).valueOrNull ?? false;
    // 协议未同意时不弹定夺窗，避免两个遮罩打架；无请求时也不渲染。
    if (req == null || !agreed) return const SizedBox.shrink();

    return Positioned.fill(
      child: Material(
        color: Colors.black54,
        child: Center(
          child: _PolicyDialog(
            request: req,
            onChoose: (policy) => _gate.answer(policy),
          ),
        ),
      ),
    );
  }
}

class _PolicyDialog extends StatelessWidget {
  final SyncPolicyRequest request;
  final ValueChanged<SyncPolicy> onChoose;
  const _PolicyDialog({required this.request, required this.onChoose});

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 460, maxHeight: 620),
      child: Card(
        color: AppColors.surface,
        elevation: 8,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
              child: Row(
                children: [
                  Icon(Icons.warning_amber_rounded, color: AppColors.danger, size: 22),
                  const SizedBox(width: 8),
                  const Expanded(
                    child: Text('同步未完成，请选择处理方式',
                        style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ),
            Flexible(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 14, 20, 4),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // 标注出错的同步方式。
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppColors.danger.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: AppColors.danger.withValues(alpha: 0.35)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('出错的同步方式：${request.method.label}',
                              style: TextStyle(
                                  fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.danger)),
                          const SizedBox(height: 4),
                          Text('来源：${request.source}',
                              style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                          const SizedBox(height: 6),
                          Text('错误详情：${request.errorDetail}',
                              style: TextStyle(fontSize: 12, height: 1.4, color: AppColors.textPrimary)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text('这次要怎么处理？',
                        style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                    const SizedBox(height: 8),
                    for (final policy in SyncPolicy.values)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: _PolicyOption(policy: policy, onTap: () => onChoose(policy)),
                      ),
                    const SizedBox(height: 2),
                    Text(
                      '提示：覆盖会删除另一端的部分对话，操作不可撤销。不确定的话选「智能合并」或「不同步」。',
                      style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 4),
          ],
        ),
      ),
    );
  }
}

class _PolicyOption extends StatelessWidget {
  final SyncPolicy policy;
  final VoidCallback onTap;
  const _PolicyOption({required this.policy, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final accent = policy.isOverwrite
        ? AppColors.danger
        : (policy == SyncPolicy.none ? AppColors.textSecondary : AppColors.primary);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          border: Border.all(color: accent.withValues(alpha: 0.5)),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(policy.icon, color: accent, size: 22),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Flexible(
                      child: Text(policy.label,
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                    ),
                    if (policy.isOverwrite)
                      Padding(
                        padding: const EdgeInsets.only(left: 6),
                        child: Text('会丢数据',
                            style: TextStyle(fontSize: 10, color: AppColors.danger, fontWeight: FontWeight.bold)),
                      ),
                  ]),
                  const SizedBox(height: 3),
                  Text(policy.detail,
                      style: TextStyle(fontSize: 11, height: 1.4, color: AppColors.textSecondary)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
