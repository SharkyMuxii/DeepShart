// target: lib/ui/agreement_gate.dart
// 职责：启动时的用户协议门控。首次打开必须阅读并点「我已阅读并同意」才能使用；
// 同意状态存本机。协议里显著标注免责声明（个人开发、可能有 bug、损失自担）。
// 未同意前，同步策略闸门不注册 UI——避免协议框与同步框打架。
//
// 弹窗实现用 OverlayEntry 直接插入 App 顶层 Overlay，而不是 showDialog：
// showDialog 在 MaterialApp.router 的 builder 层拿不到正确的 Navigator，
// 会残留一层点不掉的灰色 barrier（用户实测「整个界面蒙了一层雾」）。

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/theme.dart';
import '../state/app_providers.dart';

/// 用户不同意免责声明时退出软件。
/// 安全要点：这个函数【只在用户明确点击"不同意"时调用一次】，
/// 不在 build/initState/任何监听器里自动触发，绝不会因重建或状态变化误调用导致闪退。
/// 用 SystemNavigator.pop() 走平台正常的退出流程，而不是 exit(0) 强杀。
void _exitAppOnDisagree() {
  try {
    SystemNavigator.pop();
  } catch (_) {
    // 极端平台异常时静默——宁可停在当前页，也不强杀进程造成闪退观感。
  }
}

const _kAgreementKey = 'deepshart.agreement_accepted_v1';

/// 是否已接受用户协议（null=仍在读取）。
final agreementAcceptedProvider = FutureProvider<bool>((ref) async {
  final prefs = await ref.watch(sharedPrefsProvider.future);
  return prefs.getBool(_kAgreementKey) ?? false;
});

Future<void> saveAgreementAccepted(WidgetRef ref) async {
  final prefs = await ref.read(sharedPrefsProvider.future);
  await prefs.setBool(_kAgreementKey, true);
  ref.invalidate(agreementAcceptedProvider);
}

/// 常驻 App 顶层的门控宿主。未同意则直接渲染不可跳过的协议遮罩。
///
/// 关键修复：这里【不能】用 Overlay.maybeOf(context) + OverlayEntry ——
/// 本宿主挂在 MaterialApp.router 的 builder 返回的 Stack 里，而 builder 位于
/// Router 之上、Overlay 之下，context 里根本没有 Overlay，弹窗永远不会出现。
/// 既然 Stack 本身已是全屏叠层，直接作为它的 child 渲染即可。
class AgreementGate extends ConsumerWidget {
  const AgreementGate({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final accepted = ref.watch(agreementAcceptedProvider).valueOrNull ?? false;
    if (accepted) return const SizedBox.shrink();
    return Positioned.fill(
      child: PopScope<bool>(
        canPop: false,
        child: Material(
          color: AppColors.danger.withValues(alpha: 0.10),
          child: Center(
            // 同意后必须落盘并 invalidate，否则下次启动又变回未同意。
            child: _AgreementDialog(onAgree: () {
              saveAgreementAccepted(ref);
            }),
          ),
        ),
      ),
    );
  }
}

class _AgreementDialog extends StatefulWidget {
  final VoidCallback onAgree;
  const _AgreementDialog({required this.onAgree});

  @override
  State<_AgreementDialog> createState() => _AgreementDialogState();
}

class _AgreementDialogState extends State<_AgreementDialog> {
  bool _checked = false;

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 480, maxHeight: 560),
      child: Card(
        color: AppColors.surface,
        elevation: 8,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
              child: Row(
                children: [
                  Icon(Icons.gavel, color: AppColors.primary, size: 22),
                  const SizedBox(width: 8),
                  const Expanded(
                    child: Text('用户协议与免责声明',
                        style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ),
            Flexible(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 14, 20, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _h('一、关于本软件'),
                    _p('DeepShart 是一款个人开发、开源的人工智能对话与数据同步工具，'
                        '提供对话记录、云端/设备间同步、文件与记忆点管理等功能。'),
                    _h('二、免责声明（请重点阅读）'),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.danger.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: AppColors.danger.withValues(alpha: 0.4)),
                      ),
                      child: Text(
                        '本软件处于开源测试阶段，继续使用即视作已了解并愿意承担使用风险；'
                        '因该软件造成的损失，作者概不负责。',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          height: 1.5,
                          color: AppColors.danger,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    _p('同步与覆盖操作会修改或删除数据，操作前请自行做好备份。'
                        '使用本软件即表示你理解并接受上述风险。'),
                    _h('三、隐私与密钥'),
                    _p('腾讯云 COS 的密钥（SecretId / SecretKey）由你自行填写，'
                        '仅保存在本机，不会写入安装包，也不会上传到任何第三方。'
                        '请注意保管，不要分享给他人。'),
                    _h('四、使用许可'),
                    _p('本软件仅供个人学习与使用。请遵守相关法律法规，'
                        '不要用于违法违规用途。'),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 18),
              child: Column(
                children: [
                  // 必须勾选才能继续。
                  Row(
                    children: [
                      SizedBox(
                        width: 22,
                        height: 22,
                        child: Checkbox(
                          value: _checked,
                          onChanged: (v) => setState(() => _checked = v ?? false),
                          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                      ),
                      const SizedBox(width: 6),
                      const Expanded(
                        child: Text('我已完整阅读并同意上述免责声明',
                            style: TextStyle(fontSize: 12)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    height: 44,
                    child: FilledButton(
                      onPressed: _checked ? widget.onAgree : null,
                      child: const Text('我已阅读并同意，继续使用'),
                    ),
                  ),
                  const SizedBox(height: 6),
                  SizedBox(
                    width: double.infinity,
                    child: TextButton(
                      onPressed: _exitAppOnDisagree,
                      child: Text('不同意，退出软件',
                          style: TextStyle(color: AppColors.textSecondary)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  static Widget _h(String text) => Padding(
        padding: const EdgeInsets.only(top: 10, bottom: 4),
        child: Text(text,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
      );

  static Widget _p(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(text,
            style: TextStyle(fontSize: 12, height: 1.5, color: AppColors.textSecondary)),
      );
}
