// target: lib/ui/app_toast.dart
// 职责：统一的轻提示。所有平台都在【屏幕上方】弹出浮层，可点 × 关闭、
//       也可【左右划走】关闭（用户要求："消息弹窗统一挪到上方，可以滑走"）。

import 'dart:async';

import 'package:flutter/material.dart';

import '../core/theme.dart';

OverlayEntry? _currentEntry;
Timer? _dismissTimer;

/// 显示一条提示。
///
/// 统一行为：顶部浮层、5 秒自动消失、点 × 关闭、左右滑动划走关闭。
/// 之前移动端用底部 SnackBar（贴底压输入框、不能划走），现按用户要求统一到顶部。
void showAppToast(
  BuildContext context,
  String message, {
  Duration duration = const Duration(seconds: 5),
  bool error = false,
}) {
  final overlay = Overlay.maybeOf(context);
  if (overlay == null) {
    // 极端情况没有 Overlay（如某些对话框上下文）：退回 SnackBar，但仍尽量放顶部。
    ScaffoldMessenger.maybeOf(context)?.showSnackBar(
      SnackBar(content: Text(message), duration: duration),
    );
    return;
  }

  _dismiss();

  final entry = OverlayEntry(
    builder: (ctx) => Positioned(
      // 顶部安全区之上留白，避开状态栏/刘海。
      top: 16 + MediaQuery.of(ctx).padding.top,
      left: 0,
      right: 0,
      child: Center(
        child: _ToastCard(
          message: message,
          error: error,
          onClose: _dismiss,
        ),
      ),
    ),
  );
  _currentEntry = entry;
  overlay.insert(entry);

  _dismissTimer = Timer(duration, _dismiss);
}

void _dismiss() {
  _dismissTimer?.cancel();
  _dismissTimer = null;
  _currentEntry?.remove();
  _currentEntry = null;
}

class _ToastCard extends StatelessWidget {
  final String message;
  final bool error;
  final VoidCallback onClose;

  const _ToastCard({
    required this.message,
    required this.error,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    final accent = error ? AppColors.danger : AppColors.primary;
    return Material(
      color: Colors.transparent,
      child: Dismissible(
        key: ValueKey(message),
        direction: DismissDirection.horizontal,
        onDismissed: (_) => onClose(),
        child: Container(
          constraints: const BoxConstraints(maxWidth: 560),
          margin: const EdgeInsets.symmetric(horizontal: 24),
          padding: const EdgeInsets.fromLTRB(14, 10, 6, 10),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: accent.withValues(alpha: 0.35)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.12),
                blurRadius: 16,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                error ? Icons.error_outline : Icons.info_outline,
                size: 16,
                color: accent,
              ),
              const SizedBox(width: 8),
              Flexible(
                child: Text(
                  message,
                  style: const TextStyle(fontSize: 13, height: 1.45),
                ),
              ),
              const SizedBox(width: 4),
              InkWell(
                onTap: onClose,
                borderRadius: BorderRadius.circular(12),
                child: Padding(
                  padding: EdgeInsets.all(4),
                  child: Icon(Icons.close, size: 15, color: AppColors.textSecondary),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
