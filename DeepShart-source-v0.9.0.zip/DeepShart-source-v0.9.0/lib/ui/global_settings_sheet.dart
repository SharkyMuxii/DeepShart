// target: lib/ui/global_settings_sheet.dart
// 职责：全局设置面板——API Key、设备名称、关于信息。与单会话设置分离，任何会话共享同一份配置。

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../ai/deepseek_provider.dart';
import '../ai/model_catalog.dart';
import '../core/app_info.dart';
import '../core/theme.dart';
import 'app_toast.dart';
import 'announcement_sheet.dart';
import 'api_tutorial_screen.dart';
import 'backup_sheet.dart';
import 'file_manager_sheet.dart';
import 'font_picker_row.dart';
import 'scroll_to_bottom_button.dart';
import '../core/font_service.dart';
import '../core/palette.dart';
import '../state/app_providers.dart';
import '../state/chat_controller.dart';
import '../state/cos_sync_provider.dart';
import '../sync/sync_policy.dart';
import 'cos_sync_panel.dart';

class GlobalSettingsSheet extends ConsumerStatefulWidget {
  const GlobalSettingsSheet({super.key});

  /// 供 Windows 侧边栏内嵌复用（无滚动控制器、无 AppBar 的纯内容）。
  static Widget content() => ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          _AnnouncementSection(),
          Divider(height: 32),
          _ApiKeySection(),
          Divider(height: 32),
          _ModelSection(),
          Divider(height: 32),
          _AppearanceSection(),
          Divider(height: 32),
          _RolePromptSection(),
          Divider(height: 32),
          _DeviceSection(),
          Divider(height: 32),
          _SyncModeSection(),
          Divider(height: 32),
          _SyncBehaviorSection(),
          Divider(height: 32),
          _BackupSection(),
          Divider(height: 32),
          _FileManagerSection(),
          Divider(height: 32),
          _AboutSection(),
        ],
      );

  @override
  ConsumerState<GlobalSettingsSheet> createState() => _GlobalSettingsSheetState();
}

class _GlobalSettingsSheetState extends ConsumerState<GlobalSettingsSheet> {
  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.75,
      maxChildSize: 0.9,
      builder: (context, scrollController) => Scaffold(
        backgroundColor: AppColors.surface,
        appBar: AppBar(
          title: const Text('全局设置'),
          centerTitle: true,
          automaticallyImplyLeading: false,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        body: Stack(
          children: [
            ListView(
              controller: scrollController,
              padding: const EdgeInsets.all(16),
              children: [
                const _AnnouncementSection(),
                const Divider(height: 32),
                const _ApiKeySection(),
                const Divider(height: 32),
                const _ModelSection(),
                const Divider(height: 32),
                const _AppearanceSection(),
                const Divider(height: 32),
                const _RolePromptSection(),
                const Divider(height: 32),
                const _DeviceSection(),
                const Divider(height: 32),
                const _SyncModeSection(),
                const Divider(height: 32),
                const _SyncBehaviorSection(),
                const Divider(height: 32),
                const _BackupSection(),
                const Divider(height: 32),
                const _FileManagerSection(),
                const Divider(height: 32),
                const _AboutSection(),
              ],
            ),
            ScrollToBottomButton(controller: scrollController),
          ],
        ),
      ),
    );
  }
}

class _ApiKeySection extends ConsumerStatefulWidget {
  const _ApiKeySection();

  @override
  ConsumerState<_ApiKeySection> createState() => _ApiKeySectionState();
}

class _ApiKeySectionState extends ConsumerState<_ApiKeySection> {
  late final TextEditingController _controller;
  bool _obscure = true;
  bool _loaded = false;
  bool _testing = false;

  Future<void> _testConnection() async {
    final key = _controller.text.trim();
    if (key.isEmpty) {
      showAppToast(context, '请先填写 API Key');
      return;
    }
    setState(() => _testing = true);
    try {
      final provider = DeepSeekProvider(apiKey: key);
      final error = await provider.testConnection();
      if (!mounted) return;
      showAppToast(context, error ?? '✓ 连接正常，API Key 有效', duration: Duration(seconds: 6));
    } catch (e) {
      if (mounted) {
        showAppToast(context, '测试失败：$e');
      }
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final prefsAsync = ref.watch(sharedPrefsProvider);
    if (!_loaded) {
      prefsAsync.whenData((prefs) {
        _controller.text = prefs.getString('deepshart.deepseek_api_key') ?? '';
        _loaded = true;
      });
    }

    return _Section(
      title: 'AI 服务',
      icon: Icons.smart_toy,
      children: [
        // 教程入口放在最上面：没有 Key 的人第一步就是"去哪儿弄"，
        // 藏在帮助链接里等于没有。用整块可点卡片，明确写"没有 Key 点这里"。
        _TutorialEntry(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute<void>(builder: (_) => const ApiTutorialScreen()),
          ),
        ),
        const SizedBox(height: 14),
        const Text('DeepSeek API Key',
            style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        TextField(
          controller: _controller,
          obscureText: _obscure,
          decoration: InputDecoration(
            labelText: 'API Key',
            hintText: 'sk-...',
            border: const OutlineInputBorder(),
            isDense: true,
            suffixIcon: IconButton(
              icon: Icon(_obscure ? Icons.visibility : Icons.visibility_off),
              onPressed: () => setState(() => _obscure = !_obscure),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                icon: _testing
                    ? const SizedBox(width: 14, height: 14,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.wifi_tethering, size: 16),
                label: const Text('测试'),
                onPressed: _testing ? null : _testConnection,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: FilledButton.icon(
                icon: const Icon(Icons.save, size: 16),
                label: const Text('保存'),
                onPressed: () async {
                  await saveApiKey(ref, _controller.text);
                  ref.invalidate(aiProviderProvider);
                  if (mounted) {
                    showAppToast(context, 'API Key 已保存，所有会话生效');
                  }
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          '密钥仅保存在本机，用于调用 DeepSeek API。可前往 platform.deepseek.com 获取。'
          '保存后即可发送消息、使用深度思考与联网搜索。',
          style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
        ),
      ],
    );
  }
}

/// 全局默认角色提示词。
///
/// 单个会话在"会话设置"里填写了提示词时，以会话级为准；
/// 这里填的内容作为所有会话的兜底人格，避免"换个会话角色就丢了"。
class _RolePromptSection extends ConsumerStatefulWidget {
  const _RolePromptSection();

  @override
  ConsumerState<_RolePromptSection> createState() => _RolePromptSectionState();
}

class _RolePromptSectionState extends ConsumerState<_RolePromptSection> {
  late final TextEditingController _controller;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final promptAsync = ref.watch(globalRolePromptProvider);
    if (!_loaded) {
      promptAsync.whenData((value) {
        _controller.text = value;
        _loaded = true;
      });
    }

    return _Section(
      title: '默认角色提示词',
      icon: Icons.theater_comedy_outlined,
      children: [
        TextField(
          controller: _controller,
          maxLines: 4,
          decoration: const InputDecoration(
            labelText: '全局 System Prompt',
            hintText: '例如：你是我的鲸鱼伙伴，说话简短温柔，记得我们聊过的事',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          '所有没有单独设置角色提示词的会话都会使用这段设定。'
          '在某个会话的"会话设置"里填写提示词，可以只覆盖那一个会话。',
          style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.5),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            TextButton(
              onPressed: () => setState(_controller.clear),
              child: const Text('清空'),
            ),
            const Spacer(),
            FilledButton.icon(
              icon: const Icon(Icons.save, size: 16),
              label: const Text('保存'),
              onPressed: () async {
                final prefs = await ref.read(sharedPrefsProvider.future);
                await prefs.setString(kGlobalRolePromptKey, _controller.text.trim());
                ref.invalidate(globalRolePromptProvider);
                if (mounted) {
                  showAppToast(context, '默认角色提示词已保存，未单独设置的会话立即生效');
                }
              },
            ),
          ],
        ),
      ],
    );
  }
}

class _DeviceSection extends ConsumerStatefulWidget {
  const _DeviceSection();

  @override
  ConsumerState<_DeviceSection> createState() => _DeviceSectionState();
}

class _DeviceSectionState extends ConsumerState<_DeviceSection> {
  late final TextEditingController _controller;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final identityAsync = ref.watch(localIdentityProvider);
    if (!_loaded) {
      identityAsync.whenData((identity) {
        _controller.text = identity.deviceName;
        _loaded = true;
      });
    }

    return _Section(
      title: '设备',
      icon: Icons.devices,
      children: [
        TextField(
          controller: _controller,
          decoration: const InputDecoration(
            labelText: '设备名称（配对时对方可见）',
            border: OutlineInputBorder(),
            isDense: true,
          ),
        ),
        const SizedBox(height: 8),
        Align(
          alignment: Alignment.centerRight,
          child: FilledButton.icon(
            icon: const Icon(Icons.save, size: 16),
            label: const Text('保存'),
            onPressed: () async {
              if (_controller.text.trim().isEmpty) return;
              final prefs = await ref.read(sharedPrefsProvider.future);
              await prefs.setString('deepshart.device_name', _controller.text.trim());
              ref.invalidate(localIdentityProvider);
              if (mounted) {
                showAppToast(context, '设备名称已保存');
              }
            },
          ),
        ),
      ],
    );
  }
}

/// 教程入口卡片：醒目、整块可点。
class _TutorialEntry extends StatelessWidget {
  final VoidCallback onTap;
  const _TutorialEntry({required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
        color: AppColors.primarySoft,
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(10),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            child: Row(
              children: [
                Icon(Icons.menu_book, color: AppColors.primary, size: 22),
                SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('还没有 API Key？点这里看注册教程',
                          style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: AppColors.primary)),
                      SizedBox(height: 3),
                      Text('四步注册、实名、创建 Key、充值，附截图',
                          style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                    ],
                  ),
                ),
                Icon(Icons.chevron_right, color: AppColors.primary, size: 20),
              ],
            ),
          ),
        ),
      );
}

/// 外观：主题模式、强调色、AI/用户/UI 三类字体。
class _AppearanceSection extends ConsumerWidget {
  const _AppearanceSection();

  Future<void> _setThemeMode(WidgetRef ref, String value) async {
    final prefs = await ref.read(sharedPrefsProvider.future);
    await prefs.setString(kThemeModeKey, value);
    ref.invalidate(themeModeProvider);
  }

  Future<void> _setAccent(WidgetRef ref, Color? color) async {
    final prefs = await ref.read(sharedPrefsProvider.future);
    if (color == null) {
      await prefs.remove(kAccentColorKey);
    } else {
      await prefs.setInt(kAccentColorKey, color.toARGB32());
    }
    ref.invalidate(accentColorProvider);
  }

  Future<void> _setFont(WidgetRef ref, String key, FontRecord? record) async {
    final prefs = await ref.read(sharedPrefsProvider.future);
    if (record == null) {
      await prefs.remove(key);
    } else {
      await prefs.setString(key, encodeFontRecord(record));
    }
    // 同时刷新对应 provider，UI 立即生效。
    switch (key) {
      case kFontAiKey:
        ref.invalidate(fontAiProvider);
      case kFontUserKey:
        ref.invalidate(fontUserProvider);
      default:
        ref.invalidate(fontUiProvider);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mode = ref.watch(themeModeProvider).value ?? ThemeMode.system;
    final accent = ref.watch(accentColorProvider).value;
    final fontAi = ref.watch(fontAiProvider).value;
    final fontUser = ref.watch(fontUserProvider).value;
    final fontUi = ref.watch(fontUiProvider).value;

    return _Section(
      title: '外观',
      icon: Icons.palette_outlined,
      children: [
        const Text('主题', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          children: [
            for (final entry in <ThemeMode, String>{
              ThemeMode.system: '跟随系统',
              ThemeMode.light: '浅色',
              ThemeMode.dark: '深色',
            }.entries)
              ChoiceChip(
                label: Text(entry.value),
                selected: mode == entry.key,
                onSelected: (_) => _setThemeMode(ref, entry.key.name),
              ),
          ],
        ),
        const SizedBox(height: 14),
        const Text('UI 强调色', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          runSpacing: 6,
          children: kAccentChoices.entries.map((e) {
            final selected = (e.value == null && accent == null) ||
                (e.value != null && accent != null && e.value!.toARGB32() == accent.toARGB32());
            return ChoiceChip(
              avatar: e.value == null
                  ? const Icon(Icons.gradient, size: 14)
                  : CircleAvatar(backgroundColor: e.value, radius: 7),
              label: Text(e.key, style: const TextStyle(fontSize: 11)),
              selected: selected,
              onSelected: (_) => _setAccent(ref, e.value),
            );
          }).toList(),
        ),
        const SizedBox(height: 14),
        const Text('字体（默认系统字体）',
            style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
        const SizedBox(height: 4),
        Text(
          '上传 ttf/otf 后复制到应用目录长期保存。会话设置里还能单独覆盖 AI / 用户字体。',
          style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.5),
        ),
        const SizedBox(height: 6),
        FontPickerRow(
          label: 'AI 回复字体（全局）',
          current: fontAi,
          onChanged: (r) => _setFont(ref, kFontAiKey, r),
        ),
        FontPickerRow(
          label: '用户消息字体（全局）',
          current: fontUser,
          onChanged: (r) => _setFont(ref, kFontUserKey, r),
        ),
        FontPickerRow(
          label: '界面 UI 字体（全局）',
          current: fontUi,
          onChanged: (r) => _setFont(ref, kFontUiKey, r),
        ),
      ],
    );
  }
}

class _ModelSection extends ConsumerWidget {
  const _ModelSection();

  Future<void> _select(WidgetRef ref, BuildContext context, String id) async {
    final prefs = await ref.read(sharedPrefsProvider.future);
    await prefs.setString(kGlobalModelKey, id);
    ref.invalidate(globalModelProvider);
    // 全局 Provider 里缓存着旧模型的实例，不失效的话下一次请求还会用旧模型。
    ref.invalidate(aiProviderProvider);
    if (context.mounted) {
      showAppToast(
        context,
        '默认模型已切换为 $id。注意：换模型后前几次对话会消耗较多余额'
        '（上下文缓存要重建），请留意 token 用量。',
        duration: const Duration(seconds: 5),
      );
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final catalogAsync = ref.watch(modelCatalogProvider);
    final currentAsync = ref.watch(globalModelProvider);

    return _Section(
      title: '默认模型',
      icon: Icons.memory,
      children: [
        catalogAsync.when(
          loading: () => const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: LinearProgressIndicator(minHeight: 2),
          ),
          error: (e, _) => Text('获取模型列表失败：$e',
              style: TextStyle(color: AppColors.textSecondary)),
          data: (models) {
            final current = currentAsync.asData?.value ?? kDefaultModelId;
            // 下拉框的 value 必须存在于 items，否则 Flutter 会直接断言失败。
            // 典型场景：内置默认模型没出现在接口返回里（或还没加载完）。
            final valid = models.any((m) => m.id == current);
            final window = ModelCatalog.windowFor(current);
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                DropdownButtonFormField<String>(
                  value: valid ? current : null,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: '全局默认模型',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  hint: Text(valid ? current : '$current（接口未返回，将按默认使用）',
                      overflow: TextOverflow.ellipsis),
                  items: models
                      .map((m) => DropdownMenuItem<String>(
                            value: m.id,
                            child: Text(
                              '${m.label} · ${m.windowLabel}',
                              overflow: TextOverflow.ellipsis,
                            ),
                          ))
                      .toList(growable: false),
                  onChanged: (value) {
                    if (value == null || value == current) return;
                    _select(ref, context, value);
                  },
                ),
                const SizedBox(height: 8),
                Text(
                  '列表中带窗口值的是已识别模型；未识别的按 '
                  '${(ModelCatalog.unknownContextWindow / 1000).round()}K 保守处理。'
                  '当前模型窗口 ${contextLimitLabel(window)}，'
                  '单会话设置里可单独覆盖。',
                  style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                ),
              ],
            );
          },
        ),
      ],
    );
  }
}

/// 同步方案选择：P2P 直连 / 腾讯云 COS（互斥）。
/// 切换 COS 后 P2P 引擎停用，配对界面被 COS 面板替代。
class _SyncModeSection extends ConsumerWidget {
  const _SyncModeSection();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mode = ref.watch(syncModeProvider);
    return _Section(
      icon: Icons.sync,
      title: '同步方案',
      children: [
        SegmentedButton<SyncMode>(
          segments: const [
            ButtonSegment(value: SyncMode.p2p, label: Text('P2P 直连')),
            ButtonSegment(value: SyncMode.cos, label: Text('腾讯云 COS')),
          ],
          selected: {mode},
          onSelectionChanged: (set) async {
            final prefs = await ref.read(sharedPrefsProvider.future);
            await saveSyncMode(prefs, set.first);
            ref.read(syncModeProvider.notifier).state = set.first;
            // 切到 COS 时按新配置启动定时同步；切到 P2P 时停止 COS 定时器。
            final scheduler = ref.read(cosAutoSyncSchedulerProvider);
            if (set.first == SyncMode.cos) scheduler.start(); else scheduler.stop();
            if (context.mounted) {
              showAppToast(context, set.first == SyncMode.cos
                  ? '已切换到 COS，P2P 直连已关闭'
                  : '已切换到 P2P 直连');
            }
          },
        ),
        const SizedBox(height: 8),
        Text(
          mode == SyncMode.cos
              ? '当前：COS 云同步。对话每 5 轮自动备份到云端，也可手动上传。'
              : '当前：P2P 设备直连，需配对后同步。',
          style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          icon: Icon(mode == SyncMode.cos ? Icons.cloud_outlined : Icons.link, size: 16),
          label: Text(mode == SyncMode.cos ? '打开云同步设置' : '打开配对/同步设置'),
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute<void>(builder: (_) => Scaffold(
              backgroundColor: AppColors.surface,
              body: const SafeArea(child: CosSyncPanel()),
            )),
          ),
        ),
      ],
    );
  }
}

/// 默认同步行为：四种并列（合并/以本机为准/以对端为准/不同步），P2P 与 COS 共用。
/// 这是"全局设置"，不是 P2P/COS 各自的设置——选不同步只是暂停两种同步方式，
/// 不改变上面已选的同步方案。正常同步按此静默执行，只有出错才弹定夺窗。
class _SyncBehaviorSection extends ConsumerWidget {
  const _SyncBehaviorSection();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final current = ref.watch(syncBehaviorProvider);
    return _Section(
      icon: Icons.compare_arrows,
      title: '默认同步行为',
      children: [
        Text(
          '同步时按此行为自动执行，不再每次询问。两个同步方案（P2P/COS）共用此设置。',
          style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
        ),
        const SizedBox(height: 10),
        for (final policy in SyncPolicy.values)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: _BehaviorOption(
              policy: policy,
              selected: current == policy,
              onTap: () async {
                final prefs = await ref.read(sharedPrefsProvider.future);
                await saveSyncBehavior(prefs, policy);
                ref.read(syncBehaviorProvider.notifier).state = policy;
                // 定时同步调度器重新读配置（间隔开关在 COS 设置里，这里只需同步行为即时生效）。
                if (context.mounted) {
                  showAppToast(context, '默认同步行为已设为「${policy.label}」');
                }
              },
            ),
          ),
      ],
    );
  }
}

class _BehaviorOption extends StatelessWidget {
  final SyncPolicy policy;
  final bool selected;
  final VoidCallback onTap;
  const _BehaviorOption({required this.policy, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final accent = policy.isOverwrite
        ? AppColors.danger
        : (policy == SyncPolicy.none ? AppColors.textSecondary : AppColors.primary);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: selected ? accent.withValues(alpha: 0.08) : null,
          border: Border.all(color: selected ? accent : accent.withValues(alpha: 0.4), width: selected ? 2 : 1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(
              selected ? Icons.radio_button_checked : Icons.radio_button_unchecked,
              color: accent,
              size: 20,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Flexible(
                      child: Text(policy.label,
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                    ),
                    if (policy.isOverwrite)
                      Padding(
                        padding: const EdgeInsets.only(left: 6),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppColors.danger.withValues(alpha: 0.12),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text('会丢数据',
                              style: TextStyle(
                                  fontSize: 10, color: AppColors.danger, fontWeight: FontWeight.bold)),
                        ),
                      ),
                  ]),
                  const SizedBox(height: 4),
                  Text(policy.detail,
                      style: TextStyle(fontSize: 11, height: 1.45, color: AppColors.textSecondary)),
                  if (policy.isOverwrite) ...[
                    const SizedBox(height: 4),
                    Text(policy.overwriteHint,
                        style: TextStyle(
                            fontSize: 11, color: AppColors.danger, fontWeight: FontWeight.w600)),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// 备份入口：整块可点卡片，跳转到备份管理页。
class _BackupSection extends ConsumerWidget {
  const _BackupSection();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return _Section(
      title: '备份',
      icon: Icons.shield_outlined,
      children: [
        Material(
          color: AppColors.primarySoft,
          borderRadius: BorderRadius.circular(10),
          child: InkWell(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute<void>(builder: (_) => const BackupSheet()),
            ),
            borderRadius: BorderRadius.circular(10),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              child: Row(
                children: [
                  Icon(Icons.history, color: AppColors.primary, size: 22),
                  SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('备份与回溯',
                            style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: AppColors.primary)),
                        SizedBox(height: 3),
                        Text('同步/导入前自动留快照，误操作可一键找回',
                            style: TextStyle(
                                fontSize: 11, color: AppColors.textSecondary)),
                      ],
                    ),
                  ),
                  Icon(Icons.chevron_right, color: AppColors.primary, size: 20),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

/// 文件管理入口：统一管理【已发送】文件的归档副本（按会话分组）。
class _FileManagerSection extends StatelessWidget {
  const _FileManagerSection();

  @override
  Widget build(BuildContext context) {
    return _Section(
      title: '文件管理',
      icon: Icons.folder_outlined,
      children: [
        Material(
          color: AppColors.primarySoft,
          borderRadius: BorderRadius.circular(10),
          child: InkWell(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute<void>(builder: (_) => const FileManagerSheet()),
            ),
            borderRadius: BorderRadius.circular(10),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              child: Row(
                children: [
                  Icon(Icons.folder_open_outlined, color: AppColors.primary, size: 22),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('已发送文件',
                            style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: AppColors.primary)),
                        SizedBox(height: 3),
                        Text('按会话归档，查看占用、多选删除文件副本',
                            style: TextStyle(
                                fontSize: 11, color: AppColors.textSecondary)),
                      ],
                    ),
                  ),
                  Icon(Icons.chevron_right, color: AppColors.primary, size: 20),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

/// 公告入口：放在全局设置最前面，点开看作者主页与版本亮点。
class _AnnouncementSection extends StatelessWidget {
  const _AnnouncementSection();

  @override
  Widget build(BuildContext context) {
    return _Section(
      icon: Icons.campaign_outlined,
      title: '公告',
      children: const [AnnouncementTile()],
    );
  }
}

class _AboutSection extends StatelessWidget {
  const _AboutSection();

  @override
  Widget build(BuildContext context) => _Section(
        title: '关于',
        icon: Icons.info_outline,
        children: [
          ListTile(
            leading: Icon(Icons.apps, color: AppColors.primary),
            title: const Text(AppInfo.name),
            subtitle: const Text(AppInfo.tagline),
          ),
          ListTile(
            leading: Icon(Icons.person, color: AppColors.primary),
            title: Text(AppInfo.author),
            subtitle: Text('版本 ${AppInfo.version}'),
          ),
        ],
      );
}

class _Section extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<Widget> children;

  const _Section({
    required this.title,
    required this.icon,
    required this.children,
  });

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 18, color: AppColors.primary),
              const SizedBox(width: 8),
              Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 12),
          ...children,
        ],
      );
}
