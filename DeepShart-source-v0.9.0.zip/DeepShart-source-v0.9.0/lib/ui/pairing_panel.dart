// target: lib/ui/pairing_panel.dart
// 职责：P2P 配对界面——A 端生成/展示 6 位配对码，B 端输入配对码，展示状态机状态与确认流程。

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/theme.dart';
import 'app_toast.dart';
import '../data/store/paired_device_store.dart';
import '../state/app_providers.dart';
import '../sync/pairing_service.dart';
import '../sync/sync_engine.dart';

/// 配对面板。接入 PairingService 的显式状态机与确认请求流。
class PairingPanel extends ConsumerStatefulWidget {
  const PairingPanel({super.key});

  @override
  ConsumerState<PairingPanel> createState() => _PairingPanelState();
}

class _PairingPanelState extends ConsumerState<PairingPanel> {
  final TextEditingController _codeController = TextEditingController();

  /// 配对成功的副作用只触发一次（刷新设备列表 + 发起首轮同步）。
  bool _handledPaired = false;
  bool _joining = false;

  @override
  void dispose() {
    _codeController.dispose();
    super.dispose();
  }

  void _onStateChanged(PairingState state) {
    if (state is PairingPaired) {
      if (_handledPaired) return;
      _handledPaired = true;
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        ref.invalidate(pairedDevicesProvider);
        try {
          final engine = await ref.read(syncEngineProvider.future);
          await engine.syncNow();
        } catch (_) {
          // 网络问题不应影响配对结果展示。
        }
      });
    } else {
      _handledPaired = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final serviceAsync = ref.watch(pairingServiceProvider);

    return StreamBuilder<PairingState>(
      stream: serviceAsync.value?.states,
      initialData: const PairingIdle(),
      builder: (context, snapshot) {
        final state = snapshot.data ?? const PairingIdle();
        _onStateChanged(state);
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('设备配对',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text(
                '配对码为一次性临时通道；确认后双方记录设备并直连同步。',
                style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
              ),
              const SizedBox(height: 20),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildStateView(state, serviceAsync.value),
                      const SizedBox(height: 24),
                      const _SyncSection(),
                      const SizedBox(height: 24),
                      const Divider(),
                      const SizedBox(height: 8),
                      const Text('作为 B 端加入',
                          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _codeController,
                        decoration: const InputDecoration(
                          labelText: '输入 6 位配对码',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                        keyboardType: TextInputType.number,
                        maxLength: 6,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '点击后会先探测配对服务是否可达，再协商直连。'
                        '整个过程不超过 20 秒，失败会直接说明原因，不会卡住界面。',
                        style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.5),
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          icon: _joining
                              ? const SizedBox(
                                  width: 14,
                                  height: 14,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                              : const Icon(Icons.login, size: 16),
                          label: Text(_joining ? '正在连接…' : '输入配对码并连接'),
                          onPressed: _joining ? null : () => _join(serviceAsync.value),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStateView(PairingState state, PairingService? service) {
    if (state is PairingWorking) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.primarySoft,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            const SizedBox(
              width: 16,
              height: 16,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(state.message,
                  style: const TextStyle(fontSize: 12, height: 1.5)),
            ),
          ],
        ),
      );
    }
    if (state is PairingIdle) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('作为 A 端生成配对码：', style: TextStyle(fontSize: 13)),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              icon: const Icon(Icons.qr_code, size: 16),
              label: const Text('生成配对码'),
              onPressed: () => service?.generateCode(),
            ),
          ),
        ],
      );
    }
    if (state is PairingCodeGenerated) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.primarySoft,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            const Text('把此配对码告诉对方：', style: TextStyle(fontSize: 12)),
            const SizedBox(height: 8),
            Text(
              state.code,
              style: TextStyle(
                fontSize: 34,
                fontWeight: FontWeight.bold,
                letterSpacing: 8,
                color: AppColors.primary,
              ),
            ),
            const SizedBox(height: 8),
            Text('等待对方连接并确认…',
                style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
          ],
        ),
      );
    }
    if (state is PairingAwaitingPeerConfirm) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('对方请求配对：', style: TextStyle(fontSize: 13)),
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('设备名: ${state.peerInfo.deviceName}'),
                  Text('设备 ID: ${state.peerInfo.deviceId}',
                      style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: FilledButton(
                  onPressed: () => service?.confirm(),
                  child: const Text('确认配对'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton(
                  onPressed: () => service?.reject(),
                  child: const Text('拒绝'),
                ),
              ),
            ],
          ),
        ],
      );
    }
    if (state is PairingPaired) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFFE8F5E9),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.check_circle, color: Colors.green, size: 18),
                SizedBox(width: 6),
                Text('配对成功', style: TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 6),
            Text('已配对设备: ${state.peer.deviceName}'),
            const SizedBox(height: 8),
            TextButton(
              onPressed: () => service?.reset(),
              child: const Text('重新配对'),
            ),
          ],
        ),
      );
    }
    if (state is PairingRejected) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFFFEBEE),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFFFFCDD2)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.error_outline, size: 16, color: AppColors.danger),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(state.reason,
                      style: TextStyle(
                          fontSize: 12, color: AppColors.danger, height: 1.5)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            icon: const Icon(Icons.refresh, size: 16),
            label: const Text('重试'),
            onPressed: () => service?.reset(),
          ),
        ],
      );
    }
    return const SizedBox.shrink();
  }

  Future<void> _join(PairingService? service) async {
    final code = _codeController.text.trim();
    if (code.length != 6 || int.tryParse(code) == null) {
      showAppToast(context, '请输入 6 位数字配对码');
      return;
    }
    if (service == null) return;
    setState(() => _joining = true);
    try {
      await service.enterCode(code);
    } catch (e) {
      if (mounted) {
        showAppToast(context, '连接失败：$e');
      }
    } finally {
      if (mounted) setState(() => _joining = false);
    }
  }
}

/// 已配对设备 + 实时同步状态。
///
/// 为什么需要这块：同步是全自动的，若不把状态暴露出来，用户无法判断
/// "到底同步了没有"，只能靠猜。这里把每台设备的连接/同步结论直接呈现。
class _SyncSection extends ConsumerWidget {
  const _SyncSection();

  /// 删除已配对设备：弹确认框，避免误长按把配对删掉。
  Future<void> _confirmRemoveDevice(
    BuildContext context,
    WidgetRef ref,
    PairedDevice device, [
    Offset? position,
  ]) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除已配对设备'),
        content: Text('确定要删除设备「${device.deviceName}」吗？\n'
            '删除后需要重新配对才能继续同步。'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('删除'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final store = await ref.read(pairedDeviceStoreProvider.future);
    await store.remove(device.deviceId);
    ref.invalidate(pairedDevicesProvider);
    if (context.mounted) showAppToast(context, '已删除设备「${device.deviceName}」');
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final devicesAsync = ref.watch(pairedDevicesProvider);
    final statuses = ref.watch(syncStatusesProvider).value ?? const <PeerSyncState>[];
    final byDevice = <String, PeerSyncState>{
      for (final s in statuses) s.deviceId: s,
    };

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('已配对设备与同步',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
            const Spacer(),
            TextButton.icon(
              icon: const Icon(Icons.sync, size: 16),
              label: const Text('立即同步'),
              onPressed: () async {
                final engine = await ref.read(syncEngineProvider.future);
                await engine.syncNow();
                if (context.mounted) {
                  showAppToast(context, '已发起同步，稍候查看下方状态');
                }
              },
            ),
          ],
        ),
        const SizedBox(height: 4),
        devicesAsync.when(
          loading: () => Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Text('加载中…',
                style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
          ),
          error: (e, _) => Text('读取失败: $e',
              style: TextStyle(fontSize: 12, color: AppColors.danger)),
          data: (devices) {
            if (devices.isEmpty) {
              return Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.background,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  '尚未配对任何设备。生成配对码给对方，或在下方输入对方的配对码。',
                  style: TextStyle(fontSize: 12, color: AppColors.textSecondary, height: 1.5),
                ),
              );
            }
            return Column(
              children: devices.map((d) {
                final status = byDevice[d.deviceId];
                return GestureDetector(
                  // 安卓长按、电脑右键都能删除已配对设备。
                  onLongPress: () => _confirmRemoveDevice(context, ref, d),
                  onSecondaryTapDown: (details) =>
                      _confirmRemoveDevice(context, ref, d, details.globalPosition),
                  child: _DeviceStatusRow(device: d, status: status),
                );
              }).toList(),
            );
          },
        ),
      ],
    );
  }
}

class _DeviceStatusRow extends StatelessWidget {
  final PairedDevice device;
  final PeerSyncState? status;

  const _DeviceStatusRow({required this.device, this.status});

  @override
  Widget build(BuildContext context) {
    final (label, color) = switch (status?.status) {
      PeerSyncStatus.synced => ('已同步', const Color(0xFF10B981)),
      PeerSyncStatus.exchanging => ('同步中…', AppColors.primary),
      PeerSyncStatus.connecting => ('连接中…', AppColors.primary),
      PeerSyncStatus.failed => ('连接失败', AppColors.danger),
      PeerSyncStatus.offline => ('离线', AppColors.textSecondary),
      null => ('未连接', AppColors.textSecondary),
    };

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border.all(color: AppColors.outline),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(device.deviceName,
                    style: TextStyle(fontSize: 13, color: AppColors.textPrimary)),
                Text(
                  'ID ${device.deviceId.substring(0, device.deviceId.length.clamp(0, 8))}'
                  '${status?.error != null ? ' · ${status!.error}' : (status?.note != null ? ' · ${status!.note}' : '')}',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(fontSize: 12, color: color)),
        ],
      ),
    );
  }
}
