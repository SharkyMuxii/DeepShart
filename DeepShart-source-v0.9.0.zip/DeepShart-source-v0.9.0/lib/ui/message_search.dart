// target: lib/ui/message_search.dart
// 职责：跨会话消息正文搜索的结果模型与分组逻辑。
//
// 用户要求：
//   - 关键词搜索能"找到指定对话指定部位"（搜索正文，不只是标题）。
//   - 时间点越早的搜索结果排越后（即按命中时间倒序）。
//   - 每个会话的结果默认折叠；展开后每个对话只显示一个结果（最新那条），
//     可继续点"下一条"浏览该会话的其余命中。

import 'package:flutter/foundation.dart';

import '../data/models/chat_message.dart';

/// 一条搜索命中。
@immutable
class SearchHit {
  final ChatMessage message;
  final String snippet;

  const SearchHit({required this.message, required this.snippet});
}

/// 一个会话下的搜索结果分组。
@immutable
class SearchGroup {
  final String conversationId;
  final String conversationTitle;
  final List<SearchHit> hits;

  /// 会话内最新的一条命中时间，用于组间排序（越早越靠后）。
  DateTime get latestAt => hits.first.message.createdAt;

  const SearchGroup({
    required this.conversationId,
    required this.conversationTitle,
    required this.hits,
  });
}

/// 搜索纯逻辑：把扁平的命中列表按会话分组、组内组间都按时间倒序。
class MessageSearch {
  const MessageSearch._();

  static const int snippetRadius = 40;

  /// 生成命中处的摘要片段（命中词前后各 [snippetRadius] 字）。
  static String snippetOf(String content, String keyword, {int radius = snippetRadius}) {
    final lower = content.toLowerCase();
    final at = lower.indexOf(keyword.toLowerCase());
    if (at < 0) {
      return content.length > radius * 2
          ? '${content.substring(0, radius)}…'
          : content;
    }
    final start = (at - radius).clamp(0, content.length);
    final end = (at + keyword.length + radius).clamp(0, content.length);
    final prefix = start > 0 ? '…' : '';
    final suffix = end < content.length ? '…' : '';
    return '$prefix${content.substring(start, end)}$suffix';
  }

  /// 按会话分组并排序。
  static List<SearchGroup> group(
    List<ChatMessage> hits, {
    required String keyword,
    required Map<String, String> titles,
  }) {
    final byConv = <String, List<SearchHit>>{};
    for (final m in hits) {
      // 剥掉思考块再搜索展示，避免 <thinking> 里的无关内容干扰。
      var content = m.content;
      final tMatch = RegExp(r'<thinking>\n?[\s\S]*?\n?</thinking>').firstMatch(content);
      if (tMatch != null) {
        content = content.replaceFirst(tMatch.group(0)!, '').trim();
      }
      final snippet = snippetOf(content, keyword);
      byConv.putIfAbsent(m.conversationId, () => <SearchHit>[]).add(
            SearchHit(message: m, snippet: snippet),
          );
    }

    final groups = byConv.entries.map((e) {
      // 组内已按 created_at DESC（store 查询顺序），再确保一次。
      final sorted = List<SearchHit>.from(e.value)
        ..sort((a, b) => b.message.createdAt.compareTo(a.message.createdAt));
      return SearchGroup(
        conversationId: e.key,
        conversationTitle: titles[e.key] ?? '未命名会话',
        hits: List<SearchHit>.unmodifiable(sorted),
      );
    }).toList();

    // 组间按"每组最新命中时间"倒序：越早的会话排越后。
    groups.sort((a, b) => b.latestAt.compareTo(a.latestAt));
    return List<SearchGroup>.unmodifiable(groups);
  }
}
