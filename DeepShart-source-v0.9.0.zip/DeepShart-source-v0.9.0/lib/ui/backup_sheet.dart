// target: lib/ui/backup_sheet.dart
// 职责：备份管理页——开关、容量上限、立即备份、备份列表、回溯、删除。
//
// 这是"防止同步把记忆改坏"的最后一道保险：同步/导入是破坏性操作，
// 事前自动留一份快照，用户随时能回退。这里负责展示与手动操作。

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/theme.dart';
import '../state/app_providers.dart';
import '../sync/backup_service.dart';
import '../sync/sync_policy.dart';
import 'app_toast.dart';

class BackupSheet extends ConsumerStatefulWidget {
  const BackupSheet({super.key});

  @override
  ConsumerState<BackupSheet> createState() => _BackupSheetState();
}

class _BackupSheetState extends ConsumerState<BackupSheet> {
  bool _loaded = false;
  bool _enabled = true;
  bool _beforeSync = true;
  bool _beforeImport = true;
  int _limitMB = 100;
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    final backupAsync = ref.watch(backupServiceProvider);

    backupAsync.whenData((service) {
      if (!_loaded) {
        _enabled = service.enabled;
        _beforeSync = service.autoBackupBeforeSync;
        _beforeImport = service.autoBackupBeforeImport;
        _limitMB = (service.limitBytes / 1024 / 1024).round();
        _loaded = true;
      }
    });

    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        title: const Text('备份设置'),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: backupAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('加载失败：$e')),
        data: (service) => ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _Section(
              title: '自动备份',
              icon: Icons.shield_outlined,
              children: [
                SwitchListTile(
                  value: _enabled,
                  onChanged: (v) async {
                    setState(() => _enabled = v);
                    await service.setEnabled(v);
                  },
                  title: const Text('启用备份', style: TextStyle(fontSize: 14)),
                  subtitle: Text(
                    '关闭后同步、导入前不再自动备份。强烈不建议关闭——'
                    '一旦同步出错，没有备份就无法找回被覆盖的内容。',
                    style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                  ),
                  contentPadding: EdgeInsets.zero,
                ),
                SwitchListTile(
                  value: _beforeSync,
                  onChanged: _enabled
                      ? (v) async {
                          setState(() => _beforeSync = v);
                          await service.setBackupBeforeSync(v);
                        }
                      : null,
                  title: const Text('同步前自动备份', style: TextStyle(fontSize: 14)),
                  subtitle: Text(
                    '每次手动/自动同步、配对后首次同步前，自动留一份快照。',
                    style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                  ),
                  contentPadding: EdgeInsets.zero,
                ),
                SwitchListTile(
                  value: _beforeImport,
                  onChanged: _enabled
                      ? (v) async {
                          setState(() => _beforeImport = v);
                          await service.setBackupBeforeImport(v);
                        }
                      : null,
                  title: const Text('导入前自动备份', style: TextStyle(fontSize: 14)),
                  subtitle: Text(
                    '导入对话前自动备份，防止导入操作影响已有数据。',
                    style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                  ),
                  contentPadding: EdgeInsets.zero,
                ),
              ],
            ),
            const SizedBox(height: 20),
            _Section(
              title: '容量上限',
              icon: Icons.data_usage,
              children: [
                Row(
                  children: [
                    const Text('备份上限', style: TextStyle(fontSize: 14)),
                    const Spacer(),
                    Text('$_limitMB MB',
                        style: const TextStyle(
                            fontSize: 14, fontWeight: FontWeight.bold)),
                  ],
                ),
                Slider(
                  value: _limitMB.toDouble(),
                  min: 10,
                  max: 2000,
                  divisions: 199,
                  label: '$_limitMB MB',
                  onChanged: (v) => setState(() => _limitMB = v.round()),
                  onChangeEnd: (v) async {
                    final mb = v.round();
                    await service.setLimitBytes(mb * 1024 * 1024);
                    if (mounted) showAppToast(context, '备份上限已设为 $mb MB');
                  },
                ),
                Text(
                  '超出上限时自动删除最旧的备份（至少保留最新一份）。',
                  style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                ),
              ],
            ),
            const SizedBox(height: 20),
            _Section(
              title: '备份列表',
              icon: Icons.history,
              actions: [
                TextButton.icon(
                  icon: _busy
                      ? const SizedBox(width: 14, height: 14,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.add, size: 16),
                  label: const Text('立即备份'),
                  onPressed: _busy ? null : () => _manualBackup(service),
                ),
              ],
              children: [
                _buildList(service),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildList(BackupService service) {
    return FutureBuilder<List<BackupEntry>>(
      future: service.list(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(12),
              child: CircularProgressIndicator(),
            ),
          );
        }
        if (snapshot.hasError) {
          return Text('读取备份列表失败：${snapshot.error}',
              style: TextStyle(color: AppColors.danger));
        }
        final entries = snapshot.data ?? const <BackupEntry>[];
        if (entries.isEmpty) {
          return Text(
            '还没有备份。第一次同步或导入前会自动生成。',
            style: TextStyle(color: AppColors.textSecondary),
          );
        }
        final total = entries.fold<int>(0, (s, e) => s + e.sizeBytes);
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '共 ${entries.length} 份 · 占用 ${_fmtBytes(total)} / ${_fmtBytes(service.limitBytes)}',
              style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 8),
            ...entries.map((e) => _BackupTile(
                  entry: e,
                  onRestore: () => _confirmRestore(service, e),
                  onDelete: () => _confirmDelete(service, e),
                )),
          ],
        );
      },
    );
  }

  Future<void> _manualBackup(BackupService service) async {
    setState(() => _busy = true);
    try {
      final entry = await service.backup(reason: 'manual', force: true);
      if (mounted) {
        setState(() => _busy = false);
        showAppToast(context, '已备份：${entry?.fileName ?? ''}');
      }
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        showAppToast(context, '备份失败：$e', error: true);
      }
    }
  }

  Future<void> _confirmRestore(BackupService service, BackupEntry entry) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('回溯到这份备份？'),
        content: Text(
          '将把当前全部对话、记忆点、设置替换为\n${entry.timeLabel}\n（${entry.reasonLabel}）时的状态。\n\n'
          '回溯前会自动为当前状态再留一份备份，可随时回退。',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('确认回溯'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;

    setState(() => _busy = true);
    try {
      await service.restore(entry.path);
      // 回溯后让所有依赖数据库的 provider 重新读取，UI 立即反映旧数据。
      ref.invalidate(databaseProvider);

      // 用户要求：回溯后自动暂停同步（不同步），并提示手动去全局设置打开。
      final prefs = await ref.read(sharedPrefsProvider.future);
      await saveSyncBehavior(prefs, SyncPolicy.none);
      ref.read(syncBehaviorProvider.notifier).state = SyncPolicy.none;

      if (mounted) {
        setState(() => _busy = false);
        await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('回溯完成，同步已暂停'),
            content: const Text(
              '为保护您的数据安全，同步已暂停，请前往「全局设置」打开同步（建议使用并列）。',
            ),
            actions: [
              FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('我知道了'),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        showAppToast(context, '回溯失败：$e', error: true);
      }
    }
  }

  Future<void> _confirmDelete(BackupService service, BackupEntry entry) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除这份备份？'),
        content: Text('${entry.timeLabel}\n${entry.reasonLabel} · ${entry.sizeLabel}\n\n删除后不可恢复。'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('删除'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await service.delete(entry.path);
    if (mounted) {
      setState(() {});
      showAppToast(context, '已删除 ${entry.fileName}');
    }
  }

  static String _fmtBytes(int bytes) {
    if (bytes >= 1024 * 1024) {
      return '${(bytes / 1024 / 1024).toStringAsFixed(1)} MB';
    }
    return '${(bytes / 1024).round()} KB';
  }
}

String _sourceLabel(String source) => switch (source) {
      'cloud' => '云端备份',
      'p2p' => '对端同步',
      _ => '本机备份',
    };

class _BackupTile extends StatelessWidget {
  final BackupEntry entry;
  final VoidCallback onRestore;
  final VoidCallback onDelete;

  const _BackupTile({
    required this.entry,
    required this.onRestore,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 8),
        child: ListTile(
          // 来源图标：本机=软盘；COS 云端/P2P 对端同步=云朵上传（用户要求）。
          leading: Icon(
            entry.source == 'local' ? Icons.save_outlined : Icons.cloud_upload_outlined,
            color: entry.source == 'local' ? AppColors.textSecondary : AppColors.primary,
          ),
          title: Text(entry.timeLabel, style: const TextStyle(fontSize: 13)),
          subtitle: Text(
            '${_sourceLabel(entry.source)} · ${entry.reasonLabel} · ${entry.sizeLabel}',
            style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
          ),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                icon: const Icon(Icons.restore, size: 18),
                tooltip: '回溯到此版本',
                onPressed: onRestore,
              ),
              IconButton(
                icon: Icon(Icons.delete_outline, size: 18, color: AppColors.danger),
                tooltip: '删除',
                onPressed: onDelete,
              ),
            ],
          ),
        ),
      );
}

class _Section extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<Widget> children;
  final List<Widget>? actions;

  const _Section({
    required this.title,
    required this.icon,
    required this.children,
    this.actions,
  });

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 18, color: AppColors.primary),
              const SizedBox(width: 8),
              Text(title,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const Spacer(),
              ...?actions,
            ],
          ),
          const SizedBox(height: 8),
          ...children,
        ],
      );
}
