// target: lib/sync/stale_sync_tracker.dart
// 职责：疑似废弃同步文件（latest 快照）的分级提醒状态机。
//
// 规则（用户明确要求）：
//  - 某个 latest 文件【3天没更新】→ 询问"检测到疑似已废弃的同步文件，是否忽略并删除？"
//  - 用户否定 → 后端标记；再过【3天】仍没更新 → 红色强提示二次询问
//    "检测到极大概率已废弃的同步文件，是否忽略并删除？不删除可能导致同步功能紊乱！"
//  - 用户依旧不删 → 该文件永久不再提示。
//  - 弹窗归弹窗：期间同步【照常识别并同步】该文件，不因提醒而跳过。

import 'package:shared_preferences/shared_preferences.dart';

const _prefix = 'deepshart.stale_file.';
const threeDays = Duration(days: 3);

enum StaleLevel { none, soft, hard }

class StaleFileState {
  /// 首次被判定为"3天未更新"的时间（毫秒）。
  final int firstSeenStaleAt;

  /// 用户上次点"保留"的时间（毫秒），用于软提示后的第二个3天计时。
  final int? userDeclinedAt;

  /// 用户是否永久性忽略（硬提示后仍保留）。
  final bool permanentlyIgnored;

  const StaleFileState({
    required this.firstSeenStaleAt,
    this.userDeclinedAt,
    this.permanentlyIgnored = false,
  });

  Map<String, dynamic> toJson() => {
        'first': firstSeenStaleAt,
        if (userDeclinedAt != null) 'declined': userDeclinedAt,
        'permanent': permanentlyIgnored,
      };

  factory StaleFileState.fromJson(Map<String, dynamic> m) => StaleFileState(
        firstSeenStaleAt: (m['first'] as num?)?.toInt() ?? 0,
        userDeclinedAt: (m['declined'] as num?)?.toInt(),
        permanentlyIgnored: m['permanent'] as bool? ?? false,
      );
}

class StaleSyncTracker {
  final SharedPreferences prefs;
  StaleSyncTracker(this.prefs);

  String _key(String deviceTag) => '$_prefix$deviceTag';

  StaleFileState? read(String deviceTag) {
    final raw = prefs.getString(_key(deviceTag));
    if (raw == null || raw.isEmpty) return null;
    try {
      // 简单 key=value 序列化，避免引入额外依赖。
      final parts = raw.split(';');
      final map = <String, dynamic>{};
      for (final p in parts) {
        final i = p.indexOf('=');
        if (i < 0) continue;
        map[p.substring(0, i)] = p.substring(i + 1);
      }
      return StaleFileState(
        firstSeenStaleAt: int.tryParse(map['first'] ?? '') ?? 0,
        userDeclinedAt: int.tryParse(map['declined'] ?? '') ??
            (map.containsKey('declined') ? 0 : null),
        permanentlyIgnored: map['permanent'] == '1',
      );
    } catch (_) {
      return null;
    }
  }

  Future<void> _write(String deviceTag, StaleFileState s) async {
    final sb = StringBuffer()
      ..write('first=${s.firstSeenStaleAt}')
      ..write(';permanent=${s.permanentlyIgnored ? 1 : 0}');
    if (s.userDeclinedAt != null) sb.write(';declined=${s.userDeclinedAt}');
    await prefs.setString(_key(deviceTag), sb.toString());
  }

  /// 根据"最后更新时间"和当前时间，判断该文件应处于哪个提醒级别。
  /// 只做判断、不改状态；状态变更由用户的选择驱动（见 decline/permanentIgnore）。
  StaleLevel evaluate(String deviceTag, DateTime? lastModified, {DateTime? now}) {
    final state = read(deviceTag);
    if (state?.permanentlyIgnored == true) return StaleLevel.none;
    final t = now ?? DateTime.now().toUtc();
    final modified = lastModified;
    // 没有修改时间：保守地不当作废弃，避免误伤。
    if (modified == null) return StaleLevel.none;
    final age = t.difference(modified);
    if (age < threeDays) {
      // 文件重新更新了，之前的状态作废。
      if (state != null) prefs.remove(_key(deviceTag));
      return StaleLevel.none;
    }
    if (state == null) {
      // 第一次发现 stale：记住时间，本次给软提示。
      prefs.setString(
        _key(deviceTag),
        'first=${t.millisecondsSinceEpoch};permanent=0',
      );
      return StaleLevel.soft;
    }
    // 已经标记过：看用户否定后是否又过了3天。
    final declined = state.userDeclinedAt ?? state.firstSeenStaleAt;
    if (t.difference(DateTime.fromMillisecondsSinceEpoch(declined)) >= threeDays) {
      return StaleLevel.hard;
    }
    return StaleLevel.none;
  }

  /// 用户选择"保留"：记录否定时间，开始下一个3天计时。
  Future<void> decline(String deviceTag) async {
    final s = read(deviceTag) ?? const StaleFileState(firstSeenStaleAt: 0);
    await _write(
      deviceTag,
      StaleFileState(
        firstSeenStaleAt: s.firstSeenStaleAt,
        userDeclinedAt: DateTime.now().toUtc().millisecondsSinceEpoch,
      ),
    );
  }

  /// 硬提示后用户仍保留：永久忽略该文件，不再提示。
  Future<void> permanentIgnore(String deviceTag) async {
    final s = read(deviceTag) ?? const StaleFileState(firstSeenStaleAt: 0);
    await _write(
      deviceTag,
      StaleFileState(
        firstSeenStaleAt: s.firstSeenStaleAt,
        userDeclinedAt: s.userDeclinedAt,
        permanentlyIgnored: true,
      ),
    );
  }

  /// 用户选择删除（或文件重新出现且更新）：清掉状态。
  Future<void> clear(String deviceTag) async {
    await prefs.remove(_key(deviceTag));
  }
}
