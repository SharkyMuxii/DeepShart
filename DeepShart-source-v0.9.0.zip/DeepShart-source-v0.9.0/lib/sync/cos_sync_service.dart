// target: lib/sync/cos_sync_service.dart
// 职责：腾讯云 COS 云同步——对象存储签名(v5)、对话快照上传/下载、备份上传、设备发现。
//
// 安全设计（重要）：
//   - SecretId/SecretKey/Bucket/Region 全部在运行时由用户在设置页填入，仅存本机
//     SharedPreferences，【绝不硬编码进代码或打包进安装包】。
//   - 所有请求走 HTTPS，签名使用 COS Signature v5（HMAC-SHA1）。
//   - 对象键按设备名+时间分类，便于识别来源与回溯。

import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// COS 上传时使用的"设备名"prefs 键。用户可在 COS 设置页自定义，
/// 用于云端对象键标注来源设备；留空则回退到本机全局设备名。
const String kCosDeviceNameKey = 'deepshart.cos.device_name';

/// 历史版本容量上限配置。用户输入数字 + 选单位，统一折算成字节存本机。
/// 默认 500MB，最大 1TB（用户明确要求）。
@immutable
class CosQuotaConfig {
  final double value;
  final String unit; // kb / mb / tb / pb

  const CosQuotaConfig({this.value = 500, this.unit = 'mb'});

  static const _kValue = 'deepshart.cos.quota_value';
  static const _kUnit = 'deepshart.cos.quota_unit';

  /// 1TB 上限的字节数（硬上限，防止误填 pb 撑爆）。
  static const int maxBytes = 1024 * 1024 * 1024 * 1024; // 1TB

  factory CosQuotaConfig.fromPrefs(SharedPreferences prefs) => CosQuotaConfig(
        value: prefs.getDouble(_kValue) ?? 500,
        unit: prefs.getString(_kUnit) ?? 'mb',
      );

  double get multiplier => switch (unit) {
        'kb' => 1024,
        'tb' => 1024 * 1024 * 1024 * 1024,
        'pb' => 1024 * 1024 * 1024 * 1024 * 1024,
        _ => 1024 * 1024, // mb
      };

  /// 折算成字节，并夹到 [0, 1TB]。
  int get bytes {
    final raw = (value * multiplier).round();
    if (raw <= 0) return 0;
    return raw > maxBytes ? maxBytes : raw;
  }

  Future<void> save(SharedPreferences prefs) async {
    await prefs.setDouble(_kValue, value);
    await prefs.setString(_kUnit, unit);
  }
}

/// COS 三个互不冲突的自动同步开关配置（2026-11-20 用户要求）。
///   - 定时：每隔 N 分钟自动同步一次
///   - 按条数：每发送 N 条对话自动同步一次
///   - 启动：每次打开软件自动同步一次
@immutable
class CosAutoSyncConfig {
  final bool intervalEnabled;
  final int intervalMinutes;
  final bool roundsEnabled;
  final int rounds;
  final bool startupEnabled;

  const CosAutoSyncConfig({
    this.intervalEnabled = true,
    this.intervalMinutes = 10,
    this.roundsEnabled = false,
    this.rounds = 5,
    this.startupEnabled = true,
  });

  static const _kIntervalEnabled = 'deepshart.cos.auto_interval_enabled';
  static const _kIntervalMinutes = 'deepshart.cos.auto_interval_minutes';
  static const _kRoundsEnabled = 'deepshart.cos.auto_rounds_enabled';
  static const _kRounds = 'deepshart.cos.auto_rounds';
  static const _kStartupEnabled = 'deepshart.cos.auto_startup_enabled';

  factory CosAutoSyncConfig.fromPrefs(SharedPreferences prefs) => CosAutoSyncConfig(
        // 首次配置 COS 时默认开启"定时同步（每10分钟）"与"启动时同步"；
        // 用户手动存过的值（含主动关闭的 false）一律优先，不被默认值覆盖。
        intervalEnabled: prefs.getBool(_kIntervalEnabled) ?? true,
        intervalMinutes: prefs.getInt(_kIntervalMinutes) ?? 10,
        roundsEnabled: prefs.getBool(_kRoundsEnabled) ?? false,
        rounds: prefs.getInt(_kRounds) ?? 5,
        startupEnabled: prefs.getBool(_kStartupEnabled) ?? true,
      );

  Future<void> save(SharedPreferences prefs) async {
    await prefs.setBool(_kIntervalEnabled, intervalEnabled);
    await prefs.setInt(_kIntervalMinutes, intervalMinutes.clamp(1, 1440));
    await prefs.setBool(_kRoundsEnabled, roundsEnabled);
    await prefs.setInt(_kRounds, rounds.clamp(1, 100));
    await prefs.setBool(_kStartupEnabled, startupEnabled);
  }
}

/// 读取 COS 专用设备名（可为空）。
String cosDeviceNameFromPrefs(SharedPreferences prefs) =>
    prefs.getString(kCosDeviceNameKey)?.trim() ?? '';

/// 保存 COS 专用设备名；传空串表示清除（回退全局设备名）。
Future<void> saveCosDeviceName(SharedPreferences prefs, String name) async {
  final trimmed = name.trim();
  if (trimmed.isEmpty) {
    await prefs.remove(kCosDeviceNameKey);
  } else {
    await prefs.setString(kCosDeviceNameKey, trimmed);
  }
}

/// COS 同步配置（用户本机填入）。
@immutable
class CosConfig {
  final String secretId;
  final String secretKey;
  final String bucket;
  final String region;

  const CosConfig({
    this.secretId = '',
    this.secretKey = '',
    this.bucket = '',
    this.region = 'ap-guangzhou',
  });

  bool get isComplete =>
      secretId.trim().isNotEmpty &&
      secretKey.trim().isNotEmpty &&
      bucket.trim().isNotEmpty &&
      region.trim().isNotEmpty;

  /// 从本机存储读取。
  factory CosConfig.fromPrefs(SharedPreferences prefs) => CosConfig(
        secretId: prefs.getString(_kSecretId) ?? '',
        secretKey: prefs.getString(_kSecretKey) ?? '',
        bucket: prefs.getString(_kBucket) ?? '',
        region: prefs.getString(_kRegion) ?? 'ap-guangzhou',
      );

  static const _kSecretId = 'deepshart.cos.secret_id';
  static const _kSecretKey = 'deepshart.cos.secret_key';
  static const _kBucket = 'deepshart.cos.bucket';
  static const _kRegion = 'deepshart.cos.region';

  Future<void> save(SharedPreferences prefs) async {
    await prefs.setString(_kSecretId, secretId.trim());
    await prefs.setString(_kSecretKey, secretKey.trim());
    await prefs.setString(_kBucket, bucket.trim());
    await prefs.setString(_kRegion, region.trim());
  }

  Future<void> clear(SharedPreferences prefs) async {
    await prefs.remove(_kSecretId);
    await prefs.remove(_kSecretKey);
    await prefs.remove(_kBucket);
    await prefs.remove(_kRegion);
  }

  String get host => '$bucket.cos.$region.myqcloud.com';
}

/// 云端对象条目。
@immutable
class CosObject {
  final String key;
  final DateTime? lastModified;
  final int size;
  const CosObject(this.key, {this.lastModified, this.size = 0});

  /// 从 object key 里解析设备名标签（键格式 deepshart/<type>/<deviceTag>/<file>）。
  String get deviceTag {
    final parts = key.split('/');
    return parts.length >= 3 ? parts[2] : '未知设备';
  }

  String get fileName => key.split('/').last;
}

/// 同步运行状态。
@immutable
class CosSyncState {
  final bool busy;
  final String? lastMessage;
  final String? error;
  final DateTime? lastUploadAt;
  const CosSyncState({this.busy = false, this.lastMessage, this.error, this.lastUploadAt});

  CosSyncState copyWith({
    bool? busy,
    String? lastMessage,
    String? error,
    bool clearError = false,
    bool clearMessage = false,
    DateTime? lastUploadAt,
  }) =>
      CosSyncState(
        busy: busy ?? this.busy,
        lastMessage: clearMessage ? null : (lastMessage ?? this.lastMessage),
        error: clearError ? null : (error ?? this.error),
        lastUploadAt: lastUploadAt ?? this.lastUploadAt,
      );
}

/// COS 同步服务。
class CosSyncService {
  final SharedPreferences prefs;
  final ValueNotifier<CosSyncState> state = ValueNotifier(const CosSyncState());

  CosSyncService({required this.prefs});

  static const _prefix = 'deepshart';
  static const _lastUploadKey = 'deepshart.cos.last_upload';
  static const _roundCounterKey = 'deepshart.cos.round_counter';

  CosConfig get config => CosConfig.fromPrefs(prefs);

  DateTime? get lastUploadAt {
    final ms = prefs.getInt(_lastUploadKey);
    return ms == null ? null : DateTime.fromMillisecondsSinceEpoch(ms);
  }

  /// 每轮对话后调用；按"每 N 条对话自动同步"开关累计，到 N 返回 true 并清零。
  /// 仅在 COS 模式、配置完整、且该开关开启时才计数，避免无关模式下空转。
  bool tickRound({required bool cosModeEnabled}) {
    if (!cosModeEnabled || !config.isComplete) return false;
    final auto = CosAutoSyncConfig.fromPrefs(prefs);
    if (!auto.roundsEnabled) return false;
    final n = (prefs.getInt(_roundCounterKey) ?? 0) + 1;
    if (n >= auto.rounds) {
      prefs.setInt(_roundCounterKey, 0);
      return true;
    }
    prefs.setInt(_roundCounterKey, n);
    return false;
  }

  int get pendingRounds => prefs.getInt(_roundCounterKey) ?? 0;

  /// 设备名做对象键安全处理。
  String deviceTag(String deviceName) {
    final cleaned = deviceName
        .replaceAll(RegExp(r'[\\/:*?"<>|\r\n\t]'), '_')
        .replaceAll(RegExp(r'\s+'), '_');
    final trimmed = cleaned.isEmpty ? 'device' : cleaned;
    return trimmed.length > 40 ? trimmed.substring(0, 40) : trimmed;
  }

  // ---------------- COS Signature v5 ----------------

  /// 生成 Authorization 头。已用真实 bucket 验证可用。
  String _authorization({
    required String method,
    required String path,
    required String host,
    Map<String, String> params = const <String, String>{},
    Map<String, String> headers = const <String, String>{},
  }) {
    final cfg = config;
    final now = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
    final keyTime = '${now - 60};${now + 600}';
    final signKey = Hmac(sha1, utf8.encode(cfg.secretKey)).convert(utf8.encode(keyTime)).toString();

    // header-list / url-param-list 必须按 key 字典序，且值要 urlencode。
    final allHeaders = <String, String>{'host': host, ...headers};
    final headerKeys = allHeaders.keys.toList()..sort();
    final headerList = headerKeys.join(';');
    final headerString = headerKeys.map((k) => '${_urlEncode(k)}=${_urlEncode(allHeaders[k]!)}').join('&');

    final paramKeys = params.keys.toList()..sort();
    final paramList = paramKeys.join(';');
    final paramString = paramKeys.map((k) => '${_urlEncode(k)}=${_urlEncode(params[k]!)}').join('&');

    final httpString = '${method.toLowerCase()}\n$path\n$paramString\n$headerString\n';
    final stringToSign = 'sha1\n$keyTime\n${sha1.convert(utf8.encode(httpString)).toString()}\n';
    final signature = Hmac(sha1, utf8.encode(signKey)).convert(utf8.encode(stringToSign)).toString();

    return 'q-sign-algorithm=sha1'
        '&q-ak=${cfg.secretId}'
        '&q-sign-time=$keyTime'
        '&q-key-time=$keyTime'
        '&q-header-list=$headerList'
        '&q-url-param-list=$paramList'
        '&q-signature=$signature';
  }

  String _urlEncode(String s) => Uri.encodeComponent(s).replaceAll('+', '%20');

  HttpClient _client() => HttpClient()..connectionTimeout = const Duration(seconds: 15);

  Future<HttpClientResponse> _request({
    required String method,
    required String objectKey,
    List<int>? body,
    Map<String, String> params = const <String, String>{},
    String? contentType,
  }) async {
    final cfg = config;
    if (!cfg.isComplete) throw StateError('COS 配置不完整，请先在设置里填写 SecretId/SecretKey/Bucket/Region');

    final path = '/$objectKey';
    final uri = Uri.https(cfg.host, path, params.isEmpty ? null : params);
    final client = _client();
    try {
      final req = await client.openUrl(method, uri);
      final extraHeaders = <String, String>{};
      if (contentType != null) extraHeaders['content-type'] = contentType;
      final auth = _authorization(
        method: method,
        path: path,
        host: cfg.host,
        params: params,
        headers: extraHeaders,
      );
      req.headers.set('Authorization', auth);
      req.headers.set('Host', cfg.host);
      if (contentType != null) req.headers.set('Content-Type', contentType);
      if (body != null) req.add(body);
      return await req.close();
    } finally {
      // 注意：不要在这里 close client——response 流还没读完。由调用方读完后关闭。
    }
  }

  /// 读取响应体并关闭 client（通过 response 无法直接拿 client，这里用顶层函数处理）。
  // 采用每次请求新建 client 且读完即关；_request 返回 response 后调用方 _drain 会关闭连接，
  // client 本身随请求结束被 GC。为稳妥，改为同步读体的封装方法。

  Future<(int, String)> _requestText({
    required String method,
    required String objectKey,
    Map<String, String> params = const <String, String>{},
  }) async {
    final resp = await _request(method: method, objectKey: objectKey, params: params);
    final body = await utf8.decodeStream(resp);
    return (resp.statusCode, body);
  }

  Future<int> _requestBytes({
    required String method,
    required String objectKey,
    required List<int> body,
    String? contentType,
  }) async {
    final resp = await _request(
      method: method,
      objectKey: objectKey,
      body: body,
      contentType: contentType,
    );
    await resp.drain<void>();
    return resp.statusCode;
  }

  /// 测试配置是否可用（列出 bucket 下的对象前缀）。
  Future<(bool ok, String message)> testConnection() async {
    try {
      final cfg = config;
      if (!cfg.isComplete) return (false, '配置不完整：请填写 SecretId、SecretKey、Bucket、Region');
      final (code, body) = await _requestText(
        method: 'GET',
        objectKey: '',
        params: {'prefix': '$_prefix/', 'max-keys': '1'},
      );
      if (code == 200) return (true, '连接成功，bucket 可访问');
      return (false, '连接失败（HTTP $code）：${_stripXml(body)}');
    } catch (e) {
      return (false, '连接失败：$e');
    }
  }

  String _stripXml(String body) {
    final m = RegExp(r'<(?:Message|message)>([\s\S]*?)</(?:Message|message)>').firstMatch(body);
    if (m != null) return m.group(1)!.trim();
    return body.length > 160 ? '${body.substring(0, 160)}…' : body;
  }

  /// 列出云端所有 deepshart 对象。
  Future<List<CosObject>> listObjects() async {
    final objects = <CosObject>[];
    String? marker;
    do {
      final params = <String, String>{'prefix': '$_prefix/', 'max-keys': '1000'};
      if (marker != null) params['marker'] = marker;
      final (code, body) = await _requestText(method: 'GET', objectKey: '', params: params);
      if (code != 200) throw StateError('列举失败（HTTP $code）：${_stripXml(body)}');

      final contents = RegExp(r'<Contents>([\s\S]*?)</Contents>').allMatches(body);
      for (final c in contents) {
        final block = c.group(1)!;
        final key = _tag(block, 'Key');
        if (key.isEmpty) continue;
        final modified = _tag(block, 'LastModified');
        final size = int.tryParse(_tag(block, 'Size')) ?? 0;
        objects.add(CosObject(
          key,
          lastModified: DateTime.tryParse(modified)?.toUtc(),
          size: size,
        ));
      }
      final truncated = body.contains('<IsTruncated>true</IsTruncated>');
      marker = truncated ? _tag(body, 'NextMarker') : null;
    } while (marker != null && marker.isNotEmpty);
    // 按最后修改时间倒序：最新的排在最前面（用户要求）。
    objects.sort((a, b) {
      final at = a.lastModified?.millisecondsSinceEpoch ?? 0;
      final bt = b.lastModified?.millisecondsSinceEpoch ?? 0;
      return bt.compareTo(at);
    });
    return objects;
  }

  String _tag(String xml, String tag) {
    final m = RegExp('<$tag>([\\s\\S]*?)</$tag>').firstMatch(xml);
    return m?.group(1)?.trim() ?? '';
  }

  /// 上传一个本地文件到 COS。objectKey 形如 deepshart/snapshots/<deviceTag>/<file>。
  Future<void> uploadFile(String localPath, String objectKey) async {
    final file = File(localPath);
    if (!await file.exists()) throw StateError('待上传文件不存在：$localPath');
    final bytes = await file.readAsBytes();
    final code = await _requestBytes(
      method: 'PUT',
      objectKey: objectKey,
      body: bytes,
      contentType: 'application/octet-stream',
    );
    if (code != 200) throw StateError('上传失败（HTTP $code）');
    await prefs.setInt(_lastUploadKey, DateTime.now().millisecondsSinceEpoch);
  }

  /// 下载 COS 对象为字节。
  Future<List<int>> downloadBytes(String objectKey) async {
    final resp = await _request(method: 'GET', objectKey: objectKey);
    if (resp.statusCode != 200) {
      await resp.drain<void>();
      throw StateError('下载失败（HTTP ${resp.statusCode}）');
    }
    final bytes = <int>[];
    await for (final chunk in resp) {
      bytes.addAll(chunk);
    }
    return bytes;
  }

  /// 删除 COS 对象。
  Future<void> deleteObject(String objectKey) async {
    final code = await _requestBytes(method: 'DELETE', objectKey: objectKey, body: const <int>[]);
    if (code != 204 && code != 200) throw StateError('删除失败（HTTP $code）');
  }

  /// 人类可读的时间戳：年-月-日_时-分-秒（本地时间，便于一眼看出上传时刻）。
  String _readableStamp(DateTime at) {
    final local = at.toLocal();
    String two(int v) => v.toString().padLeft(2, '0');
    return '${local.year}-${two(local.month)}-${two(local.day)}'
        '_${two(local.hour)}-${two(local.minute)}-${two(local.second)}';
  }

  /// 生成"对话快照"的对象键（设备名 + 年月日_时分秒，保留历史便于回溯）。
  String snapshotKey(String deviceName, DateTime at) {
    final tag = deviceTag(deviceName);
    final stamp = _readableStamp(at);
    return '$_prefix/snapshots/$tag/${tag}_$stamp.db';
  }

  /// 生成"最新快照指针"的对象键（固定名，覆盖写——对端可直接取最新，无需遍历）。
  String latestSnapshotKey(String deviceName) {
    final tag = deviceTag(deviceName);
    return '$_prefix/snapshots/$tag/latest_$tag.db';
  }

  /// 生成"备份"的对象键（设备名 + 年月日_时分秒 + 原因）。
  String backupKey(String deviceName, DateTime at, String reason) {
    final tag = deviceTag(deviceName);
    final stamp = _readableStamp(at);
    return '$_prefix/backups/$tag/${tag}_${stamp}_$reason.db';
  }

  /// 生成"会话删除墓碑"操作文件的键（每台设备一份，按设备名区分，互不覆盖）。
  /// 内容为该设备删除过的会话内部 ID + 删除时间（JSON）。
  String tombstoneKey(String deviceName) {
    final tag = deviceTag(deviceName);
    return '$_prefix/tombstones/$tag.json';
  }

  /// 上传本机墓碑 JSON（覆盖写，始终是当前全量）。
  Future<void> uploadTombstones(String deviceName, Map<String, int> tombstones) async {
    final body = jsonEncode({'tombstones': tombstones});
    final code = await _requestBytes(
      method: 'PUT',
      objectKey: tombstoneKey(deviceName),
      body: utf8.encode(body),
      contentType: 'application/json',
    );
    if (code != 200) throw StateError('墓碑上传失败（HTTP $code）');
  }

  /// 下载某台设备的墓碑 JSON。
  Future<Map<String, int>> downloadTombstones(String objectKey) async {
    final bytes = await downloadBytes(objectKey);
    final decoded = jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
    final raw = decoded['tombstones'] as Map<String, dynamic>? ?? {};
    return {
      for (final e in raw.entries) e.key: (e.value as num).toInt(),
    };
  }
}
