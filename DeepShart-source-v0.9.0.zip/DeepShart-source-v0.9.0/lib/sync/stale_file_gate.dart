// target: lib/sync/stale_file_gate.dart
// 职责：疑似废弃同步文件的全局提醒闸门。与 sync_policy_gate 同款：
// 后台同步检测到 stale 文件 → report() 入队 → App 顶层宿主直接渲染弹窗
// （不用 Overlay.showDialog，因为 MaterialApp.router.builder 层没有 Overlay）。
// 用户选择"删除/保留"后 answer() 回填，驱动 tracker 改状态或删云端文件。

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'stale_sync_tracker.dart';

enum StaleChoice { delete, keep }

@immutable
class StaleFileRequest {
  /// 云端对象键（用于删除）。
  final String objectKey;

  /// 设备标签（用于 tracker 记状态）。
  final String deviceTag;

  final StaleLevel level;

  final Completer<StaleChoice> completer;

  const StaleFileRequest({
    required this.objectKey,
    required this.deviceTag,
    required this.level,
    required this.completer,
  });
}

class StaleFileGate extends StateNotifier<StaleFileRequest?> {
  StaleFileGate() : super(null);

  final List<StaleFileRequest> _queue = <StaleFileRequest>[];
  bool _uiReady = false;

  void registerUI() {
    _uiReady = true;
    _pump();
  }

  void unregisterUI() {
    _uiReady = false;
  }

  Future<StaleChoice> report({
    required String objectKey,
    required String deviceTag,
    required StaleLevel level,
  }) {
    final req = StaleFileRequest(
      objectKey: objectKey,
      deviceTag: deviceTag,
      level: level,
      completer: Completer<StaleChoice>(),
    );
    _queue.add(req);
    _pump();
    // 超时兜底为"保留"：绝不因为没人点而自动删除云端文件。
    return req.completer.future.timeout(
      const Duration(seconds: 180),
      onTimeout: () => StaleChoice.keep,
    );
  }

  void answer(StaleChoice choice) {
    final req = state;
    if (req == null) return;
    state = null;
    if (!req.completer.isCompleted) req.completer.complete(choice);
    _pump();
  }

  void _pump() {
    if (!_uiReady || state != null || _queue.isEmpty) return;
    state = _queue.removeAt(0);
  }
}

final staleFileGateProvider =
    StateNotifierProvider<StaleFileGate, StaleFileRequest?>((ref) => StaleFileGate());
