// target: lib/sync/snapshot_merge_service.dart
// 职责：把一份"完整数据库快照"（COS 下载的，或 P2P 对端传来的）逐条合并进本地库。
//
// 核心设计（用户明确要求：统一逻辑，不做两套）：
//   - 不再整库替换。快照里的每条消息走 MessageStore.insertOrMerge，
//     【向量时钟】自动区分两种情况：
//       * 单纯一方多聊（before/after 包含关系）→ 自动合并，不问用户；
//       * 真·方向冲突（concurrent）→ insertOrMerge 写入 ConflictRecord，
//         复用现有的冲突裁决 UI，由用户整体选一个版本。
//   - 会话/记忆点/压缩视图同理走各自 store 的 insertOrMerge。
//   - 这与 P2P 走的是【完全相同的合并语义】——COS 和 P2P 只差"数据怎么到达"，
//     落地合并共用这一套，不让用户面对两套割裂的逻辑。

import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:sqflite/sqflite.dart';

import '../data/models/chat_message.dart';
import '../data/models/important_memory.dart';
import 'backup_service.dart';
import '../data/store/conversation_store.dart';
import '../data/store/deleted_conversation_store.dart';
import '../data/store/important_memory_store.dart';
import '../data/store/message_store.dart';

/// 合并结果统计，供 UI 告诉用户"自动合并了多少、有几个冲突要选"。
@immutable
class MergeReport {
  final int messagesMerged;
  final int messagesIgnored;
  final int conflicts;
  final int memoriesMerged;
  final int conversationsMerged;
  final String? error;

  const MergeReport({
    this.messagesMerged = 0,
    this.messagesIgnored = 0,
    this.conflicts = 0,
    this.memoriesMerged = 0,
    this.conversationsMerged = 0,
    this.error,
  });

  bool get hasConflicts => conflicts > 0;

  /// conversationsMerged = -1 是内部约定的"整库已被对端覆盖"标记。
  bool get overwroteWholeDb => conversationsMerged < 0;

  String get summary {
    if (overwroteWholeDb) return '已用对端数据整库覆盖本机';
    return '自动合并 $messagesMerged 条消息、$memoriesMerged 条记忆点'
        '（重复 $messagesIgnored 条）'
        + (hasConflicts ? '；$conflicts 处方向冲突待你选择版本' : '；无冲突');
  }
}

/// 快照合并服务。
class SnapshotMergeService {
  final Database db;
  final MessageStore messageStore;
  final ImportantMemoryStore memoryStore;
  final ConversationStore conversationStore;
  final DeletedConversationStore deletedStore;

  SnapshotMergeService({
    required this.db,
    required this.messageStore,
    required this.memoryStore,
    required this.conversationStore,
    required this.deletedStore,
  });

  /// 把一个快照 db 文件合并进本地库。
  /// [snapshotPath] 是下载到本地的完整 .db 文件。
  Future<MergeReport> mergeFromSnapshot(String snapshotPath) async {
    if (!File(snapshotPath).existsSync()) {
      return const MergeReport(error: '快照文件不存在');
    }
    // 与备份回溯 / COS 上传共用同一把 db 锁：ATTACH 期间不能有人 VACUUM INTO。
    return BackupService.dbLock.run(() => _mergeFromSnapshotLocked(snapshotPath));
  }

  Future<MergeReport> _mergeFromSnapshotLocked(String snapshotPath) async {
    // 用唯一 alias，避免与可能存在的其它 ATTACH 冲突。
    const alias = 'snap_merge';
    final escaped = snapshotPath.replaceAll("'", "''");
    await db.execute("ATTACH DATABASE '$escaped' AS $alias");
    try {
      // 注意：不包裹外层事务——各 store 的 insertOrMerge 是独立原子操作，
      // 混用事务会让 store 的写入绕过 txn。逐条合并即可，正确性由向量时钟保证。
      var merged = 0, ignored = 0, conflicts = 0;
      var memories = 0, convs = 0;

      // ---- 墓碑过滤（用户明确要求）：已删除的会话不得死灰复燃 ----
      // 快照里若仍带着【本机已删 ID】的会话/消息，直接跳过，不插回本地库。
      // 墓碑存于本机数据库表，随整库备份/回溯一起恢复。
      final tombstones = await deletedStore.readAll();
      final deletedIds = tombstones.keys.toSet();

      // ---- 消息：核心。逐条 insertOrMerge，向量时钟自动判自动合并 vs 冲突 ----
      final msgRows = await db.rawQuery(
        'SELECT * FROM $alias.chat_messages WHERE deleted = 0',
      );
      for (final row in msgRows) {
        if (deletedIds.contains(row['conversation_id'])) continue;
        final msg = ChatMessage.fromJson(Map<String, dynamic>.from(row));
        final result = await messageStore.insertOrMerge(msg);
        if (result.hasConflict) {
          conflicts += result.conflicts.length;
        } else if (result.inserted || result.updated) {
          merged++;
        } else {
          ignored++;
        }
      }

      // ---- 会话：按 id 合并（会话本身冲突概率低，直接 upsert 较新的）----
      final convRows = await db.rawQuery('SELECT * FROM $alias.conversations');
      for (final row in convRows) {
        final map = Map<String, dynamic>.from(row);
        final id = map['id'] as String?;
        if (id == null || id.isEmpty) continue;
        if (deletedIds.contains(id)) continue; // 墓碑：已删会话不复活
        final local = await conversationStore.get(id);
        final remoteUpdated = (map['updated_at'] as num?)?.toInt() ?? 0;
        final localUpdated = local?.updatedAt.millisecondsSinceEpoch ?? 0;
        if (remoteUpdated > localUpdated) {
          await conversationStore.upsert(Conversation.fromJson(map));
          convs++;
        }
      }

      // ---- 记忆点：走 insertOrMerge，自带向量时钟，并发进裁决表 ----
      final memRows = await db.rawQuery(
        'SELECT * FROM $alias.important_memories WHERE deleted = 0',
      );
      for (final row in memRows) {
        final mem = ImportantMemory.fromJson(Map<String, dynamic>.from(row));
        final result = await memoryStore.insertOrMerge(mem);
        if (result.inserted || result.updated) memories++;
      }

      return MergeReport(
        messagesMerged: merged,
        messagesIgnored: ignored,
        conflicts: conflicts,
        memoriesMerged: memories,
        conversationsMerged: convs,
      );
    } catch (e) {
      return MergeReport(error: '合并失败：$e');
    } finally {
      await db.execute('DETACH DATABASE $alias');
    }
  }
}
