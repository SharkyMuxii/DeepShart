// target: lib/sync/sync_policy.dart
// 职责：统一的「同步行为」定义与全局闸门。用户要求（2026-11-20 修订）：
//   四种并列同步行为（P2P 与 COS 共用同一套）：
//     1) 智能合并（默认）：互补，真冲突写入 conflicts 表由裁决弹窗让用户选版本。
//     2) 以本机/本端为准：本机整库覆盖对端（会丢对端独有对话）。
//     3) 以对端为准：对端整库覆盖本机（会丢本机独有对话）。
//     4) 不同步：暂停 P2P 与 COS 两种同步方式（不改方案选择本身）。
// 行为是「全局默认」，正常同步直接按它静默执行、不弹窗。
// 【定夺窗只在静默同步出错时弹】：合并过程抛错、无法完成时，才询问用户手动选择，
// 并标注出错的同步方式（P2P / 腾讯云 COS）与错误详情。

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// 同步行为（四种并列）。
enum SyncPolicy {
  /// 智能合并：两边互补；真·方向冲突(concurrent)写入 conflicts 表由裁决弹窗选版本。
  merge,

  /// 以本机/本端为准：把本机整库快照推给对端并覆盖它（会丢对端独有对话）。
  localWins,

  /// 以对端为准：拉取对端整库快照覆盖本机（会丢本机独有对话）。
  remoteWins,

  /// 不同步：暂停 P2P 与 COS 两种同步方式（不影响 P2P/COS 的方案选择）。
  none,
}

extension SyncPolicyX on SyncPolicy {
  String get label => switch (this) {
        SyncPolicy.merge => '智能合并（推荐）',
        SyncPolicy.localWins => '以本机为准',
        SyncPolicy.remoteWins => '以对端为准',
        SyncPolicy.none => '不同步',
      };

  String get detail => switch (this) {
        SyncPolicy.merge =>
          '把两边的对话互补到一起；只有两边都改了、方向冲突的地方才再弹窗让你选。不会丢任何一边的对话。',
        SyncPolicy.localWins =>
          '用这台设备的全部数据覆盖对端。对端独有的对话会被删除——请确认对端没有你想保留的内容。覆盖前会自动保留一份本机备份。',
        SyncPolicy.remoteWins =>
          '用对端的全部数据覆盖这台设备。本机独有的对话会被删除——请确认本机没有你想保留的内容。覆盖前会自动保留一份本机备份。',
        SyncPolicy.none =>
          '暂停 P2P 直连与腾讯云 COS 两种方式的自动同步。不会改变你已选的同步方案，随时可在这里重新打开。',
      };

  /// 覆盖类行为（会导致数据丢失）的简短警示，用于设置页标注。
  bool get isOverwrite => this == SyncPolicy.localWins || this == SyncPolicy.remoteWins;

  String get overwriteHint => isOverwrite ? '会导致聊天记录丢失，仅建议在同步冲突时使用' : '';

  IconData get icon => switch (this) {
        SyncPolicy.merge => Icons.merge_type,
        SyncPolicy.localWins => Icons.upload_file,
        SyncPolicy.remoteWins => Icons.download,
        SyncPolicy.none => Icons.pause_circle_outline,
      };
}

/// 字符串名 → SyncPolicy（线路/存储兼容，缺省 merge）。
SyncPolicy syncPolicyFromName(String name) => switch (name) {
      'localWins' => SyncPolicy.localWins,
      'remoteWins' => SyncPolicy.remoteWins,
      'none' => SyncPolicy.none,
      _ => SyncPolicy.merge,
    };

// ---------------------------------------------------------------------------
// 全局默认同步行为：持久化在 SharedPreferences，P2P 与 COS 共用。
// 正常同步直接读它静默执行，不弹窗。
// ---------------------------------------------------------------------------
const String kSyncBehaviorKey = 'deepshart.sync_behavior';

/// 全局默认同步行为。默认智能合并。
final syncBehaviorProvider = StateProvider<SyncPolicy>((ref) => SyncPolicy.merge);

/// 启动时从本机存储加载默认同步行为，由 bootstrap 调用一次。
Future<SyncPolicy> loadSyncBehavior(SharedPreferences prefs) async =>
    syncPolicyFromName(prefs.getString(kSyncBehaviorKey) ?? 'merge');

/// 保存默认同步行为到本机。
Future<void> saveSyncBehavior(SharedPreferences prefs, SyncPolicy policy) async {
  await prefs.setString(kSyncBehaviorKey, policy.name);
}

// ---------------------------------------------------------------------------
// 同步方式来源：用于定夺窗标注"是哪条同步链路出错"。
// ---------------------------------------------------------------------------
enum SyncMethod { p2p, cos }

extension SyncMethodX on SyncMethod {
  String get label => this == SyncMethod.cos ? '腾讯云 COS' : 'P2P 直连';
}

/// 一次「出错定夺」请求。仅在静默同步失败时产生。
@immutable
class SyncPolicyRequest {
  /// 同步来源描述，例如「设备 DeepShart-1234」或「云端快照 · 平板A」。
  final String source;

  /// 出错的同步方式（标注给用户看）。
  final SyncMethod method;

  /// 错误详情（合并过程的具体异常）。
  final String errorDetail;

  final Completer<SyncPolicy> completer;

  const SyncPolicyRequest({
    required this.source,
    required this.method,
    required this.errorDetail,
    required this.completer,
  });
}

/// 全局出错定夺闸门。state 为当前正在等待用户选择的请求（null = 无）。
///
/// 与旧版区别：不再在每次同步前询问，只在【静默同步出错】时由同步层调用
/// askOnError 弹窗；用户的选择仅用于本次失败的处理，不改全局默认行为。
class SyncPolicyGate extends StateNotifier<SyncPolicyRequest?> {
  SyncPolicyGate() : super(null);

  final List<SyncPolicyRequest> _queue = <SyncPolicyRequest>[];
  bool _uiReady = false;

  /// App 顶层宿主挂载后调用，之后才会把请求推给 UI 弹窗。
  void registerUI() {
    _uiReady = true;
    _pump();
  }

  void unregisterUI() {
    _uiReady = false;
  }

  /// 静默同步出错后请求用户定夺。超时兜底为「智能合并」。
  Future<SyncPolicy> askOnError(
    String source, {
    required SyncMethod method,
    required String errorDetail,
  }) {
    final req = SyncPolicyRequest(
      source: source,
      method: method,
      errorDetail: errorDetail,
      completer: Completer<SyncPolicy>(),
    );
    _queue.add(req);
    _pump();
    return req.completer.future.timeout(
      const Duration(seconds: 180),
      onTimeout: () => SyncPolicy.merge,
    );
  }

  /// 兼容入口：等价 askOnError，默认按 P2P 来源处理（旧测试/旧调用）。
  Future<SyncPolicy> ask(String source) => askOnError(
        source,
        method: SyncMethod.p2p,
        errorDetail: '',
      );

  /// 用户做出选择后调用，推进队列。
  void answer(SyncPolicy policy) {
    final req = state;
    if (req == null) return;
    state = null;
    if (!req.completer.isCompleted) req.completer.complete(policy);
    _pump();
  }

  void _pump() {
    if (!_uiReady || state != null || _queue.isEmpty) return;
    state = _queue.removeAt(0);
  }
}

final syncPolicyGateProvider =
    StateNotifierProvider<SyncPolicyGate, SyncPolicyRequest?>((ref) => SyncPolicyGate());
