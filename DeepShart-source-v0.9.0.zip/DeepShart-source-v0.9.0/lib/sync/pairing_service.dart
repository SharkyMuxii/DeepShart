// target: lib/sync/pairing_service.dart
// 职责：实现 6 位配对码生成、带确认的配对握手状态机，以及确认后彼此 deviceId 的持久化。

import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:peer_rtc/peer_rtc.dart';
import 'package:uuid/uuid.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

import '../data/store/paired_device_store.dart';

// ============================================================================
// 关于信令与直连（重要架构说明）
// ----------------------------------------------------------------------------
// WebRTC 协议本身无法凭空建立连接：两端必须先通过某种"信令通道"交换 SDP/ICE。
// peer_rtc 是 PeerJS 的 Dart 移植，默认使用 PeerJS 公共云信令服务器完成这一次性
// 交换——它不是本项目自建的中央服务器，且仅用于握手；握手成功后聊天数据全部走
// RTCPeerConnection 的 DataChannel 端到端直连，不经任何中转。
// 配对码 = 临时的 peer id，因此"配对码交换"用的是带外渠道（用户口头/扫码传递），
// 一次性使用；确认后双方改用稳定的 deviceId 作为 peer id 长期重连。
//
// 稳定性设计（针对"点一下按钮整个客户端卡死然后闪退"）：
//  1. 所有建连动作都是 async，且先做信令可达性预检——不可达就立刻给出可读错误，
//     绝不把 UI 卡在"正在连接"里。
//  2. iceCandidatePoolSize 从 peer_rtc 默认的 10 改成 0。默认值会在
//     RTCPeerConnection 创建瞬间就向 5 个 Google STUN + 4 个公共 TURN 同时发起
//     ICE 收集；在没有网卡/网络受限的机器上，这一步最容易把原生 webrtc 线程拖死。
//  3. STUN 换成国内可达的服务器，并且默认不再挂公共 TURN 演示账号（那些人人都能
//     用的免费额度经常已失效，只会拖长 ICE 收集时间）。需要 TURN 时可自行注入。
//  4. 每个阶段都有超时与错误回调，失败一律落到 PairingRejected，由 UI 展示原因。
// ============================================================================

/// 本地设备身份，由上层注入（通常持久化在 SharedPreferences）。
@immutable
class LocalIdentity {
  final String deviceId;
  final String deviceName;

  const LocalIdentity({required this.deviceId, required this.deviceName});
}

/// 配对状态——用封闭的 sealed 类建模，而不是布尔标志位拼接。
/// 合法迁移：idle → codeGenerated → awaitingPeerConfirm → paired / rejected。
sealed class PairingState {
  const PairingState();
}

final class PairingIdle extends PairingState {
  const PairingIdle();
}

/// 正在做某件耗时的事（探测信令 / 建通道），UI 用这段文字告诉用户在等什么。
final class PairingWorking extends PairingState {
  final String message;
  const PairingWorking(this.message);
}

/// A 端已生成配对码，正在等待 B 接入。
final class PairingCodeGenerated extends PairingState {
  final String code;
  const PairingCodeGenerated(this.code);
}

/// B 已接入，正在等待其"确认配对"动作；host 侧持有关联的对端信息。
final class PairingAwaitingPeerConfirm extends PairingState {
  final String code;
  final PeerInfo peerInfo;
  const PairingAwaitingPeerConfirm({required this.code, required this.peerInfo});
}

final class PairingPaired extends PairingState {
  final PairedDevice peer;
  const PairingPaired(this.peer);
}

final class PairingRejected extends PairingState {
  final String reason;
  const PairingRejected(this.reason);
}

/// 对端在握手中暴露的标识，用于 B 端确认界面展示。
@immutable
class PeerInfo {
  final String deviceId;
  final String deviceName;

  const PeerInfo({required this.deviceId, required this.deviceName});

  Map<String, dynamic> toJson() => {'deviceId': deviceId, 'deviceName': deviceName};

  factory PeerInfo.fromJson(Map<String, dynamic> json) => PeerInfo(
        deviceId: json['deviceId'] as String,
        deviceName: json['deviceName'] as String,
      );
}

/// 驱动状态机的事件。事件与状态分离，保证每次迁移都可审计、可单测。
sealed class PairingEvent {
  const PairingEvent();
}

final class GenerateCode extends PairingEvent {
  const GenerateCode();
}

final class PeerConnected extends PairingEvent {
  final PeerInfo peerInfo;
  const PeerConnected(this.peerInfo);
}

final class ConfirmPairing extends PairingEvent {
  const ConfirmPairing();
}

final class RejectPairing extends PairingEvent {
  final String reason;
  const RejectPairing(this.reason);
}

final class ResetPairing extends PairingEvent {
  const ResetPairing();
}

/// 纯状态机：只负责"当前状态 + 事件 → 下一状态"的合法性判断，不碰网络。
///
/// 为什么单独抽出来：配对握手是典型的异步竞态场景（B 可能在 codeGenerated 之前
/// 就连入，用户可能重复点击确认）。集中迁移表可以让非法迁移直接抛错暴露，
/// 而不是靠散落的 if/isXxx 布尔判断导致状态漂移。
class PairingStateMachine {
  PairingState _state = const PairingIdle();
  PairingState get state => _state;

  /// 按 (当前状态, 事件) 返回下一状态；未定义的组合一律抛异常。
  PairingState transition(PairingEvent event) {
    final next = switch ((_state, event)) {
      // 失败可以从任意阶段发生：网络断了、信令不可达、对端拒绝……
      // 早期只允许从 awaitingPeerConfirm 失败，导致别处出错时直接抛 StateError，
      // UI 反而看不到任何原因。
      (_, RejectPairing(:final reason)) => PairingRejected(reason),
      (_, ResetPairing()) => const PairingIdle(),
      (PairingIdle(), GenerateCode()) =>
        PairingCodeGenerated(PairingCodeGenerator.generate()),
      (PairingCodeGenerated(:final code), PeerConnected(:final peerInfo)) =>
        PairingAwaitingPeerConfirm(code: code, peerInfo: peerInfo),
      (PairingAwaitingPeerConfirm(), ConfirmPairing()) =>
        // 具体 peer 数据在 service 层用 events 携带的上下文补齐；这里保留占位，
        // service 调用 transitionWithPeer 处理需要数据的迁移。
        throw StateError('ConfirmPairing requires peer context; use transitionWithPeer'),
      _ => throw StateError(
          'Illegal pairing transition: ${_state.runtimeType} + ${event.runtimeType}'),
    };
    _state = next;
    return next;
  }

  /// 带数据的确认迁移，单独成方法避免 sealed switch 数据传递过于拥挤。
  PairingState confirmWith(PairedDevice peer) {
    if (_state is! PairingAwaitingPeerConfirm) {
      throw StateError('confirmWith only valid in awaitingPeerConfirm');
    }
    _state = PairingPaired(peer);
    return _state;
  }

  PairingState forceState(PairingState state) {
    _state = state;
    return state;
  }
}

class PairingCodeGenerator {
  PairingCodeGenerator._();

  /// 生成 6 位数字码，前缀固定以便作为 peer id 与同步用的稳定 id 区分。
  static String generate() {
    final random = Random.secure();
    final value = random.nextInt(1000000);
    return value.toString().padLeft(6, '0');
  }

  static const String peerIdPrefix = 'DS-PAIR-';
  static const String stablePeerIdPrefix = 'DS-';

  static String pairPeerId(String code) => '$peerIdPrefix$code';
  static String stablePeerId(String deviceId) => '$stablePeerIdPrefix$deviceId';
}

/// 线路消息类型。配对阶段的数据量极小，直接用 JSON Map 走 DataChannel。
sealed class PairingWireMessage {
  const PairingWireMessage();

  Map<String, dynamic> toJson();

  static PairingWireMessage parse(Map<String, dynamic> json) {
    switch (json['type'] as String) {
      case 'hello':
        return HelloMessage(PeerInfo.fromJson(json['peer'] as Map<String, dynamic>));
      case 'confirm':
        return const ConfirmMessage();
      case 'reject':
        return RejectMessage(json['reason'] as String? ?? '对端拒绝了配对');
      default:
        throw FormatException('Unknown pairing wire type: ${json['type']}');
    }
  }
}

final class HelloMessage extends PairingWireMessage {
  final PeerInfo peer;
  const HelloMessage(this.peer);

  @override
  Map<String, dynamic> toJson() => {'type': 'hello', 'peer': peer.toJson()};
}

final class ConfirmMessage extends PairingWireMessage {
  const ConfirmMessage();

  @override
  Map<String, dynamic> toJson() => {'type': 'confirm'};
}

final class RejectMessage extends PairingWireMessage {
  final String reason;
  const RejectMessage(this.reason);

  @override
  Map<String, dynamic> toJson() => {'type': 'reject', 'reason': reason};
}

/// 配对服务：持有临时 peer_rtc 连接，驱动状态机，确认后落盘已配对设备。
class PairingService {
  final LocalIdentity local;
  final PairedDeviceStore store;

  final PairingStateMachine _machine = PairingStateMachine();
  final StreamController<PairingState> _stateController =
      StreamController<PairingState>.broadcast();

  /// B 端需要展示"是否确认与 A 配对"时，从此流取对端信息。
  final StreamController<PeerInfo> _confirmationRequest =
      StreamController<PeerInfo>.broadcast();

  Peer? _peer;
  DataConnection? _connection;
  PeerInfo? _remoteInfo;
  StreamSubscription<dynamic>? _onOpenSub;
  StreamSubscription<dynamic>? _onConnSub;
  StreamSubscription<dynamic>? _onDataSub;
  StreamSubscription<dynamic>? _onErrorSub;
  Timer? _helloTimeout;
  String? _currentCode;

  /// 一台设备只允许有一个 Peer；重复建连会抢同一个 peer id 并被服务端踢掉。
  bool _busy = false;

  PairingService({required this.local, required this.store});

  Stream<PairingState> get states => _stateController.stream;
  Stream<PeerInfo> get confirmationRequests => _confirmationRequest.stream;
  PairingState get currentState => _machine.state;

  /// 国内可达性更好的 STUN 列表。
  /// 不用 stun.l.google.com：在部分网络里它连不上，ICE 收集会一直等到超时。
  static const List<Map<String, dynamic>> _stunServers = <Map<String, dynamic>>[
    {'urls': 'stun:stun.qq.com:3478'},
    {'urls': 'stun:stun.miwifi.com:3478'},
    {'urls': 'stun:stun.chat.bilibili.com:3478'},
    {'urls': 'stun:stun.l.google.com:19302'},
  ];

  static Map<String, dynamic> get iceConfig => <String, dynamic>{
        'iceServers': _stunServers,
        'sdpSemantics': 'unified-plan',
        // 关键：不要预收集。默认的 10 会在 createPeerConnection 里立刻发起
        // 一轮 STUN/TURN，网络受限时会把这步拖成"点按钮就卡死"。
        'iceCandidatePoolSize': 0,
      };

  /// 信令可达性预检。返回 null 表示能连上；否则返回可读的错误。
  ///
  /// 为什么要单独探一次：PeerJS 的连接是 fire-and-forget，socket 失败只会
  /// 静默 close，UI 会一直停在"等待对方连接"。先探一次就能把"网络根本到不了
  /// 信令服务器"和"对方没在线"区分开，用户知道该换网络还是该找对方。
  static Future<String?> probeSignaling({
    Duration timeout = const Duration(seconds: 6),
  }) async {
    WebSocketChannel? channel;
    try {
      final probeId = 'DS-PROBE-${DateTime.now().microsecondsSinceEpoch}';
      channel = WebSocketChannel.connect(
        Uri.parse('wss://0.peerjs.com:443/peerjs?key=peerjs&id=$probeId&token=probe&version=1'),
      );
      await channel.ready.timeout(timeout);
      return null;
    } on TimeoutException {
      return '连接配对服务器超时（0.peerjs.com:443）。\n'
          '常见原因：① 当前网络屏蔽了该域名 ② DNS 被污染 ③ 代理/VPN 拦截。\n'
          '建议：换手机热点或关闭代理后重试。';
    } catch (e) {
      return '无法连接配对服务器（0.peerjs.com:443）：$e\n'
          '请换一个网络（例如手机热点）后重试。';
    } finally {
      try {
        await channel?.sink.close();
      } catch (_) {
        // 关闭失败无所谓，探测通道本来就是一次性的。
      }
    }
  }

  /// A 端：生成配对码并以配对码作为临时 peer id 等待 B 接入。
  Future<void> generateCode() async {
    if (_busy) return;
    _busy = true;
    try {
      if (_machine.state is! PairingIdle) reset();
      final state = _machine.transition(const GenerateCode()) as PairingCodeGenerated;
      _currentCode = state.code;
      _emit(state);

      _emit(const PairingWorking('正在检查配对服务器连通性…'));
      final probeError = await probeSignaling();
      if (probeError != null) {
        _fail(probeError);
        return;
      }

      // 先以"等待"状态展示配对码，再建 Peer——建连失败也不会让配对码消失。
      await _openPeer(
        peerId: PairingCodeGenerator.pairPeerId(state.code),
        workingMessage: '正在等待对方输入配对码…',
      );
      _emit(state);
    } catch (e) {
      _fail('生成配对码失败：$e');
    } finally {
      _busy = false;
    }
  }

  /// B 端：输入配对码，连接到 A 的临时 peer id；连接建立后主动交换 hello。
  Future<void> enterCode(String code) async {
    if (_busy) return;
    _busy = true;
    try {
      _currentCode = code.trim();
      _remoteInfo = null;

      _emit(const PairingWorking('正在检查配对服务器连通性…'));
      final probeError = await probeSignaling();
      if (probeError != null) {
        _fail(probeError);
        return;
      }

      final peer = await _openPeer(
        peerId: PairingCodeGenerator.stablePeerId(const Uuid().v4()),
        workingMessage: '正在协商点对点直连…（最长 20 秒）',
      );

      // 必须在 peer 的 socket 真正 open 之后再 connect：在未就绪的 Peer 上
      // 立刻创建 RTCPeerConnection 是 peer_rtc 最容易出问题的一条路径。
      final conn = peer.connect(PairingCodeGenerator.pairPeerId(_currentCode!));
      _bindConnection(conn);

      _helloTimeout?.cancel();
      _helloTimeout = Timer(const Duration(seconds: 20), () {
        if (_remoteInfo == null) {
          _fail('对方没有响应。\n'
              '请确认：① A 端仍停留在配对码页面 ② 两端都能正常上网 '
              '③ 配对码没有输错。');
        }
      });
    } catch (e) {
      _fail('连接失败：$e');
    } finally {
      _busy = false;
    }
  }

  Future<Peer> _openPeer({
    required String peerId,
    required String workingMessage,
  }) async {
    _disposePeer();
    _emit(PairingWorking(workingMessage));

    final peer = Peer(
      id: peerId,
      options: PeerOptions(
        config: iceConfig,
        // 关掉自动重连：重连风暴会不停重建 socket，用户体感就是"卡死"。
        autoReconnect: false,
        connectionTimeoutMs: 12000,
        debug: LogLevel.Disabled,
      ),
    );
    _peer = peer;

    _onConnSub = peer.onConnection.listen(_bindConnection);
    _onErrorSub = peer.onError.listen((error) {
      _fail('配对通道错误：$error');
    });

    // 等 socket 真正 open；超时就直接给出可操作的提示，而不是静静等下去。
    try {
      await peer.onOpen.first.timeout(const Duration(seconds: 10));
    } on TimeoutException {
      _fail('连接配对服务器超时。请换网络后重试。');
      throw TimeoutException('peer open timeout');
    }
    return peer;
  }

  void _bindConnection(DataConnection conn) {
    _connection = conn;
    _onDataSub?.cancel();
    _onDataSub = conn.onData.listen((data) {
      try {
        _handleWire(data);
      } catch (e) {
        _fail('收到无法识别的配对消息：$e');
      }
    });
    // 连接一开就互报身份；确认动作由用户在 B 端确认界面显式触发。
    conn.onOpen.listen((_) {
      _send(HelloMessage(PeerInfo(deviceId: local.deviceId, deviceName: local.deviceName)));
    });
    conn.onClose.listen((_) {
      if (_machine.state is PairingPaired) return;
      if (_remoteInfo == null) {
        _fail('连接已断开：对方可能取消配对或网络中断。');
      }
    });
  }

  Future<void> _handleWire(dynamic data) async {
    final raw = data is String ? _decode(data) : data;
    if (raw is! Map) return;
    final msg = PairingWireMessage.parse(Map<String, dynamic>.from(raw));

    switch (msg) {
      case HelloMessage(:final peer):
        _remoteInfo = peer;
        _helloTimeout?.cancel();
        // A/B 都进入"待确认"：A 等 B 点击确认，B 弹出确认界面。
        if (_machine.state is PairingCodeGenerated) {
          _emit(_machine.transition(PeerConnected(peer)));
        } else if (_machine.state is PairingIdle || _machine.state is PairingWorking) {
          _machine.forceState(
            const PairingCodeGenerated('inbound'),
          );
          _emit(_machine.transition(PeerConnected(peer)));
        }
        _confirmationRequest.add(peer);

      case ConfirmMessage():
        await _finishPaired();

      case RejectMessage(:final reason):
        _fail(reason);
    }
  }

  /// B 端用户点击"确认配对"。
  Future<void> confirm() async {
    if (_remoteInfo == null) {
      throw StateError('confirm called before peer identity exchange');
    }
    _send(const ConfirmMessage());
    await _finishPaired();
  }

  /// B 端用户点击"拒绝"。
  void reject() {
    _send(const RejectMessage('用户拒绝配对'));
    _fail('用户拒绝配对');
  }

  /// 重置配对流程，回到 idle，以便重新发起/重新配对。
  void reset() {
    _helloTimeout?.cancel();
    _helloTimeout = null;
    _disposePeer();
    _remoteInfo = null;
    _currentCode = null;
    if (_machine.state is! PairingIdle) {
      _emit(_machine.transition(const ResetPairing()));
    } else {
      _emit(const PairingIdle());
    }
  }

  Future<void> _finishPaired() async {
    final remote = _remoteInfo;
    if (remote == null) throw StateError('Missing remote peer info on confirm');
    if (_machine.state is PairingPaired) return;
    final device = PairedDevice(
      deviceId: remote.deviceId,
      deviceName: remote.deviceName,
      pairedAt: DateTime.now().toUtc(),
    );
    // 双方都把对方写入持久化列表——这是"确认后"才允许发生的副作用。
    await store.upsert(device);
    _emit(_machine.confirmWith(device));
  }

  void _send(PairingWireMessage message) {
    _connection?.send(message.toJson());
  }

  Map<String, dynamic>? _decode(String raw) {
    try {
      // peer_rtc 的 onData 通常已把 JSON 解成 Map；若收到字符串则在此兜底解析。
      return jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  void _emit(PairingState state) {
    if (!_stateController.isClosed) _stateController.add(state);
  }

  /// 统一的失败出口：清掉建连中资源，避免半死连接继续持有 peer id。
  void _fail(String reason) {
    _helloTimeout?.cancel();
    _helloTimeout = null;
    _remoteInfo = null;
    try {
      _emit(_machine.transition(RejectPairing(reason)));
    } catch (_) {
      _emit(PairingRejected(reason));
    }
  }

  void _disposePeer() {
    _onOpenSub?.cancel();
    _onConnSub?.cancel();
    _onDataSub?.cancel();
    _onErrorSub?.cancel();
    _onOpenSub = null;
    _onConnSub = null;
    _onDataSub = null;
    _onErrorSub = null;
    try {
      _connection?.dispose();
    } catch (_) {}
    _connection = null;
    try {
      _peer?.dispose();
    } catch (_) {}
    _peer = null;
  }

  Future<void> dispose() async {
    _helloTimeout?.cancel();
    _disposePeer();
    await _stateController.close();
    await _confirmationRequest.close();
  }
}
