// target: lib/sync/backup_service.dart
// 职责：同步/导入等破坏性操作前的整库备份，以及备份的列出、回溯与容量回收。
//
// 为什么这件事必须做（用户明确提出）：
//   同步会把对端的数据合进来、可能触发裁决与覆盖，一旦逻辑有偏差就是
//   "记忆被改坏了"。备份是唯一能兜住这种事故的东西——它不依赖任何业务逻辑正确。

import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

/// 一份备份的元信息。
@immutable
class BackupEntry {
  final String path;
  final String fileName;
  final DateTime createdAt;
  final int sizeBytes;

  /// 触发原因：sync / import / manual / restore。
  final String reason;

  /// 来源：local（本机）/ cloud（COS 云端下载）/ p2p（对端同步来的）。
  /// 仅用于 UI 区分图标；文件本体都保存在本机备份目录。
  final String source;

  const BackupEntry({
    required this.path,
    required this.fileName,
    required this.createdAt,
    required this.sizeBytes,
    required this.reason,
    this.source = 'local',
  });

  String get sizeLabel {
    if (sizeBytes >= 1024 * 1024) {
      return '${(sizeBytes / 1024 / 1024).toStringAsFixed(1)} MB';
    }
    return '${(sizeBytes / 1024).round()} KB';
  }

  String get timeLabel {
    final local = createdAt.toLocal();
    String two(int v) => v.toString().padLeft(2, '0');
    return '${local.year}-${two(local.month)}-${two(local.day)} '
        '${two(local.hour)}:${two(local.minute)}:${two(local.second)}';
  }

  String get reasonLabel => switch (reason) {
        'sync' => '同步前',
        'import' => '导入前',
        'restore' => '回溯前',
        _ => '手动',
      };
}

/// 极简互斥锁：保证全进程内 VACUUM INTO / ATTACH 这类互斥的 db 操作串行执行。
/// 回溯、备份、快照合并都会动同一个 db 连接，并发时会抛
/// "attempt to re-open an already-closed object" / "database is locked"。
class _DbLock {
  Future<void> _tail = Future.value();

  Future<T> run<T>(Future<T> Function() action) {
    final previous = _tail;
    final completer = Completer<void>();
    _tail = completer.future;
    return previous.catchError((_) {}).then((_) async {
      try {
        return await action();
      } finally {
        completer.complete();
      }
    });
  }
}

class BackupService {
  /// 进程级共享锁：与 snapshot_merge_service / cos 上传共用同一把锁。
  static final _DbLock dbLock = _DbLock();

  final Database db;
  final SharedPreferences prefs;

  /// 本机设备名，写入备份文件名做来源标注（本地回溯与 COS 云备份都靠它区分设备）。
  final String deviceName;

  BackupService({
    required this.db,
    required this.prefs,
    this.deviceName = '',
  });

  /// 设备名做文件名安全处理：去掉路径分隔符与控制字符，压缩空白，限长。
  String get _deviceTag {
    final cleaned = deviceName
        .replaceAll(RegExp(r'[\\/:*?"<>|\r\n\t]'), '_')
        .replaceAll(RegExp(r'\s+'), '_');
    final trimmed = cleaned.isEmpty ? 'device' : cleaned;
    return trimmed.length > 24 ? trimmed.substring(0, 24) : trimmed;
  }

  static const String enabledKey = 'deepshart.backup_enabled';
  static const String limitKey = 'deepshart.backup_limit_bytes';
  static const String autoSyncKey = 'deepshart.backup_before_sync';
  static const String autoImportKey = 'deepshart.backup_before_import';

  /// 默认上限 100MB（用户指定）。
  static const int defaultLimitBytes = 100 * 1024 * 1024;

  /// 至少保留最新一份，哪怕它本身已超过上限。
  static const int minKeep = 1;

  bool get enabled => prefs.getBool(enabledKey) ?? true;
  int get limitBytes => prefs.getInt(limitKey) ?? defaultLimitBytes;
  bool get autoBackupBeforeSync => prefs.getBool(autoSyncKey) ?? true;
  bool get autoBackupBeforeImport => prefs.getBool(autoImportKey) ?? true;

  Future<void> setEnabled(bool value) => prefs.setBool(enabledKey, value);
  Future<void> setLimitBytes(int value) => prefs.setInt(limitKey, value);
  Future<void> setBackupBeforeSync(bool value) => prefs.setBool(autoSyncKey, value);
  Future<void> setBackupBeforeImport(bool value) => prefs.setBool(autoImportKey, value);

  /// 备份目录：与数据库同级的 backups/。（公开给 COS 云备份编排层使用）
  Future<Directory> get backupDirectory async => _backupDir();

  /// 当前数据库文件路径（COS 快照上传用 VACUUM INTO 需要源路径）。
  String get dbFilePath => db.path;

  Future<Directory> _backupDir() async {
    final dbPath = db.path;
    final dir = Directory(p.join(p.dirname(dbPath), 'backups'));
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  /// 执行一次备份。
  ///
  /// 用 `VACUUM INTO` 而不是复制文件：
  ///   1) WAL 模式下直接 copy 可能拿到不一致的快照；
  ///   2) VACUUM INTO 会重写为紧凑文件，去掉空闲页，同等数据体积更小。
  /// 返回 null 表示未启用或被跳过。
  Future<BackupEntry?> backup({required String reason, bool force = false}) async {
    if (!force && !enabled) return null;

    final dir = await _backupDir();
    final now = DateTime.now();
    String two(int v) => v.toString().padLeft(2, '0');
    final stamp = '${now.year}${two(now.month)}${two(now.day)}-'
        '${two(now.hour)}${two(now.minute)}${two(now.second)}';
    // 文件名标注来源设备 + 原因 + 时间，便于本地回溯与云端分类识别。
    final base = '$stamp-$_deviceTag-$reason';
    // 同一秒内多次触发时加序号，避免覆盖。
    var file = File(p.join(dir.path, '$base.db'));
    var index = 1;
    while (await file.exists()) {
      file = File(p.join(dir.path, '$base-${index++}.db'));
    }

    // VACUUM 是特殊语句，不支持参数绑定，路径必须内联（单引号翻倍转义）。
    // 用共享锁串行化：避免与同步的 ATTACH / 另一个 VACUUM 并发导致 already-closed。
    final escapedPath = file.path.replaceAll("'", "''");
    await dbLock.run(() => db.execute("VACUUM INTO '$escapedPath'"));

    final entry = BackupEntry(
      path: file.path,
      fileName: p.basename(file.path),
      createdAt: now,
      sizeBytes: await file.length(),
      reason: reason,
    );
    await enforceLimit();
    return entry;
  }

  /// 同步前的自动备份（带节流）。
  ///
  /// 为什么节流：自动同步可能在启动、重连、手动点按等场景连续触发，
  /// 每次都备一份会在几分钟内把 100MB 配额刷满、把有用备份挤掉。
  Future<BackupEntry?> backupBeforeSync() async {
    if (!enabled || !autoBackupBeforeSync) return null;
    final entries = await list();
    for (final entry in entries) {
      if (entry.reason != 'sync') continue;
      if (DateTime.now().difference(entry.createdAt).inSeconds < 60) return null;
      break;
    }
    return backup(reason: 'sync');
  }

  /// 导入前的自动备份。
  Future<BackupEntry?> backupBeforeImport() async {
    if (!enabled || !autoBackupBeforeImport) return null;
    return backup(reason: 'import');
  }

  /// 列出全部备份（按时间倒序）。
  Future<List<BackupEntry>> list() async {
    final dir = await _backupDir();
    final files = await dir
        .list()
        .where((e) => e is File && e.path.endsWith('.db'))
        .cast<File>()
        .toList();

    final entries = <BackupEntry>[];
    for (final file in files) {
      final stat = await file.stat();
      final name = p.basename(file.path);
      // 来源推断：cloud- = COS 云端下载，shared_ = P2P 对端同步，其余为本机。
      final source = name.startsWith('cloud-')
          ? 'cloud'
          : (name.startsWith('shared_') ? 'p2p' : 'local');
      entries.add(BackupEntry(
        path: file.path,
        fileName: name,
        createdAt: stat.modified,
        sizeBytes: stat.size,
        // 文件名格式：20261118-213045-sync.db
        reason: _reasonFromName(name),
        source: source,
      ));
    }
    entries.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return entries;
  }

  String _reasonFromName(String name) {
    // 新格式 stamp-device-reason[-seq]，旧格式 stamp-reason[-seq]。
    // reason 只可能是这几个固定值，直接在结尾匹配，避免被设备名里的 '-' 干扰。
    final stem = name.replaceAll(RegExp(r'\.db$'), '');
    for (final r in const ['sync', 'import', 'restore', 'manual']) {
      if (RegExp('-$r(?:-\\d+)?\$').hasMatch(stem)) return r;
    }
    // 兼容旧文件名（stamp-reason，且 reason 在中间）：找任一已知片段。
    for (final r in const ['sync', 'import', 'restore']) {
      if (stem.contains('-$r')) return r;
    }
    return 'manual';
  }

  /// 超过上限时从最旧的开始删，直到总量 ≤ 上限；至少保留最新一份。
  ///
  /// 为什么"至少留一份"：上限设得很小（比如 1MB）而库本身有 5MB 时，
  /// 若严格按上限执行就会把唯一一份也删掉——那等于备份功能从未存在过。
  Future<int> enforceLimit() async {
    final entries = await list();
    var total = entries.fold<int>(0, (s, e) => s + e.sizeBytes);
    final limit = limitBytes;

    var removed = 0;
    // 从最旧的开始删。
    for (var i = entries.length - 1; i >= 0 && total > limit; i--) {
      if (entries.length - removed <= minKeep) break;
      final file = File(entries[i].path);
      if (await file.exists()) {
        final size = await file.length();
        await file.delete();
        total -= size;
        removed++;
      }
    }
    return removed;
  }

  Future<void> delete(String path) async {
    final file = File(path);
    if (await file.exists()) await file.delete();
  }

  /// 从备份回溯。
  ///
  /// 实现方式：先把当前状态再备一份（防止"回错站"），再用 ATTACH 把备份库的
  /// 每张表数据搬回当前库——这样不需要关闭/重开数据库连接，UI 也不会失联。
  ///
  /// 注意：只搬数据不搬表结构。旧备份可能缺新列，按列名取交集后写入，
  /// 缺的列用默认值，保证"老备份也能恢复"。
  Future<BackupEntry?> restore(String backupPath) async {
    if (!await File(backupPath).exists()) {
      throw FileSystemException('备份文件不存在', backupPath);
    }

    // 回溯前先给当前状态留一份，避免用户回错站后无路可退。
    // safety 备份失败不该阻断回溯本身——降级为 null，继续搬数据。
    BackupEntry? safety;
    try {
      safety = await backup(reason: 'restore', force: true);
    } catch (_) {}

    // 整段 ATTACH → 搬数据 → DETACH 都用共享锁串行化，避免与同步/其它
    // VACUUM INTO 并发导致 "already-closed object" / "database is locked"。
    return dbLock.run(() => _restoreLocked(backupPath, safety));
  }

  Future<BackupEntry?> _restoreLocked(String backupPath, BackupEntry? safety) async {
    // ATTACH 同样按字面量拼接（参数绑定在部分 SQLite 版本上对 ATTACH 无效）。
    final escapedBackup = backupPath.replaceAll("'", "''");
    await db.execute("ATTACH DATABASE '$escapedBackup' AS backup");
    try {
      final tables = await db.rawQuery(
        "SELECT name FROM backup.sqlite_master WHERE type='table' "
        "AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '%_fts%'",
      );

      // 备份库里每张表的建表 SQL（用于主库缺表时补齐）。
      final createSql = <String, String>{};
      for (final row in await db.rawQuery(
        "SELECT name, sql FROM backup.sqlite_master WHERE type='table' "
        "AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '%_fts%'",
      )) {
        final name = row['name']?.toString() ?? '';
        final sql = row['sql']?.toString();
        if (name.isNotEmpty && sql != null) createSql[name] = sql;
      }

      await db.transaction((txn) async {
        for (final row in tables) {
          final table = row['name']?.toString() ?? '';
          if (table.isEmpty) continue;

          // 关键修复：必须限定 main. —— ATTACH 后 unqualified 的 PRAGMA table_info
          // 会搜到 backup 库的表，导致误判主库有该表，随后 INSERT INTO main.xxx 报
          // "no such table"（用户实测回溯失败）。
          var current = await txn.rawQuery('PRAGMA main.table_info($table)');
          if (current.isEmpty) {
            // 主库还没有这张表（对应 Store 尚未懒加载建表）→ 用备份的建表 SQL 补建。
            final sql = createSql[table];
            if (sql != null && sql.isNotEmpty) {
              await txn.execute(sql);
              current = await txn.rawQuery('PRAGMA main.table_info($table)');
            }
          }
          if (current.isEmpty) continue;
          final currentCols =
              current.map((c) => c['name']?.toString() ?? '').toSet();

          final backupInfo = await txn.rawQuery('PRAGMA backup.table_info($table)');
          final shared = backupInfo
              .map((c) => c['name']?.toString() ?? '')
              .where(currentCols.contains)
              .toList();
          if (shared.isEmpty) continue;

          final cols = shared.join(', ');
          await txn.execute('DELETE FROM main.$table');
          await txn.rawInsert(
            'INSERT INTO main.$table ($cols) SELECT $cols FROM backup.$table',
          );
        }
      });
    } finally {
      await db.execute('DETACH DATABASE backup');
    }
    return safety;
  }

  /// 备份总占用，供设置页显示"已用 X / 上限 Y"。
  Future<int> totalBytes() async {
    final entries = await list();
    return entries.fold<int>(0, (s, e) => s + e.sizeBytes);
  }
}
