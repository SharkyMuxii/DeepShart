// target: lib/sync/sync_engine.dart
// 职责：启动时自动连接已配对设备，交换向量时钟摘要，计算缺失增量并通过 DataChannel 同步落地。

import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'dart:convert';

import 'package:offline_sync_engine/offline_sync_engine.dart';
import 'package:path/path.dart' as p;
import 'package:peer_rtc/peer_rtc.dart' as rtc;
import 'package:shared_preferences/shared_preferences.dart';

import '../data/models/chat_message.dart';
import '../data/models/compaction_view.dart';
import '../data/models/important_memory.dart';
import '../data/models/session_summary.dart';
import '../data/store/compaction_view_store.dart';
import '../data/store/conversation_store.dart';
import '../data/store/deleted_conversation_store.dart';
import '../data/store/important_memory_store.dart';
import '../data/store/message_store.dart';
import '../data/store/paired_device_store.dart';
import 'backup_service.dart';
import 'pairing_service.dart';
import 'snapshot_merge_service.dart';
import 'sync_policy.dart';

// ============================================================================
// offline_sync_engine 的使用边界（核心设计决策）
// ----------------------------------------------------------------------------
// 该包提供 VersionTracker（向量时钟）与 isConcurrent()/dominates() —— 我们只借用
// 这两个"检测并发"的原语。它的 SyncRecord.merge() 会自动确定性合并，这与本项目
// "冲突必须由用户裁决"的决策相悖，因此这里【刻意不调用】merge()。
// 流程：VersionTracker 检测 → 若并发/缺失则把完整 ChatMessage 交给
// MessageStore.insertOrMerge → 由 store 生成 ConflictRecord 交 UI 裁决。
// 这样既复用了 CRDT 的检测语义，又完全保留了用户最终选择权。
// ============================================================================

/// 按估算大小把列表切成多段，保证单条 DataChannel 消息不会超限。
///
/// 为什么必须有：1314 条消息一次性 JSON 化约 700KB，远超 SCTP 单帧上限，
/// send 会静默失败——用户看到的就是"一直同步中，什么也没同步"。
@visibleForTesting
List<List<T>> chunkByEstimatedSize<T>(
  List<T> items,
  int Function(T item) sizeOf, {
  int maxChars = 48 * 1024,
}) {
  final chunks = <List<T>>[];
  var current = <T>[];
  var size = 0;
  for (final item in items) {
    final itemSize = sizeOf(item);
    if (current.isNotEmpty && size + itemSize > maxChars) {
      chunks.add(current);
      current = <T>[];
      size = 0;
    }
    current.add(item);
    size += itemSize;
  }
  if (current.isNotEmpty) chunks.add(current);
  return chunks;
}

/// 同步线路消息。
sealed class SyncWireMessage {
  const SyncWireMessage();

  Map<String, dynamic> toJson();

  static SyncWireMessage parse(Map<String, dynamic> json) {
    switch (json['type'] as String) {
      case 'summary':
        return VectorSummaryMessage(
          entries: (json['entries'] as List<dynamic>)
              .map((e) => VectorSummaryEntry.fromJson(e as Map<String, dynamic>))
              .toList(),
          isLast: json['last'] as bool? ?? true,
        );
      case 'delta':
        return DeltaMessage(
          messages: (json['messages'] as List<dynamic>)
              .map((e) => ChatMessage.fromJson(e as Map<String, dynamic>))
              .toList(),
          isLast: json['last'] as bool? ?? true,
        );
      case 'conversations':
        return ConversationsMessage(
          conversations: (json['conversations'] as List<dynamic>)
              .map((e) => Conversation.fromJson(e as Map<String, dynamic>))
              .toList(),
        );
      case 'bye':
        return const ByeMessage();
      case 'views':
        return ViewsMessage(
          views: (json['views'] as List<dynamic>)
              .map((e) => CompactionView.fromJson(e as Map<String, dynamic>))
              .toList(),
          isLast: json['last'] as bool? ?? true,
        );
      case 'memories':
        return MemoriesMessage(
          memories: (json['memories'] as List<dynamic>)
              .map((e) => ImportantMemory.fromJson(e as Map<String, dynamic>))
              .toList(),
          isLast: json['last'] as bool? ?? true,
        );
      case 'summaries':
        return SummariesMessage(
          summaries: (json['summaries'] as List<dynamic>)
              .map((e) => SessionSummary.fromJson(e as Map<String, dynamic>))
              .toList(),
          isLast: json['last'] as bool? ?? true,
        );
      case 'backups':
        return BackupsMessage(
          fromDevice: json['fromDevice'] as String? ?? '对端设备',
          fileName: json['fileName'] as String? ?? 'backup.db',
          base64Content: json['data'] as String? ?? '',
          isLast: json['last'] as bool? ?? true,
        );
      case 'policy':
        return PolicyMessage(
          policy: json['policy'] as String? ?? 'merge',
          fromDevice: json['fromDevice'] as String? ?? '对端设备',
        );
      case 'overwrite':
        return OverwriteSnapshotMessage(
          fromDevice: json['fromDevice'] as String? ?? '对端设备',
          base64Content: json['data'] as String? ?? '',
          isLast: json['last'] as bool? ?? true,
        );
      case 'snapshot_exchange':
        return SnapshotExchangeMessage(
          fromDevice: json['fromDevice'] as String? ?? '对端设备',
          base64Content: json['data'] as String? ?? '',
          isLast: json['last'] as bool? ?? true,
        );
      default:
        throw FormatException('Unknown sync wire type: ${json['type']}');
    }
  }
}

/// 一条消息的 (id, 向量时钟) 摘要——用于判断对方是否已有该版本。
class VectorSummaryEntry {
  final String messageId;
  final Map<String, int> vector;

  const VectorSummaryEntry({required this.messageId, required this.vector});

  Map<String, dynamic> toJson() => {
        'messageId': messageId,
        'vector': vector,
      };

  factory VectorSummaryEntry.fromJson(Map<String, dynamic> json) => VectorSummaryEntry(
        messageId: json['messageId'] as String,
        vector: (json['vector'] as Map).map((k, v) => MapEntry(k as String, (v as num).toInt())),
      );
}

class VectorSummaryMessage extends SyncWireMessage {
  final List<VectorSummaryEntry> entries;

  /// 分片标记：长摘要必须拆成多条，否则单条 SCTP 消息超过 256KB 会直接失败。
  final bool isLast;

  const VectorSummaryMessage({required this.entries, this.isLast = true});

  @override
  Map<String, dynamic> toJson() => {
        'type': 'summary',
        'entries': entries.map((e) => e.toJson()).toList(),
        'last': isLast,
      };
}

class DeltaMessage extends SyncWireMessage {
  final List<ChatMessage> messages;
  final bool isLast;

  const DeltaMessage({required this.messages, this.isLast = true});

  @override
  Map<String, dynamic> toJson() => {
        'type': 'delta',
        'messages': messages.map((m) => m.toJson()).toList(),
        'last': isLast,
      };
}

class ByeMessage extends SyncWireMessage {
  const ByeMessage();

  @override
  Map<String, dynamic> toJson() => {'type': 'bye'};
}

/// 压缩视图交换。
///
/// 为什么压缩也要同步：视图决定了"哪些老内容以摘要形式出现"，两端视图不一致
/// 会让同一条对话在两台设备上得到不同回答。但**不一致时不自动覆盖**——按用户
/// 要求，先同步消息、再同步视图、最后由用户选一边。
class ViewsMessage extends SyncWireMessage {
  final List<CompactionView> views;
  final bool isLast;

  const ViewsMessage({required this.views, this.isLast = true});

  @override
  Map<String, dynamic> toJson() => {
        'type': 'views',
        'views': views.map((v) => v.toJson()).toList(),
        'last': isLast,
      };
}

/// 记忆点同步。按 id + 向量时钟走 insertOrMerge，冲突交给记忆点自己的裁决表。
class MemoriesMessage extends SyncWireMessage {
  final List<ImportantMemory> memories;
  final bool isLast;

  const MemoriesMessage({required this.memories, this.isLast = true});

  @override
  Map<String, dynamic> toJson() => {
        'type': 'memories',
        'memories': memories.map((m) => m.toJson()).toList(),
        'last': isLast,
      };
}

/// 会话摘要同步：按"较新版本优先"（用户明确指定）。
class SummariesMessage extends SyncWireMessage {
  final List<SessionSummary> summaries;
  final bool isLast;

  const SummariesMessage({required this.summaries, this.isLast = true});

  @override
  Map<String, dynamic> toJson() => {
        'type': 'summaries',
        'summaries': summaries.map((s) => s.toJson()).toList(),
        'last': isLast,
      };
}

/// 备份文件同步（P2P）。base64 编码的 .db 备份 + 来源设备名 + 原文件名。
/// 只传小体积备份（≤1MB），避免单帧与 100MB 配额失控。分片用 isLast 标记收齐。
class BackupsMessage extends SyncWireMessage {
  final String fromDevice;
  final String fileName;
  final String base64Content;
  final bool isLast;

  const BackupsMessage({
    required this.fromDevice,
    required this.fileName,
    required this.base64Content,
    this.isLast = true,
  });

  @override
  Map<String, dynamic> toJson() => {
        'type': 'backups',
        'fromDevice': fromDevice,
        'fileName': fileName,
        'data': base64Content,
        'last': isLast,
      };
}

/// 会话元数据（标题/时间）。
///
/// 为什么必须单独同步：消息是按 conversationId 归属的，但对端如果没有该会话的
/// 元数据行，会话列表就查不到它——表现为"消息同步了但列表里看不到"。因此连接
/// 建立时先把整张会话表推过去，对端只补齐缺失项，不覆盖已有标题（本地重命名优先）。
class ConversationsMessage extends SyncWireMessage {
  final List<Conversation> conversations;
  const ConversationsMessage({required this.conversations});

  @override
  Map<String, dynamic> toJson() => {
        'type': 'conversations',
        'conversations': conversations.map((c) => c.toJson()).toList(),
      };
}

/// 同步策略决策：由发起同步的一端选定，通过线路告知对端，避免两端各弹一次窗
/// 得出矛盾结论。策略值用 sync_policy.dart 的 SyncPolicy.name（merge/localWins/remoteWins）。
class PolicyMessage extends SyncWireMessage {
  final String policy;
  final String fromDevice;

  const PolicyMessage({required this.policy, required this.fromDevice});

  @override
  Map<String, dynamic> toJson() => {
        'type': 'policy',
        'policy': policy,
        'fromDevice': fromDevice,
      };
}

/// 整库覆盖载荷：把发起端 VACUUM 出来的完整 db 以 base64 分片发给对端，
/// 对端收齐后调用 backupService.restore() 整库替换。仅当用户选"覆盖"时发送。
class OverwriteSnapshotMessage extends SyncWireMessage {
  final String fromDevice;
  final String base64Content;
  final bool isLast;

  const OverwriteSnapshotMessage({
    required this.fromDevice,
    required this.base64Content,
    this.isLast = true,
  });

  @override
  Map<String, dynamic> toJson() => {
        'type': 'overwrite',
        'fromDevice': fromDevice,
        'data': base64Content,
        'last': isLast,
      };
}

/// 双向快照交换载荷：与 COS 对齐——每次同步双方各自提交自己的整库快照，
/// 收到对端快照后按全局行为落地（merge 走 SnapshotMergeService，覆盖策略走 restore）。
/// 与 OverwriteSnapshotMessage 的区别：那个是"我要你整库换成我的"，这个是"我们各自交快照互补"。
class SnapshotExchangeMessage extends SyncWireMessage {
  final String fromDevice;
  final String base64Content;
  final bool isLast;

  const SnapshotExchangeMessage({
    required this.fromDevice,
    required this.base64Content,
    this.isLast = true,
  });

  @override
  Map<String, dynamic> toJson() => {
        'type': 'snapshot_exchange',
        'fromDevice': fromDevice,
        'data': base64Content,
        'last': isLast,
      };
}

/// 单台设备的同步会话状态。
enum PeerSyncStatus { connecting, exchanging, synced, failed, offline }

class PeerSyncState {
  final String deviceId;
  final PeerSyncStatus status;
  final String? error;

  /// 同步结论摘要，例如"收到 32 条 / 发出 5 条"。
  final String? note;

  const PeerSyncState({
    required this.deviceId,
    required this.status,
    this.error,
    this.note,
  });
}

/// 同步引擎。启动时对每个已配对设备尝试连接；连接成功后进入摘要交换与增量同步。
class SyncEngine {
  final MessageStore store;
  final ConversationStore conversationStore;
  final PairedDeviceStore pairedStore;
  final LocalIdentity local;

  /// 压缩视图与记忆点的存储：同步不再只交换消息。
  final CompactionViewStore viewStore;
  final ImportantMemoryStore memoryStore;

  /// 会话删除墓碑：接收 P2P 增量时过滤已删会话，防止本机删过的会话被对端复活。
  final DeletedConversationStore? deletedStore;

  /// 双向快照交换：把对端发来的整库快照落地（走与 COS 相同的 SnapshotMergeService）。
  /// 由 provider 注入；未注入时收到对端快照走旧的整库 restore 兜底。
  final Future<MergeReport> Function(String snapshotPath)? mergeSnapshotFromFile;

  /// 用于持久化"压缩视图待裁决"状态：重启后用户仍能看到那次冲突。
  final SharedPreferences prefs;

  /// 同步前的自动备份。为 null 时不备份（例如测试环境未装配）。
  ///
  /// 为什么放在这里而不是 UI 层：同步有多个入口（启动自动、配对后首次、
  /// 手动点按），散落在 UI 各处容易漏。集中在 syncNow/start 里兜底最可靠。
  final BackupService? backupService;

  final StreamController<PeerSyncState> _statusController =
      StreamController<PeerSyncState>.broadcast();

  /// 压缩视图待裁决通知（会话 id）。UI 订阅后弹出"选一边"的窗口。
  final StreamController<String> _viewConflicts = StreamController<String>.broadcast();

  /// 整个引擎只持有一个 Peer。
  ///
  /// 之前是"每台设备一个 Peer"，但它们都用 `DS-<本机 deviceId>` 作为 id，
  /// 第二个 Peer 注册上去就会被服务端判为 id 占用并踢掉第一个，两台设备都连不稳。
  rtc.Peer? _peer;
  bool _openingPeer = false;

  final Map<String, rtc.DataConnection> _outgoing = <String, rtc.DataConnection>{};
  final Map<String, Timer> _connectTimers = <String, Timer>{};
  final List<StreamSubscription<dynamic>> _subscriptions = <StreamSubscription<dynamic>>[];

  /// 已绑定过监听的数据通道，避免 dial 与 onConnection 两条路径重复绑定
  /// 造成同一帧被处理两次（重复推送/重复冲突记录）。
  final Set<String> _boundConnections = <String>{};

  /// 已经启动过摘要交换的连接（按 deviceId:hash），防止重复推送。
  final Set<String> _startedExchanges = <String>{};

  /// 分片接收缓冲：长摘要/长增量都要按 last 标记收齐再处理。
  final Map<String, List<VectorSummaryEntry>> _summaryBuffers = <String, List<VectorSummaryEntry>>{};
  final Map<String, int> _received = <String, int>{};
  final Map<String, int> _sent = <String, int>{};

  /// 整库覆盖：某设备是否处于覆盖模式（收到非 merge 策略时置位）。
  final Map<String, bool> _coverMode = <String, bool>{};

  /// 整库覆盖载荷的分片累积缓冲（base64 解码后的原始字节）。
  final Map<String, BytesBuilder> _overwriteBuffers = <String, BytesBuilder>{};

  /// 双向快照交换的分片缓冲（与覆盖分开，避免两种载荷混在一起）。
  final Map<String, BytesBuilder> _snapshotExchangeBuffers = <String, BytesBuilder>{};

  /// 覆盖落地后的 UI 刷新回调（由 provider 注入 invalidate）。
  final VoidCallback? onOverwriteApplied;

  /// 同步策略闸门：仅在【静默同步出错】时才询问用户，把结果通过线路告知对端。
  final SyncPolicyGate? policyGate;

  /// 读取全局默认同步行为（P2P/COS 共用）。正常同步直接按它静默执行、不弹窗。
  /// 由 provider 注入；未注入时退回 merge。
  final SyncPolicy Function() readBehavior;

  /// 覆盖操作前先留一份本机备份的钩子（用户明确要求）。由 provider 注入。
  final Future<void> Function()? backupBeforeOverwrite;

  /// 出错定夺后，用户选的新行为写回全局默认的钩子。由 provider 注入。
  /// 未注入时用户的定夺只作用于本次提示，不改全局。
  final Future<void> Function(SyncPolicy policy)? applyErrorDecision;

  SyncEngine({
    required this.store,
    required this.conversationStore,
    required this.pairedStore,
    required this.local,
    required this.viewStore,
    required this.memoryStore,
    required this.prefs,
    this.deletedStore,
    this.mergeSnapshotFromFile,
    this.backupService,
    this.policyGate,
    this.onOverwriteApplied,
    SyncPolicy Function()? readBehavior,
    this.backupBeforeOverwrite,
    this.applyErrorDecision,
  }) : readBehavior = readBehavior ?? (() => SyncPolicy.merge);

  Stream<PeerSyncState> get statuses => _statusController.stream;

  /// P2P 同时只与【一台】已配对设备同步，其余排队。
  /// 用户明确要求：一次只允许两台设备互相同步，第三台及更多等前两台结束再轮，
  /// 以防并发数据交叉导致 bug。P2P 也【只连配对过的设备】——队列来源就是 pairedStore。
  final List<String> _syncQueue = <String>[];
  bool _queueRunning = false;
  String? _activeSyncDevice;

  /// 全局行为是"不同步"时，暂停 P2P 同步（不改配对方案本身）。
  bool get _paused => readBehavior() == SyncPolicy.none;

  /// 应用启动后调用：把已配对设备依次入队串行同步。
  Future<void> start() async {
    if (_paused) return;
    final devices = await pairedStore.loadAll();
    if (devices.isEmpty) return;
    await _backupBeforeSync();
    for (final device in devices) {
      enqueueDevice(device.deviceId);
    }
  }

  /// 手动触发一次同步：清空队列、断开旧通道，重新串行同步所有配对设备。
  Future<void> syncNow() async {
    if (_paused) return;
    final devices = await pairedStore.loadAll();
    await _backupBeforeSync();
    _syncQueue.clear();
    for (final device in devices) {
      _outgoing.remove(device.deviceId)?.dispose();
      _connectTimers.remove(device.deviceId)?.cancel();
    }
    for (final device in devices) {
      enqueueDevice(device.deviceId);
    }
  }

  /// 把一台【已配对】设备加入同步队列（去重）。
  void enqueueDevice(String deviceId) {
    if (!_syncQueue.contains(deviceId)) _syncQueue.add(deviceId);
    // 不 await：让 start()/syncNow() 立即返回，避免 bootstrap 被等待阻塞。
    _pumpQueue();
  }

  /// 推进队列：一次只连一台，等它 settled 再连下一台。
  Future<void> _pumpQueue() async {
    if (_queueRunning || _activeSyncDevice != null || _syncQueue.isEmpty) return;
    _queueRunning = true;
    try {
      while (_syncQueue.isNotEmpty) {
        final deviceId = _syncQueue.removeAt(0);
        _activeSyncDevice = deviceId;
        await _connectTo(deviceId);
        // 等这台设备同步结束（synced 或 failed）才继续。
        await _waitForSettled(deviceId);
        _activeSyncDevice = null;
      }
    } finally {
      _queueRunning = false;
    }
  }

  /// 等待某台设备的同步收敛信号。
  Completer<void>? _settledCompleter;
  String? _settledForDevice;

  Future<void> _waitForSettled(String deviceId) async {
    // 若已经 settled（极快完成），直接返回。
    if (_settledForDevice == deviceId) {
      _settledForDevice = null;
      return;
    }
    _settledCompleter = Completer<void>();
    _settledForDevice = deviceId;
    // 兜底超时，防止任何异常路径导致队列永久卡死。
    await _settledCompleter!.future.timeout(
      const Duration(seconds: 40),
      onTimeout: () {},
    );
  }

  void _onDeviceSettled(String deviceId) {
    if (_settledForDevice == deviceId) {
      _settledForDevice = null;
      final c = _settledCompleter;
      _settledCompleter = null;
      if (c != null && !c.isCompleted) c.complete();
    }
  }

  /// 同步前备份的兜底封装：备份失败绝不影响同步主流程。
  Future<void> _backupBeforeSync() async {
    try {
      await backupService?.backupBeforeSync();
    } catch (_) {
      // 备份是保险不是前提：失败就静默跳过，不能因此卡住同步。
    }
  }

  /// 建一次 Peer 并等它 open；失败时所有设备都标记为"连接失败"。
  Future<bool> _ensurePeer() async {
    if (_peer != null) return true;
    if (_openingPeer) return false;
    _openingPeer = true;
    try {
      final peer = rtc.Peer(
        id: PairingCodeGenerator.stablePeerId(local.deviceId),
        options: rtc.PeerOptions(
          // 与配对阶段同一套 ICE 配置：不预收集、STUN 走国内可达服务器。
          config: PairingService.iceConfig,
          autoReconnect: false,
          connectionTimeoutMs: 12000,
        ),
      );
      _peer = peer;
      _subscriptions.add(peer.onConnection.listen((conn) {
        _bindDataConnection(_deviceIdFromPeer(conn.peer), conn);
      }));
      _subscriptions.add(peer.onError.listen((error) {
        for (final device in _outgoing.keys.toList()) {
          _emit(PeerSyncState(
            deviceId: device,
            status: PeerSyncStatus.failed,
            error: '信令错误：$error',
          ));
        }
      }));
      await peer.onOpen.first.timeout(const Duration(seconds: 10));
      return true;
    } catch (e) {
      _peer?.dispose();
      _peer = null;
      for (final device in _outgoing.keys.toList()) {
        _emit(PeerSyncState(
          deviceId: device,
          status: PeerSyncStatus.failed,
          error: '无法连接配对服务器（0.peerjs.com）',
        ));
      }
      return false;
    } finally {
      _openingPeer = false;
    }
  }

  /// `DS-<deviceId>` → deviceId。
  String _deviceIdFromPeer(String peerId) =>
      peerId.startsWith(PairingCodeGenerator.stablePeerIdPrefix)
          ? peerId.substring(PairingCodeGenerator.stablePeerIdPrefix.length)
          : peerId;

  Future<void> _connectTo(String deviceId) async {
    // 每轮同步重新计数，否则第二次同步会显示"收到 300 条"这种累计值。
    _received[deviceId] = 0;
    _sent[deviceId] = 0;
    _summaryBuffers.remove(deviceId);
    _emit(PeerSyncState(deviceId: deviceId, status: PeerSyncStatus.connecting));

    if (!await _ensurePeer()) return;
    final peer = _peer;
    if (peer == null) return;

    // 协议：字典序较小的一方主动 connect，另一方监听 onConnection，避免双连冲突。
    final shouldDial = local.deviceId.compareTo(deviceId) < 0;
    if (shouldDial) {
      try {
        final conn = peer.connect(PairingCodeGenerator.stablePeerId(deviceId));
        _outgoing[deviceId] = conn;
        _bindDataConnection(deviceId, conn);
      } catch (e) {
        _emit(PeerSyncState(
          deviceId: deviceId,
          status: PeerSyncStatus.failed,
          error: '$e',
        ));
        return;
      }
    }

    // 连接与摘要交换都要有终点：到点还没有结果就标失败，
    // 不能让 UI 永远停在"连接中…"。
    _connectTimers.remove(deviceId)?.cancel();
    _connectTimers[deviceId] = Timer(const Duration(seconds: 25), () {
      _emit(PeerSyncState(
        deviceId: deviceId,
        status: PeerSyncStatus.failed,
        error: '对方无响应（可能离线或网络不通）',
      ));
    });
  }

  void _bindDataConnection(String deviceId, rtc.DataConnection conn) {
    // 同一通道只绑定一次，防止 dial / onConnection 双路径重复挂监听。
    final key = '$deviceId:${identityHashCode(conn)}';
    if (!_boundConnections.add(key)) return;

    _emit(PeerSyncState(deviceId: deviceId, status: PeerSyncStatus.exchanging));

    final dataSub = conn.onData.listen((data) async {
      try {
        final raw = data is String ? jsonDecode(data) as Map<String, dynamic> : data;
        if (raw is! Map) return;
        await _handleWire(deviceId, conn, SyncWireMessage.parse(Map<String, dynamic>.from(raw)));
      } catch (e) {
        _connectTimers.remove(deviceId)?.cancel();
        final detail = '同步数据解析/合并失败：$e';
        _emit(PeerSyncState(
          deviceId: deviceId,
          status: PeerSyncStatus.failed,
          error: detail,
        ));
        // 静默同步出错 → 弹定夺窗，让用户手动选择处理方式。
        unawaited(_coordinateError(deviceId, detail));
      }
    });
    _subscriptions.add(dataSub);

    Future<void> startExchange() async {
      if (!_startedExchanges.add(key)) return;
      _connectTimers.remove(deviceId)?.cancel();

      // 同步行为：只由字典序较小的一端（dialer）读取全局默认行为并广播决策，
      // 避免两端各自判断得出矛盾结论。另一端等待 PolicyMessage 后执行。
      // 【正常同步按默认行为静默执行，不弹窗；定夺窗只在出错时才弹。】
      final isDecider = local.deviceId.compareTo(deviceId) < 0;
      if (isDecider) {
        final policy = readBehavior();
        if (policy == SyncPolicy.none) {
          // 兜底：不同步。正常入口 start/syncNow 已拦截，这里只处理边界。
          _emit(PeerSyncState(deviceId: deviceId, status: PeerSyncStatus.synced,
              note: '同步已暂停（不同步）'));
          _finishSync(deviceId);
          return;
        }
        _coverMode[deviceId] = policy != SyncPolicy.merge;
        // 先广播行为决策，再据此动作。
        conn.send(PolicyMessage(policy: policy.name, fromDevice: local.deviceName).toJson());
        if (policy == SyncPolicy.merge) {
          // 【与 COS 统一】先提交自己的整库快照给对端，再等对端快照落地合并。
          await _sendSnapshotExchange(conn);
        } else if (policy == SyncPolicy.localWins) {
          // 本机为准：覆盖前先留备份，把本机整库发给对端覆盖它。
          await backupBeforeOverwrite?.call();
          await _sendOverwriteSnapshot(conn);
          _finishSync(deviceId);
        }
        // remoteWins：等对端推快照过来，这里不主动发。
        return;
      }

      // 非决策端：等 PolicyMessage 到达后再动作（见 _handleWire 的 PolicyMessage 分支）。
      // 若本端未注入闸门（兼容旧调用/测试），退回直接增量同步。
      if (policyGate == null) {
        _sendConversations(conn);
        _sendSummary(deviceId, conn);
      }
    }

    // 连接打开即交换摘要，让增量计算基于双方真实时钟而非本地猜测。
    final openSub = conn.onOpen.listen((_) => startExchange());
    _subscriptions.add(openSub);

    // 关键修复：对端主动连入时，DataConnection 可能在我们挂监听之前就已经 open，
    // 'open' 事件永远等不到 → 双方都不发摘要，UI 就永远停在"同步中"。
    if (conn.open) {
      Future<void>.microtask(startExchange);
    }
  }

  Future<void> _handleWire(
    String deviceId,
    rtc.DataConnection conn,
    SyncWireMessage msg,
  ) async {
    switch (msg) {
      case ConversationsMessage(:final conversations):
        await _mergeConversations(conversations); // 内部按墓碑过滤已删会话

      case VectorSummaryMessage(:final entries, :final isLast):
        // 摘要是分片发的：先收齐，最后一片到了再算增量。
        final buffer = _summaryBuffers.putIfAbsent(deviceId, () => <VectorSummaryEntry>[]);
        buffer.addAll(entries);
        if (isLast) {
          final all = List<VectorSummaryEntry>.from(buffer);
          _summaryBuffers.remove(deviceId);
          await _sendMissingDelta(deviceId, conn, all);
        }

      case DeltaMessage(:final messages, :final isLast):
        for (final incoming in messages) {
          // 墓碑过滤：本机已删会话的消息不插回，防止死灰复燃。
          if (deletedStore != null && await deletedStore!.isDeleted(incoming.conversationId)) {
            continue;
          }
          // 冲突不会在此被裁决，只会被 insertOrMerge 转成 ConflictRecord 推给 UI。
          await store.insertOrMerge(incoming);
        }
        _received[deviceId] = (_received[deviceId] ?? 0) + messages.length;
        if (isLast) {
          _finishSync(deviceId);
        }

      case ByeMessage():
        _finishSync(deviceId);

      case ViewsMessage(:final views):
        await _mergeViews(views);

      case MemoriesMessage(:final memories):
        // 记忆点自带向量时钟：并发时进记忆点自己的裁决表，不在这里抢答。
        for (final memory in memories) {
          await memoryStore.insertOrMerge(memory);
        }

      case PolicyMessage(:final policy, :final fromDevice):
        // 决策端已把行为广播过来。非决策端据此行动，不再自己弹窗。
        final decided = _policyFromName(policy);
        if (decided == SyncPolicy.none) {
          _emit(PeerSyncState(deviceId: deviceId, status: PeerSyncStatus.synced,
              note: '同步已暂停（不同步）'));
          _finishSync(deviceId);
          return;
        }
        _coverMode[deviceId] = decided != SyncPolicy.merge;
        if (decided == SyncPolicy.merge) {
          // 【与 COS 统一】非决策端也提交自己的整库快照给对端。
          await _sendSnapshotExchange(conn);
        } else if (decided == SyncPolicy.localWins) {
          // 对端以它为准：等它推整库快照过来，这里静默等待。
          _emit(PeerSyncState(deviceId: deviceId, status: PeerSyncStatus.exchanging,
              note: '正在接收对端覆盖数据（来自 $fromDevice）'));
        } else {
          // remoteWins：以本机为准——把本机整库推给决策端。覆盖前先留备份。
          await backupBeforeOverwrite?.call();
          await _sendOverwriteSnapshot(conn);
          _finishSync(deviceId);
        }

      case SnapshotExchangeMessage(:final base64Content, :final isLast):
        // 双向快照交换：收齐对端整库快照后，按 merge 语义落地（含墓碑过滤）。
        // 与 COS 完全同一套 SnapshotMergeService，确保 P2P/COS 行为统一。
        final builder = _snapshotExchangeBuffers.putIfAbsent(deviceId, () => BytesBuilder());
        builder.add(base64.decode(base64Content));
        if (isLast) {
          final bytes = builder.takeBytes();
          _snapshotExchangeBuffers.remove(deviceId);
          // _applySnapshotExchange 内部已 emit(synced) 释放队列，不再重复 _finishSync。
          await _applySnapshotExchange(Uint8List.fromList(bytes), fromDevice: deviceId);
        }

      case OverwriteSnapshotMessage(:final base64Content, :final isLast):
        // 整库覆盖载荷分片收齐后整库替换本机。
        final builder = _overwriteBuffers.putIfAbsent(deviceId, () => BytesBuilder());
        builder.add(base64.decode(base64Content));
        if (isLast) {
          final bytes = builder.takeBytes();
          _overwriteBuffers.remove(deviceId);
          await _applyOverwriteSnapshot(Uint8List.fromList(bytes), fromDevice: deviceId);
          _finishSync(deviceId);
        }

      case BackupsMessage(:final fromDevice, :final fileName, :final base64Content, :final isLast):
        await _receiveBackup(fromDevice, fileName, base64Content);
        if (isLast) {
          // 备份是最后附加的一批，不触发 _finishSync（由 DeltaMessage/Bye 触发）。
        }

      case SummariesMessage(:final summaries):
        for (final incoming in summaries) {
          final local = await conversationStore.getSummary(incoming.conversationId);
          // 用户指定的规则：默认用较新版本。
          if (local == null || incoming.generatedAt.isAfter(local.generatedAt)) {
            await conversationStore.saveSummary(incoming);
          }
        }
    }
  }

  /// 合并压缩视图。
  ///
  /// 规则（用户明确要求）：
  ///   - 对端没有、我有 → 发过去（已在 _sendExtras 完成）；
  ///   - 我没有、对端有 → 直接接受；
  ///   - 两边都有且是同一次压缩 → 忽略；
  ///   - 两边都有但不是同一次 → **不自动覆盖**，记入待裁决，由用户整体选一边。
  Future<void> _mergeViews(List<CompactionView> incoming) async {
    for (final remote in incoming) {
      final local = await viewStore.get(remote.conversationId);
      if (local == null) {
        await viewStore.save(remote);
        continue;
      }
      if (local.id == remote.id) continue;
      // 只在对端更新时登记；否则我这边的版本更值得保留，不发打扰。
      if (remote.updatedAt.isAfter(local.updatedAt)) {
        await prefs.setString(
          viewConflictKey(remote.conversationId),
          jsonEncode(remote.toJson()),
        );
        _viewConflicts.add(remote.conversationId);
      }
    }
  }

  /// 压缩视图待裁决通知（会话 id）。
  Stream<String> get viewConflicts => _viewConflicts.stream;

  /// 待裁决状态的存储键。UI 读取它来展示"用对端的/保留本机"。
  static String viewConflictKey(String conversationId) =>
      'deepshart.view_conflict.$conversationId';

  /// 收敛到"已同步"。
  ///
  /// 注意：收到 bye 时绝不能再回 bye——两边互回会形成无限回执风暴，
  /// 表现为状态在"同步中/已同步"之间反复跳。bye 只由"我已经把增量发完/没有增量"的一方发出。
  void _finishSync(String deviceId) {
    _connectTimers.remove(deviceId)?.cancel();
    final received = _received[deviceId] ?? 0;
    final sent = _sent[deviceId] ?? 0;
    _emit(PeerSyncState(
      deviceId: deviceId,
      status: PeerSyncStatus.synced,
      note: received == 0 && sent == 0
          ? '已是最新，没有需要同步的内容'
          : '收到 $received 条 / 发出 $sent 条',
    ));
    _onDeviceSettled(deviceId);
  }

  /// 补齐对端有、本地没有的会话元数据。已存在的会话保留本地标题（本地改名优先）。
  Future<void> _mergeConversations(List<Conversation> incoming) async {
    for (final conv in incoming) {
      // 墓碑过滤：本机已删的会话即使对端还推过来，也不补建。
      if (deletedStore != null && await deletedStore!.isDeleted(conv.id)) continue;
      final existing = await conversationStore.get(conv.id);
      if (existing == null) {
        await conversationStore.upsert(conv);
      }
    }
  }

  Future<void> _sendConversations(rtc.DataConnection conn) async {
    var all = await conversationStore.watchAllStreamSource();
    if (all.isEmpty) return;
    // 空白新对话不同步（用户要求）：标题是"新对话"且一条消息都没有的会话，
    // 只在本地临时存在，推给对端只会制造一坨空对话。
    final nonEmpty = <Conversation>[];
    for (final c in all) {
      if (c.title.startsWith('新对话')) {
        final messages = await store.readAll(c.id);
        if (messages.isEmpty) continue;
      }
      nonEmpty.add(c);
    }
    all = nonEmpty;
    if (all.isEmpty) return;
    conn.send(ConversationsMessage(conversations: all).toJson());
  }

  /// 单条 WebRTC DataChannel 消息的安全上限。
  /// SCTP 的上限通常是 256KB，但不同实现差异很大；取 48KB 既稳又不会太碎。
  static const int _maxChunkChars = 48 * 1024;

  Future<void> _sendSummary(String deviceId, rtc.DataConnection conn) async {
    final all = await store.readAllAcrossConversations(includeDeleted: true);
    if (all.isEmpty) {
      conn.send(const VectorSummaryMessage(entries: <VectorSummaryEntry>[]).toJson());
      return;
    }

    final entries = all
        .map((m) => VectorSummaryEntry(messageId: m.id, vector: m.versionVector.counters))
        .toList(growable: false);
    final chunks = chunkByEstimatedSize<VectorSummaryEntry>(
      entries,
      (e) => e.messageId.length + e.vector.length * 12 + 24,
      maxChars: _maxChunkChars,
    );
    for (var i = 0; i < chunks.length; i++) {
      conn.send(VectorSummaryMessage(entries: chunks[i], isLast: i == chunks.length - 1).toJson());
    }
  }

  /// 计算对方缺失的增量：对每条本地消息，用 VersionTracker 判断对方是否已经"见到"。
  ///
  /// 为什么用 dominates 而不是简单比较 updatedAt：
  /// 对方摘要里若存在一条消息的向量被本地向量支配（local.dominates(remote)），
  /// 说明本地有对方没有的因果事件 —— 这条消息必须推送。
  /// 若两者 isConcurrent，同样推送，让接收端 insertOrMerge 生成冲突交给用户。
  Future<void> _sendMissingDelta(
    String deviceId,
    rtc.DataConnection conn,
    List<VectorSummaryEntry> remoteSummary,
  ) async {
    final remoteById = <String, VectorSummaryEntry>{
      for (final e in remoteSummary) e.messageId: e,
    };

    final localMessages = await store.readAllAcrossConversations(includeDeleted: true);
    final missing = <ChatMessage>[];
    for (final m in localMessages) {
      final remote = remoteById[m.id];
      final localTracker = VersionTracker(Map<String, int>.from(m.versionVector.counters));
      final remoteTracker = remote == null
          ? VersionTracker()
          : VersionTracker(Map<String, int>.from(remote.vector));

      // 精确判定：远端没有 / 版本相同则跳过；本地领先或并发才推送。
      // 若远端领先（remote 支配 local），说明它持有更新版本，本地应等待接收而非推送。
      final needSend = remote == null ||
          ((localTracker != remoteTracker) &&
              (localTracker.dominates(remoteTracker) ||
                  localTracker.isConcurrent(remoteTracker)));
      if (needSend) missing.add(m);
    }

    _sent[deviceId] = missing.length;

    if (missing.isEmpty) {
      // 即使没有消息增量，也要交换压缩视图/记忆点/摘要——它们独立于消息存在。
      await _sendExtras(conn);
      // 回一个 bye，否则对端会一直停在"交换中"。
      conn.send(const ByeMessage().toJson());
      _finishSync(deviceId);
      return;
    }

    // 分批发送：1314 条消息塞进一条 JSON 会远超 DataChannel 单帧上限，
    // send 会静默失败，表现就是"一直同步中"。这里按字符数切片。
    final chunks = chunkByEstimatedSize<ChatMessage>(
      missing,
      (m) => m.content.length + 320,
      maxChars: _maxChunkChars,
    );
    for (var i = 0; i < chunks.length; i++) {
      conn.send(DeltaMessage(messages: chunks[i], isLast: i == chunks.length - 1).toJson());
    }
    // 消息发完后接着发"附属数据"，顺序固定：消息 → 视图 → 记忆点 → 摘要。
    await _sendExtras(conn);
    // 发完最后一片就告诉对方"我这边发完了"，否则双方都在等对方的结束标记。
    conn.send(const ByeMessage().toJson());
    _finishSync(deviceId);
  }

  /// 发送压缩视图、记忆点与会话摘要。
  ///
  /// 顺序上必须在消息之后：视图里引用的是消息 id，对端先有消息再收到视图
  /// 才能正确落地；反过来会出现"视图指向不存在的消息"的悬空引用。
  /// 接收对端同步来的备份：写到本机备份目录，文件名标注来源设备。
  /// 这样备份列表能识别"这份来自别的设备"，用云朵图标区分（用户要求）。
  /// 字符串策略名 → SyncPolicy（线路上只传 name，避免耦合枚举顺序）。
  SyncPolicy _policyFromName(String name) => syncPolicyFromName(name);

  /// 【与 COS 统一】提交自己的整库快照：VACUUM INTO 生成一致性快照，
  /// base64 分片发给对端。对端收到后走 merge（含墓碑过滤），不是整库覆盖。
  Future<void> _sendSnapshotExchange(rtc.DataConnection conn) async {
    final bs = backupService;
    if (bs == null) return;
    final tmp = p.join(
      Directory.systemTemp.path,
      'deepshart-p2p-exchange-${DateTime.now().millisecondsSinceEpoch}.db',
    );
    final f = File(tmp);
    try {
      await BackupService.dbLock.run(() => bs.db.execute("VACUUM INTO '${tmp.replaceAll("'", "''")}'"));
      final bytes = await f.readAsBytes();
      const int chunkChars = 32 * 1024; // base64 放大约 4/3，32K 字符远低于 SCTP 单帧上限
      final b64 = base64.encode(bytes);
      final total = (b64.length / chunkChars).ceil();
      for (var i = 0; i < total; i++) {
        final start = i * chunkChars;
        final end = (start + chunkChars).clamp(0, b64.length);
        conn.send(SnapshotExchangeMessage(
          fromDevice: local.deviceName,
          base64Content: b64.substring(start, end),
          isLast: i == total - 1,
        ).toJson());
      }
    } catch (e) {
      _emit(PeerSyncState(
        deviceId: local.deviceId,
        status: PeerSyncStatus.failed,
        error: '提交本机快照失败：$e',
      ));
    } finally {
      if (await f.exists()) {
        try { await f.delete(); } catch (_) {}
      }
    }
  }

  /// 【与 COS 统一】落地对端发来的快照：写临时文件 → 走 SnapshotMergeService
  /// （与 COS 完全相同的 merge 语义 + 墓碑过滤）。未注入 merge 回调时退回整库 restore。
  Future<void> _applySnapshotExchange(Uint8List bytes, {required String fromDevice}) async {
    final tmp = p.join(
      Directory.systemTemp.path,
      'deepshart-p2p-incoming-${DateTime.now().millisecondsSinceEpoch}.db',
    );
    final f = File(tmp);
    try {
      await f.writeAsBytes(bytes, flush: true);
      final merger = mergeSnapshotFromFile;
      if (merger != null) {
        final report = await merger(tmp);
        _emit(PeerSyncState(
          deviceId: fromDevice,
          status: PeerSyncStatus.synced,
          note: report.error != null
              ? '快照合并失败：${report.error}'
              : '已合并对端快照：${report.summary}',
        ));
      } else {
        // 兜底：无 merge 回调时整库 restore（旧行为）。
        final bs = backupService;
        if (bs != null) {
          await bs.restore(tmp);
          onOverwriteApplied?.call();
        }
        _emit(PeerSyncState(
          deviceId: fromDevice,
          status: PeerSyncStatus.synced,
          note: '已接收对端整库快照',
        ));
      }
    } catch (e) {
      final detail = '对端快照落地失败：$e';
      _emit(PeerSyncState(
        deviceId: fromDevice,
        status: PeerSyncStatus.failed,
        error: detail,
      ));
      unawaited(_coordinateError(fromDevice, detail));
    } finally {
      if (await f.exists()) {
        try { await f.delete(); } catch (_) {}
      }
    }
  }

  /// 把本机整库以 VACUUM INTO 生成一致性快照，再 base64 分片发给对端。
  /// 每片控制在 _maxChunkChars 以内，避免 DataChannel 单帧超限。
  Future<void> _sendOverwriteSnapshot(rtc.DataConnection conn) async {
    final bs = backupService;
    if (bs == null) return;
    final tmp = p.join(
      Directory.systemTemp.path,
      'deepshart-p2p-overwrite-${DateTime.now().millisecondsSinceEpoch}.db',
    );
    final f = File(tmp);
    try {
      await BackupService.dbLock.run(() => bs.db.execute("VACUUM INTO '${tmp.replaceAll("'", "''")}'"));
      final bytes = await f.readAsBytes();
      // base64 会把体积放大约 4/3，按字符数分片。
      const int chunkChars = 32 * 1024;
      final b64 = base64.encode(bytes);
      final total = (b64.length / chunkChars).ceil();
      for (var i = 0; i < total; i++) {
        final start = i * chunkChars;
        final end = (start + chunkChars).clamp(0, b64.length);
        conn.send(OverwriteSnapshotMessage(
          fromDevice: local.deviceName,
          base64Content: b64.substring(start, end),
          isLast: i == total - 1,
        ).toJson());
      }
    } catch (_) {
      // 覆盖发送失败：不阻塞其它同步，状态由超时/对端超时兜底。
    } finally {
      if (await f.exists()) {
        try { await f.delete(); } catch (_) {}
      }
    }
  }

  /// 应用对端发来的整库快照：写临时文件 → backup.restore() 整库替换 → 刷新 UI。
  /// restore 内部会先自动留一份安全备份，可回溯。
  Future<void> _applyOverwriteSnapshot(Uint8List bytes, {required String fromDevice}) async {
    final bs = backupService;
    if (bs == null) return;
    final tmp = p.join(
      Directory.systemTemp.path,
      'deepshart-p2p-incoming-${DateTime.now().millisecondsSinceEpoch}.db',
    );
    final f = File(tmp);
    try {
      await f.writeAsBytes(bytes, flush: true);
      await bs.restore(tmp);
      onOverwriteApplied?.call();
      _emit(PeerSyncState(
        deviceId: fromDevice,
        status: PeerSyncStatus.synced,
        note: '已用对端数据整库覆盖本机',
      ));
    } catch (e) {
      final detail = '整库覆盖失败：$e';
      _emit(PeerSyncState(
        deviceId: fromDevice,
        status: PeerSyncStatus.failed,
        error: detail,
      ));
      unawaited(_coordinateError(fromDevice, detail));
    } finally {
      if (await f.exists()) {
        try { await f.delete(); } catch (_) {}
      }
    }
  }

  Future<void> _receiveBackup(String fromDevice, String fileName, String base64Content) async {
    final bs = backupService;
    if (bs == null || base64Content.isEmpty) return;
    try {
      final dir = await bs.backupDirectory;
      // 文件名安全化 + 标注来源，避免覆盖本机同名备份。
      final safeDevice = fromDevice.replaceAll(RegExp(r'[\\/:*?"<>|\r\n\t]'), '_');
      final safeName = fileName.replaceAll(RegExp(r'[\\/:*?"<>|\r\n\t]'), '_');
      final target = p.join(dir.path, 'shared_${safeDevice}_$safeName');
      final f = File(target);
      if (await f.exists()) return; // 已同步过，幂等。
      final bytes = base64.decode(base64Content);
      await f.writeAsBytes(bytes, flush: true);
      await bs.enforceLimit(); // 遵守总容量上限。
    } catch (_) {
      // 单份备份失败不影响主同步。
    }
  }

  /// 发送本地备份给对端：只发小体积（≤1MB）备份，避免单帧超限与配额失控。
  Future<void> _sendBackups(rtc.DataConnection conn) async {
    final bs = backupService;
    if (bs == null) return;
    try {
      final dir = await bs.backupDirectory;
      final files = dir
          .listSync()
          .whereType<File>()
          .where((f) => f.path.endsWith('.db') && !p.basename(f.path).startsWith('shared_'))
          .toList();
      if (files.isEmpty) return;
      final deviceTag = local.deviceName;
      final eligible = <File>[];
      for (final f in files) {
        final stat = await f.stat();
        if (stat.size <= 1024 * 1024) eligible.add(f); // 只发 ≤1MB 的备份。
      }
      for (var i = 0; i < eligible.length; i++) {
        final f = eligible[i];
        final bytes = await f.readAsBytes();
        conn.send(BackupsMessage(
          fromDevice: deviceTag,
          fileName: p.basename(f.path),
          base64Content: base64.encode(bytes),
          isLast: i == eligible.length - 1,
        ).toJson());
      }
    } catch (_) {
      // 备份同步失败不影响主同步。
    }
  }

  Future<void> _sendExtras(rtc.DataConnection conn) async {
    try {
      final views = await viewStore.readAll();
      if (views.isNotEmpty) {
        final chunks = chunkByEstimatedSize<CompactionView>(
          views,
          (v) => jsonEncode(v.toJson()).length + 32,
          maxChars: _maxChunkChars,
        );
        for (var i = 0; i < chunks.length; i++) {
          conn.send(ViewsMessage(
            views: chunks[i],
            isLast: i == chunks.length - 1,
          ).toJson());
        }
      }

      final memories = await memoryStore.readAllAcrossConversations();
      if (memories.isNotEmpty) {
        final chunks = chunkByEstimatedSize<ImportantMemory>(
          memories,
          (m) => jsonEncode(m.toJson()).length + 32,
          maxChars: _maxChunkChars,
        );
        // 记忆点可能上千条，必须分片，否则单帧超限会静默失败。
        for (var i = 0; i < chunks.length; i++) {
          conn.send(MemoriesMessage(
            memories: chunks[i],
            isLast: i == chunks.length - 1,
          ).toJson());
        }
      }

      final summaries = await conversationStore.readAllSummaries();
      if (summaries.isNotEmpty) {
        conn.send(SummariesMessage(summaries: summaries).toJson());
      }

      // 备份也随每次同步发给对端（用户要求）。放在最后，失败不影响主同步。
      await _sendBackups(conn);
    } catch (_) {
      // 附属数据失败不能影响主同步（消息已经发完了）。
    }
  }

  /// 静默同步出错后的定夺协调：仅此时弹窗，标注同步方式=P2P，用户四选一。
  /// 用户的选择写回全局默认行为（通过注入的 applyErrorDecision），下次同步生效。
  Future<void> _coordinateError(String deviceId, String detail) async {
    final gate = policyGate;
    if (gate == null) return;
    try {
      final decision = await gate.askOnError(
        '设备 $deviceId',
        method: SyncMethod.p2p,
        errorDetail: detail,
      );
      await applyErrorDecision?.call(decision);
    } catch (_) {
      // 定夺流程异常不影响同步状态收尾。
    }
  }

  void _emit(PeerSyncState state) {
    if (!_statusController.isClosed) _statusController.add(state);
    // 同步收敛（成功或失败）即释放串行队列的当前槽位，让下一台设备开连。
    if (state.status == PeerSyncStatus.synced || state.status == PeerSyncStatus.failed) {
      _onDeviceSettled(state.deviceId);
    }
  }

  Future<void> dispose() async {
    for (final timer in _connectTimers.values) {
      timer.cancel();
    }
    _connectTimers.clear();
    for (final sub in _subscriptions) {
      await sub.cancel();
    }
    for (final conn in _outgoing.values) {
      conn.dispose();
    }
    _peer?.dispose();
    _peer = null;
    await _viewConflicts.close();
    await _statusController.close();
  }
}
