// target: lib/ai/deepseek_provider.dart
// 职责：实现 DeepSeekProvider（思考/联网搜索/文件上传的参数映射）与重要记忆点的旁路提取存储。

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';

import 'ai_provider.dart';

/// DeepSeek 余额信息。金额用 double 存，展示时按币种格式化。
@immutable
class AccountBalance {
  final double total;
  final String currency;
  final bool available;

  const AccountBalance({
    required this.total,
    required this.currency,
    required this.available,
  });

  String get symbol => currency.toUpperCase() == 'USD' ? '\$' : '¥';

  String get display => '$symbol${total.toStringAsFixed(2)}';
}

/// DeepSeek API 客户端。model 保持可配置，默认 deepseek-flash。
///
/// 参数映射（为什么这样设计）：
///  - 思考模式：thinking.type = enabled/disabled。这是官方新 API 的开关，
///    比旧时代切换 deepseek-reasoner 模型更准确，且 temperature 在思考模式下无效，
///    因此当 thinkingEnabled 为 true 时【不发送 temperature】，避免静默传入无效值。
///  - 联网搜索：searchEnabled 时在 tools 中声明 deepseek_web_search。
///    思考模式打开=深度思考搜索，非思考模式打开=普通联网搜索，二者由同一工具 + thinking 组合表达。
///  - 文件上传：先 POST /files 得到 file_id，再把 file_id 拼入 user 消息的 content 数组。
class DeepSeekProvider implements AiProvider {
  final Dio _dio;
  final String apiKey;
  final String baseUrl;
  final String model;

  DeepSeekProvider({
    required this.apiKey,
    Dio? dio,
    this.baseUrl = 'https://api.deepseek.com',
    this.model = 'deepseek-flash',
  }) : _dio = dio ?? Dio() {
    _dio.options = BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 120),
      headers: {
        'Authorization': 'Bearer $apiKey',
        'Content-Type': 'application/json',
      },
    );
    // 流式请求（ResponseType.stream）出错时，Dio 把错误体也包成 ResponseBody，
    // 导致上层 friendlyError 只能显示 "Instance of 'ResponseBody'"（用户实测
    // DeepSeek Pro 400 就是这个现象）。这里在错误拦截里把字节流读成字符串并
    // 回填，让服务端返回的真实原因能一路透传到 UI。
    _dio.interceptors.add(InterceptorsWrapper(
      onError: (e, handler) async {
        final data = e.response?.data;
        if (data is ResponseBody) {
          try {
            final bytes = await data.stream.fold<List<int>>(
              <int>[],
              (acc, chunk) => acc..addAll(chunk),
            );
            e.response?.data = utf8.decode(bytes, allowMalformed: true);
          } catch (_) {
            e.response?.data = '服务端返回了无法解析的错误体';
          }
        }
        handler.next(e);
      },
    ));
  }

  @override
  String get displayName => 'DeepSeek';

  @override
  bool get supportsThinking => true;

  @override
  bool get supportsSearch => true;

  @override
  bool get supportsFileUpload => true;

  /// 轻量连通性自检：GET /models 不消耗对话额度。
  /// 返回 null 表示连通正常；否则返回可读的错误说明。
  Future<String?> testConnection() async {
    try {
      await _dio.get<dynamic>('/models');
      return null; // 200
    } on DioException catch (e) {
      final code = e.response?.statusCode;
      if (code == 401 || code == 403) {
        return '网络正常，但 API Key 无效或无权限（HTTP $code）';
      }
      if (code == null) {
        // 网络层失败：DNS / 超时 / 连接失败
        final msg = e.message?.toLowerCase() ?? '';
        if (msg.contains('host lookup') || e.error.toString().toLowerCase().contains('host lookup')) {
          return '手机无法解析 api.deepseek.com（DNS 失败）。请检查网络，或换 Wi-Fi / 流量。';
        }
        return '无法连接 DeepSeek：${e.message ?? e.error}';
      }
      return 'DeepSeek 返回 HTTP $code';
    } catch (e) {
      return '连接测试失败：$e';
    }
  }

  /// 查询账户余额：GET /user/balance。
  /// 这是 DeepSeek 官方的账户接口，不消耗对话额度。
  Future<AccountBalance> fetchBalance() async {
    final response = await _dio.get<Map<String, dynamic>>('/user/balance');
    final data = response.data ?? const <String, dynamic>{};
    final infos = (data['balance_infos'] as List?) ?? const [];
    if (infos.isEmpty) {
      return AccountBalance(
        total: 0,
        currency: 'CNY',
        available: data['is_available'] as bool? ?? false,
      );
    }
    // 优先人民币账户；没有就取第一条。
    final info = infos.firstWhere(
      (e) => (e as Map)['currency']?.toString().toUpperCase() == 'CNY',
      orElse: () => infos.first,
    ) as Map;
    final total = double.tryParse(info['total_balance']?.toString() ?? '') ?? 0;
    return AccountBalance(
      total: total,
      currency: info['currency']?.toString() ?? 'CNY',
      available: data['is_available'] as bool? ?? false,
    );
  }

  @override
  Future<AiResponse> sendMessage(
    List<AiMessage> messages, {
    AiRequestOptions options = const AiRequestOptions(),
  }) async {
    final body = DeepSeekProvider.buildRequestBody(model, messages, options);
    final response = await _dio.post<Map<String, dynamic>>(
      '/chat/completions',
      data: body,
      options: Options(
        receiveTimeout: DeepSeekProvider.receiveTimeoutFor(
          jsonEncode(body).length,
        ),
      ),
    );
    return _parseResponse(response.data!);
  }

  @override
  Stream<AiStreamChunk> sendMessageStream(
    List<AiMessage> messages, {
    AiRequestOptions options = const AiRequestOptions(),
  }) async* {
    final body = DeepSeekProvider.buildRequestBody(model, messages, options)..['stream'] = true;
    // ResponseType.stream 时 dio 把响应体包装成 ResponseBody，其 .stream 是字节流。
    final response = await _dio.post<ResponseBody>(
      '/chat/completions',
      data: body,
      options: Options(
        responseType: ResponseType.stream,
        receiveTimeout: DeepSeekProvider.receiveTimeoutFor(
          jsonEncode(body).length,
        ),
      ),
    );

    // UTF-8 解码必须用流式 transform：decoder.convert(bytes) 每次独立解码，
    // 一个中文字符的多字节序列若正好跨在两个 SSE chunk 之间，就会被切断并抛
    // FormatException: Unfinished UTF-8 octet sequence（用户实测）
    // ——这正是"输入报错"截图里的异常。utf8.decoder 的流式转换会缓存半个
    // 多字节序列，等下一块字节到齐再解码，从根本上避免边界切断。
    final lines = response.data!.stream
        .cast<List<int>>()
        .transform(utf8.decoder)
        .transform(const LineSplitter());

    var citationsEmitted = false;
    await for (final line in lines) {
      if (!line.startsWith('data:')) continue;
      final payload = line.substring(5).trim();
      if (payload == '[DONE]' || payload.isEmpty) continue;
      final chunk = jsonDecode(payload) as Map<String, dynamic>;
      final choice = (chunk['choices'] as List?)?.first as Map<String, dynamic>?;
      final delta = choice?['delta'] as Map<String, dynamic>?;
      if (delta != null) {
        final thinking = delta['reasoning_content'] as String?;
        final answer = delta['content'] as String?;
        if (thinking != null && thinking.isNotEmpty) yield ThinkingChunk(thinking);
        if (answer != null && answer.isNotEmpty) yield AnswerChunk(answer);
      }
      // 引用(annotations)只在带 finish_reason 的最后一块下发一次。
      // 复用非流式路径同一套解析逻辑，保证两路行为一致。
      if (!citationsEmitted) {
        final message = choice?['message'] as Map<String, dynamic>? ?? delta;
        final annotations = message?['annotations'];
        if (annotations != null) {
          final citations = parseAnnotations(annotations);
          if (citations.isNotEmpty) {
            citationsEmitted = true;
            yield CitationsChunk(citations);
          }
        }
      }
    }
  }

  /// API 参数映射的核心。静态纯函数，便于单测断言参数组合。
  static Map<String, dynamic> buildRequestBody(
    String model,
    List<AiMessage> messages,
    AiRequestOptions options,
  ) {
    final mappedMessages = <Map<String, dynamic>>[];
    if (options.systemPrompt != null && options.systemPrompt!.isNotEmpty) {
      mappedMessages.add({'role': 'system', 'content': options.systemPrompt});
    }
    for (final m in messages) {
      if (m.fileIds.isEmpty) {
        mappedMessages.add({'role': m.role, 'content': m.content});
      } else {
        // 官方 Files API 文档的 Chat Completions 示例：
        //   {"type":"text","text":"..."},
        //   {"type":"file","file_id":"file-api-..."}
        // file_id 必须在内容块顶层，不能包成 {"file":{"file_id":...}}
        // ——包一层会被服务端判为格式错误直接 400。
        final parts = <Map<String, dynamic>>[
          {'type': 'text', 'text': m.content},
          ...m.fileIds.map((id) => {'type': 'file', 'file_id': id}),
        ];
        mappedMessages.add({'role': m.role, 'content': parts});
      }
    }

    // 角色提示词加固：
    // 只在开头放一条 system 时，长对话里模型会跟着历史里自己的旧身份走
    // （实测：设了"你的物种是鲨鱼"，但前文全在自称 AI 助手，它照样回答"我是 AI 助手"）。
    // 因此在最后一条用户消息之前再注入一次同样的设定，用"最高优先级"明确压过历史。
    if (options.systemPrompt != null && options.systemPrompt!.isNotEmpty && mappedMessages.length > 1) {
      final reinforce = <String, dynamic>{
        'role': 'system',
        'content': '【角色设定·最高优先级】\n'
            '以下设定必须遵守，优先级高于历史对话中任何与之矛盾的自我描述：\n'
            '${options.systemPrompt}',
      };
      mappedMessages.insert(mappedMessages.length - 1, reinforce);
    }

    final body = <String, dynamic>{
      'model': model,
      'messages': mappedMessages,
      'thinking': {'type': options.thinkingEnabled ? 'enabled' : 'disabled'},
    };
    // temperature 在思考模式下无效——不发送，而不是发送后被忽略。
    if (!options.thinkingEnabled) {
      body['temperature'] = options.temperature.clamp(0.0, 2.0);
    } else {
      // 思考强度：DeepSeek 官方只接受 low / high / max 三个值。
      // 必须和 thinking.type=enabled 同时出现；关闭思考时传了也没意义，
      // 这里只在开启时下发，避免无效参数污染请求体。
      final effort = options.reasoningEffort.toLowerCase();
      body['reasoning_effort'] =
          const ['low', 'high', 'max'].contains(effort) ? effort : 'high';
    }

    if (options.searchEnabled) {
      // DeepSeek 2026-11 新版内置搜索工具：type 必须直接是 "deepseek_web_search"。
      // 旧写法 {"type":"web_search", "web_search":{...}} 会被服务端以 422 拒绝。
      // 思考开=深度思考搜索，思考关=普通联网搜索，由 thinking 组合表达。
      body['tools'] = [
        {'type': 'deepseek_web_search'},
      ];
    }
    // 输出上限：显式下发才可控。不透传 null，避免把 "max_tokens": null 当成 0。
    final maxOut = options.maxOutputTokens;
    if (maxOut != null && maxOut > 0) {
      body['max_tokens'] = maxOut;
    }
    return body;
  }

  /// 按请求体大小分档设置接收超时。
  ///
  /// 为什么不能固定 120 秒：大上下文（≥256K）光 prefill 就可能几十秒，
  /// 加上思考模式很容易破 120 秒 → Dio 抛超时 → 用户重试 → 那一大段输入
  /// 又被计费一次。分档总比"一刀切超时"稳妥。
  ///
  /// 注意：超时后由 UI 决定是否重试，Provider 层绝不自动重试，
  /// 否则一次超时会变成两次计费。
  static Duration receiveTimeoutFor(int bodyChars) {
    if (bodyChars > 800000) return const Duration(seconds: 600);
    if (bodyChars > 200000) return const Duration(seconds: 300);
    return const Duration(seconds: 120);
  }

  /// 拉取可用模型 id 列表（GET /models，不消耗对话额度）。
  ///
  /// 失败时抛异常，由上层回落到本地缓存/内置表 —— 设置页不能因为
  /// 一次网络抖动就变成空白下拉框。
  Future<List<String>> fetchModels() async {
    final response = await _dio.get<Map<String, dynamic>>('/models');
    final data = response.data?['data'] as List? ?? const [];
    final ids = <String>[];
    for (final item in data) {
      if (item is! Map) continue;
      final id = item['id']?.toString().trim() ?? '';
      if (id.isNotEmpty) ids.add(id);
    }
    return ids;
  }

  AiResponse _parseResponse(Map<String, dynamic> json) {
    final choice = (json['choices'] as List?)?.first as Map<String, dynamic>?;
    final message = choice?['message'] as Map<String, dynamic>?;
    final thinking = message?['reasoning_content'] as String? ?? '';
    final answer = message?['content'] as String? ?? '';

    final citations = parseAnnotations(message?['annotations']);

    return AiResponse(
      thinkingContent: thinking,
      citations: citations,
      finalAnswer: answer,
    );
  }

  /// 把 API 返回的 annotations 解析成引用列表（公开静态方法，便于单测）。
  ///
  /// DeepSeek 2026-11 官方结构（查证 api-docs.deepseek.com / 联网工具文档）：
  ///   annotations: [{ type: 'url_citation',
  ///                   url_citation: { url, title, start_index, end_index } }]
  /// 注意字段藏在 `url_citation` 这一层里，直接读 annotation['url'] 会全空 ——
  /// 这正是用户截图里"搜索引用"变成一列 ` - ` 横线的根因。
  /// 这里兼容多种形态：url_citation 嵌套 / search_result 嵌套 / 扁平 / url 嵌套。
  static List<AiCitation> parseAnnotations(Object? raw) {
    final annotations = raw as List<dynamic>? ?? [];
    final citations = <AiCitation>[];
    for (final a in annotations) {
      if (a is! Map<String, dynamic>) continue;

      // 逐层剥出真正装 title/url 的那个 Map。
      final Map<String, dynamic> source;
      final nc = a['url_citation'];
      final sr = a['search_result'];
      final nu = a['url'];
      if (nc is Map<String, dynamic>) {
        source = nc;
      } else if (sr is Map<String, dynamic>) {
        source = sr;
      } else if (nu is Map<String, dynamic>) {
        source = nu;
      } else {
        source = a; // 扁平形态：{type, title, url}
      }

      final title = (source['title'] ?? source['name'] ?? '').toString().trim();
      final url = (source['url'] ?? source['link'] ?? '').toString().trim();
      final snippet = source['snippet']?.toString();
      final start = (source['start_index'] ?? a['start_index']) as num?;
      final end = (source['end_index'] ?? a['end_index']) as num?;

      // 标题和链接都空说明这条解析失败，直接丢弃 —— 绝不再生成空壳引用，
      // 否则 UI 又会把分隔符 " - " 渲染成一条横线。
      if (title.isEmpty && url.isEmpty) continue;

      citations.add(AiCitation(
        title: title.isEmpty ? url : title,
        url: url,
        snippet: snippet,
        startIndex: start?.toInt(),
        endIndex: end?.toInt(),
      ));
    }
    return citations;
  }

  @override
  Future<UploadedFile> uploadFile(String path) async {
    final file = File(path);
    if (!await file.exists()) {
      throw FileSystemException('Upload target not found', path);
    }
    // DeepSeek Files API：图片用 user_data；文档类必须用 text_recognition，
    // 否则服务端返回 400（文档用 user_data 上传是不允许的）。
    final ext = path.split('.').last.toLowerCase();
    const imageExts = {'jpg', 'jpeg', 'png', 'gif', 'webp'};
    const docExts = {'pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx'};
    final purpose = imageExts.contains(ext)
        ? 'user_data'
        : docExts.contains(ext)
            ? 'text_recognition'
            : 'user_data'; // txt/md/csv/json 等文本也用 user_data
    final form = FormData.fromMap({
      // 文档类要求 purpose 字段在 file 之前；FormData 按插入顺序编码。
      'purpose': purpose,
      'file': await MultipartFile.fromFile(
        path,
        filename: file.uri.pathSegments.last,
      ),
    });
    final response = await _dio.post<Map<String, dynamic>>(
      '/files',
      data: form,
      options: Options(
        contentType: 'multipart/form-data',
        // 大文件（如几十 MB 的 pptx）上传比普通请求慢，必须给足发送超时，
        // 否则 socket 在上传中途被 Dio 掐断，被上层误报成"解析不了域名"。
        sendTimeout: const Duration(seconds: 180),
        receiveTimeout: const Duration(seconds: 180),
        // 必须清掉 BaseOptions 里的全局 Content-Type: application/json，
        // 否则它会覆盖 multipart 边界，服务端收到错误 Content-Type 返回 400。
        headers: {'Content-Type': null},
      ),
    );
    final data = response.data!;
    return UploadedFile(
      fileId: data['id'] as String,
      fileName: file.uri.pathSegments.last,
      mimeType: data['mime_type'] as String?,
    );
  }
}

// ============================================================================
// 重要记忆点：旁路提取与 CRDT 存储
// ============================================================================

/// 提取器返回的 JSON 结构。importance >= 0.85 才值得落盘（用户要求"严厉一些"）。
@immutable
class MemoryExtraction {
  final double importance;
  final String summary;
  final List<String> tags;
  final String reasoning;

  const MemoryExtraction({
    required this.importance,
    required this.summary,
    required this.tags,
    required this.reasoning,
  });

  bool get isImportant => importance >= kMemoryImportanceThreshold;
}

/// 记忆落盘阈值。用户要求"标准太松、严厉一些"后从 0.7 提到 0.85：
/// 只有真正的核心锚点（身份、关键偏好、明确要求记住的事）才配进记忆点。
const double kMemoryImportanceThreshold = 0.85;

/// System 提示词。用户明确要求改打分口径——不要问"这重要吗"，
/// 而是问"删掉这段后 AI 还会不会认得用户是谁、会不会影响核心情感连接"。
const String kMemoryExtractorPrompt =
    '你是记忆价值评估员。只返回合法 JSON，不要解释、不要 markdown、不要代码块。\n'
    '打分时不要问"这通常重要吗"，要做一个**删除测试**：\n'
    '「如果把这段话从记忆里永久删掉，AI 以后还会不会认得用户是谁？会不会破坏核心情感连接或反复强调的偏好？」\n'
    '评分标准（务必严格，宁可少存）：\n'
    '9-10 分（0.9-1.0）：核心身份锚点。例："我叫海鲜"、"我是医学生"、"我的猫叫深蓝"、'
    '用户明确要求"记住…"、不可动摇的关系设定。删了 AI 就认不出人或情感断裂。\n'
    '7-8 分（0.7-0.8）：重要但非身份级——反复出现的偏好、长期项目的关键约束。删了会有明显遗憾，但仍认得出人。\n'
    '1-6 分（0.1-0.6）：普通对话、一次性信息、临时安排、寒暄、AI 自己的推测、举例。删了毫无影响。\n'
    '注意：绝大多数日常对话应评 1-3 分。只有"删除后会让 AI 认不出用户"的内容才给 9-10 分。\n'
    '返回 JSON 格式（importance 用 0.0-1.0，即分数/10）：\n'
    '{"importance": 0.0-1.0, "summary": "一句自包含的话", "tags": ["lowercase_tag"], "reasoning": "一句话说明删除测试结论"}';

/// 旁路提取器：把本轮 user + assistant 文本交给模型评估重要性。
/// 不参与主对话流，失败时静默跳过，绝不影响正常聊天。
class MemoryExtractor {
  final DeepSeekProvider provider;

  MemoryExtractor(this.provider);

  Future<MemoryExtraction?> extract({
    required String conversationId,
    required String userMessage,
    required String assistantReply,
  }) async {
    try {
      final response = await provider.sendMessage(
        [
          AiMessage(
            role: 'user',
            content: 'User: $userMessage\nAssistant: $assistantReply',
          )
        ],
        options: const AiRequestOptions(systemPrompt: kMemoryExtractorPrompt),
      );
      final decoded = jsonDecode(response.finalAnswer) as Map<String, dynamic>;
      return MemoryExtraction(
        importance: (decoded['importance'] as num).toDouble(),
        summary: decoded['summary'] as String? ?? '',
        tags: (decoded['tags'] as List<dynamic>?)?.cast<String>() ?? const <String>[],
        reasoning: decoded['reasoning'] as String? ?? '',
      );
    } catch (_) {
      // 旁路功能：解析失败或网络异常都不应打断主对话。
      return null;
    }
  }
}
