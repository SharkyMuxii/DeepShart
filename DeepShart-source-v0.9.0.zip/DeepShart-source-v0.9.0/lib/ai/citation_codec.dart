// target: lib/ai/citation_codec.dart
// 职责：把联网搜索引用的结构化数据编码进 ChatMessage.content，并从 content 解析回来。
//
// 为什么不改 ChatMessage 加字段：消息结构牵一发动全身（同步、向量时钟、toJson、
// 旧库迁移）。用一段带标记的编码塞在正文末尾，既保留全部信息，又不碰数据模型。
// 用 base64(JSON) 而不是裸"标题 - 链接"：标题里含 '-'、换行、'[引用]' 都不会破坏解析，
// 也不会再出现"空数据渲染成一根横线"的事故。

import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../ai/ai_provider.dart';

class CitationCodec {
  const CitationCodec._();

  static const String openTag = '<citations_b64>';
  static const String closeTag = '</citations_b64>';

  /// 把正文与引用编码成一个可存入 content 的字符串。
  /// [thinking] 由调用方单独包 <thinking>，这里只管正文 + 引用。
  static String encode(String answer, List<AiCitation> citations) {
    final buffer = StringBuffer(answer);
    final usable = citations.where((c) => c.title.isNotEmpty || c.url.isNotEmpty).toList();
    if (usable.isEmpty) return answer;

    buffer.writeln();
    buffer.write(openTag);
    final payload = jsonEncode(usable.map((c) => c.toJson()).toList());
    buffer.write(base64Encode(utf8.encode(payload)));
    buffer.write(closeTag);
    return buffer.toString();
  }

  /// 从 content 中拆出正文与引用；没有标记时 citations 为空、正文原样返回。
  static CitationDecoded decode(String content) {
    final start = content.indexOf(openTag);
    if (start < 0) return CitationDecoded(body: content, citations: const <AiCitation>[]);
    final end = content.indexOf(closeTag, start);
    if (end < 0) return CitationDecoded(body: content, citations: const <AiCitation>[]);

    final body = content.substring(0, start).trimRight();
    final encoded = content.substring(start + openTag.length, end).trim();
    final citations = <AiCitation>[];
    try {
      final decoded = utf8.decode(base64Decode(encoded));
      final list = jsonDecode(decoded) as List<dynamic>;
      for (final item in list) {
        if (item is Map<String, dynamic>) {
          citations.add(AiCitation.fromJson(item));
        }
      }
    } catch (_) {
      // 坏数据不应让整条消息显示不出来：正文照常显示，引用区留空。
    }
    return CitationDecoded(body: body, citations: List<AiCitation>.unmodifiable(citations));
  }

  /// 去掉 content 里的引用编码块，用于回填输入框 / 回放给模型 / 复制纯文本。
  static String strip(String content) => decode(content).body;

  /// 在正文里按服务端给的 start_index/end_index 插入 〔n〕 角标。
  ///
  /// 从后往前插入，避免前面的插入改变后面字符的索引。
  /// 没有索引信息的引用跳过（它们仍会在来源列表里列出）。
  static String withInlineMarkers(String body, List<AiCitation> citations) {
    final positioned = <MapEntry<int, int>>[]; // index -> citation number (1-based)
    for (var i = 0; i < citations.length; i++) {
      final c = citations[i];
      final s = c.startIndex;
      if (s == null || s < 0 || s >= body.length) continue;
      positioned.add(MapEntry(s, i + 1));
    }
    if (positioned.isEmpty) return body;

    // 同一位置多个引用合并成一个 〔1,2〕 形式不现实（正则只认纯数字），
    // 这里按位置排序、同位置只保留第一个，其余仍在来源列表可见。
    positioned.sort((a, b) => b.key.compareTo(a.key));
    var result = body;
    final seen = <int>{};
    for (final entry in positioned) {
      if (!seen.add(entry.key)) continue;
      result = result.substring(0, entry.key) +
          '〔${entry.value}〕' +
          result.substring(entry.key);
    }
    return result;
  }
}

@immutable
class CitationDecoded {
  final String body;
  final List<AiCitation> citations;
  const CitationDecoded({required this.body, required this.citations});
}
