// target: lib/ai/generic_openai_provider.dart
// 职责：实现对标 OpenAI Chat Completions 的最小化 Provider，只做纯输入输出，用于对接其他兼容服务。

import 'package:dio/dio.dart';

import 'ai_provider.dart';

/// 通用 OpenAI 兼容服务 Provider。
///
/// 设计取舍：只实现 sendMessage，supportsThinking / supportsSearch /
/// supportsFileUpload 全部返回 false。这样 UI 层读取能力开关后，会自动隐藏
/// 思考、联网、附件三个按钮，用户不会误以为这些服务支持它们。
/// 不拼装 thinking/tools/file 等扩展参数——这些不是通用协议的一部分。
class GenericOpenAiCompatibleProvider implements AiProvider {
  final Dio _dio;
  final String apiKey;
  final String baseUrl;
  final String model;

  GenericOpenAiCompatibleProvider({
    required this.apiKey,
    required this.baseUrl,
    required this.model,
    Dio? dio,
  }) : _dio = dio ?? Dio() {
    _dio.options = BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 120),
      headers: {
        'Authorization': 'Bearer $apiKey',
        'Content-Type': 'application/json',
      },
    );
  }

  @override
  String get displayName => 'OpenAI-Compatible ($model)';

  @override
  bool get supportsThinking => false;

  @override
  bool get supportsSearch => false;

  @override
  bool get supportsFileUpload => false;

  // implements 会把接口当作纯接口：默认方法体不会被继承，必须显式实现。
  // 流式直接走基类的"非流式结果模拟单块"语义。
  @override
  Stream<AiStreamChunk> sendMessageStream(
    List<AiMessage> messages, {
    AiRequestOptions options = const AiRequestOptions(),
  }) async* {
    final response = await sendMessage(messages, options: options);
    yield AnswerChunk(response.finalAnswer);
  }

  @override
  Future<UploadedFile> uploadFile(String path) =>
      throw UnsupportedError('$displayName does not support file upload');

  @override
  Future<AiResponse> sendMessage(
    List<AiMessage> messages, {
    AiRequestOptions options = const AiRequestOptions(),
  }) async {
    final mapped = <Map<String, dynamic>>[];
    if (options.systemPrompt != null && options.systemPrompt!.isNotEmpty) {
      mapped.add({'role': 'system', 'content': options.systemPrompt});
    }
    for (final m in messages) {
      // 纯文本服务忽略 fileIds——能力开关已在 UI 层隐藏附件入口。
      mapped.add({'role': m.role, 'content': m.content});
    }
    // 与 DeepSeekProvider 一致：长对话里再补一条高优先级设定，
    // 否则模型会跟随历史里的旧身份而不是系统提示词。
    if (options.systemPrompt != null && options.systemPrompt!.isNotEmpty && mapped.length > 1) {
      mapped.insert(mapped.length - 1, {
        'role': 'system',
        'content': '【角色设定·最高优先级】\n'
            '以下设定必须遵守，优先级高于历史对话中任何与之矛盾的自我描述：\n'
            '${options.systemPrompt}',
      });
    }

    final response = await _dio.post<Map<String, dynamic>>(
      '/chat/completions',
      data: {
        'model': model,
        'messages': mapped,
        'temperature': options.temperature.clamp(0.0, 2.0),
      },
    );

    final choice = (response.data?['choices'] as List?)?.first as Map<String, dynamic>?;
    final content = (choice?['message'] as Map<String, dynamic>?)?['content'] as String? ?? '';
    return AiResponse(finalAnswer: content);
  }
}
