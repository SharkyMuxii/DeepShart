// target: lib/ai/memory_blacklist.dart
// 职责：记忆点黑名单——命中的内容既不自动进记忆点，也不在对话中提交给大模型。
//
// 用户约定：多个关键词用三个竖线 ||| 分隔，例如 "前女友|||赌博|||某人名"。

class MemoryBlacklist {
  const MemoryBlacklist._();

  static const String separator = '|||';

  /// 把用户输入的整串按 ||| 切成关键词列表，去空、去首尾空格。
  static List<String> parse(String raw) => raw
      .split(separator)
      .map((s) => s.trim())
      .where((s) => s.isNotEmpty)
      .toList(growable: false);

  /// 归一化：用于字面去重与包含匹配。去空白与常见标点，转小写。
  static String normalize(String text) => text
      .toLowerCase()
      .replaceAll(RegExp(r'[\s，。、；：""''！？,.;:!?|]'), '');

  /// 文本是否命中黑名单任一关键词（关键词包含匹配，归一化后比较）。
  static bool matches(String text, List<String> keywords) {
    if (keywords.isEmpty) return false;
    final normalizedText = normalize(text);
    for (final keyword in keywords) {
      final k = normalize(keyword);
      if (k.isNotEmpty && normalizedText.contains(k)) return true;
    }
    return false;
  }
}
