// target: lib/ai/memory_curator.dart
// 职责：记忆点整理——去重、合并同类、按目标比例精简，并与库内条目对齐落盘。
//
// 为什么要单独一层而不是塞进 UI：
//   整理涉及"分批调用 + 结果对齐 + 软删除"，任何一步出错都会造成记忆丢失。
//   把它做成可单测的纯业务对象，UI 只负责确认与展示进度。
//
// 与"同步时去重"的分工（用户明确要求）：
//   同步只做字面归一化去重（免费、必做）；语义级去重只在用户主动点"整理"时
//   调模型执行——否则每次同步都会产生一次账单。

import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../data/models/chat_message.dart' show VectorClock;
import '../data/models/important_memory.dart';
import '../data/store/important_memory_store.dart';
import 'ai_provider.dart';
import 'token_estimator.dart';

/// 整理结果。数值全部来自真实执行过程，供 UI 展示"省了多少"。
@immutable
class CuratorOutcome {
  final int beforeCount;
  final int afterCount;
  final int beforeTokens;
  final int afterTokens;

  /// 实际调用了模型几次（分批数）。
  final int calls;

  /// 预计花费（人民币，按官方缓存未命中的输入价粗算）。
  final double estimatedCost;

  const CuratorOutcome({
    required this.beforeCount,
    required this.afterCount,
    required this.beforeTokens,
    required this.afterTokens,
    required this.calls,
    required this.estimatedCost,
  });

  bool get changed => afterTokens < beforeTokens || afterCount < beforeCount;
}

/// 整理前的花费预估，用于"先报账再执行"。
@immutable
class CuratorEstimate {
  final int batchCount;
  final int inputTokens;
  final double estimatedCost;

  const CuratorEstimate({
    required this.batchCount,
    required this.inputTokens,
    required this.estimatedCost,
  });

  String get display => '约 ${batchCount} 次调用，输入约 ${inputTokens} token，'
      '预计 ¥${estimatedCost.toStringAsFixed(3)}';
}

class MemoryCurator {
  final AiProvider provider;
  final ImportantMemoryStore store;

  MemoryCurator({required this.provider, required this.store});

  /// 单批输入上限。太小会切碎上下文、太大则单次账单高。
  static const int batchInputTokens = 6000;

  /// 默认压到原体积的 50%（用户指定的默认值）。
  static const double defaultKeepRatio = 0.5;

  /// 官方 V3.2 缓存未命中输入价：$0.28 / 1M token ≈ ¥2.0 / 1M。
  static const double inputPricePerToken = 2.0 / 1000000;

  /// 输出价 $0.42 / 1M ≈ ¥3.0 / 1M，整理输出远小于输入，按 1/4 输入量估。
  static const double outputPricePerToken = 3.0 / 1000000;

  /// 只算账不动手。
  CuratorEstimate estimate(List<ImportantMemory> memories, {double keepRatio = defaultKeepRatio}) {
    final total = memories.fold<int>(0, (s, m) => s + TokenEstimator.estimate(m.summary) + 6);
    final batches = math.max(1, (total / batchInputTokens).ceil());
    // 每批带 prompt 开销约 300 token。
    final input = total + batches * 300;
    final output = (input * keepRatio).round();
    return CuratorEstimate(
      batchCount: batches,
      inputTokens: input,
      estimatedCost: input * inputPricePerToken + output * outputPricePerToken,
    );
  }

  /// 执行整理并写回。
  ///
  /// [apply] 为 false 时只计算不落盘（测试与预览用）。
  Future<CuratorOutcome> curate({
    required String conversationId,
    required String deviceId,
    double keepRatio = defaultKeepRatio,
    bool apply = true,
  }) async {
    final all = await store.readAll(conversationId);
    // 锁定的记忆点完全不参与整理：既不进模型，也不被复用 id 改写或软删除。
    // 用户明确要求"锁定后不会参加记忆点整理"，这是核心锚点的保险。
    final locked = all.where((m) => m.locked).toList(growable: false);
    final memories = all.where((m) => !m.locked).toList(growable: false);
    if (memories.isEmpty) {
      return CuratorOutcome(
        beforeCount: all.length,
        afterCount: locked.length,
        beforeTokens: all.fold<int>(0, (s, m) => s + TokenEstimator.estimate(m.summary) + 6),
        afterTokens: locked.fold<int>(0, (s, m) => s + TokenEstimator.estimate(m.summary) + 6),
        calls: 0,
        estimatedCost: 0,
      );
    }

    final beforeTokens = memories.fold<int>(
      0,
      (s, m) => s + TokenEstimator.estimate(m.summary) + 6,
    );
    final estimateBefore = estimate(memories, keepRatio: keepRatio);

    // 第一步：字面去重（零成本）。同一句话被提取两次是最常见的冗余来源。
    final byText = <String, ImportantMemory>{};
    for (final m in _byImportance(memories)) {
      final key = _normalize(m.summary);
      final existing = byText[key];
      // 保留重要度更高的那条；相同则保留更早创建的（信息通常更原始）。
      if (existing == null || m.importance > existing.importance) {
        byText[key] = m;
      }
    }
    var working = byText.values.toList(growable: false);

    // 第二步：分批交给模型做语义合并与精简。
    final targetTokens = math.max(
      200,
      (beforeTokens * keepRatio).round(),
    );

    final batches = _splitBatches(working);
    var calls = 0;
    final merged = <String>[];
    for (final batch in batches) {
      final texts = batch.map((m) => m.summary).toList(growable: false);
      // 每批的目标长度按批内占比分配，避免某批过度压缩。
      final batchTokens = texts.fold<int>(0, (s, t) => s + TokenEstimator.estimate(t) + 6);
      final batchTarget = math.max(
        80,
        (batchTokens * keepRatio).round(),
      );
      try {
        final result = await _callModel(texts, batchTarget);
        calls++;
        merged.addAll(result);
      } catch (_) {
        // 模型失败不能让用户丢记忆：这一批保留原文。
        merged.addAll(texts);
      }
    }

    // 第三步：若合并后仍显著超出目标（跨批重复），再跑一轮收敛。
    var finalTexts = _dedupeTexts(merged);
    var afterTokens = finalTexts.fold<int>(0, (s, t) => s + TokenEstimator.estimate(t) + 6);
    if (afterTokens > targetTokens * 1.6 && finalTexts.length > 3) {
      try {
        final second = await _callModel(finalTexts, targetTokens);
        calls++;
        finalTexts = _dedupeTexts(second);
        afterTokens = finalTexts.fold<int>(0, (s, t) => s + TokenEstimator.estimate(t) + 6);
      } catch (_) {
        // 收敛失败就接受当前结果，不再二次冒险。
      }
    }

    if (apply) {
      await _persist(
        conversationId: conversationId,
        deviceId: deviceId,
        originals: _byImportance(working),
        curated: finalTexts,
      );
    }

    final lockedTokens = locked.fold<int>(0, (s, m) => s + TokenEstimator.estimate(m.summary) + 6);
    return CuratorOutcome(
      beforeCount: all.length,
      afterCount: finalTexts.length + locked.length,
      beforeTokens: beforeTokens + lockedTokens,
      afterTokens: afterTokens + lockedTokens,
      calls: calls,
      estimatedCost: estimateBefore.estimatedCost,
    );
  }

  List<ImportantMemory> _byImportance(List<ImportantMemory> list) {
    final copy = List<ImportantMemory>.from(list);
    copy.sort((a, b) {
      final byImportance = b.importance.compareTo(a.importance);
      if (byImportance != 0) return byImportance;
      return a.createdAt.compareTo(b.createdAt);
    });
    return copy;
  }

  /// 归一化：去空白、去标点、小写，用于字面去重。
  String _normalize(String text) =>
      text.toLowerCase().replaceAll(RegExp(r'[\s，。、；：""''！？,.;:!?]'), '');

  List<String> _dedupeTexts(List<String> texts) {
    final seen = <String>{};
    final result = <String>[];
    for (final t in texts) {
      final trimmed = t.trim();
      if (trimmed.isEmpty) continue;
      if (seen.add(_normalize(trimmed))) result.add(trimmed);
    }
    return result;
  }

  List<List<ImportantMemory>> _splitBatches(List<ImportantMemory> list) {
    final batches = <List<ImportantMemory>>[];
    var current = <ImportantMemory>[];
    var tokens = 0;
    for (final m in list) {
      final cost = TokenEstimator.estimate(m.summary) + 6;
      if (current.isNotEmpty && tokens + cost > batchInputTokens) {
        batches.add(current);
        current = <ImportantMemory>[];
        tokens = 0;
      }
      current.add(m);
      tokens += cost;
    }
    if (current.isNotEmpty) batches.add(current);
    return batches;
  }

  Future<List<String>> _callModel(List<String> texts, int targetTokens) async {
    final prompt = '你是记忆整理助手。下面是用户在不同对话里累积的"重要记忆点"。\n'
        '任务：\n'
        '1. 删除语义重复的条目（同一事实只留一条，措辞取最完整的）；\n'
        '2. 合并同一主题的碎片（合并后必须是一句自包含的话）；\n'
        '3. 不得新增任何未出现的信息，不得丢弃独立的偏好或事实；\n'
        '4. 总长度控制在 $targetTokens token 以内，优先压缩啰嗦措辞而非丢事实；\n'
        '5. 只输出 JSON，不要解释、不要代码块：\n'
        '{"memories": ["...", "..."]}\n\n'
        '待整理条目：\n${texts.map((t) => '- $t').join('\n')}';

    final response = await provider.sendMessage(
      <AiMessage>[AiMessage(role: 'user', content: prompt)],
    );
    final raw = _extractJson(response.finalAnswer);
    final decoded = jsonDecode(raw);
    final list = decoded is Map ? decoded['memories'] : null;
    if (list is! List) return texts;
    return list.map((e) => e.toString().trim()).where((t) => t.isNotEmpty).toList();
  }

  /// 模型偶尔会带 ```json 代码块或前后废话，这里做一次容错提取。
  String _extractJson(String text) {
    final start = text.indexOf('{');
    final end = text.lastIndexOf('}');
    if (start >= 0 && end > start) return text.substring(start, end + 1);
    return text;
  }

  /// 把整理结果对齐到库内条目。
  ///
  /// 策略：按重要度从高到低，前 N 条复用原 id 改写内容（保留 created/importance），
  /// 其余标记为 deleted（软删除，能同步到对端且可解释）。
  /// 为什么复用 id 而不是"全删全建"：全建会产生一批新记忆点，同步到对端后
  /// 旧的一起留着，等于整理了个寂寞。
  Future<void> _persist({
    required String conversationId,
    required String deviceId,
    required List<ImportantMemory> originals,
    required List<String> curated,
  }) async {
    if (curated.isEmpty) return;

    final reusable = originals.take(curated.length).toList(growable: false);
    for (var i = 0; i < reusable.length; i++) {
      final updated = reusable[i].edit(
        editingDeviceId: deviceId,
        newSummary: curated[i],
      );
      await store.insertOrMerge(updated);
    }

    // 条目数变少：多出来的软删除。
    for (var i = curated.length; i < originals.length; i++) {
      final removed = originals[i].edit(
        editingDeviceId: deviceId,
        newDeleted: true,
      );
      await store.insertOrMerge(removed);
    }

    // 条目数变多（模型拆分了条目）：新增补齐。
    for (var i = originals.length; i < curated.length; i++) {
      await store.insertOrMerge(ImportantMemory(
        id: const Uuid().v4(),
        conversationId: conversationId,
        summary: curated[i],
        tags: const <String>[],
        importance: 0.8,
        createdAt: DateTime.now().toUtc(),
        versionVector: VectorClock.empty().tick(deviceId),
        deviceId: deviceId,
      ));
    }
  }
}
