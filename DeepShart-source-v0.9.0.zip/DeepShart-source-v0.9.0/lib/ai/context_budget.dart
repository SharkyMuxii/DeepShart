// target: lib/ai/context_budget.dart
// 职责：把"上下文上限"落成真实的请求裁剪——决定这一次到底把哪些历史发给模型。
//
// 设计原则（用户明确要求）：
//   1. 上限 = 单次提交给 API 的输入 token 上限，不是"压缩提示线"；
//   2. 裁剪只发生在请求层，**一条记录都不写库**——用户翻历史永远看到全文；
//   3. 当前提问与角色提示词永不被裁（裁了就是答非所问 / 角色失效）；
//   4. 记忆点与开头锚点优先保留，因为"记得设定"比"记得寒暄"重要；
//   5. 滑窗少滑狠滑：一次滑到预算的 55%，靠 anchor 让后续若干轮前缀稳定，
//      否则每轮都从新位置开始 = 缓存全失效 = 越省越贵。

import 'dart:math' as math;

import 'package:flutter/foundation.dart';

import '../data/models/chat_message.dart';
import '../data/models/conversation_settings.dart';
import '../data/models/important_memory.dart';
import 'model_catalog.dart';
import 'token_estimator.dart';

/// 一次裁剪的用量报告。UI 用它回答"这次到底花了多少上下文"。
@immutable
class BudgetReport {
  /// 生效的输入上限（若当前提问本身超长，会临时放宽）。
  final int limit;

  final int systemTokens;
  final int currentTokens;
  final int memoryTokens;
  final int anchorTokens;

  /// 最近历史实际占用。
  final int historyTokens;

  final int totalTokens;

  /// 历史总条数（不含当前提问）。
  final int totalMessages;

  /// 实际带上的历史条数。
  final int includedMessages;

  /// 被滑窗丢弃的历史条数。
  final int droppedMessages;

  /// 记忆点：纳入条数 / 可用条数。
  final int memoryIncluded;
  final int memoryAvailable;

  /// 本次是否发生了滑窗（重新计算了起点）。
  final bool slid;

  /// 下次应当从哪条消息开始（null 表示没有历史可带）。
  final String? nextAnchorId;

  /// 当前提问自身就超过上限时置位——此时历史会被压到最小。
  final bool questionOverflow;

  /// 是否配置了上限。false 表示走默认值。
  final bool customLimit;

  const BudgetReport({
    required this.limit,
    required this.systemTokens,
    required this.currentTokens,
    required this.memoryTokens,
    required this.anchorTokens,
    required this.historyTokens,
    required this.totalTokens,
    required this.totalMessages,
    required this.includedMessages,
    required this.droppedMessages,
    required this.memoryIncluded,
    required this.memoryAvailable,
    required this.slid,
    required this.nextAnchorId,
    required this.questionOverflow,
    required this.customLimit,
  });

  double get usageRatio => limit <= 0 ? 0 : totalTokens / limit;

  /// 给用户看的一句话结论。
  String get summary {
    final buffer = StringBuffer()
      ..write('本次输入约 $totalTokens / $limit token')
      ..write('（历史 ${includedMessages}/${totalMessages} 条');
    if (droppedMessages > 0) buffer.write('，滑掉 ${droppedMessages} 条');
    if (memoryIncluded > 0) buffer.write('，记忆点 $memoryIncluded 条');
    buffer.write('）');
    if (questionOverflow) buffer.write('；当前消息过长，历史已压到最小');
    return buffer.toString();
  }
}

/// 裁剪结果：真正要发出去的历史 + 记忆点 + 报告。
@immutable
class BudgetResult {
  final List<ChatMessage> history;
  final List<ImportantMemory> memories;
  final BudgetReport report;

  const BudgetResult({
    required this.history,
    required this.memories,
    required this.report,
  });
}

class ContextBudget {
  const ContextBudget._();

  /// 未配置上限时的默认值。
  ///
  /// 为什么默认保守：默认值就是"什么都不设置时每次会花多少"，定大了等于
  /// 替用户决定多花钱。想用长上下文的人会主动调，不想调的人应当便宜。
  static const int defaultLimit = 64000;

  /// 记忆点最多占上限的比例。用户要求"稍微高一点"——记忆点带来的连贯性
  /// 收益比多几条闲聊上下文更高，15% 是权衡后的值。
  static const double memoryShare = 0.15;

  /// 记忆点最多占"剩余预算"的比例，避免提问很长时记忆点反客为主。
  static const double memoryMaxShareOfRemaining = 0.40;

  /// 开头锚点的固定预算。用户要求"位置兜底还是那么多"，所以不随上限放大。
  static const int anchorFloorTokens = 2000;

  /// 滑窗后保留比例：一次滑到预算的 55%，留 45% 给后续若干轮。
  static const double slideKeepRatio = 0.55;

  /// 给历史保留的最小可用预算，低于它就认为装不下任何历史。
  static const int minHistoryTokens = 200;

  /// 按上限裁剪一次请求。
  ///
  /// [history] 不含当前提问，且已按 createdAt 升序、已过滤删除与 system 消息。
  /// [slideAnchorId] 是上一轮算出的起点，传它可以让前缀尽量稳定（缓存友好）。
  static BudgetResult fit({
    required List<ChatMessage> history,
    ChatMessage? current,
    List<ImportantMemory> memories = const <ImportantMemory>[],
    required ConversationSettings settings,
    required String modelId,
    String? systemPrompt,
    String? slideAnchorId,
  }) {
    final modelWindow = _windowFor(modelId);
    final configured = settings.contextLimit;
    final customLimit = configured != null && configured > 0;

    // 上限不得超过模型窗口：用户换了小窗口模型后，旧的上限值必须被收住，
    // 否则每次请求都会 400。
    var limit = customLimit ? math.min(configured, modelWindow) : math.min(defaultLimit, modelWindow);

    // 角色提示词会被注入两次（开头 + 末条用户消息前加固），预算必须按两份算，
    // 否则每次都悄悄超出上限。
    final systemTokens = systemPrompt == null || systemPrompt.isEmpty
        ? 0
        : TokenEstimator.estimate(systemPrompt) * 2;

    final currentTokens = current == null ? 0 : TokenEstimator.estimateMessage(current);

    // 当前提问永不裁剪。它本身就超上限时，只能放宽上限并把历史压到最小。
    var questionOverflow = false;
    final minimumNeeded = systemTokens + currentTokens + minHistoryTokens;
    if (minimumNeeded > limit) {
      questionOverflow = true;
      limit = minimumNeeded;
    }

    final remaining = math.max(0, limit - systemTokens - currentTokens);

    // ---- 记忆点：按重要度、再按时间排序，装到预算为止 ----
    final ranked = List<ImportantMemory>.from(memories)
      ..sort((a, b) {
        final byImportance = b.importance.compareTo(a.importance);
        if (byImportance != 0) return byImportance;
        return b.createdAt.compareTo(a.createdAt);
      });

    final memoryBudget = math.min(
      remaining * memoryShare,
      remaining * memoryMaxShareOfRemaining,
    ).floor();

    final pickedMemories = <ImportantMemory>[];
    var memoryTokens = 0;
    for (final memory in ranked) {
      final cost = TokenEstimator.estimate(memory.summary) + 6;
      if (memoryTokens + cost > memoryBudget) break;
      memoryTokens += cost;
      pickedMemories.add(memory);
    }

    // ---- 开头锚点：显式钉住的最优先，其次才是"开头几条"的位置兜底 ----
    final anchorBudget = math.min(anchorFloorTokens, remaining * 0.10).floor();
    // 锚点最多占历史条数的 30%，避免短会话被锚点吃光。
    final anchorMaxCount = history.isEmpty ? 0 : math.max(1, (history.length * 0.30).floor());
    final anchorMessages = <ChatMessage>[];
    var anchorTokens = 0;

    // 1) 用户显式钉住的锚点：位置无关，可以出现在会话任意位置。
    //    允许略微超出锚点预算（1.5 倍），因为这是用户主动指定的"必须记住"，
    //    静默丢掉比多花一点 token 更糟。
    final pinnedCeiling = (anchorBudget * 1.5).round();
    for (final message in history.where((m) => m.pinned)) {
      final cost = TokenEstimator.estimateMessage(message);
      if (anchorTokens + cost > pinnedCeiling) break;
      anchorTokens += cost;
      anchorMessages.add(message);
    }

    // 2) 位置兜底：填满剩余锚点预算，只取会话最前面几条。
    for (final message in history) {
      if (anchorMessages.length >= anchorMaxCount * 2) break;
      if (anchorTokens >= anchorBudget) break;
      if (anchorMessages.contains(message)) continue;
      final cost = TokenEstimator.estimateMessage(message);
      if (anchorTokens + cost > anchorBudget) break;
      anchorTokens += cost;
      anchorMessages.add(message);
    }

    // ---- 最近历史：吃掉剩余预算，必要时滑窗 ----
    final historyBudget = math.max(
      0,
      remaining - memoryTokens - anchorTokens,
    );

    var slid = false;
    var startIndex = 0;
    var recent = <ChatMessage>[];

    if (historyBudget >= minHistoryTokens && history.isNotEmpty) {
      if (slideAnchorId != null) {
        final idx = history.indexWhere((m) => m.id == slideAnchorId);
        if (idx >= 0) startIndex = idx;
      }

      var fromStart = 0;
      for (var i = startIndex; i < history.length; i++) {
        fromStart += TokenEstimator.estimateMessage(history[i]);
      }

      if (fromStart <= historyBudget) {
        // 还装得下：完全不动起点，前缀保持连续，缓存可以持续命中。
        recent = history.sublist(startIndex);
      } else {
        // 装不下了：一次滑到预算的 55%，让接下来几十轮都不用再滑。
        final target = (historyBudget * slideKeepRatio).round();
        var acc = 0;
        var cut = history.length;
        for (var i = history.length - 1; i >= 0; i--) {
          final cost = TokenEstimator.estimateMessage(history[i]);
          if (acc + cost > target) break;
          acc += cost;
          cut = i;
        }
        // 至少带 1 条，否则等于把最新上下文也丢了。
        if (cut >= history.length && history.isNotEmpty) {
          cut = history.length - 1;
        }
        recent = history.sublist(cut);
        startIndex = cut;
        slid = true;
      }
    }

    // ---- 合并锚点与最近段，去重并按时间排序 ----
    final seen = <String>{};
    final included = <ChatMessage>[];
    for (final m in anchorMessages) {
      if (seen.add(m.id)) included.add(m);
    }
    for (final m in recent) {
      if (seen.add(m.id)) included.add(m);
    }
    included.sort((a, b) => a.createdAt.compareTo(b.createdAt));

    // 首条必须是 user：以孤立的 assistant 回复开头的历史既脱离提问没有意义，
    // 部分服务端还会直接拒绝这种序列。
    while (included.isNotEmpty && included.first.role == MessageRole.assistant) {
      included.removeAt(0);
    }

    var historyTokens = 0;
    for (final m in included) {
      historyTokens += TokenEstimator.estimateMessage(m);
    }

    final totalTokens = systemTokens + currentTokens + memoryTokens + historyTokens;

    final nextAnchor = included.isEmpty
        ? null
        : (recent.isNotEmpty ? recent.first.id : included.first.id);

    return BudgetResult(
      history: List<ChatMessage>.unmodifiable(included),
      memories: List<ImportantMemory>.unmodifiable(pickedMemories),
      report: BudgetReport(
        limit: limit,
        systemTokens: systemTokens,
        currentTokens: currentTokens,
        memoryTokens: memoryTokens,
        anchorTokens: anchorTokens,
        historyTokens: historyTokens,
        totalTokens: totalTokens,
        totalMessages: history.length,
        includedMessages: included.length,
        droppedMessages: math.max(0, history.length - included.length),
        memoryIncluded: pickedMemories.length,
        memoryAvailable: memories.length,
        slid: slid,
        nextAnchorId: nextAnchor,
        questionOverflow: questionOverflow,
        customLimit: customLimit,
      ),
    );
  }

  /// 模型窗口查表。口径与设置页共用 [ModelCatalog] 一份，避免"设置页说能设
  /// 512K、预算层却按 128K 裁"这种两套标准打架。
  static int _windowFor(String modelId) => ModelCatalog.windowFor(modelId);
}
