// target: lib/ai/model_catalog.dart
// 职责：维护可用模型清单与"模型 → 上下文窗口"映射，供全局/会话设置选择，并给上下文上限档位提供上界。
//
// 为什么需要这张表（而不是直接用接口返回）：
//   DeepSeek 的 GET /models 只返回 id，不返回上下文窗口；而"能设多大的上下文上限"
//   完全取决于窗口。没有映射就只能让用户随便填，结果就是请求被服务端 400。
//   所以这里维护一份内置表，并用接口返回的 id 动态补齐（新模型按保守值处理）。

import 'package:flutter/foundation.dart';

/// 上下文上限的可选档位（token）。UI 只暴露这些值，避免用户填出畸形数字。
const List<int> kContextLimitTiers = <int>[
  64000,
  128000,
  256000,
  512000,
  1000000,
];

/// 默认模型 id。与旧版本保持兼容（历史会话没有 model 列时按它走）。
const String kDefaultModelId = 'deepseek-flash';

@immutable
class ModelInfo {
  final String id;

  /// 展示名。未知模型直接用 id。
  final String label;

  /// 上下文窗口（token）。
  final int contextWindow;

  /// 是否支持思考模式。DeepSeek 全线支持，保留字段便于将来接别的厂商。
  final bool thinkingCapable;

  /// 是否来自内置表。false 表示接口新出现、尚未内置的模型。
  final bool builtin;

  const ModelInfo({
    required this.id,
    required this.label,
    required this.contextWindow,
    this.thinkingCapable = true,
    this.builtin = true,
  });

  /// 例如 128K / 1M，给下拉菜单做副标题。
  String get windowLabel => contextWindow >= 1000000
      ? '${(contextWindow / 1000000).toStringAsFixed(contextWindow % 1000000 == 0 ? 0 : 1)}M 上下文'
      : '${(contextWindow / 1000).round()}K 上下文';
}

class ModelCatalog {
  const ModelCatalog._();

  /// 内置表。窗口值来自 DeepSeek 官方文档：
  ///   - V3.2 的 chat / reasoner 两个别名均为 128K；
  ///   - V4 系列（flash / pro）为 1M。
  /// 分不清具体代际时按 128K 保守处理 —— 保守的代价只是"不能设太大"，
  /// 激进的代价是请求直接 400，两者不对称。
  ///
  /// 2026-11 实测：服务端报错 "The supported API model names are
  /// deepseek-flash, deepseek-v4-pro"。旧的 deepseek-pro / deepseek-v4-flash
  /// 已被废弃，必须从可选项移除，否则用户一选就 400。
  static const List<ModelInfo> builtin = <ModelInfo>[
    ModelInfo(
      id: 'deepseek-v4-pro',
      label: 'DeepSeek V4 Pro',
      contextWindow: 1000000,
    ),
    ModelInfo(
      id: 'deepseek-flash',
      label: 'DeepSeek Flash',
      contextWindow: 1000000,
    ),
    // chat / reasoner 是 V3.2 的老别名，服务端仍兼容，保留给老会话。
    ModelInfo(
      id: 'deepseek-chat',
      label: 'deepseek-chat（V3.2）',
      contextWindow: 128000,
    ),
    ModelInfo(
      id: 'deepseek-reasoner',
      label: 'deepseek-reasoner（V3.2 思考）',
      contextWindow: 128000,
    ),
  ];

  /// 失效模型名 → 当前有效名。老用户设置里存了旧 id 时，在发请求前
  /// 自动映射，避免升级后一发送就 400。基于服务端 2026-11 的错误提示。
  static const Map<String, String> _retiredIds = <String, String>{
    'deepseek-pro': 'deepseek-v4-pro',
    'deepseek-v4-flash': 'deepseek-flash',
  };

  /// 把可能过时的模型 id 归一化成服务端当前接受的名字。
  /// 未知 id 原样返回（可能是服务端新上的模型，不该擅自改写）。
  static String canonicalize(String id) {
    final trimmed = id.trim();
    return _retiredIds[trimmed.toLowerCase()] ?? trimmed;
  }

  /// 未知模型的保守窗口。
  static const int unknownContextWindow = 128000;

  static ModelInfo? find(String id) {
    for (final m in builtin) {
      if (m.id == id) return m;
    }
    return null;
  }

  /// 查窗口。未知模型按 [unknownContextWindow] 处理。
  static int windowFor(String modelId) =>
      find(modelId)?.contextWindow ?? unknownContextWindow;

  /// 该模型可选的最大档位；若窗口比最小档位还小，返回窗口本身。
  static int maxLimitFor(String modelId) {
    final window = windowFor(modelId);
    var best = 0;
    for (final tier in kContextLimitTiers) {
      if (tier <= window) best = tier;
    }
    return best == 0 ? window : best;
  }

  /// 可选档位（已按模型窗口过滤）。
  static List<int> tiersFor(String modelId) {
    final window = windowFor(modelId);
    final tiers = kContextLimitTiers.where((t) => t <= window).toList(growable: false);
    return tiers.isEmpty ? <int>[window] : tiers;
  }

  /// 把接口返回的 id 列表与内置表合并：内置的排前面并保留元信息，
  /// 新出现的追加在后（附"未知窗口"提示）。
  static List<ModelInfo> merge(Iterable<String> remoteIds) {
    final seen = <String>{};
    final result = <ModelInfo>[];
    for (final m in builtin) {
      seen.add(m.id);
      result.add(m);
    }
    for (final id in remoteIds) {
      var trimmed = id.trim();
      if (trimmed.isEmpty) continue;
      // 接口/缓存里若还有失效名，归一到有效名再收录，避免下拉里出现
      // 一选就 400 的选项（服务端已明确废弃 deepseek-pro）。
      trimmed = canonicalize(trimmed);
      if (!seen.add(trimmed)) continue;
      result.add(ModelInfo(
        id: trimmed,
        label: trimmed,
        contextWindow: unknownContextWindow,
        builtin: false,
      ));
    }
    return List<ModelInfo>.unmodifiable(result);
  }
}

/// 档位的人类可读标签：64K / 128K / 256K / 512K / 1M。
String contextLimitLabel(int tokens) {
  if (tokens >= 1000000) {
    final m = tokens / 1000000;
    return '${m.toStringAsFixed(m % 1 == 0 ? 0 : 1)}M';
  }
  return '${(tokens / 1000).round()}K';
}
