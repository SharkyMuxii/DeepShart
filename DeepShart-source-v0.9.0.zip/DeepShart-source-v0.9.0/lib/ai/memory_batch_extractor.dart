// target: lib/ai/memory_batch_extractor.dart
// 职责：把"一键设置记忆点"落成可控的批量任务——按轮次分批提交，可取消、可预估花费。
//
// 为什么必须分批（用户实测担忧，且确实会炸）：
//   一次性把 100 万 token 的对话丢给模型请求记忆点，必然超出模型窗口直接 400；
//   即便不超，单次账单也大得离谱。按 20 轮一批，既安全又能看到进度。

import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../data/models/chat_message.dart';
import '../data/models/important_memory.dart';
import '../data/store/important_memory_store.dart';
import '../data/store/message_store.dart';
import 'ai_provider.dart';
import 'deepseek_provider.dart' show kMemoryImportanceThreshold;
import 'memory_blacklist.dart';
import 'token_estimator.dart';

/// 批量提取的结果。
@immutable
class BatchMemoryOutcome {
  final int scannedMessages;
  final int batches;
  final int saved;
  final int inputTokens;
  final double estimatedCost;
  final bool cancelled;

  const BatchMemoryOutcome({
    required this.scannedMessages,
    required this.batches,
    required this.saved,
    required this.inputTokens,
    required this.estimatedCost,
    this.cancelled = false,
  });

  String get display => cancelled
      ? '已取消：处理 $scannedMessages 条，新增 $saved 个记忆点'
      : '处理 $scannedMessages 条，新增 $saved 个记忆点'
          '（$batches 批，约 ¥${estimatedCost.toStringAsFixed(3)}）';
}

/// 批量提取的预估，用于按钮上直接标价。
@immutable
class BatchMemoryEstimate {
  final int batches;
  final int inputTokens;
  final double estimatedCost;

  const BatchMemoryEstimate({
    required this.batches,
    required this.inputTokens,
    required this.estimatedCost,
  });

  String get display => '$batches 批 · 输入约 $inputTokens token · 预计 ¥${estimatedCost.toStringAsFixed(3)}';
}

class MemoryBatchExtractor {
  final AiProvider provider;
  final MessageStore messageStore;
  final ImportantMemoryStore memoryStore;

  MemoryBatchExtractor({
    required this.provider,
    required this.messageStore,
    required this.memoryStore,
  });

  /// 一批包含多少条消息（≈ 20 轮问答）。
  static const int messagesPerBatch = 40;

  /// 低于这个重要度不值得存。用户要求"严厉一些"后统一提到 0.85，
  /// 与单轮提取器共用同一常量，避免两处标准不一致。
  static const double importanceThreshold = kMemoryImportanceThreshold;

  /// 与 MemoryCurator 采用同一价格口径（缓存未命中输入）。
  static const double inputPricePerToken = 2.0 / 1000000;
  static const double outputPricePerToken = 3.0 / 1000000;

  /// 只算账。UI 在按钮上直接显示这个，避免"点完才发现贵"。
  BatchMemoryEstimate estimate(List<ChatMessage> messages) {
    final usable = messages.where((m) => m.role != MessageRole.system).toList(growable: false);
    final batches = (usable.length / messagesPerBatch).ceil().clamp(0, 999999);
    final inputTokens = TokenEstimator.estimateMessages(usable) + batches * 260;
    // 输出按每批约 600 token（多条记忆点的 JSON）。
    final outputTokens = batches * 600;
    return BatchMemoryEstimate(
      batches: batches,
      inputTokens: inputTokens,
      estimatedCost:
          inputTokens * inputPricePerToken + outputTokens * outputPricePerToken,
    );
  }

  /// 读取需要处理的消息。[sinceMs] 为 null 表示全量重刷。
  Future<List<ChatMessage>> pendingMessages(
    String conversationId, {
    int? sinceMs,
  }) async {
    final all = await messageStore.readAll(conversationId);
    final usable = all
        .where((m) => m.role != MessageRole.system && m.content.trim().isNotEmpty)
        .toList(growable: false);
    if (sinceMs == null) return usable;
    return usable
        .where((m) => m.createdAt.millisecondsSinceEpoch > sinceMs)
        .toList(growable: false);
  }

  /// 执行批量提取。
  ///
  /// [onProgress] 每批回调一次（已完成批数, 总批数）。
  /// [shouldCancel] 返回 true 时在当前批结束后停止，已提取的部分保留。
  Future<BatchMemoryOutcome> run({
    required String conversationId,
    required String deviceId,
    List<ChatMessage>? messages,
    int? sinceMs,
    List<String> blacklist = const <String>[],
    void Function(int done, int total)? onProgress,
    bool Function()? shouldCancel,
  }) async {
    final source = messages ?? await pendingMessages(conversationId, sinceMs: sinceMs);
    if (source.isEmpty) {
      return const BatchMemoryOutcome(
        scannedMessages: 0,
        batches: 0,
        saved: 0,
        inputTokens: 0,
        estimatedCost: 0,
      );
    }

    // 已有记忆点用于字面去重，避免同一句话每跑一次就多一条。
    // 用 Map 保留原对象：再次提取命中时给它 reextractCount+1（"回忆越多记得越牢"）。
    final existing = await memoryStore.readAll(conversationId);
    final known = <String, ImportantMemory>{
      for (final m in existing) _normalize(m.summary): m,
    };

    final batches = <List<ChatMessage>>[];
    for (var i = 0; i < source.length; i += messagesPerBatch) {
      batches.add(source.sublist(
        i,
        (i + messagesPerBatch).clamp(0, source.length),
      ));
    }

    var saved = 0;
    var inputTokens = 0;
    var cancelled = false;

    for (var index = 0; index < batches.length; index++) {
      if (shouldCancel?.call() ?? false) {
        cancelled = true;
        break;
      }
      final batch = batches[index];
      final transcript = batch
          .map((m) => '${m.role == MessageRole.assistant ? 'AI' : '用户'}: ${m.content}')
          .join('\n');
      inputTokens += TokenEstimator.estimate(transcript) + 260;

      List<_Extracted> items;
      try {
        items = await _callModel(transcript);
      } catch (_) {
        // 单批失败不影响其他批：跳过并继续，最后如实报告。
        onProgress?.call(index + 1, batches.length);
        continue;
      }

      for (final item in items) {
        if (item.importance < importanceThreshold) continue;
        // 黑名单命中的条目直接跳过，不进记忆点。
        if (MemoryBlacklist.matches(item.summary, blacklist)) continue;
        final key = _normalize(item.summary);
        if (key.isEmpty) continue;
        final prior = known[key];
        if (prior != null) {
          // 再次命中：给旧记忆点加权（回忆越多记得越牢）。edit() 会 tick 时钟，
          // 因此能覆盖写入而不是被 insertOrMerge 判 equal 丢弃。
          await memoryStore.insertOrMerge(prior.edit(
            editingDeviceId: deviceId,
            newReextractCount: prior.reextractCount + 1,
          ));
          continue;
        }
        final created = ImportantMemory.create(
          conversationId: conversationId,
          summary: item.summary,
          tags: item.tags,
          importance: item.importance,
          deviceId: deviceId,
        );
        await memoryStore.insertOrMerge(created);
        known[key] = created; // 占位，防止本轮内重复
        saved++;
      }
      onProgress?.call(index + 1, batches.length);
    }

    return BatchMemoryOutcome(
      scannedMessages: source.length,
      batches: batches.length,
      saved: saved,
      inputTokens: inputTokens,
      estimatedCost: inputTokens * inputPricePerToken +
          batches.length * 600 * outputPricePerToken,
      cancelled: cancelled,
    );
  }

  String _normalize(String text) =>
      text.toLowerCase().replaceAll(RegExp(r'[\s，。、；：""''！？,.;:!?]'), '');

  Future<List<_Extracted>> _callModel(String transcript) async {
    const prompt = '你是记忆提取助手。下面是一段用户与 AI 的对话。\n'
        '对每条候选信息做**删除测试**：如果把这段话从记忆里永久删掉，'
        'AI 以后还会不会认得用户是谁、会不会破坏核心情感连接或反复强调的偏好？\n'
        '只有"删了就认不出人/情感断裂"的才给高分，务必严格，宁可少存。\n'
        '只提取：核心身份锚点（名字、职业、宠物、关系设定）、用户明确要求记住的事、'
        '不可动摇的稳定偏好与禁忌。\n'
        '不要提取：寒暄、一次性信息、临时安排、AI 的推测、对话里的举例。\n'
        '每条必须是一句自包含的话（脱离上下文也能读懂）。\n'
        'importance：0.9-1.0=核心身份锚点（删了认不出人）/ 0.7-0.8=重要偏好'
        '（删了有明显遗憾但仍认得出）/ 0.1-0.6=普通信息（删了无影响，不要存）。\n'
        '大多数日常内容应评 0.1-0.3，不要因为其"看起来有用"就给高分。\n'
        '只输出 JSON，不要解释：\n'
        '{"memories":[{"importance":0.9,"summary":"...","tags":["lowercase_tag"]}]}\n'
        '若没有任何值得记住的内容，输出 {"memories":[]}。\n\n'
        '对话：\n';

    final response = await provider.sendMessage(
      <AiMessage>[AiMessage(role: 'user', content: '$prompt$transcript')],
    );
    final raw = _extractJson(response.finalAnswer);
    final decoded = jsonDecode(raw);
    final list = decoded is Map ? decoded['memories'] : null;
    if (list is! List) return const <_Extracted>[];

    final result = <_Extracted>[];
    for (final item in list) {
      if (item is! Map) continue;
      final summary = item['summary']?.toString().trim() ?? '';
      if (summary.isEmpty) continue;
      final importance = (item['importance'] as num?)?.toDouble() ?? 0.5;
      final tags = (item['tags'] as List?)
              ?.map((t) => t.toString().trim().toLowerCase())
              .where((t) => t.isNotEmpty)
              .toList() ??
          const <String>[];
      result.add(_Extracted(
        summary: summary,
        importance: importance,
        tags: tags,
      ));
    }
    return result;
  }

  String _extractJson(String text) {
    final start = text.indexOf('{');
    final end = text.lastIndexOf('}');
    if (start >= 0 && end > start) return text.substring(start, end + 1);
    return text;
  }
}

@immutable
class _Extracted {
  final String summary;
  final double importance;
  final List<String> tags;

  const _Extracted({
    required this.summary,
    required this.importance,
    required this.tags,
  });
}
