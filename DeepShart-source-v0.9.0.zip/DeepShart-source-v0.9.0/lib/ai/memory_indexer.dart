// target: lib/ai/memory_indexer.dart
// 职责：记忆索引的纯逻辑——判断用户是否在问"记忆"，从问题里自动提取检索关键词，
//       判断上下文内已有记忆是否覆盖了该问题。全部纯函数，便于单测。
//
// 为什么不用 AI 生成关键词：那会为每次"问记忆"多一次 API 调用（延迟 + 成本）。
// 中文场景下从问题里剥掉停用词、取 2 字以上的词/英文词，对"我记得…吗"、"我之前
// 说过的 X"这类问法已经够准；搜不到时最坏结果只是没补充记忆，不会答错。

/// 问"记忆"的触发词。命中任一即认为用户在回忆之前的内容。
const List<String> kMemoryQueryMarkers = <String>[
  '记得', '记住', '记得吗', '说过', '提过', '聊过', '之前', '以前', '上次',
  '刚才', '回忆', '回想', '我的', '我喜欢', '我讨厌', '我习惯', '我要求',
  '你答应', '约定', '我说', '告诉你', '告诉过', '是不是跟', '之前那个',
  '你还记', '有没有记', '我记得', 'don\'t you remember', 'remember',
  '我之前', '早先', '先前', '一开始', '最初',
];

/// 停用词：提取关键词时剔除，避免搜出一堆"的/了/吗"。
const Set<String> kMemoryQueryStopWords = <String>{
  '的', '了', '吗', '呢', '吧', '啊', '呀', '哦', '嗯', '是', '我', '你',
  '他', '她', '它', '这', '那', '个', '些', '在', '有', '和', '与', '或',
  '不', '没', '把', '被', '给', '对', '从', '到', '就', '还', '也', '都',
  '而', '并', '很', '太', '再', '又', '请', '问', '一下', '现在', '什么',
  '怎么', '为什么', '哪', '谁', '多少', '是否', 'can', 'you', 'the', 'a',
  'is', 'it', 'my', 'do', 'did', 'what', 'where', 'when',
};

abstract final class MemoryIndexer {
  /// 用户这句话是不是在问"记忆/之前的事"。
  static bool looksLikeMemoryQuery(String text) {
    final lowered = text.toLowerCase();
    for (final marker in kMemoryQueryMarkers) {
      if (lowered.contains(marker.toLowerCase())) return true;
    }
    return false;
  }

  /// 从问题里自动提取检索关键词。
  /// 中文按连续汉字切 2~6 字滑窗，英文按单词，剔除停用词，去重后最多 [max] 个。
  static List<String> extractKeywords(String text, {int max = 6}) {
    final keywords = <String>[];
    final seen = <String>{};

    void add(String w) {
      final t = w.trim().toLowerCase();
      if (t.length < 2 || kMemoryQueryStopWords.contains(t) || seen.contains(t)) return;
      seen.add(t);
      keywords.add(t);
    }

    // 英文 / 数字词
    for (final m in RegExp(r'[A-Za-z0-9_]{2,}').allMatches(text)) {
      add(m.group(0)!);
    }
    // 中文：先取连续汉字串，再切成 2~4 字的片段（覆盖"颜色偏好"这类组合）。
    for (final m in RegExp(r'[\u4e00-\u9fff]{2,}').allMatches(text)) {
      final run = m.group(0)!;
      if (run.length <= 4) {
        add(run);
      } else {
        for (var len = 4; len >= 2; len--) {
          for (var i = 0; i + len <= run.length; i++) {
            add(run.substring(i, i + len));
          }
        }
      }
    }
    // 长词优先，避免"我"这种单字或过短片段排在前面淹没问题核心。
    keywords.sort((a, b) => b.length.compareTo(a.length));
    return keywords.take(max).toList(growable: false);
  }

  /// 上下文内已有的记忆（summary 列表）是否已经覆盖这些关键词。
  /// 命中任意一个关键词就算"上下文里已有相关记忆"，无需再去全库搜。
  static bool contextCovers(List<String> summaries, List<String> keywords) {
    if (keywords.isEmpty) return true;
    final joined = summaries.join('\n').toLowerCase();
    for (final k in keywords) {
      if (joined.contains(k)) return true;
    }
    return false;
  }
}
