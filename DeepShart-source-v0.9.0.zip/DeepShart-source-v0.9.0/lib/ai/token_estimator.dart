// target: lib/ai/token_estimator.dart
// 职责：近似 token 估算。独立成文件是为了让"预算裁剪"和"压缩"共用同一套口径。
//
// 为什么不能继续用"中文 1 字 = 1 token"：
//   实测 DeepSeek 对中文约 0.6~0.7 token/字，旧口径把占用高估了近 1.6 倍。
//   后果是用户设了 64K 上限，实际只装了约 40K 的内容，而界面上显示"已用 60K"，
//   两边都对不上。校准后"设多少就是多少"，压缩也不会被过早触发。

import '../data/models/chat_message.dart';

class TokenEstimator {
  const TokenEstimator._();

  /// 中文/日文假名的经验系数（token per 字）。
  static const double cjkFactor = 0.65;

  /// 其余字符（ASCII、标点、空格、emoji）的经验系数（token per 字符）。
  static const double otherFactor = 0.28;

  static int estimate(String text) {
    if (text.isEmpty) return 0;
    var cjk = 0;
    var other = 0;
    for (final r in text.runes) {
      final isCjk = (r >= 0x3040 && r <= 0x30FF) || // 假名
          (r >= 0x3400 && r <= 0x4DBF) || // 扩展 A
          (r >= 0x4E00 && r <= 0x9FFF) || // 基本汉字
          (r >= 0xF900 && r <= 0xFAFF) || // 兼容汉字
          (r >= 0xFF00 && r <= 0xFF65); // 全角标点
      if (isCjk) {
        cjk++;
      } else {
        other++;
      }
    }
    return (cjk * cjkFactor + other * otherFactor).ceil();
  }

  /// 每条消息额外 4 token：角色标签、分隔符等协议开销。
  static int estimateMessage(ChatMessage message) =>
      estimate(message.content) + 4;

  static int estimateMessages(Iterable<ChatMessage> messages) =>
      messages.fold(0, (sum, m) => sum + estimateMessage(m));
}
