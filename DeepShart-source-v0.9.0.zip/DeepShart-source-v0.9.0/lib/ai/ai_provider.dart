// target: lib/ai/ai_provider.dart
// 职责：定义多厂商 AI 服务的统一抽象接口与响应结构，供 UI 层按能力开关调度，不感知具体厂商。

import 'dart:async';

import 'package:flutter/foundation.dart';

/// 传给模型的一条输入消息。与厂商协议解耦，由各 Provider 负责映射到具体格式。
@immutable
class AiMessage {
  final String role; // system / user / assistant
  final String content;

  /// 已上传得到的 file_id 列表（仅支持文件上传的 Provider 消费）。
  final List<String> fileIds;

  const AiMessage({
    required this.role,
    required this.content,
    this.fileIds = const <String>[],
  });
}

/// 本轮请求的可选能力开关与会话参数。
@immutable
class AiRequestOptions {
  final bool thinkingEnabled;
  final bool searchEnabled;
  final double temperature;

  /// 会话系统提示词，作为置顶 system 消息注入。
  final String? systemPrompt;

  /// 深度思考强度（low / high / max）。仅在 [thinkingEnabled] 为 true 时发送。
  final String reasoningEffort;

  /// 单次回答的 token 上限（映射到 max_tokens）。null 表示用服务端默认值。
  ///
  /// 为什么必须可配：输出是最贵的计费项（约为输入单价的两倍），不给上限
  /// 等于把账单交给服务端默认值（非思考 4K / 思考 32K）。会话设置里可实时调。
  final int? maxOutputTokens;

  const AiRequestOptions({
    this.thinkingEnabled = false,
    this.searchEnabled = false,
    this.temperature = 1.0,
    this.systemPrompt,
    this.reasoningEffort = 'high',
    this.maxOutputTokens,
  });
}

/// 模型响应：思考内容、引用与最终答案三者严格分离，供 UI 分区渲染。
@immutable
class AiResponse {
  /// 思考模式下模型在最终答案前的推理内容；非思考模式为空。
  final String thinkingContent;

  /// 联网搜索产生的引用条目（标题 + URL 等）。
  final List<AiCitation> citations;

  /// 最终答案正文。
  final String finalAnswer;

  const AiResponse({
    this.thinkingContent = '',
    this.citations = const <AiCitation>[],
    required this.finalAnswer,
  });
}

@immutable
class AiCitation {
  final String title;
  final String url;
  final String? snippet;

  /// 该来源在回答正文中对应的字符区间（DeepSeek url_citation 的
  /// start_index/end_index）。用于在正文对应位置渲染可点击角标。
  /// null 表示服务端没给定位信息，只能作为普通来源列出。
  final int? startIndex;
  final int? endIndex;

  const AiCitation({
    required this.title,
    required this.url,
    this.snippet,
    this.startIndex,
    this.endIndex,
  });

  factory AiCitation.fromJson(Map<String, dynamic> json) => AiCitation(
        title: json['title'] as String? ?? '',
        url: json['url'] as String? ?? '',
        snippet: json['snippet'] as String?,
        startIndex: (json['start_index'] as num?)?.toInt(),
        endIndex: (json['end_index'] as num?)?.toInt(),
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'title': title,
        'url': url,
        if (snippet != null) 'snippet': snippet,
        if (startIndex != null) 'start_index': startIndex,
        if (endIndex != null) 'end_index': endIndex,
      };
}

/// 流式增量事件。DeepSeek 实现会逐步推送思考与答案片段。
sealed class AiStreamChunk {
  const AiStreamChunk();
}

final class ThinkingChunk extends AiStreamChunk {
  final String delta;
  const ThinkingChunk(this.delta);
}

final class AnswerChunk extends AiStreamChunk {
  final String delta;
  const AnswerChunk(this.delta);
}

final class CitationsChunk extends AiStreamChunk {
  final List<AiCitation> citations;
  const CitationsChunk(this.citations);
}

/// 文件上传结果。
@immutable
class UploadedFile {
  final String fileId;
  final String fileName;
  final String? mimeType;

  const UploadedFile({required this.fileId, required this.fileName, this.mimeType});
}

/// AI 服务统一接口。
///
/// 四个能力方法对应任务书中的四个方法。GenericOpenAiCompatibleProvider 只实现
/// sendMessage，其余返回 false，从而让 UI 能按 capability 动态隐藏思考/搜索/附件开关，
/// 而不是调用不存在的能力后崩溃。
abstract class AiProvider {
  /// 厂商展示名，用于设置页与错误提示。
  String get displayName;

  /// 发送一轮对话并返回完整响应。
  Future<AiResponse> sendMessage(
    List<AiMessage> messages, {
    AiRequestOptions options = const AiRequestOptions(),
  });

  /// 流式发送；默认用非流式结果模拟单块，子类可覆盖为真流式。
  Stream<AiStreamChunk> sendMessageStream(
    List<AiMessage> messages, {
    AiRequestOptions options = const AiRequestOptions(),
  }) async* {
    final response = await sendMessage(messages, options: options);
    if (response.thinkingContent.isNotEmpty) {
      yield ThinkingChunk(response.thinkingContent);
    }
    if (response.citations.isNotEmpty) {
      yield CitationsChunk(response.citations);
    }
    yield AnswerChunk(response.finalAnswer);
  }

  bool get supportsThinking;
  bool get supportsSearch;
  bool get supportsFileUpload;

  /// 不支持文件上传的 Provider 调用时抛出 UnsupportedError。
  Future<UploadedFile> uploadFile(String path) {
    throw UnsupportedError('$displayName does not support file upload');
  }
}
