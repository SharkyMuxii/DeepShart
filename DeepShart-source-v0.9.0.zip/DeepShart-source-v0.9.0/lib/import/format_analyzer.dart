// target: lib/import/format_analyzer.dart
// 职责：用大模型分析"聊天记录排版格式"——取前若干轮问答发给模型，
// 让它返回【角色标记词表】和【时间格式】，不让它写正则（模型写的正则极易把
// 角色/时间吞进正文，实测导入失败）。解析全文由 SpecBasedImporter 用确定性
// 代码完成，并对常见标记做内置兜底，从而稳定支持各种来源的聊天记录。

import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../ai/ai_provider.dart';

/// 从用户标注的"标记头"里确定性剥出角色标记，不依赖大模型。
/// 例："【AI】[2026-11-19 19:44]" → "【AI】"；"User 2024/1/1" → "User"。
/// 这是 AI 解析失败时的兜底——标记头是用户亲手框的，字符串本身最可靠。
ImportFormatSpec? specFromAnchorsDirectly(String aiHead, String humanHead) {
  String stripTime(String head) {
    var s = head.trim();
    // 去掉各种时间戳：方括号时间、ISO 日期时间、纯时间、数字串。
    s = s.replaceAll(RegExp(r'\[[^\]]*\d{1,4}[-/]\d{1,2}[-/]\d{1,2}[^\]]*\]'), '');
    s = s.replaceAll(RegExp(r'\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?'), '');
    s = s.replaceAll(RegExp(r'\d{1,2}:\d{2}(?::\d{2})?'), '');
    s = s.replaceAll(RegExp(r'\[[^\]]*\]'), ''); // 其余方括号内容
    return s.trim();
  }

  final userMark = stripTime(humanHead);
  final aiMark = stripTime(aiHead);
  // 标记必须短且非空——过长说明 head 里混进了正文，不能当标记用。
  final userOk = userMark.isNotEmpty && userMark.length <= 20;
  final aiOk = aiMark.isNotEmpty && aiMark.length <= 20;
  if (!userOk && !aiOk) return null;
  return ImportFormatSpec(
    userMarkers: userOk ? <String>[userMark] : const <String>[],
    assistantMarkers: aiOk ? <String>[aiMark] : const <String>[],
    note: '由手动标注的标记头直接提取（未经大模型）',
    anchored: true,
  );
}

/// 模型返回的排版规则：只描述"角色怎么标记、时间长什么样"。
@immutable
class ImportFormatSpec {
  /// 用户侧角色标记原文（如 "我"、"【我】"、"User"、"user:"）。
  final List<String> userMarkers;

  /// 助手侧角色标记原文（如 "AI"、"【AI】"、"DeepSeek"、"助手"）。
  final List<String> assistantMarkers;

  /// 时间戳正则源（可选）。空则用内置通用正则识别。
  final String? timePattern;

  /// 模型对这份格式的说明。
  final String? note;

  /// 是否来自用户手动标注的锚点。true 时解析器严格只用这些标记，
  /// 不对未匹配行做"延续上一段角色"的猜测——避免例外格式整段垮掉。
  final bool anchored;

  const ImportFormatSpec({
    this.userMarkers = const <String>[],
    this.assistantMarkers = const <String>[],
    this.timePattern,
    this.note,
    this.anchored = false,
  });

  bool get isValid => userMarkers.isNotEmpty || assistantMarkers.isNotEmpty;

  ImportFormatSpec copyWith({bool? anchored}) => ImportFormatSpec(
        userMarkers: userMarkers,
        assistantMarkers: assistantMarkers,
        timePattern: timePattern,
        note: note,
        anchored: anchored ?? this.anchored,
      );

  Map<String, dynamic> toJson() => {
        'userMarkers': userMarkers,
        'assistantMarkers': assistantMarkers,
        'timePattern': timePattern,
        'note': note,
        'anchored': anchored,
      };

  factory ImportFormatSpec.fromJson(Map<String, dynamic> json) => ImportFormatSpec(
        userMarkers: (json['userMarkers'] as List<dynamic>?)
                ?.map((e) => e.toString().trim())
                .where((s) => s.isNotEmpty)
                .toList() ??
            const <String>[],
        assistantMarkers: (json['assistantMarkers'] as List<dynamic>?)
                ?.map((e) => e.toString().trim())
                .where((s) => s.isNotEmpty)
                .toList() ??
            const <String>[],
        timePattern: json['timePattern'] as String?,
        note: json['note'] as String?,
        anchored: json['anchored'] as bool? ?? false,
      );
}

/// 用大模型分析排版格式（只认标记词表，不让模型写正则）。
class ImportFormatAnalyzer {
  final AiProvider provider;

  ImportFormatAnalyzer({required this.provider});

  /// [sample] 取前若干轮问答的文本。返回 null 表示模型没给出可用规则。
  Future<ImportFormatSpec?> analyze(String sample) async {
    if (sample.trim().isEmpty) return null;
    final excerpt = sample.length > 12000 ? sample.substring(0, 12000) : sample;
    final prompt = '''
你是一个"聊天记录格式分析器"。下面是一份聊天记录开头片段（约前5轮问答）。

最重要的任务：找出【区分每一段对话的"角色标注信号"】。
聊天记录里通常有固定的标注把"用户说的话"和"AI/助手说的话"分开，例如：
  【我】[...]   /   【AI】[...]
  User:  /  Assistant:
  我：  /  助手：
这些标注就是"分段信号"——每出现一次就代表新的一段对话开始。请原样、逐字地把它们找出来。

返回一个 JSON 对象（只输出 JSON，不要解释文字、不要代码块围栏）：
{
  "userMarkers": ["用户侧的角色标注信号，原样", ...],
  "assistantMarkers": ["AI侧的角色标注信号，原样", ...],
  "timePattern": "时间戳的正则，或空字符串",
  "note": "一句话说明：每段以什么开头、时间戳在哪、正文从哪开始"
}

填写规则（务必逐字照抄原文）：
- 从片段里每条消息的最开头找标注。若看到「【我】[2026-11-19 19:44]」，
  用户标注就是 "【我】"（含书名括号，不含时间）；「【AI】[...]」则 AI 标注是 "【AI】"。
- 标注必须包含它自带的括号/方括号/冒号，如 "【我】"、"我:"、"我："、"User:"。
- 不要把时间戳写进标注，也不要把正文写进标注。
- 若某段的标注看不清或两段标注相同，宁可少填，并在 note 里说明"角色不确定"。
- timePattern：只写能匹配到时间戳那一段的正则；没有时间就给 ""。
- 只输出上述 JSON，字段名和类型不能变。

聊天记录片段：
---
$excerpt
---
''';

    try {
      final response = await provider.sendMessage(
        [AiMessage(role: 'user', content: prompt)],
        options: const AiRequestOptions(temperature: 0.1),
      );
      var text = response.finalAnswer.trim();
      if (text.startsWith('```')) {
        text = text.replaceFirst(RegExp(r'^```[a-zA-Z]*\s*'), '');
        text = text.replaceFirst(RegExp(r'\s*```$'), '');
      }
      final start = text.indexOf('{');
      final end = text.lastIndexOf('}');
      if (start < 0 || end <= start) return null;
      final json = jsonDecode(text.substring(start, end + 1)) as Map<String, dynamic>;
      final spec = ImportFormatSpec.fromJson(json);
      return spec.isValid ? spec : null;
    } catch (e) {
      debugPrint('ImportFormatAnalyzer failed: $e');
      return null;
    }
  }

  /// 基于用户【手动标注】的锚点识别格式（推荐路径）。
  ///
  /// [aiHead] 是用户框选的"AI 说的话"前面紧邻的那串（如 "【AI】[2026-11-19 19:44]"），
  /// [humanHead] 同理（如 "【我】[2026-11-19 19:44]"）。这两串是用户亲手框的，
  /// 是最可靠的标记样本——大模型只需从这两个短串里逐字提取"角色标记"和"时间格式"，
  /// 不再需要从整篇里猜，准确率大幅提升。
  ///
  /// 返回 null 表示连这两个明确样本都解析不出，此时应交给用户兜底，不自行决策。
  Future<ImportFormatSpec?> analyzeWithAnchors({
    required String excerpt,
    required String aiHead,
    required String humanHead,
    required String aiSample,
    required String humanSample,
  }) async {
    final prompt = '''
你是一个"聊天记录格式分析器"。用户已经亲手框选了两段话，并给出了每段话【前面紧邻的标记串】。
你的任务：从这两个标记串里，逐字提取出【角色标记】和【时间格式】。不要猜、不要脑补整篇格式。

【第 1 段：AI/助手说的话】
- 标记串（正文前面紧邻的内容，正文本身已被框走）：「$aiHead」
- 正文开头（供参考）：「${aiSample.length > 60 ? aiSample.substring(0, 60) : aiSample}」

【第 2 段：人（用户）说的话】
- 标记串：「$humanHead」
- 正文开头（供参考）：「${humanSample.length > 60 ? humanSample.substring(0, 60) : humanSample}」

返回一个 JSON 对象（只输出 JSON，不要解释文字、不要代码块围栏）：
{
  "userMarkers": ["人侧的角色标记原文", ...],
  "assistantMarkers": ["AI侧的角色标记原文", ...],
  "timePattern": "时间戳的正则，或空字符串",
  "note": "一句话说明每段以什么开头、时间戳在哪"
}

填写规则（务必严格）：
- 角色标记 = 标记串里【代表"谁在说话"】的那几个字，必须逐字照抄原文，含它自带的括号/冒号。
  例：标记串「【AI】[2026-11-19 19:44]」→ AI 标记是 "【AI】"；
      标记串「我: 」→ 人标记是 "我:"；标记串「User 2024/1/1」→ 人是 "User"。
- 绝对不要把时间戳写进角色标记，也不要把正文写进去。
- 时间戳若紧跟在标记后面，用正则描述它的样子（如 "\\[\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}\\]"）；
  没有时间戳就给空字符串 ""。
- 若某个标记串里找不到明确的角色词，宁可把该数组留空 []，并在 note 里说明"该侧标记不明确"。
- 只输出上述 JSON，字段名和类型不能变。
''';

    try {
      final response = await provider.sendMessage(
        [AiMessage(role: 'user', content: prompt)],
        options: const AiRequestOptions(temperature: 0.0),
      );
      var text = response.finalAnswer.trim();
      if (text.startsWith('```')) {
        text = text.replaceFirst(RegExp(r'^```[a-zA-Z]*\s*'), '');
        text = text.replaceFirst(RegExp(r'\s*```$'), '');
      }
      final start = text.indexOf('{');
      final end = text.lastIndexOf('}');
      if (start < 0 || end <= start) return null;
      final json = jsonDecode(text.substring(start, end + 1)) as Map<String, dynamic>;
      final spec = ImportFormatSpec.fromJson(json);
      if (!spec.isValid) return null;
      return spec.copyWith(anchored: true);
    } catch (e) {
      debugPrint('ImportFormatAnalyzer.analyzeWithAnchors failed: $e');
      return null;
    }
  }
}
