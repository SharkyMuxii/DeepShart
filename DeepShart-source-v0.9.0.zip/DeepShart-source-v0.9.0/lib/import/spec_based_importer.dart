// target: lib/import/spec_based_importer.dart
// 职责：按识别出的【角色标记词表】确定性切分全文。
// 不依赖模型写正则——模型只给标记（如 "【我】"/"【AI】"），逐行扫描、剥掉标记与
// 时间戳、把角色后的正文归属到对应消息。
//
// 两条铁律（用户明确要求）：
// 1) 绝不"确定一对后默认后面一问一答交替"——每一段的角色只由它自己的标记决定。
// 2) anchored 模式（用户手动标注锚点）下，任何无法归类的行都记录进 unassigned，
//    交给用户定夺，绝不自行猜测把它塞进某一段，避免例外格式把整段搞垮。

import 'dart:convert';

import 'package:crypto/crypto.dart';

import '../data/models/chat_message.dart';
import 'format_analyzer.dart';

class SpecParseResult {
  final List<ChatMessage> messages;
  final int parsedLines;

  /// 无法归类的行（锚点模式下）：出现在任何标记之前、或内容可疑。
  /// 非空时 UI 应提示用户定夺，而不是直接导入。
  final List<String> unassigned;

  const SpecParseResult({
    required this.messages,
    required this.parsedLines,
    this.unassigned = const <String>[],
  });

  bool get isUsable => messages.length >= 2;
  bool get hasUnassigned => unassigned.isNotEmpty;
}

/// 一行被识别出的结果。
class _Line {
  final MessageRole role;
  final String content;
  final DateTime? time;
  const _Line(this.role, this.content, this.time);
}

class SpecBasedImporter {
  /// 内置兜底标记：仅当 spec 完全没给标记时才启用。
  static const List<String> _fallbackUser = [
    '【我】', '我:', '我：', 'User:', 'user:', 'USER:', '用户:', '用户：',
    'Me:', 'me:', 'Human:', 'human:', 'Q:', 'Q：', '问:', '问：',
  ];
  static const List<String> _fallbackAssistant = [
    '【AI】', '【助手】', 'AI:', 'AI：', 'Assistant:', 'assistant:', 'ASSISTANT:',
    'ChatGPT:', 'GPT:', 'DeepSeek:', 'deepseek:', '助手:', '助手：', '模型:',
    'A:', 'A：', '答:', '答：',
  ];

  /// 用 [spec] 的标记词表解析 [text]。
  SpecParseResult parse(
    String text, {
    required ImportFormatSpec spec,
    required String conversationId,
    DateTime? fallbackTime,
  }) {
    final modelHasMarkers = spec.userMarkers.isNotEmpty || spec.assistantMarkers.isNotEmpty;
    // 锚点模式：严格只用用户标注确认的标记，绝不再混入内置兜底（兜底会误切正文）。
    final anchored = spec.anchored && modelHasMarkers;
    final userMarkers = <String>{
      ...((anchored || modelHasMarkers) ? spec.userMarkers : _fallbackUser),
    };
    final assistantMarkers = <String>{
      ...((anchored || modelHasMarkers) ? spec.assistantMarkers : _fallbackAssistant),
    };
    // 长标记优先匹配，避免 "我" 抢先匹配 "【我】"。
    final allMarkers = <String>[
      ...{...userMarkers, ...assistantMarkers},
    ]..sort((a, b) => b.length.compareTo(a.length));

    final lines = text.split(RegExp(r'\r?\n'));
    final parsed = <_Line>[];
    final unassigned = <String>[];
    MessageRole? currentRole;
    final buffer = <String>[];
    DateTime? currentTime;
    var timeCursor = (fallbackTime ?? DateTime.now()).toUtc().subtract(const Duration(days: 30));

    _Line? flush() {
      final role = currentRole;
      if (role == null || buffer.isEmpty) return null;
      final content = buffer.join('\n').trim();
      buffer.clear();
      if (content.isEmpty) return null;
      return _Line(role, content, currentTime);
    }

    for (final rawLine in lines) {
      final line = rawLine.trimRight();
      final trimmed = line.trimLeft();
      String? matched;
      for (final m in allMarkers) {
        if (trimmed.startsWith(m)) {
          matched = m;
          break;
        }
      }

      if (matched != null) {
        // 遇到标记 = 新的一段。角色只由本段标记决定，绝不看上一段是什么。
        final prev = flush();
        if (prev != null) parsed.add(prev);
        currentRole = userMarkers.contains(matched) ? MessageRole.user : MessageRole.assistant;
        var rest = trimmed.substring(matched.length).trimLeft();
        final timeInfo = _stripLeadingTime(rest, spec.timePattern);
        rest = timeInfo.rest;
        currentTime = timeInfo.time;
        if (rest.isNotEmpty) buffer.add(rest);
      } else {
        // 非标记行。
        if (currentRole != null) {
          // 已有当前段：这是多行正文的续行，追加（一段话跨多行是常态）。
          buffer.add(line);
        } else if (trimmed.isNotEmpty) {
          // 还没有任何标记就出现了内容。
          if (anchored) {
            // 锚点模式：这种行无法归类，记录下来交用户定夺，不自行猜测角色。
            unassigned.add(trimmed);
          }
          // 非锚点模式：可能是标题/说明，跳过。
        }
      }
    }
    final last = flush();
    if (last != null) parsed.add(last);

    final messages = <ChatMessage>[];
    for (final item in parsed) {
      final content = item.content.trim();
      if (content.isEmpty) continue;
      final createdAt = item.time ?? timeCursor.add(const Duration(seconds: 1));
      if (createdAt.isAfter(timeCursor)) timeCursor = createdAt;
      final digest = md5
          .convert(utf8.encode('$conversationId|$createdAt|${item.role.name}|$content'))
          .toString();
      messages.add(ChatMessage.create(
        conversationId: conversationId,
        role: item.role,
        content: content,
        deviceId: 'imported-llm',
        id: 'llm-$digest',
        createdAt: createdAt,
      ));
    }

    return SpecParseResult(
      messages: messages,
      parsedLines: parsed.length,
      unassigned: unassigned,
    );
  }

  /// 从行首剥掉时间戳，返回剩余文本与解析出的时间。
  ({String rest, DateTime? time}) _stripLeadingTime(String s, String? pattern) {
    final candidates = <RegExp>[];
    if (pattern != null && pattern.trim().isNotEmpty) {
      try {
        candidates.add(RegExp('^(?:${pattern})\\s*'));
      } catch (_) {}
    }
    // 内置常见时间格式：[2026-11-19 19:44] / 2026-11-19 19:44 / 11-7 23:26
    candidates.addAll([
      RegExp(r'^\[\s*\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?\s*\]\s*'),
      RegExp(r'^\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?\s*'),
      RegExp(r'^\[?\d{1,2}[-/]\d{1,2}[-/]\d{2,4}\s+\d{1,2}:\d{2}(?::\d{2})?\]?\s*'),
      RegExp(r'^\[?\d{1,2}:\d{2}(?::\d{2})?\]?\s*'),
    ]);
    for (final re in candidates) {
      final m = re.firstMatch(s);
      if (m == null) continue;
      final time = _parseTime(m.group(0)!.trim());
      return (rest: s.substring(m.end).trimLeft(), time: time);
    }
    return (rest: s, time: null);
  }

  DateTime? _parseTime(String raw) {
    var t = raw.replaceAll(RegExp(r'[\[\]]'), '').trim();
    final numeric = num.tryParse(t);
    if (numeric != null) {
      final ms = numeric < 100000000000 ? (numeric * 1000).toInt() : numeric.toInt();
      return DateTime.fromMillisecondsSinceEpoch(ms).toUtc();
    }
    t = t.replaceAll('/', '-');
    final short = RegExp(r'^(\d{1,2})-(\d{1,2})\s+(\d{1,2}):(\d{2})');
    final sm = short.firstMatch(t);
    if (sm != null) {
      final now = DateTime.now();
      return DateTime.utc(
        now.year,
        int.parse(sm.group(1)!),
        int.parse(sm.group(2)!),
        int.parse(sm.group(3)!),
        int.parse(sm.group(4)!),
      );
    }
    return DateTime.tryParse(t)?.toUtc();
  }
}
