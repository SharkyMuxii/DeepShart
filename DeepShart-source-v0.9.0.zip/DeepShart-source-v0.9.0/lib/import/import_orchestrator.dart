// target: lib/import/import_orchestrator.dart
// 职责：统一导入入口，按扩展名/内容分发到 JSON 或 TXT 解析器，并把结果落入 MessageStore。

import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../data/models/chat_message.dart';
import '../data/store/message_store.dart';
import 'deepseek_json_importer.dart';
import 'plain_text_importer.dart';

/// 导入结果：产生冲突的消息 id 列表交由 UI 走裁决流程（走 MessageStore 的 ConflictRecord 流）。
@immutable
class ImportOutcome {
  final int importedCount;
  final int conflictCount;
  final bool needsUserConfirmation;
  final String? conversationId;

  const ImportOutcome({
    required this.importedCount,
    this.conflictCount = 0,
    this.needsUserConfirmation = false,
    this.conversationId,
  });
}

/// 导入编排器。负责：分发 → 用户确认 → 逐条 insertOrMerge（复用冲突流程）。
class ImportOrchestrator {
  final MessageStore store;
  final String localDeviceId;

  final DeepSeekJsonImporter _jsonImporter = DeepSeekJsonImporter();
  final PlainTextImporter _textImporter = PlainTextImporter();

  ImportOrchestrator({required this.store, required this.localDeviceId});

  /// 根据文件路径扩展名分发。.json 走 JSON 解析器，其余走 TXT。
  Future<ParseResult> parseFile(String path) async {
    final content = await File(path).readAsString();
    return parseText(content, fileName: path);
  }

  /// 直接从字节解析。
  ///
  /// 为什么优先用这个：Android 上 file_picker 返回的 path 可能是缓存副本或
  /// content:// 转存路径，用 File(path).readAsString() 有概率读不到或读不全；
  /// 而 picker 已经拿到的 bytes 是确定可用的。UTF-8 解码失败时降级用
  /// latin1 兜底，避免单个坏字节让整份文件报废。
  ParseResult parseBytes(Uint8List bytes, {required String fileName}) {
    String content;
    try {
      content = utf8.decode(bytes);
    } on FormatException {
      content = utf8.decode(bytes, allowMalformed: true);
    }
    return parseText(content, fileName: fileName);
  }

  /// 按文件名分发解析器。
  ParseResult parseText(String content, {required String fileName}) {
    final lower = fileName.toLowerCase();
    final looksJson = lower.endsWith('.json') ||
        content.trimLeft().startsWith('{') ||
        content.trimLeft().startsWith('[');
    if (looksJson) {
      return ParseResult(deepSeek: _jsonImporter.parse(content));
    }
    return ParseResult(
      plainText: _textImporter.parse(
        content,
        conversationId: const Uuid().v4(),
      ),
      rawText: content,
    );
  }

  /// 用户确认角色后，把消息批量导入。每条都走 insertOrMerge——
  /// 若 id 与已有消息冲突，不自动覆盖，生成 ConflictRecord 走用户裁决（任务书要求）。
  ///
  /// 额外处理"历史空正文修复"：旧版解析器把 DeepSeek 的 fragments 正文漏掉了，
  /// 库里已经存在一批 content 为空的记录。同一份文件再次导入时 id 相同、
  /// 向量时钟也相同，会被判定为 equal 直接忽略，用户永远修不好。
  /// 这里检测到"本地为空、导入有正文"时给导入版本 tick 一次本地设备，
  /// 让它因果支配旧记录，从而覆盖修复（不产生假冲突）。
  Future<ImportOutcome> commitMessages(List<ChatMessage> messages) async {
    var conflicts = 0;
    final usable = messages
        .where((m) => m.content.trim().isNotEmpty)
        .toList(growable: false);

    final existing = <String, ChatMessage>{};
    for (final conversationId in usable.map((m) => m.conversationId).toSet()) {
      for (final m in await store.readAll(conversationId, includeDeleted: true)) {
        existing[m.id] = m;
      }
    }

    for (var message in usable) {
      final local = existing[message.id];
      if (local != null &&
          local.content.trim().isEmpty &&
          message.content.trim().isNotEmpty) {
        message = message.touch(localDeviceId);
      }
      final result = await store.insertOrMerge(message);
      if (result.hasConflict) conflicts += result.conflicts.length;
    }
    return ImportOutcome(
      importedCount: usable.length,
      conflictCount: conflicts,
    );
  }
}

/// 解析结果联合类型。UI 据此决定展示哪个确认界面。
@immutable
class ParseResult {
  final DeepSeekImportResult? deepSeek;
  final PlainTextImportResult? plainText;
  final String? rawText;

  const ParseResult({this.deepSeek, this.plainText, this.rawText});

  bool get needsConfirmation =>
      (deepSeek?.needsConfirmation ?? false) || (plainText?.needsConfirmation ?? false);

  String? get conversationId => deepSeek?.conversationId ?? plainText?.conversationId;

  RoleConfirmationRequest? get confirmationRequest =>
      deepSeek?.confirmationRequest ?? plainText?.confirmationRequest;

  /// 用户确认角色后重建消息列表（JSON 路径：按索引覆盖角色）。
  List<ChatMessage> rebuildWithRoles(Map<int, MessageRole> roles) {
    if (deepSeek != null) {
      // 解析器本身无状态，这里新建实例即可复用它的角色覆盖逻辑。
      return DeepSeekJsonImporter().buildConfirmedMessages(deepSeek!, roleOverrides: roles);
    }
    final text = rawText;
    final plain = plainText;
    if (text != null && plain != null) {
      return PlainTextImporter().buildConfirmedMessages(
        text,
        conversationId: plain.conversationId,
        roleBySegmentIndex: roles,
      );
    }
    return const <ChatMessage>[];
  }
}
