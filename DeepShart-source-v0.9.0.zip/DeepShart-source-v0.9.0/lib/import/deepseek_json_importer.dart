// target: lib/import/deepseek_json_importer.dart
// 职责：解析 DeepSeek 导出的 JSON，兼容字符串与 parts 两种 content 形态，生成稳定 ID 去重。

import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';

import '../data/models/chat_message.dart';

/// 导入预览项：一条待导入消息及其确认状态。
@immutable
class ImportedMessage {
  final ChatMessage message;

  const ImportedMessage(this.message);
}

/// 角色确认请求。当检测到某段消息角色无法可靠判定，或大模型输出需要用户确认时，
/// 提取最多 4 段内容的前 50 字，交给 UI 展示并让用户确认。
@immutable
class RoleConfirmationRequest {
  final String conversationId;

  /// 需要确认角色的候选片段（每段 = 预览文本 + 原始索引）。
  final List<PreviewSegment> segments;

  const RoleConfirmationRequest({
    required this.conversationId,
    required this.segments,
  });
}

@immutable
class PreviewSegment {
  final int index;
  final String preview;

  const PreviewSegment({required this.index, required this.preview});
}

/// DeepSeek JSON 导入解析结果。
/// 若需要用户确认，则 messages 为空且 confirmationRequest 非空。
@immutable
class DeepSeekImportResult {
  final String conversationId;
  final String? title;
  final List<ChatMessage> messages;
  final RoleConfirmationRequest? confirmationRequest;

  /// 解析成功但因没有正文而跳过的消息数（例如只有元数据、只有思考无回答）。
  final int skippedEmpty;

  const DeepSeekImportResult({
    required this.conversationId,
    this.title,
    this.messages = const <ChatMessage>[],
    this.confirmationRequest,
    this.skippedEmpty = 0,
  });

  bool get needsConfirmation => confirmationRequest != null;
}

/// DeepSeek 导出 JSON 解析器。
class DeepSeekJsonImporter {
  /// 解析导出 JSON。
  ///
  /// 结构容错（为什么不只认顶层数组）：
  /// DeepSeek 网页/客户端的导出并不总是顶层数组——实测有单会话对象
  /// `{id,title,messages}`，也有套一层容器 `{data:[...]}` 的情形。
  /// 早期版本只接受 List，用户拿着合法导出文件却被判"格式不对"。
  /// 这里按"找到第一个带 messages 数组的对象"来定位会话，兼容三种形态。
  ///
  /// 稳定 ID 策略（为什么这样设计）：
  /// 缺失 id 时，用 (conversationId + role + content + 时间戳) 的 SHA-256 前 16 位
  /// 生成确定性 id。这样同一份文件重复导入会得到相同 id，走 insertOrMerge 时
  /// 判定为幂等（equal 或 before），不会产生重复记录，也不会误报冲突。
  DeepSeekImportResult parse(String jsonText) {
    // Windows/部分编辑器导出会带 UTF-8 BOM，jsonDecode 遇到 BOM 直接抛错。
    final cleaned = jsonText.replaceFirst('\uFEFF', '').trim();
    if (cleaned.isEmpty) {
      throw const FormatException('文件是空的，没有读到任何内容。请确认选择的是导出的 JSON 文件。');
    }

    dynamic decoded;
    try {
      decoded = jsonDecode(cleaned);
    } on FormatException catch (e) {
      throw FormatException(
        '不是合法的 JSON（${e.message}）。'
        '如果文件是从别处复制的，请确认内容完整、未被截断。',
      );
    }

    final root = _locateConversation(decoded);
    if (root == null) {
      final actual = decoded is List
          ? '顶层是数组，但里面没有含 messages 的会话对象'
          : decoded is Map
              ? '顶层是对象，键为 ${decoded.keys.take(8).join(', ')}，但找不到 messages 数组'
              : '顶层是 ${decoded.runtimeType}';
      throw FormatException('无法识别为对话导出文件：$actual');
    }

    final convId = (root['conversation_id'] ?? root['id'] ?? '').toString();
    final resolvedConvId = convId.isNotEmpty
        ? convId
        : _stableHash('conversation:${root['title'] ?? ''}:${root['inserted_at'] ?? ''}');

    final rawMessages = _messagesOf(root)!;
    final messages = <ChatMessage>[];
    final uncertain = <PreviewSegment>[];
    var skippedEmpty = 0;
    for (final raw in rawMessages) {
      if (raw is! Map) continue;
      final parsed = _parseMessage(Map<String, dynamic>.from(raw), resolvedConvId);
      if (parsed == null) continue;
      if (parsed.message.content.trim().isEmpty) {
        skippedEmpty++;
        continue;
      }
      if (parsed.roleGuessed && uncertain.length < 8) {
        uncertain.add(PreviewSegment(
          index: messages.length,
          preview: _truncate(parsed.message.content, 60),
        ));
      }
      messages.add(parsed.message);
    }
    if (messages.isEmpty) {
      throw FormatException(
        '找到了 ${rawMessages.length} 条消息记录，但没有一条能被识别出正文。'
        '支持 role + content，也支持 DeepSeek 导出的 fragments 结构'
        '（fragments[].type=REQUEST/RESPONSE/THINK + fragments[].content）。',
      );
    }

    return DeepSeekImportResult(
      conversationId: resolvedConvId,
      title: root['title']?.toString(),
      messages: messages,
      skippedEmpty: skippedEmpty,
      // 只有"角色无法识别、已按默认角色暂存"的情况才需要用户确认。
      // 之前只要存在 assistant 消息就把整份导入标记成"部分角色需人工确认"，
      // 属于误报，会让用户以为导入不完整。
      confirmationRequest: uncertain.isEmpty
          ? null
          : RoleConfirmationRequest(
              conversationId: resolvedConvId,
              segments: uncertain,
            ),
    );
  }

  /// 在任意嵌套层级里找到第一个"带 messages 数组的对象"。
  ///
  /// 兼容三种真实形态：
  ///   1. `[{id,title,messages:[...]}]`   多会话数组
  ///   2. `{id,title,messages:[...]}`     单会话对象
  ///   3. `{data:[{...messages...}]}`     套一层容器
  Map<String, dynamic>? _locateConversation(dynamic decoded, [int depth = 0]) {
    if (depth > 4) return null;

    if (decoded is List) {
      for (final item in decoded) {
        final found = _locateConversation(item, depth + 1);
        if (found != null) return found;
      }
      return null;
    }

    if (decoded is Map) {
      final map = Map<String, dynamic>.from(decoded);
      final rawMessages = _messagesOf(map);
      if (rawMessages is List && rawMessages.isNotEmpty) return map;

      const containerKeys = ['data', 'conversations', 'chats', 'items', 'history', 'results'];
      for (final key in containerKeys) {
        final value = map[key];
        if (value is List || value is Map) {
          final found = _locateConversation(value, depth + 1);
          if (found != null) return found;
        }
      }
      for (final value in map.values) {
        if (value is List) {
          final found = _locateConversation(value, depth + 1);
          if (found != null) return found;
        }
      }
      // messages 存在但为空数组：交回上层报"没有可识别的消息"，比"找不到字段"更准确。
      if (rawMessages is List) return map;
      return null;
    }

    return null;
  }

  /// 取消息数组，兼容几种常见键名。
  List<dynamic>? _messagesOf(Map<String, dynamic> map) {
    for (final key in const ['messages', 'chat_messages', 'msgs']) {
      final v = map[key];
      if (v is List) return v;
    }
    return null;
  }

  /// 用户确认后，把解析结果转换为正式导入消息。
  /// 若用户指出角色判断有误，可传入 roleOverrides 按索引修正。
  List<ChatMessage> buildConfirmedMessages(
    DeepSeekImportResult result, {
    Map<int, MessageRole> roleOverrides = const <int, MessageRole>{},
  }) =>
      result.messages.asMap().entries.map((entry) {
        final override = roleOverrides[entry.key];
        if (override == null) return entry.value;
        return entry.value.copyWith(role: override);
      }).toList(growable: false);

  _ParsedMessage? _parseMessage(Map<String, dynamic> raw, String convId) {
    final roleStr = (raw['role'] ?? raw['author'] ?? raw['sender'])?.toString().toLowerCase();
    var role = _parseRole(roleStr);
    // 角色无法识别时不要直接丢弃：整条消息的正文可能完全有效，
    // 按 fragments 的类型猜一个默认角色先导入，并标记"待用户确认"。
    final roleGuessed = role == null;
    role ??= _guessRole(raw);

    final extracted = _extractBody(raw);
    final content = extracted.body;
    final id = (raw['id'] ?? raw['message_id'] ?? raw['msg_id'])?.toString();
    final stableId = id != null && id.isNotEmpty
        ? id
        : _stableHash('$convId|$roleStr|$content|${raw['inserted_at'] ?? ''}');

    // DeepSeek 各版本导出用的时间键名不一，尽量多兼容：
    // 网页导出常见 inserted_at / created_at，API 导出常见 timestamp / create_time，
    // 也有驼峰 createdAt 或秒级 time。取第一个存在的非空值。
    DateTime? resolvedTime;
    for (final key in const [
      'inserted_at', 'created_at', 'create_time', 'createdAt',
      'timestamp', 'time', 'updated_at', 'date',
    ]) {
      final v = raw[key];
      if (v != null) {
        resolvedTime = _parseTime(v);
        break;
      }
    }
    final createdAt = resolvedTime ?? DateTime.now().toUtc();

    return _ParsedMessage(
      roleGuessed: roleGuessed,
      message: ChatMessage(
        id: stableId,
        conversationId: convId,
        role: role,
        content: content,
        createdAt: createdAt,
        updatedAt: createdAt,
        deviceId: 'imported',
        versionVector: _clockFor(stableId, createdAt),
      ),
    );
  }

  /// 从 messages[].fragments 猜角色：RESPONSE/THINK 属于 AI，REQUEST 属于用户。
  MessageRole _guessRole(Map<String, dynamic> raw) {
    final frags = raw['fragments'] ?? raw['parts'];
    if (frags is List) {
      for (final f in frags) {
        if (f is! Map) continue;
        final type = (f['type'] ?? f['role'] ?? '').toString().toUpperCase();
        if (type.contains('RESPONSE') || type.contains('THINK') || type.contains('ANSWER')) {
          return MessageRole.assistant;
        }
        if (type.contains('REQUEST') || type.contains('USER') || type.contains('QUERY')) {
          return MessageRole.user;
        }
      }
    }
    return MessageRole.user;
  }

  /// 提取正文与思考内容。
  ///
  /// DeepSeek 网页/客户端导出的真实结构并不是 `content: "..."`，而是：
  ///   {"role":"ASSISTANT","fragments":[
  ///      {"type":"THINK","content":"..."},
  ///      {"type":"RESPONSE","content":"..."}]}
  /// 早期只读 raw['content']，于是 1315 条消息全部被解析成空字符串，
  /// 导入后就是一串空白气泡。这里按 fragments 的类型分别取思考与正文。
  ({String body, String thinking}) _extractBody(Map<String, dynamic> raw) {
    final thinkingParts = <String>[];
    final bodyParts = <String>[];

    void addThinking(dynamic value) {
      final text = _contentToText(value).trim();
      if (text.isNotEmpty) thinkingParts.add(text);
    }

    void addBody(dynamic value) {
      final text = _contentToText(value).trim();
      if (text.isNotEmpty) bodyParts.add(text);
    }

    // 标准字段
    addBody(raw['content']);
    // 思考字段（不同导出用的键名不一样）
    addThinking(raw['reasoning_content']);
    addThinking(raw['thinking_content']);
    addThinking(raw['reasoning']);

    final frags = raw['fragments'] ?? raw['parts'] ?? raw['contents'];
    if (frags is List && frags.isNotEmpty) {
      for (final frag in frags) {
        if (frag is String) {
          addBody(frag);
          continue;
        }
        if (frag is! Map) continue;
        final type = (frag['type'] ?? frag['role'] ?? '').toString().toUpperCase();
        final value = frag['content'] ?? frag['text'] ?? frag['value'];
        if (type.contains('THINK') ||
            type.contains('REASON') ||
            type.contains('COT')) {
          addThinking(value);
        } else {
          addBody(value);
        }
      }
    }

    // 还有些导出把正文放在 message / data 里再包一层
    final nested = raw['message'] ?? raw['data'];
    if (bodyParts.isEmpty && nested is Map) {
      addBody(nested['content']);
    }
    if (bodyParts.isEmpty) {
      addBody(raw['text'] ?? raw['body'] ?? raw['value']);
    }

    var body = bodyParts.join('\n\n').trim();
    if (thinkingParts.isNotEmpty) {
      // 与 ChatController 写库的结构一致，UI 才能正确分区渲染。
      final thinking = thinkingParts.join('\n\n');
      body = '<thinking>\n$thinking\n</thinking>${body.isEmpty ? '' : '\n$body'}';
    }
    return (body: body, thinking: thinkingParts.join('\n\n'));
  }

  /// content 兼容多种形态：字符串、parts 数组、带 text 字段的对象。
  String _contentToText(dynamic raw) {
    if (raw == null) return '';
    if (raw is String) return raw;
    if (raw is num || raw is bool) return raw.toString();
    if (raw is List) {
      final buffer = StringBuffer();
      for (final part in raw) {
        final text = _contentToText(part);
        if (text.isEmpty) continue;
        if (buffer.isNotEmpty) buffer.write('\n');
        buffer.write(text);
      }
      return buffer.toString();
    }
    if (raw is Map) {
      for (final key in const ['text', 'content', 'value', 'body', 'message']) {
        final value = raw[key];
        if (value is String && value.isNotEmpty) return value;
        if (value is List || value is Map) {
          final nested = _contentToText(value);
          if (nested.isNotEmpty) return nested;
        }
      }
      return '';
    }
    return '';
  }

  MessageRole? _parseRole(String? value) => switch (value) {
        'user' || 'human' || '用户' => MessageRole.user,
        'assistant' || 'ai' || 'model' || '助手' || '大模型' => MessageRole.assistant,
        'system' || '系统' => MessageRole.system,
        _ => null,
      };

  DateTime _parseTime(dynamic value) {
    if (value == null) return DateTime.now().toUtc();
    if (value is num) return _msToUtc(value.toDouble());
    final text = value.toString().trim();
    // 纯数字字符串（如 "1736932245" 或 "1736932245000"）：按 Unix 时间戳解析。
    if (RegExp(r'^\d+$').hasMatch(text)) {
      return _msToUtc(double.tryParse(text) ?? DateTime.now().toUtc().millisecondsSinceEpoch.toDouble());
    }
    return DateTime.tryParse(text)?.toUtc() ?? DateTime.now().toUtc();
  }

  DateTime _msToUtc(double value) {
    // 秒级时间戳与毫秒级时间戳的区分：小于 1e11 视为秒。
    final ms = value < 100000000000 ? (value * 1000).toInt() : value.toInt();
    return DateTime.fromMillisecondsSinceEpoch(ms, isUtc: true);
  }

  /// 导入消息的向量时钟：以固定导入设备 + 时间戳为种子，
  /// 保证同一文件重复导入得到完全相同的时钟，走幂等路径不产生冲突。
  VectorClock _clockFor(String id, DateTime time) {
    final seed = _stableHash('$id|${time.millisecondsSinceEpoch}');
    final counter = seed.hashCode.abs() % 1000 + 1;
    return VectorClock.fromJson(<String, dynamic>{'imported': counter});
  }

  String _stableHash(String input) =>
      sha256.convert(utf8.encode(input)).toString().substring(0, 16);

  String _truncate(String text, int max) =>
      text.length <= max ? text : '${text.substring(0, max)}…';
}

/// 单条消息的解析结果，附带"角色是否是猜的"。
@immutable
class _ParsedMessage {
  final ChatMessage message;
  final bool roleGuessed;

  const _ParsedMessage({required this.message, required this.roleGuessed});
}
