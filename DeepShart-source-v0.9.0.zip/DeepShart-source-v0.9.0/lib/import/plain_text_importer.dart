// target: lib/import/plain_text_importer.dart
// 职责：解析通用 TXT 对话记录，识别 user/assistant 前缀；无法识别时提取同一角色 4 段预览请求确认。

import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';

import '../data/models/chat_message.dart';
import 'deepseek_json_importer.dart' show PreviewSegment, RoleConfirmationRequest;

@immutable
class PlainTextImportResult {
  final String conversationId;
  final List<ChatMessage> messages;
  final RoleConfirmationRequest? confirmationRequest;

  const PlainTextImportResult({
    required this.conversationId,
    this.messages = const <ChatMessage>[],
    this.confirmationRequest,
  });

  bool get needsConfirmation => confirmationRequest != null;
}

/// 通用 TXT 导入解析器。
///
/// 按空行分段，每段尝试识别 user: / assistant: / 用户：/ 助手： 前缀。
/// 无法识别角色的段落会被收集；当同一疑似角色的段落达到 4 段时，
/// 提取各段前 50 字请求用户确认（任务书要求）。
class PlainTextImporter {
  /// [defaultRole] 用于无法识别前缀时的兜底，默认 user。
  PlainTextImportResult parse(
    String text, {
    required String conversationId,
    MessageRole defaultRole = MessageRole.user,
  }) {
    final blocks = _splitBlocks(text);
    if (blocks.isEmpty) {
      throw const FormatException('TXT import contains no content');
    }

    final messages = <ChatMessage>[];
    final unrecognized = <_UnrecognizedBlock>[];
    var timeCursor = DateTime.now().toUtc().subtract(Duration(minutes: blocks.length));

    for (var i = 0; i < blocks.length; i++) {
      final block = blocks[i];
      final parsed = _parseBlock(block);
      if (parsed != null) {
        final (role, content, thinking) = parsed;
        final stableId = _stableHash('$conversationId|$i|$role|$content');
        timeCursor = timeCursor.add(const Duration(seconds: 1));
        messages.add(ChatMessage(
          id: stableId,
          conversationId: conversationId,
          role: role,
          content: content,
          createdAt: timeCursor,
          updatedAt: timeCursor,
          deviceId: 'imported',
          versionVector: VectorClock.fromJson(<String, dynamic>{
            'imported': stableId.hashCode.abs() % 1000 + 1,
          }),
        ));
      } else {
        unrecognized.add(_UnrecognizedBlock(index: i, content: block));
      }
    }

    // 本段 TXT 原生支持我们自己的导出格式（含 thinking 块）——单独识别。
    final nativeMessages = _tryParseNativeFormat(text, conversationId);
    if (nativeMessages.isNotEmpty) {
      return PlainTextImportResult(
        conversationId: conversationId,
        messages: nativeMessages,
      );
    }

    final needsConfirm = unrecognized.length >= 4;
    return PlainTextImportResult(
      conversationId: conversationId,
      messages: needsConfirm ? const <ChatMessage>[] : messages,
      confirmationRequest: needsConfirm
          ? RoleConfirmationRequest(
              conversationId: conversationId,
              segments: unrecognized
                  .take(4)
                  .map((b) => PreviewSegment(
                        index: b.index,
                        preview: _truncate(b.content, 50),
                      ))
                  .toList(),
            )
          : null,
    );
  }

  /// 用户对预览段确认角色后，按索引生成正式消息。
  List<ChatMessage> buildConfirmedMessages(
    String text, {
    required String conversationId,
    required Map<int, MessageRole> roleBySegmentIndex,
  }) {
    final blocks = _splitBlocks(text);
    final result = <ChatMessage>[];
    var time = DateTime.now().toUtc().subtract(Duration(minutes: blocks.length));
    for (var i = 0; i < blocks.length; i++) {
      final role = roleBySegmentIndex[i] ?? _parseRoleFromPrefix(blocks[i]) ?? MessageRole.user;
      final stableId = _stableHash('$conversationId|$i|${role.name}|${blocks[i]}');
      time = time.add(const Duration(seconds: 1));
      result.add(ChatMessage(
        id: stableId,
        conversationId: conversationId,
        role: role,
        content: _stripPrefix(blocks[i]),
        createdAt: time,
        updatedAt: time,
        deviceId: 'imported',
        versionVector: VectorClock.fromJson(<String, dynamic>{
          'imported': stableId.hashCode.abs() % 1000 + 1,
        }),
      ));
    }
    return result;
  }

  List<String> _splitBlocks(String text) => text
      .split(RegExp(r'\n\s*\n'))
      .map((b) => b.trim())
      .where((b) => b.isNotEmpty)
      .toList(growable: false);

  /// 解析 [会话][消息] 原生格式：id/role/time/thinking/content + ~~~~ 包裹。
  List<ChatMessage> _tryParseNativeFormat(String text, String conversationId) {
    if (!text.contains('[消息]')) return const <ChatMessage>[];
    final convMatch = RegExp(r'\[会话ID\]\s*(\S+)').firstMatch(text);
    final convId = convMatch?.group(1) ?? conversationId;
    final result = <ChatMessage>[];

    for (final match in RegExp(r'\[消息\]([\s\S]*?)(?=\[消息\]|$)').allMatches(text)) {
      final body = match.group(1)!;
      final idMatch = RegExp(r'^id:\s*(\S+)', multiLine: true).firstMatch(body);
      final roleMatch = RegExp(r'^role:\s*(\S+)', multiLine: true).firstMatch(body);
      final timeMatch = RegExp(r'^time:\s*(\S+)', multiLine: true).firstMatch(body);
      final contentMatch = RegExp(r'content:\s*\n~~~~\n([\s\S]*?)\n~~~~').firstMatch(body);
      if (idMatch == null || roleMatch == null || contentMatch == null) continue;
      final role = _parseRoleFromPrefix('${roleMatch.group(1)}:');
      if (role == null) continue;
      final time = DateTime.tryParse(timeMatch?.group(1) ?? '')?.toUtc() ??
          DateTime.now().toUtc();
      result.add(ChatMessage(
        id: idMatch.group(1)!,
        conversationId: convId,
        role: role,
        content: contentMatch.group(1)!,
        createdAt: time,
        updatedAt: time,
        deviceId: 'imported',
        versionVector: VectorClock.fromJson(<String, dynamic>{
          'imported': idMatch.group(1)!.hashCode.abs() % 1000 + 1,
        }),
      ));
    }
    return result;
  }

  (MessageRole, String, String)? _parseBlock(String block) {
    final role = _parseRoleFromPrefix(block);
    if (role == null) return null;
    final content = _stripPrefix(block);
    return (role, content, '');
  }

  MessageRole? _parseRoleFromPrefix(String block) {
    final lower = block.toLowerCase();
    if (lower.startsWith('user:') || lower.startsWith('用户：') || lower.startsWith('用户:')) {
      return MessageRole.user;
    }
    if (lower.startsWith('assistant:') ||
        lower.startsWith('助手：') ||
        lower.startsWith('助手:') ||
        lower.startsWith('ai:')) {
      return MessageRole.assistant;
    }
    if (lower.startsWith('system:') || lower.startsWith('系统：')) {
      return MessageRole.system;
    }
    return null;
  }

  String _stripPrefix(String block) =>
      block.replaceFirst(RegExp(r'^(user|assistant|system|ai|用户|助手|系统)\s*[:：]\s*', caseSensitive: false), '');

  String _stableHash(String input) =>
      sha256.convert(utf8.encode(input)).toString().substring(0, 16);

  String _truncate(String text, int max) =>
      text.length <= max ? text : '${text.substring(0, max)}…';
}

class _UnrecognizedBlock {
  final int index;
  final String content;
  const _UnrecognizedBlock({required this.index, required this.content});
}
