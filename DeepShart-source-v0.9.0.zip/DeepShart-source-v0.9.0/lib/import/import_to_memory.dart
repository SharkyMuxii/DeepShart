// target: lib/import/import_to_memory.dart
// 职责：导入成功后，把导入的对话【全量】转成 app 标准记忆条目（ImportantMemory）
// 存入记忆库，使这些对话在后续会话中能被记忆检索命中。
//
// 设计要点（用户明确要求）：
// - 全量：每条有正文的消息都转一条记忆，不经过 AI 提炼（确定性、不过滤、不丢失）。
// - 不改原文件：只读导入进来的 ChatMessage，原始导入文件分毫不动（不触犯记忆底线）。
// - 幂等：记忆 id 由消息 id 确定性派生，重复导入同一会话不会产生重复记忆。
// - 可回溯：每条记忆的 tags 标注"导入/角色/来源会话"，便于识别与清理。

import 'package:crypto/crypto.dart';
import 'dart:convert';

import '../data/models/chat_message.dart';
import '../data/models/important_memory.dart';
import '../data/store/important_memory_store.dart';

class ImportToMemoryOutcome {
  final int saved;
  final int skipped;
  const ImportToMemoryOutcome({required this.saved, required this.skipped});
}

/// 把导入消息全量转标准记忆并落库。
class ImportToMemory {
  final ImportantMemoryStore memoryStore;
  final String deviceId;

  ImportToMemory({required this.memoryStore, required this.deviceId});

  /// [messages] 是本次导入并已入库的消息；[sourceLabel] 是来源文件名/标题。
  Future<ImportToMemoryOutcome> run({
    required String conversationId,
    required String sourceLabel,
    required List<ChatMessage> messages,
  }) async {
    var saved = 0;
    var skipped = 0;
    for (final m in messages) {
      final content = m.content.trim();
      // 空正文、纯 thinking 段不转记忆。
      final plain = _stripThinking(content);
      if (plain.isEmpty) {
        skipped++;
        continue;
      }
      // summary 上限：记忆是"要点"而非全文存档，单条过长会挤占上下文预算。
      // 全量指"每条消息都转"，不是"每条都无限长"——过长时截断并标注。
      final summary = plain.length > 500 ? '${plain.substring(0, 500)}…' : plain;
      final roleLabel = m.role == MessageRole.user ? '我' : 'AI';
      // 确定性 id：来自消息 id，重复导入同会话幂等。
      final digest = md5.convert(utf8.encode('import-memory|${m.id}')).toString();
      final memory = ImportantMemory(
        id: 'imem-$digest',
        conversationId: conversationId,
        summary: summary,
        tags: <String>['导入', roleLabel, sourceLabel],
        importance: 0.55,
        createdAt: m.createdAt.toUtc(),
        versionVector: mMemoryClock(m.id),
        deviceId: deviceId,
        locked: false,
      );
      try {
        await memoryStore.insertOrMerge(memory);
        saved++;
      } catch (_) {
        skipped++;
      }
    }
    return ImportToMemoryOutcome(saved: saved, skipped: skipped);
  }

  /// 单条消息用一个固定 tick 的向量时钟——只用于让 insertOrMerge 能落库，
  /// 幂等靠确定性 id 保证，不依赖时钟比较。
  VectorClock mMemoryClock(String messageId) =>
      VectorClock.empty().tick('import-$messageId');

  String _stripThinking(String s) => s
      .replaceAll(RegExp(r'<thinking>[\s\S]*?</thinking>'), '')
      .trim();
}
