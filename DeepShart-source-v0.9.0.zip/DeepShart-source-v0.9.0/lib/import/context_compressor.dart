// target: lib/import/context_compressor.dart
// 职责：上下文压缩——token 估算、分档压缩（轻度/中度/重度）、头尾与重点记忆保护、摘要生成与真正落库。
//
// 历史教训（用户实测反馈）：
//   旧实现给消息做 `copyWith(deleted: true)` 后走 `insertOrMerge`，但没有 tick 向量时钟，
//   store 比对结果是 "equal" → 直接 ignored。于是"压缩成功、省了 token、扣了钱"，
//   而消息一条没少。现在所有改写一律走 `touch(deviceId, ...)`：它同时递增时钟、
//   刷新 updatedAt 与 deviceId，store 才会真的把新版本写进去。

import 'dart:math' as math;

import 'package:flutter/foundation.dart';

import '../ai/ai_provider.dart';
import '../ai/context_budget.dart';
import '../ai/token_estimator.dart';
import '../data/models/chat_message.dart';
import '../data/models/compaction_view.dart';
import '../data/models/compression_level.dart';
import '../data/models/conversation_settings.dart';
import '../data/models/important_memory.dart';
import '../data/models/session_summary.dart';
import '../data/store/message_store.dart';

// 估算口径统一由 token_estimator 提供；这里 re-export 是为了不破坏既有引用
// （压缩面板、控制器、测试都从本文件取 TokenEstimator）。
export '../ai/token_estimator.dart' show TokenEstimator;

/// Token 估算器。避免引入 tiktoken 的庞大词表：用字符分类的近似估算，
/// 对中英混合文本误差在可接受范围。实现见 [TokenEstimator]。
///
/// 校准说明：旧口径"中文 1 字 = 1 token"把占用高估近 1.6 倍，
/// 导致 64K 上限实际只装约 40K、压缩被过早触发。现按官方量级取 0.65。

/// 一次压缩的结果。数值全部来自"压缩后真实的消息集合"，不再是理论推算。
@immutable
class CompressionOutcome {
  /// 压缩后应当存在的消息集合（apply=true 时与库内一致）。
  final List<ChatMessage> finalMessages;

  final String summary;
  final int beforeTokens;
  final int afterTokens;

  /// 被整体折叠（软删除）的条数。
  final int deletedCount;

  /// 被截断成片段的条数。
  final int truncatedCount;

  /// 因被标记为重要记忆而原样保留的条数。
  final int memoryProtectedCount;

  /// 头尾原样保留的条数（最老 + 最新）。
  final int headKeptCount;
  final int tailKeptCount;

  /// 没有可压缩内容时为 true，[skipReason] 说明原因。
  final bool skipped;
  final String? skipReason;

  /// 压缩产出的视图。非 null 时由调用方落库（本类不再写库）。
  ///
  /// 为什么把"计算"和"落盘"分开：压缩现在是视图层操作，落盘要经过
  /// CompactionViewStore，而计算过程（含昂贵的摘要调用）必须能被单独调用
  /// （预览、估算、测试）。混在一起会导致"点取消也花了钱"。
  final CompactionView? view;

  const CompressionOutcome({
    required this.finalMessages,
    required this.summary,
    required this.beforeTokens,
    required this.afterTokens,
    this.deletedCount = 0,
    this.truncatedCount = 0,
    this.memoryProtectedCount = 0,
    this.headKeptCount = 0,
    this.tailKeptCount = 0,
    this.skipped = false,
    this.skipReason,
    this.view,
  });

  int get savedTokens => beforeTokens - afterTokens;

  bool get changed => !skipped && (deletedCount + truncatedCount) > 0;
}

/// 压缩的花费预估。压缩是唯一会"批量调用模型"的操作，必须先报账再执行。
@immutable
class CompressionCostEstimate {
  final int calls;
  final double cost;

  const CompressionCostEstimate({required this.calls, required this.cost});

  String get display => '预计 $calls 次模型调用，约 ¥${cost.toStringAsFixed(3)}';
}

/// 上下文压缩器。
class ContextCompressor {
  final AiProvider provider;
  final MessageStore store;

  /// 单次喂给摘要模型的字符上限。超过就按消息边界切块做 map-reduce。
  static const int chunkChars = 40000;

  /// 参与摘要的总字符上限。超出后只取"较新"的部分：
  /// 越老的信息价值越低，没必要为了它反复花 token。
  static const int maxSummaryInputChars = 90000;

  /// 一次最多合并几块摘要（成本上限）。
  static const int maxChunks = 3;

  ContextCompressor({required this.provider, required this.store});

  /// 粗算这次压缩会花多少钱、调用几次模型。
  ///
  /// 只看字符规模，不跑模型，所以可以在点按钮之前展示。
  /// 价格口径与 MemoryCurator / MemoryBatchExtractor 保持一致（缓存未命中）。
  static CompressionCostEstimate estimateCost(
    List<ChatMessage> messages,
    ConversationSettings settings,
  ) {
    final level = CompressionLevel.values[settings.compressionLevel.clamp(0, 2)];
    final totalChars = messages.fold<int>(0, (s, m) => s + m.content.length);
    final chunks = math.max(1, (totalChars / chunkChars).ceil());

    var calls = chunks;
    var n = chunks;
    while (n > 1) {
      n = (n / 6).ceil();
      calls += n;
    }

    final inputTokens = TokenEstimator.estimateMessages(messages);
    // 归并阶段的输入 ≈ 上一层的摘要量，用摘要字数上限近似。
    final mergeInput = (calls - chunks) * level.summaryChars * 0.65;
    final outputTokens = calls * level.summaryChars * 0.65;
    final cost = (inputTokens + mergeInput) * 2.0 / 1000000 +
        outputTokens * 3.0 / 1000000;
    return CompressionCostEstimate(calls: calls, cost: cost);
  }

  /// 判断是否需要压缩。达到用户配置比例（默认 80%）或手动触发时为 true。
  bool shouldCompress({
    required List<ChatMessage> messages,
    required ConversationSettings settings,
    int? providerContextWindow,
  }) {
    if (!settings.compressionEnabled) return false;
    // 上限口径与"发送预算"共用一处，避免压缩提示线（5.1 万）与真实上限（6.4 万）
    // 各说各话，导致用户被过早催着压缩。
    final limit = settings.contextLimit ?? providerContextWindow ?? ContextBudget.defaultLimit;
    final used = TokenEstimator.estimateMessages(messages);
    return used >= limit * settings.compressionThreshold;
  }

  /// 执行压缩。
  ///
  /// 保留策略（用户指定）：
  ///   1. 最新的一段（`keepRecentRatio`）原样保留；
  ///   2. 最老的一段（`keepOldestRatio`）原样保留——会话开头的设定、前提最不能丢；
  ///   3. 被标为重要记忆的消息原样保留；
  ///   4. 中段按"离现在越远、保留得越少"分三层：完整原文 → 开头片段 → 折叠进摘要。
  ///      三层各占多少由 [CompressionLevel] 决定。
  ///
  /// [apply] 为 false 时只计算不写库（导入场景消息还没入库）。
  Future<CompressionOutcome> compress({
    required String conversationId,
    required List<ChatMessage> messages,
    required ConversationSettings settings,
    required String localDeviceId,
    List<ImportantMemory> memories = const <ImportantMemory>[],
  }) async {
    final systemMessages =
        messages.where((m) => m.role == MessageRole.system).toList(growable: false);
    final chat = messages.where((m) => m.role != MessageRole.system).toList(growable: false);
    final level = CompressionLevel.values[settings.compressionLevel.clamp(0, 2)];
    final beforeTokens = TokenEstimator.estimateMessages(messages);

    CompressionOutcome skip(String reason) => CompressionOutcome(
          finalMessages: messages,
          summary: '',
          beforeTokens: beforeTokens,
          afterTokens: beforeTokens,
          skipped: true,
          skipReason: reason,
        );

    if (chat.length < 6) {
      return skip('消息只有 ${chat.length} 条，还不足以压缩（至少 6 条）');
    }

    // ---- 1. 头尾保护 ----
    final keepRecent =
        math.max(2, (chat.length * settings.keepRecentRatio).round());
    final keepOldest =
        math.max(0, (chat.length * settings.keepOldestRatio).round());

    if (keepRecent + keepOldest >= chat.length - 1) {
      return skip(
        '按当前设置（最新 ${(settings.keepRecentRatio * 100).round()}%'
        ' + 最老 ${(settings.keepOldestRatio * 100).round()}%）已覆盖全部消息，'
        '没有中段可压。调低保留比例或提高压缩程度再试。',
      );
    }

    final tailStart = chat.length - keepRecent;
    final headKept = chat.sublist(0, keepOldest);
    final middle = chat.sublist(keepOldest, tailStart);
    final tailKept = chat.sublist(tailStart);

    // ---- 2. 重要记忆保护 ----
    final memoryProtected = <bool>[];
    for (final m in middle) {
      memoryProtected.add(_isMemoryProtected(m, memories));
    }

    // 已有的压缩摘要也必须保留：再压一次等于把上一轮的结论丢掉。
    bool isExistingSummary(ChatMessage m) =>
        m.content.contains(CompressionMarkers.openTag);

    // ---- 3. 中段分层 ----
    final candidates = <int>[];
    for (var i = 0; i < middle.length; i++) {
      if (memoryProtected[i]) continue;
      if (isExistingSummary(middle[i])) continue;
      candidates.add(i);
    }

    if (candidates.isEmpty) {
      return skip('中段没有可压缩的消息（全部是记忆点或已有摘要）');
    }

    // 从新到旧排列，越靠前保留得越完整。
    final newestFirst = candidates.reversed.toList(growable: false);
    final fullCount = (newestFirst.length * level.fullShare).round();
    final excerptCount = (newestFirst.length * level.excerptShare).round();

    final keepFull = <int>{};
    final makeExcerpt = <int>{};
    final drop = <int>{};
    for (var rank = 0; rank < newestFirst.length; rank++) {
      final index = newestFirst[rank];
      if (rank < fullCount) {
        keepFull.add(index);
      } else if (rank < fullCount + excerptCount) {
        // 太短的消息截断没意义，等同保留。
        final m = middle[index];
        if (m.content.length <= level.excerptChars * 1.2) {
          keepFull.add(index);
        } else {
          makeExcerpt.add(index);
        }
      } else {
        drop.add(index);
      }
    }

    if (drop.isEmpty && makeExcerpt.isEmpty) {
      return skip('当前压缩程度下所有中段消息都能原样保留，无需压缩');
    }

    // ---- 3.5 先算净收益，再决定要不要真的花 token 生成摘要 ----
    // 摘要本身有开销（最多 level.summaryChars 字）。如果"留下的内容 + 摘要"
    // 已经不小于原上下文，那这次压缩注定白花钱，直接跳过并说明原因。
    var keptTokens = TokenEstimator.estimateMessages(systemMessages) +
        TokenEstimator.estimateMessages(headKept) +
        TokenEstimator.estimateMessages(tailKept);
    var savedByRemoval = 0;
    for (var i = 0; i < middle.length; i++) {
      final m = middle[i];
      final original = TokenEstimator.estimate(m.content) + 4;
      if (drop.contains(i)) {
        savedByRemoval += original;
        continue;
      }
      if (makeExcerpt.contains(i)) {
        final shortTokens = TokenEstimator.estimate(_excerpt(m.content, level.excerptChars)) + 4;
        keptTokens += shortTokens;
        savedByRemoval += original - shortTokens;
        continue;
      }
      keptTokens += original;
    }

    // 摘要开销按经验估：约"省下来的四分之一 + 300 字"，且不超过档位上限。
    final estimatedSummaryTokens =
        math.min(level.summaryChars, 300 + (savedByRemoval / 4).round());
    if (keptTokens + estimatedSummaryTokens >= beforeTokens) {
      return skip(
        '按当前档位（${level.label}）压缩后约 ${keptTokens + estimatedSummaryTokens} tokens，'
        '不小于压缩前的 $beforeTokens，省不下空间，已跳过（没有调用模型，不扣费）。'
        '提高压缩程度或降低保留比例再试。',
      );
    }

    // ---- 4. 生成摘要 ----
    // 摘要的原料是"被折叠 + 被截断"的原消息：截断只保留开头片段，
    // 尾部信息必须由摘要兜住，否则就是纯丢信息。
    final summarySources = <ChatMessage>[];
    for (var i = 0; i < middle.length; i++) {
      if (drop.contains(i) || makeExcerpt.contains(i)) {
        summarySources.add(middle[i]);
      }
    }
    summarySources.sort((a, b) => a.createdAt.compareTo(b.createdAt));

    final summaryText = await _summarize(
      messages: summarySources,
      maxChars: level.summaryChars,
      settings: settings,
    );

    // ---- 5. 组装压缩后的消息集合 ----
    final truncatedMessages = <ChatMessage>[];
    final excerpted = <ChatMessage>[];
    final visibleMiddle = <ChatMessage>[];
    for (var i = 0; i < middle.length; i++) {
      final m = middle[i];
      if (drop.contains(i)) continue;
      if (makeExcerpt.contains(i)) {
        final short = m.copyWith(content: _excerpt(m.content, level.excerptChars));
        excerpted.add(short);
        visibleMiddle.add(short);
        truncatedMessages.add(m);
        continue;
      }
      visibleMiddle.add(m);
    }

    final summaryMessage = summaryText.isEmpty
        ? null
        : ChatMessage.create(
            conversationId: conversationId,
            role: MessageRole.user,
            content: CompressionMarkers.wrap(summaryText),
            deviceId: localDeviceId,
            // 摘要放在"最老保护段"之后、中段之前，时间线仍然连贯。
            createdAt: headKept.isNotEmpty
                ? headKept.last.createdAt.add(const Duration(milliseconds: 1))
                : (middle.isNotEmpty
                    ? middle.first.createdAt.subtract(const Duration(milliseconds: 1))
                    : DateTime.now().toUtc()),
          );

    final finalMessages = <ChatMessage>[
      ...systemMessages,
      ...headKept,
      if (summaryMessage != null) summaryMessage,
      ...visibleMiddle,
      ...tailKept,
    ];

    // 净收益检查：消息都很短时，"摘要 + 标记"的开销可能比省下来的还多。
    // 这种情况必须诚实跳过，而不是花掉 token 换来一个更大的上下文。
    final afterTokens = TokenEstimator.estimateMessages(finalMessages);
    if (afterTokens >= beforeTokens) {
      return CompressionOutcome(
        finalMessages: messages,
        summary: '',
        beforeTokens: beforeTokens,
        afterTokens: beforeTokens,
        skipped: true,
        skipReason: '按当前档位压缩后 ${afterTokens} tokens ≥ 压缩前 $beforeTokens，'
            '省不下空间（消息偏短，摘要开销大于收益）。提高压缩程度或降低保留比例再试。',
      );
    }

    // ---- 6. 产出视图（不写库）----
    //
    // 甲方案的核心：压缩不删除、不改写任何消息，只生成一份"视图"，
    // 由发送层在组装请求时应用。原文永远留在库里，用户随时能展开。
    // 这也让同步彻底告别"压缩冲突"——既然从不修改消息，就不存在并发版本。
    final view = CompactionView.create(
      conversationId: conversationId,
      level: settings.compressionLevel.clamp(0, 2),
      summary: summaryText,
      foldedIds: drop.map((i) => middle[i].id).toSet(),
      excerpts: {
        for (final original in truncatedMessages)
          original.id: _excerpt(original.content, level.excerptChars),
      },
      deviceId: localDeviceId,
    );

    return CompressionOutcome(
      finalMessages: finalMessages,
      summary: summaryText,
      beforeTokens: beforeTokens,
      afterTokens: afterTokens,
      deletedCount: drop.length,
      truncatedCount: makeExcerpt.length,
      memoryProtectedCount:
          memoryProtected.where((protected) => protected).length,
      headKeptCount: keepOldest,
      tailKeptCount: keepRecent,
      view: view,
    );
  }

  /// 生成人读摘要（会话摘要），与压缩摘要分开存储展示。
  Future<SessionSummary> generateSessionSummary({
    required String conversationId,
    required List<ChatMessage> messages,
    required String localDeviceId,
  }) async {
    final transcript = messages
        .map((m) => '${m.role.name}: ${m.content}')
        .join('\n');
    final response = await provider.sendMessage(
      [AiMessage(role: 'user', content: '$kSessionSummaryPrompt\n\n---\n$transcript')],
    );
    return SessionSummary.create(
      conversationId: conversationId,
      summaryText: response.finalAnswer.trim(),
      sourceMessageCount: messages.length,
      deviceId: localDeviceId,
    );
  }

  /// 一句话说明这条消息为什么被重点保留。
  bool _isMemoryProtected(ChatMessage message, List<ImportantMemory> memories) {
    final text = message.content.trim();
    if (text.isEmpty) return false;
    for (final memory in memories) {
      final summary = memory.summary.trim();
      if (summary.isEmpty) continue;
      // 1) 记忆摘要里引用了这句原文的开头（用户通常就是复制这句话去建记忆的）。
      final probe = text.length <= 24 ? text : text.substring(0, 24);
      if (probe.length >= 8 && summary.contains(probe)) return true;
      // 2) 这条消息本身就包含了记忆摘要。
      if (summary.length >= 8 && text.contains(summary)) return true;
      // 3) 记忆创建时间附近的对话：用户是按着那几句点的"设为记忆"。
      final minutes = message.createdAt.difference(memory.createdAt).inMinutes.abs();
      if (minutes <= 3) return true;
    }
    return false;
  }

  String _excerpt(String text, int chars) {
    final flat = text.trim();
    if (flat.length <= chars) return flat;
    return '${flat.substring(0, chars)}……';
  }

  /// 摘要生成：分块 + 递归归并，**覆盖全部输入**。
  ///
  /// 旧实现有三处硬上限（总输入 9 万字符、最多 3 块），对 2M token 的对话
  /// 等于只概括了最后 4.5%——用户看到"压缩成功、钱花了、内容还是没了"。
  /// 现在改成 map-reduce：所有块各自摘要，再逐层归并到一条。
  ///
  /// 代价是调用次数随规模线性增长，所以调用方必须先把预估费用展示给用户。
  Future<String> _summarize({
    required List<ChatMessage> messages,
    required int maxChars,
    required ConversationSettings settings,
  }) async {
    if (messages.isEmpty) return '';

    String line(ChatMessage m) =>
        '${m.role == MessageRole.user ? '用户' : 'AI'}: ${m.content}';

    // 按消息边界切块，避免把一句话劈成两半。
    final chunks = <String>[];
    final buffer = StringBuffer();
    for (final m in messages) {
      final text = '${line(m)}\n';
      if (buffer.length + text.length > chunkChars && buffer.isNotEmpty) {
        chunks.add(buffer.toString());
        buffer.clear();
      }
      buffer.write(text);
    }
    if (buffer.isNotEmpty) chunks.add(buffer.toString());
    if (chunks.isEmpty) return '';

    final prompt = kCompressionPrompt.replaceAll('{max_summary_chars}', '$maxChars');

    // map：每块独立摘要。单块时直出，避免多一次归并调用。
    if (chunks.length == 1) {
      return _callModel('$prompt\n\n---\n${chunks.first}', settings, maxChars);
    }

    var level = <String>[];
    for (final chunk in chunks) {
      level.add(await _callModel('$prompt\n\n---\n$chunk', settings, maxChars));
    }

    // reduce：每 6 条合并一次，直到只剩一条。合并组越大轮次越少、越省钱，
    // 但每组内容太长会丢细节，6 是折中值。
    const mergeFanIn = 6;
    var round = 1;
    while (level.length > 1) {
      final next = <String>[];
      for (var i = 0; i < level.length; i += mergeFanIn) {
        final group = level.sublist(
          i,
          (i + mergeFanIn).clamp(0, level.length),
        );
        if (group.length == 1) {
          next.add(group.first);
          continue;
        }
        final merged = group
            .asMap()
            .entries
            .map((e) => '【第 ${e.key + 1} 段要点】\n${e.value}')
            .join('\n\n');
        next.add(await _callModel(
          '$prompt\n\n以上是同一段对话不同部分的要点（第 $round 层归并），'
          '请按时间顺序合并去重成一份完整摘要，不要遗漏未完成事项。\n\n---\n$merged',
          settings,
          maxChars,
        ));
      }
      level = next;
      round++;
    }
    return level.first;
  }

  Future<String> _callModel(
    String content,
    ConversationSettings settings,
    int maxChars,
  ) async {
    // 摘要任务不注入角色提示词：那是聊天人格，会污染客观归纳。
    final response = await provider.sendMessage(
      [AiMessage(role: 'user', content: content)],
      options: const AiRequestOptions(temperature: 0.3),
    );
    var text = response.finalAnswer.trim();
    if (text.length > maxChars) text = text.substring(0, maxChars);
    return text;
  }
}
