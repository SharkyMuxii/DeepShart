// target: lib/main.dart
// 职责：应用入口——初始化 Flutter 绑定、Riverpod 作用域并启动 DeepShart。

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app.dart';
import 'dev/pairing_selftest.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ProviderScope(child: DeepShartApp()));

  // 排障入口：仅在设置了环境变量时运行，普通启动完全不受影响。
  if (Platform.environment['DEEPSHART_SELFTEST'] == 'pair') {
    PairingSelfTest.run();
  }
}
