// target: lib/core/palette.dart
// 职责：运行时可切换的色板——浅色 / 深海蓝深色，并支持用户自定义强调色(UI 颜色)。
//
// 为什么用全局可变状态而不是 Riverpod：AppColors 在项目里被 266 处引用，其中
// 大量在 const 上下文。若改成依赖 ref 的 provider，所有引用点都要重写。
// 这里由 app.dart 在每次主题/强调色变化时同步一次 _current，然后整棵树重建，
// AppColors 的静态 getter 自然拿到新色板——改动面最小、行为可预测。

import 'package:flutter/material.dart';

@immutable
class AppPalette {
  final Color primary;
  final Color primaryDark;
  final Color primarySoft;
  final Color background;
  final Color surface;
  final Color outline;
  final Color textPrimary;
  final Color textSecondary;
  final Color danger;
  final Brightness brightness;

  /// 锚点消息气泡的金色系。背景/边框/正文/强调各一色，
  /// 保证浅色与深色主题下"整条气泡变金"且文字仍清晰可读。
  final Color anchorSurface;
  final Color anchorBorder;
  final Color anchorText;
  final Color anchorAccent;

  const AppPalette({
    required this.primary,
    required this.primaryDark,
    required this.primarySoft,
    required this.background,
    required this.surface,
    required this.outline,
    required this.textPrimary,
    required this.textSecondary,
    required this.danger,
    required this.brightness,
    required this.anchorSurface,
    required this.anchorBorder,
    required this.anchorText,
    required this.anchorAccent,
  });

  bool get isDark => brightness == Brightness.dark;
}

/// 深海蓝浅色（原默认）。
const AppPalette kLightPalette = AppPalette(
  primary: Color(0xFF2E6BF6),
  primaryDark: Color(0xFF1B4FD8),
  primarySoft: Color(0xFFEAF1FF),
  background: Color(0xFFF7F9FC),
  surface: Color(0xFFFFFFFF),
  outline: Color(0xFFE3E8F0),
  textPrimary: Color(0xFF1A2233),
  textSecondary: Color(0xFF6B7688),
  danger: Color(0xFFE5484D),
  brightness: Brightness.light,
  // 浅色锚点：暖金渐变底 + 深褐字，保证浅底上金色可读。
  anchorSurface: Color(0xFFFFF6DC),
  anchorBorder: Color(0xFFE0A30A),
  anchorText: Color(0xFF6B4A00),
  anchorAccent: Color(0xFFB87900),
);

/// 深海蓝深色。用户选定"现成深海蓝深色"方案——背景是深海军蓝，不是纯黑。
const AppPalette kDarkPalette = AppPalette(
  primary: Color(0xFF6FA0FF),
  primaryDark: Color(0xFF8FB8FF),
  primarySoft: Color(0xFF1B3358),
  background: Color(0xFF0E1A2B),
  surface: Color(0xFF16263D),
  outline: Color(0xFF2A435F),
  textPrimary: Color(0xFFE8F0FA),
  textSecondary: Color(0xFF9BB0C9),
  danger: Color(0xFFFF6B6E),
  brightness: Brightness.dark,
  // 深色锚点：暗金底 + 浅金字，深海主题下依然一眼能看出是锚点。
  anchorSurface: Color(0xFF3A2E0E),
  anchorBorder: Color(0xFFC9971B),
  anchorText: Color(0xFFFFE9A8),
  anchorAccent: Color(0xFFF0C44A),
);

/// 用户可选的强调色（UI 颜色）。value 为 null 表示跟随主题默认蓝。
const Map<String, Color?> kAccentChoices = <String, Color?>{
  '默认深海蓝': null,
  '青碧': Color(0xFF0EA5A5),
  '紫罗兰': Color(0xFF8B5CF6),
  '暖橙': Color(0xFFF59E0B),
  '朱红': Color(0xFFE5484D),
  '松绿': Color(0xFF10B981),
};
