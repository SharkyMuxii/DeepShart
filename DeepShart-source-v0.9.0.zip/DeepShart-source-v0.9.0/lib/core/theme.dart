// target: lib/core/theme.dart
// 职责：定义 DeepShart 蓝白/深海深色设计语言的 Material 3 主题，作为 Windows 与 Android 两套外壳共享的视觉基础。
//
// 色板与字体均为运行时可切换：AppColors 静态 getter 读 [AppRuntime]，
// 由 app.dart 在主题/强调色/字体变化时同步一次，再整树重建。

import 'package:flutter/material.dart';

import 'palette.dart';

/// 全局运行时外观配置。app.dart 在 build 时同步这些值。
class AppRuntime {
  AppRuntime._();

  static AppPalette palette = kLightPalette;

  /// 全局默认字体族。null = 系统字体（遵循各平台 fallback）。
  static String? fontFamily;

  static Color get primary => palette.primary;
}

/// 动态色板 token。所有 UI 通过它取色，主题切换后自动生效。
/// 注意：这些是 getter 而非 const，因此调用处的 const 需要移除（已处理）。
abstract final class AppColors {
  static Color get primary => AppRuntime.palette.primary;
  static Color get primaryDark => AppRuntime.palette.primaryDark;
  static Color get primarySoft => AppRuntime.palette.primarySoft;
  static Color get background => AppRuntime.palette.background;
  static Color get surface => AppRuntime.palette.surface;
  static Color get outline => AppRuntime.palette.outline;
  static Color get textPrimary => AppRuntime.palette.textPrimary;
  static Color get textSecondary => AppRuntime.palette.textSecondary;
  static Color get danger => AppRuntime.palette.danger;

  /// 锚点气泡金色系（随浅色/深色主题切换）。
  static Color get anchorSurface => AppRuntime.palette.anchorSurface;
  static Color get anchorBorder => AppRuntime.palette.anchorBorder;
  static Color get anchorText => AppRuntime.palette.anchorText;
  static Color get anchorAccent => AppRuntime.palette.anchorAccent;

  static bool get isDark => AppRuntime.palette.isDark;
}

class AppTheme {
  const AppTheme._();

  /// 默认字体栈：不指定自定义字体时用系统字体栈，保证中英文 fallback 一致。
  static const List<String> systemFontFallback = <String>[
    'Microsoft YaHei',
    'Noto Sans CJK SC',
    'PingFang SC',
    'sans-serif',
  ];

  /// 当前字体族：用户没设自定义字体时返回 null，让 Flutter 用系统默认。
  static String? get fontFamily => AppRuntime.fontFamily;

  /// 根据运行时色板与字体生成主题。[palette] 显式传入，避免与全局状态竞争。
  static ThemeData build(AppPalette palette) {
    final family = AppRuntime.fontFamily;
    final base = ThemeData(
      useMaterial3: true,
      fontFamily: family,
      // 自定义字体只覆盖拉丁/符号，中文仍走系统 fallback。
      fontFamilyFallback: family == null ? systemFontFallback : systemFontFallback,
      brightness: palette.brightness,
      colorScheme: ColorScheme.fromSeed(
        seedColor: palette.primary,
        brightness: palette.brightness,
        primary: palette.primary,
        surface: palette.surface,
      ),
      scaffoldBackgroundColor: palette.background,
      textTheme: TextTheme(
        bodyLarge: const TextStyle(fontSize: 16, height: 1.4),
        bodyMedium: const TextStyle(fontSize: 14, height: 1.4),
        bodySmall: const TextStyle(fontSize: 12, height: 1.35),
        titleLarge: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
        titleMedium: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        titleSmall: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
      ).apply(bodyColor: palette.textPrimary),
    );

    return base.copyWith(
      cardTheme: CardThemeData(
        elevation: 0,
        color: palette.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: palette.outline),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: palette.primary,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: palette.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: palette.surface,
        foregroundColor: palette.textPrimary,
      ),
    );
  }

  /// 兼容旧引用：静态浅色主题（app.dart 已改用 build）。
  static ThemeData get light => build(AppRuntime.palette);
}
