// target: lib/core/app_database.dart
// 职责：统一初始化 SQLite 数据库工厂。Android 用 sqflite 原生实现，Windows/Linux/macOS 用 ffi 实现。

import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class AppDatabase {
  AppDatabase._();

  /// 为什么集中在这里初始化：sqflite 在桌面端没有原生实现，必须切换到 ffi 工厂。
  /// 若不在入口统一处理，Windows 上打开数据库会直接抛出 MissingPluginException。
  static Future<Database> open({String name = 'deepshart.db'}) async {
    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    }
    final dbPath = await databaseFactory.getDatabasesPath();
    return databaseFactory.openDatabase(
      p.join(dbPath, name),
      options: OpenDatabaseOptions(
        version: 1,
        onCreate: (db, _) async {
          // 表结构由各 Store 的 open() 负责建立，这里只保证数据库文件存在。
        },
      ),
    );
  }
}
