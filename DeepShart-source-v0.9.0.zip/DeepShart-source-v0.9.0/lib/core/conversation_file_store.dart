// target: lib/core/conversation_file_store.dart
// 职责：已发送文件的"归档副本"存储。每个会话一个私有目录：
//   <appDocs>/conversation_files/<conversationId>/<文件名>
// 发送附件成功后复制一份进来；文件管理页只扫描这些副本，删除也只删副本，
// 绝不动用户选择文件时的原始路径（对话气泡仍用 localPath 打开原件）。
// 明确不做容量上限、不做自动滚动删除——避免超大文件把应用搞崩。

import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// 一个已归档文件副本。
class ArchivedFile {
  final String conversationId;
  final String name;
  final String path;
  final int size;
  final DateTime modified;

  const ArchivedFile({
    required this.conversationId,
    required this.name,
    required this.path,
    required this.size,
    required this.modified,
  });
}

class ConversationFileStore {
  ConversationFileStore._();

  static Future<Directory> _root() async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, 'conversation_files'));
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  /// 某个会话的归档目录（不存在则创建）。
  static Future<Directory> _dirFor(String conversationId) async {
    final root = await _root();
    // 会话 id 形如 conv-2026...-uuid，本身就是安全文件名；再兜底清洗路径分隔符。
    final safe = conversationId.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    final dir = Directory(p.join(root.path, safe));
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  /// 把原文件复制一份进会话归档目录。返回副本路径；失败返回 null（不影响发送主流程）。
  ///
  /// 关键：幂等。副本名由【来源原件路径的稳定哈希 + 原文件名】构成，
  /// 同一个原件永远映射到同一份副本——重复归档只会覆盖同一文件，不会另存新副本。
  /// 这修掉了"打开一次文件管理页就多复制一份、越删越多"的 bug。
  static Future<String?> archive({
    required String conversationId,
    required String sourcePath,
    String? displayName,
  }) async {
    try {
      final src = File(sourcePath);
      if (!await src.exists()) return null;
      final dir = await _dirFor(conversationId);
      final base = displayName ?? p.basename(sourcePath);
      final ext = p.extension(base);
      final stem = p.basenameWithoutExtension(base);
      // 用来源路径做稳定短哈希（FNV-1a），保证同名不同来源也能区分、同来源恒定。
      final hash = stableHashFor(sourcePath);
      final name = '${stem}_$hash$ext';
      final target = File(p.join(dir.path, name));
      if (!await target.exists()) {
        await src.copy(target.path);
      }
      return target.path;
    } catch (_) {
      return null;
    }
  }

  /// 稳定字符串哈希（FNV-1a 32 位），仅用于生成幂等文件名，非安全用途。
  static String stableHashFor(String s) {
    var h = 0x811c9dc5;
    for (final code in s.codeUnits) {
      h ^= code;
      h = (h * 0x01000193) & 0xffffffff;
    }
    return h.toRadixString(16).padLeft(8, '0');
  }

  /// 扫描全部会话归档目录，返回按会话分组的文件列表（只列真实存在的文件）。
  static Future<Map<String, List<ArchivedFile>>> scanAll() async {
    final result = <String, List<ArchivedFile>>{};
    try {
      final root = await _root();
      await for (final convDir in root.list()) {
        if (convDir is! Directory) continue;
        final convId = p.basename(convDir.path);
        final files = <ArchivedFile>[];
        await for (final entity in convDir.list()) {
          if (entity is! File) continue;
          try {
            final stat = await entity.stat();
            files.add(ArchivedFile(
              conversationId: convId,
              name: p.basename(entity.path),
              path: entity.path,
              size: stat.size,
              modified: stat.modified,
            ));
          } catch (_) {}
        }
        if (files.isNotEmpty) {
          files.sort((a, b) => b.modified.compareTo(a.modified));
          result[convId] = files;
        }
      }
    } catch (_) {}
    return result;
  }

  /// 某个会话归档文件的总字节数。
  static int totalSize(List<ArchivedFile> files) =>
      files.fold<int>(0, (sum, f) => sum + f.size);

  /// 删除一个归档副本（只删副本，不动原件）。
  static Future<void> delete(String path) async {
    try {
      final f = File(path);
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }

  /// 删除多个归档副本。
  static Future<int> deleteAll(Iterable<String> paths) async {
    var n = 0;
    for (final path in paths) {
      final f = File(path);
      if (await f.exists()) {
        try { await f.delete(); n++; } catch (_) {}
      }
    }
    return n;
  }
}
