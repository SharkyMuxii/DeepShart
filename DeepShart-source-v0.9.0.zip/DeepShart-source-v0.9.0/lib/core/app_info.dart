// target: lib/core/app_info.dart
// 职责：集中管理应用品牌信息——产品名、作者标注、版本文案，供各外壳与设置页统一展示。

abstract final class AppInfo {
  static const String name = 'DeepShart';
  static const String author = 'Made by Muxi';
  static const String tagline = 'P2P 直连 · CRDT 用户裁决 · 多厂商 AI';
  /// 双端统一版本号。pubspec.yaml 的 version 也保持 0.9.0+9。
  static const String version = 'V0.9.0';
}
