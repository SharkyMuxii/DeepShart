// target: lib/core/font_service.dart
// 职责：自定义字体的上传、持久化与运行时加载。
//
// 用户要求：
//   - 全局设置里分别设 AI / 用户 / UI 字体，默认系统字体。
//   - 单会话只可调 AI / 用户字体，不影响其它会话。
//   - 上传 ttf/otf 后复制进应用私有目录持久化，重启仍在。

import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

class FontService {
  FontService._();

  /// 用户字体的保存目录（应用文档目录下 fonts/）。
  static Future<Directory> _fontDir() async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, 'fonts'));
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  /// 复制字体文件到应用目录并返回新路径。
  /// [family] 作为字族标识（用文件名 stem，避免冲突）。
  static Future<FontRecord> importFont(String sourcePath) async {
    final file = File(sourcePath);
    if (!await file.exists()) throw FileSystemException('字体文件不存在', sourcePath);
    final ext = p.extension(sourcePath).toLowerCase();
    if (ext != '.ttf' && ext != '.otf') {
      throw FormatException('只支持 ttf / otf 字体文件');
    }
    final dir = await _fontDir();
    // 用时间戳避免同名覆盖：同一字体传两次也不会互相干扰。
    final stem = p.basenameWithoutExtension(sourcePath);
    final safeStem = stem.replaceAll(RegExp(r'[^\w\u4e00-\u9fff-]'), '_');
    final name = '${safeStem}_${DateTime.now().microsecondsSinceEpoch}$ext';
    final target = File(p.join(dir.path, name));
    await file.copy(target.path);

    // 运行时注册：字族名用唯一文件名，避免和系统字体重名。
    final family = 'custom_$safeStem';
    await _loadFont(target.path, family);
    return FontRecord(family: family, path: target.path, label: stem);
  }

  /// 把已保存的字体加载进运行时（应用启动时对已设置的字体调用）。
  static Future<void> loadSavedFont(FontRecord record) async {
    if (!await File(record.path).exists()) return;
    try {
      await _loadFont(record.path, record.family);
    } catch (_) {
      // 损坏/丢失的字体不应让应用起不来，静默跳过回落到系统字体。
    }
  }

  static Future<void> _loadFont(String path, String family) async {
    final bytes = await File(path).readAsBytes();
    final byteData = ByteData.sublistView(bytes);
    final loader = FontLoader(family)
      ..addFont(Future<ByteData>.value(byteData));
    await loader.load();
  }

  /// 列出用户导入过的所有字体（从目录扫描）。
  static Future<List<FontRecord>> listImported() async {
    final dir = await _fontDir();
    final files = dir
        .listSync()
        .whereType<File>()
        .where((f) => f.path.endsWith('.ttf') || f.path.endsWith('.otf'))
        .toList();
    return files.map((f) {
      final name = p.basenameWithoutExtension(f.path);
      final stem = name.contains('_') ? name.substring(0, name.lastIndexOf('_')) : name;
      return FontRecord(family: 'custom_$stem', path: f.path, label: stem);
    }).toList();
  }
}

@immutable
class FontRecord {
  final String family;
  final String path;
  final String label;
  const FontRecord({required this.family, required this.path, required this.label});
}
