// target: lib/data/models/chat_message.dart
// 职责：定义聊天消息的 CRDT 兼容数据模型，内含向量时钟与并发判定算法，供本地存储与 P2P 增量同步共用。

import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

/// 消息角色。与 OpenAI Chat Completions / DeepSeek 的 wire 值保持一致，
/// 避免 AI 服务层再做一次枚举映射。
enum MessageRole { user, assistant, system }

extension MessageRoleX on MessageRole {
  String get wireValue => switch (this) {
        MessageRole.user => 'user',
        MessageRole.assistant => 'assistant',
        MessageRole.system => 'system',
      };

  static MessageRole fromWire(String value) => switch (value) {
        'user' => MessageRole.user,
        'assistant' => MessageRole.assistant,
        'system' => MessageRole.system,
        _ => throw FormatException('Unknown message role: $value'),
      };
}

/// 附件描述。location 既可以是设备本地绝对路径，也可以是远程 URL。
/// type 约定为 pdf / office / image / text / other，供 UI 选择图标与上传策略。
@immutable
class MessageAttachment {
  final String type;
  final String location;
  final String? fileName;
  final String? mimeType;

  /// 文件首次提交时所在的本地设备路径。仅用于本机显示缩略图/打开文件；
  /// 同步到另一台设备后该路径可能失效，UI 必须能优雅降级为"仅显示文件名"。
  /// 可选字段，老数据没有也能正常解析。
  final String? localPath;

  const MessageAttachment({
    required this.type,
    required this.location,
    this.fileName,
    this.mimeType,
    this.localPath,
  });

  Map<String, dynamic> toJson() => {
        'type': type,
        'location': location,
        if (fileName != null) 'file_name': fileName,
        if (mimeType != null) 'mime_type': mimeType,
        if (localPath != null) 'local_path': localPath,
      };

  factory MessageAttachment.fromJson(Map<String, dynamic> json) => MessageAttachment(
        type: json['type'] as String,
        location: json['location'] as String,
        fileName: json['file_name'] as String?,
        mimeType: json['mime_type'] as String?,
        localPath: json['local_path'] as String?,
      );

  /// 是否为图片附件（供 UI 渲染缩略图）。同时看 mimeType 与文件名后缀，
  /// 兼容不同导出来源只写了其中一种的情况。
  bool get isImage {
    final mime = mimeType?.toLowerCase() ?? '';
    if (mime.startsWith('image/')) return true;
    final name = (fileName ?? localPath ?? '').toLowerCase();
    return const ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.heic']
        .any(name.endsWith);
  }
}

/// 向量时钟关系：描述 this 相对 other 的因果位置。
enum ClockRelation {
  /// this 因果上早于 other（other 支配 this）。
  before,

  /// this 因果上晚于 other（this 支配 other）。
  after,

  /// 双方计数器完全一致。
  equal,

  /// 双方互不知晓对方的修改——这就是需要用户裁决的并发冲突。
  concurrent,
}

/// DeviceId -> 逻辑计数器 的向量时钟。
///
/// 为什么用向量时钟而不是 updatedAt 时间戳：
/// 两台设备离线编辑时系统时钟可能漂移，单纯比较时间戳会把"并发修改"误判为
/// "有先后的修改"从而静默覆盖一方。向量时钟能精确区分三种情况：
///   - after/before：存在真实因果先后，可以安全地取较新版本；
///   - concurrent：两个分支互不知晓，必须交由用户裁决（本项目核心决策）。
///
/// 语义与 offline_sync_engine 的 operation-based vector clock 保持一致，
/// 但裁决层不采用该引擎默认的"确定性自动合并"，见 message_store.dart 顶部说明。
@immutable
class VectorClock {
  final Map<String, int> _counters;

  const VectorClock._(this._counters);

  factory VectorClock.empty() => const VectorClock._(<String, int>{});

  factory VectorClock.fromJson(Map<String, dynamic> json) => VectorClock._(
        json.map((key, value) => MapEntry(key, (value as num).toInt())),
      );

  factory VectorClock.parse(String serialized) =>
      VectorClock.fromJson(jsonDecode(serialized) as Map<String, dynamic>);

  Map<String, dynamic> toJson() => Map<String, dynamic>.from(_counters);

  String serialize() => jsonEncode(toJson());

  /// 不可变更新：在指定设备上的计数 +1，其余设备保持不变。
  VectorClock tick(String deviceId) {
    final next = Map<String, int>.from(_counters);
    next[deviceId] = (next[deviceId] ?? 0) + 1;
    return VectorClock._(next);
  }

  /// 逐设备取最大值。用于"已经知晓对方全部历史"时推进本地时钟
  /// （例如用户裁决完成后的时钟对齐）。
  VectorClock merge(VectorClock other) {
    final next = Map<String, int>.from(_counters);
    other._counters.forEach((device, count) {
      next[device] = count > (next[device] ?? 0) ? count : next[device]!;
    });
    return VectorClock._(next);
  }

  /// 核心算法：判断 this 相对 other 的因果关系。
  ///
  /// 遍历双方设备键的并集。若同一个键上 this > other，说明 this 至少有一个
  /// other 未知的事件；若 this < other，说明 other 至少有一个 this 未知的事件。
  /// 两者同时成立 => 双方各持有对方没有的事件 => concurrent，必须停下来交给用户。
  /// 只有单方向成立 => 因果支配，可以安全取较新者。
  ClockRelation compare(VectorClock other) {
    var greater = false;
    var less = false;
    final keys = <String>{..._counters.keys, ...other._counters.keys};
    for (final key in keys) {
      final a = _counters[key] ?? 0;
      final b = other._counters[key] ?? 0;
      if (a > b) greater = true;
      if (a < b) less = true;
      if (greater && less) return ClockRelation.concurrent;
    }
    if (greater) return ClockRelation.after;
    if (less) return ClockRelation.before;
    return ClockRelation.equal;
  }

  /// 同步握手阶段交换的紧凑摘要，形如 "devA:3|devB:7"，按 deviceId 排序保证稳定。
  String digest() {
    final keys = _counters.keys.toList()..sort();
    return keys.map((k) => '$k:${_counters[k]}').join('|');
  }

  Map<String, int> get counters => Map<String, int>.unmodifiable(_counters);

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is VectorClock && mapEquals(_counters, other._counters));

  @override
  int get hashCode => Object.hashAllUnordered(_counters.entries);

  @override
  String toString() => 'VectorClock(${serialize()})';
}

/// CRDT 兼容的聊天消息。所有字段均为 final，任何修改都通过 [copyWith] 产生新对象，
/// 这样才能保证放进 ConflictRecord 的两个版本不会被后续写操作意外篡改。
@immutable
class ChatMessage {
  final String id;
  final String conversationId;
  final MessageRole role;
  final String content;
  final List<MessageAttachment> attachments;
  final DateTime createdAt;
  final DateTime updatedAt;

  /// 最后一次修改该消息的设备。用户裁决后也会更新为裁决设备。
  final String deviceId;

  /// 软删除标记。P2P 同步必须传播删除操作，因此不物理删除行。
  final bool deleted;

  /// 用户手动钉住的锚点。
  ///
  /// 为什么需要它：压缩与滑窗都可以把老内容挤出窗口，但"设定、前提、关键约定"
  /// 可能出现在会话任意位置（例如导入的 1M 对话里，人设在第 300 条）。
  /// 靠"开头几条"猜位置并不可靠，所以留一个显式的、可同步的标记。
  final bool pinned;

  final VectorClock versionVector;

  const ChatMessage({
    required this.id,
    required this.conversationId,
    required this.role,
    required this.content,
    this.attachments = const <MessageAttachment>[],
    required this.createdAt,
    required this.updatedAt,
    required this.deviceId,
    this.deleted = false,
    this.pinned = false,
    required this.versionVector,
  });

  /// 新建消息：自动分配 UUID、UTC 时间与初始时钟。
  factory ChatMessage.create({
    required String conversationId,
    required MessageRole role,
    required String content,
    required String deviceId,
    List<MessageAttachment> attachments = const <MessageAttachment>[],
    String? id,
    DateTime? createdAt,
    bool pinned = false,
  }) {
    final now = (createdAt ?? DateTime.now()).toUtc();
    return ChatMessage(
      id: id ?? const Uuid().v4(),
      conversationId: conversationId,
      role: role,
      content: content,
      attachments: attachments,
      createdAt: now,
      updatedAt: now,
      deviceId: deviceId,
      pinned: pinned,
      versionVector: VectorClock.empty().tick(deviceId),
    );
  }

  /// 用户对现有消息产生一次编辑（包括软删除与冲突裁决）时调用。
  /// 必须同时 tick 时钟并刷新 deviceId/updatedAt，否则对端会把新值判为旧版本或并发。
  ChatMessage touch(
    String editingDeviceId, {
    String? newContent,
    bool? newDeleted,
    bool? newPinned,
    List<MessageAttachment>? newAttachments,
  }) =>
      copyWith(
        content: newContent ?? content,
        deleted: newDeleted ?? deleted,
        pinned: newPinned ?? pinned,
        attachments: newAttachments ?? attachments,
        deviceId: editingDeviceId,
        updatedAt: DateTime.now().toUtc(),
        versionVector: versionVector.tick(editingDeviceId),
      );

  ChatMessage copyWith({
    String? id,
    String? conversationId,
    MessageRole? role,
    String? content,
    List<MessageAttachment>? attachments,
    DateTime? createdAt,
    DateTime? updatedAt,
    String? deviceId,
    bool? deleted,
    bool? pinned,
    VectorClock? versionVector,
  }) =>
      ChatMessage(
        id: id ?? this.id,
        conversationId: conversationId ?? this.conversationId,
        role: role ?? this.role,
        content: content ?? this.content,
        attachments: attachments ?? this.attachments,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deviceId: deviceId ?? this.deviceId,
        deleted: deleted ?? this.deleted,
        pinned: pinned ?? this.pinned,
        versionVector: versionVector ?? this.versionVector,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'conversation_id': conversationId,
        'role': role.wireValue,
        'content': content,
        'attachments': jsonEncode(attachments.map((a) => a.toJson()).toList()),
        'created_at': createdAt.millisecondsSinceEpoch,
        'updated_at': updatedAt.millisecondsSinceEpoch,
        'device_id': deviceId,
        'deleted': deleted ? 1 : 0,
        'pinned': pinned ? 1 : 0,
        'version_vector': versionVector.serialize(),
      };

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    final rawAttachments = json['attachments'];
    List<MessageAttachment> attachments;
    if (rawAttachments == null) {
      attachments = const <MessageAttachment>[];
    } else if (rawAttachments is String) {
      final decoded = jsonDecode(rawAttachments) as List<dynamic>;
      attachments = decoded
          .map((e) => MessageAttachment.fromJson(e as Map<String, dynamic>))
          .toList(growable: false);
    } else {
      attachments = (rawAttachments as List<dynamic>)
          .map((e) => MessageAttachment.fromJson(e as Map<String, dynamic>))
          .toList(growable: false);
    }

    final rawVv = json['version_vector'];
    final vv = rawVv is String
        ? VectorClock.parse(rawVv)
        : VectorClock.fromJson((rawVv as Map).cast<String, dynamic>());

    return ChatMessage(
      id: json['id'] as String,
      conversationId: json['conversation_id'] as String,
      role: MessageRoleX.fromWire(json['role'] as String),
      content: json['content'] as String,
      attachments: attachments,
      createdAt: DateTime.fromMillisecondsSinceEpoch((json['created_at'] as num).toInt(), isUtc: true),
      updatedAt: DateTime.fromMillisecondsSinceEpoch((json['updated_at'] as num).toInt(), isUtc: true),
      deviceId: json['device_id'] as String,
      deleted: (json['deleted'] as num?) == 1,
      pinned: (json['pinned'] as num?) == 1,
      versionVector: vv,
    );
  }

  @override
  String toString() => 'ChatMessage($id, ${role.wireValue}, vv=$versionVector)';
}
