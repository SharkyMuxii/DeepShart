// target: lib/data/models/compaction_view.dart
// 职责：定义"压缩视图"——压缩产物的唯一载体。
//
// 为什么压缩不直接改消息（用户明确要求）：
//   "不希望静默修改对话文件，那样有种自己的记忆被偷偷篡改的不安感。"
//   所以压缩的结果不是"删掉/改写消息"，而是一份**视图**：告诉发送层
//   "这一段折叠成摘要、这一条只保留开头 N 字"，原文一个字都不动。
//   好处是顺带解决了同步冲突：既然从不修改消息，就不存在消息级并发冲突。

import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import 'chat_message.dart';
import 'session_summary.dart' show CompressionMarkers;

@immutable
class CompactionView {
  final String id;
  final String conversationId;

  /// 压缩档位（0 轻度 / 1 中度 / 2 重度），仅用于展示"当时用的是什么强度"。
  final int level;

  /// 折叠区间被压成的摘要正文（不含标记包裹）。
  final String summary;

  /// 被整体折叠的消息 id。
  final Set<String> foldedIds;

  /// 被截断成片段的消息 id → 片段正文。
  final Map<String, String> excerpts;

  final DateTime createdAt;
  final DateTime updatedAt;
  final String deviceId;

  const CompactionView({
    required this.id,
    required this.conversationId,
    required this.level,
    required this.summary,
    required this.foldedIds,
    required this.excerpts,
    required this.createdAt,
    required this.updatedAt,
    required this.deviceId,
  });

  bool get isEmpty => foldedIds.isEmpty && excerpts.isEmpty;

  int get foldedCount => foldedIds.length;
  int get excerptCount => excerpts.length;

  factory CompactionView.create({
    required String conversationId,
    required int level,
    required String summary,
    required Set<String> foldedIds,
    required Map<String, String> excerpts,
    required String deviceId,
  }) {
    final now = DateTime.now().toUtc();
    return CompactionView(
      id: const Uuid().v4(),
      conversationId: conversationId,
      level: level,
      summary: summary,
      foldedIds: Set<String>.unmodifiable(foldedIds),
      excerpts: Map<String, String>.unmodifiable(excerpts),
      createdAt: now,
      updatedAt: now,
      deviceId: deviceId,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'view_id': id,
        'conversation_id': conversationId,
        'level': level,
        'summary': summary,
        'folded_ids': jsonEncode(foldedIds.toList()),
        'excerpts': jsonEncode(excerpts),
        'created_at': createdAt.millisecondsSinceEpoch,
        'updated_at': updatedAt.millisecondsSinceEpoch,
        'device_id': deviceId,
      };

  factory CompactionView.fromJson(Map<String, dynamic> json) {
    List<String> ids = const <String>[];
    final rawIds = json['folded_ids'];
    if (rawIds is String && rawIds.isNotEmpty) {
      ids = (jsonDecode(rawIds) as List<dynamic>).cast<String>();
    } else if (rawIds is List) {
      ids = rawIds.cast<String>();
    }

    Map<String, String> excerpts = const <String, String>{};
    final rawExcerpts = json['excerpts'];
    if (rawExcerpts is String && rawExcerpts.isNotEmpty) {
      excerpts = (jsonDecode(rawExcerpts) as Map<String, dynamic>)
          .map((k, v) => MapEntry(k, v.toString()));
    } else if (rawExcerpts is Map) {
      excerpts = rawExcerpts.map((k, v) => MapEntry(k.toString(), v.toString()));
    }

    return CompactionView(
      id: json['view_id'] as String? ?? json['id'] as String? ?? '',
      conversationId: json['conversation_id'] as String,
      level: (json['level'] as num?)?.toInt() ?? 1,
      summary: json['summary'] as String? ?? '',
      foldedIds: Set<String>.unmodifiable(ids),
      excerpts: Map<String, String>.unmodifiable(excerpts),
      createdAt: DateTime.fromMillisecondsSinceEpoch(
        (json['created_at'] as num?)?.toInt() ?? 0,
        isUtc: true,
      ),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(
        (json['updated_at'] as num?)?.toInt() ?? 0,
        isUtc: true,
      ),
      deviceId: json['device_id'] as String? ?? '',
    );
  }

  /// 摘要消息的固定 id：同一份视图每次生成的 id 必须一致，
  /// 否则每次请求的上下文前缀都变，缓存永远命中不了。
  String get summaryMessageId => 'compact-summary-$id';

  /// 把视图作用到消息列表上，得到"这次要发给模型的样子"。
  ///
  /// 纯函数：不修改传入消息，也不写库。原文永远留在 chat_messages 里，
  /// UI 随时可以展开查看。
  List<ChatMessage> materialize(List<ChatMessage> messages) {
    if (isEmpty) return messages;

    final result = <ChatMessage>[];
    ChatMessage? summaryMessage;
    DateTime? firstFoldedAt;

    for (final message in messages) {
      if (foldedIds.contains(message.id)) {
        firstFoldedAt ??= message.createdAt;
        continue;
      }

      // 摘要插在第一个被折叠的位置，时间线仍然读得通。
      if (firstFoldedAt != null && summaryMessage == null) {
        summaryMessage = _buildSummaryMessage(firstFoldedAt, message.deviceId);
        result.add(summaryMessage);
      }

      final excerpt = excerpts[message.id];
      if (excerpt == null) {
        result.add(message);
      } else {
        // 保留原 id 与时间，只替换正文——这样预算与去重逻辑完全复用。
        result.add(message.copyWith(content: excerpt));
      }
    }

    if (summaryMessage == null && firstFoldedAt != null) {
      result.add(_buildSummaryMessage(firstFoldedAt, deviceId));
    }
    return result;
  }

  ChatMessage _buildSummaryMessage(DateTime at, String fallbackDevice) {
    return ChatMessage(
      id: summaryMessageId,
      conversationId: conversationId,
      role: MessageRole.user,
      content: CompressionMarkers.wrap(summary),
      attachments: const <MessageAttachment>[],
      createdAt: at,
      updatedAt: at,
      deviceId: deviceId.isEmpty ? fallbackDevice : deviceId,
      versionVector: VectorClock.empty(),
    );
  }
}

