// target: lib/data/models/compression_level.dart
// 职责：定义压缩程度档位，以及每档在"保留原文 / 保留片段 / 折叠成摘要"上的具体比例。
//
// 为什么把比例写在这里而不是散在 UI 和压缩器里：
//   UI 要展示"大概会压缩多少"，压缩器要按同一套比例执行。两边共用一份配置，
//   展示的数字与真实行为才不会对不上（之前就出现过"说压缩了但内容没变"）。

/// 压缩程度。用户在压缩面板上三选一。
enum CompressionLevel {
  /// 轻度：尽量保留原文，只把最早的一段折叠成摘要。
  light,

  /// 中度：默认档，中间区域保留片段、较老部分折叠。
  medium,

  /// 重度：只保留近期原文与骨架，其余全部折叠成摘要。
  heavy,
}

extension CompressionLevelSpec on CompressionLevel {
  String get label => switch (this) {
        CompressionLevel.light => '轻度',
        CompressionLevel.medium => '中度',
        CompressionLevel.heavy => '重度',
      };

  /// 一句话说明，直接显示在档位卡片上。
  String get description => switch (this) {
        CompressionLevel.light => '尽量保留原文，只在上下文吃紧时折叠最旧的一段',
        CompressionLevel.medium => '近期原文 + 中段片段 + 早期摘要，日常推荐',
        CompressionLevel.heavy => '只留近期原文，其余压成摘要，最省 token',
      };

  /// 中间区域（既不是最老保护段、也不是最新保护段）里，按"从新到旧"排序后
  /// 保留完整原文的比例。
  double get fullShare => switch (this) {
        CompressionLevel.light => 0.60,
        CompressionLevel.medium => 0.35,
        CompressionLevel.heavy => 0.15,
      };

  /// 接着再往下的这段，保留开头若干字符作为"片段"，让人还能认出聊过什么。
  double get excerptShare => switch (this) {
        CompressionLevel.light => 0.28,
        CompressionLevel.medium => 0.30,
        CompressionLevel.heavy => 0.20,
      };

  /// 片段保留多少字符（取消息开头，尾部用"……"标记被压缩）。
  int get excerptChars => switch (this) {
        CompressionLevel.light => 400,
        CompressionLevel.medium => 220,
        CompressionLevel.heavy => 120,
      };

  /// 摘要最大字符数：档位越重，摘要反而写得更长（因为原文丢得更多），
  /// 这是刻意的——保证"压缩得狠"不等于"信息黑洞"。
  int get summaryChars => switch (this) {
        CompressionLevel.light => 2400,
        CompressionLevel.medium => 1600,
        CompressionLevel.heavy => 1000,
      };

  /// 给用户看的粗略估算：中间区域大致还能保留多少比例的文字。
  /// 计算方式：完整保留段 + 片段段 × 片段长度/平均消息长度的经验折算（约 0.28）。
  int get estimatedKeepPercent {
    final ratio = fullShare + excerptShare * 0.28;
    return (ratio * 100).round();
  }

  /// 档位卡片的副标题，例如"约保留 68% 原文"。
  String get keepHint => '约保留 $estimatedKeepPercent% 原文';
}
