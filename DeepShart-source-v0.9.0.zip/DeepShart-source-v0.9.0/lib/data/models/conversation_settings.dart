// target: lib/data/models/conversation_settings.dart
// 职责：定义单会话设置模型——角色提示词、temperature、压缩阈值、上下文上限、摘要免打扰标志。

import 'package:flutter/foundation.dart';

/// 单会话设置。与会话摘要分表存储，但在同一个设置页展示。
@immutable
class ConversationSettings {
  final String conversationId;
  final String? title;

  /// 角色提示词。null/空表示使用应用通用系统提示；修改后从下一轮生效。
  final String? systemPrompt;

  /// 灵活度，范围 0.0-2.0，默认 1.0。只映射到 temperature，不暴露 top_p。
  final double temperature;

  /// 深度思考强度：0=低（low）、1=标准（high）、2=极限（max）。
  ///
  /// 映射到 DeepSeek 的 reasoning_effort。只在打开"深度思考"时发送；
  /// 关掉思考时该值不参与请求（服务端也不接受 reasoning_effort 配合 disabled）。
  final int thinkingEffort;

  /// 是否开启自动压缩提示。
  final bool compressionEnabled;

  /// 触发压缩的上下文占用比例，默认 0.8（80%）。
  final double compressionThreshold;

  /// 上下文窗口上限（token 数）。null 表示使用 provider 默认值。
  final int? contextLimit;

  /// 最近 N 条消息原样保留，默认 6。
  ///
  /// 新版本改用 [keepRecentRatio]（按比例保留最新内容），此字段保留为兼容旧库
  /// 与同步，不再参与压缩计算。
  final int keepRecentCount;

  /// 压缩程度：0=轻度、1=中度、2=重度。对应 CompressionLevel 的索引。
  final int compressionLevel;

  /// 最新内容原样保留的比例（占全部消息），默认 15%。
  ///
  /// 为什么用比例而不是条数：一次导入 1300 条和日常聊 30 条，用户想要的
  /// "保留最近一点"完全不是一个数量级，固定条数会让短会话一条都不压。
  final double keepRecentRatio;

  /// 最老内容原样保留的比例（占全部消息），默认 10%。
  /// 会话开头通常是设定、背景、关键前提，压掉最容易让模型"失忆"。
  final double keepOldestRatio;

  /// 是否在本会话内不再显示压缩提示弹窗。
  final bool suppressCompressionPrompt;

  /// 本会话使用的模型 id。null 表示跟随全局默认模型。
  ///
  /// 为什么允许会话级覆盖：不同话题的诉求不一样——写代码想要 Pro，
  /// 闲聊想用 Flash 省钱。全局只提供"默认值"，不该成为强制。
  final String? model;

  /// 单次回答的 token 上限（映射到 max_tokens）。null 表示按思考强度取建议值。
  final int? maxOutputTokens;

  /// 是否自动提取重要记忆点。关闭只是停止"自动"，手动添加与整理不受影响。
  final bool autoMemory;

  /// 是否参与跨会话记忆共享。
  ///
  /// 语义是"读取"而不是"合并"：开启后本会话在构建上下文时，会把其他
  /// 开启了同一开关的会话的记忆点一并纳入，各会话的数据本身仍互相独立，
  /// 不会因为共享而被写进对方的库。
  final bool memorySync;

  /// 记忆共享编码：4 位数字/字母。只有 memorySync 开启且编码相同的会话之间
  /// 才互相共享记忆点。null / 空表示用默认公共池（仍共享给同样留空且开启的会话）。
  final String? memoryCode;

  /// 本会话的 AI 回复字体（FontRecord JSON）。null 表示跟随全局字体设置。
  /// 用户要求：会话级只能调 AI / 用户字体，不能调 UI 字体，也不影响其它会话。
  final String? aiFont;

  /// 本会话的用户消息字体（FontRecord JSON）。null 表示跟随全局。
  final String? userFont;

  /// 最后一次修改时间。用于双端合并设置（后写覆盖），null 表示从未落盘。
  final DateTime? updatedAt;

  const ConversationSettings({
    required this.conversationId,
    this.title,
    this.systemPrompt,
    this.temperature = 1.0,
    this.thinkingEffort = 1,
    this.compressionEnabled = true,
    this.compressionThreshold = 0.8,
    this.contextLimit,
    this.keepRecentCount = 6,
    this.compressionLevel = 1,
    this.keepRecentRatio = 0.15,
    this.keepOldestRatio = 0.10,
    this.suppressCompressionPrompt = false,
    this.model,
    this.maxOutputTokens,
    this.autoMemory = true,
    this.memorySync = false,
    this.memoryCode,
    this.aiFont,
    this.userFont,
    this.updatedAt,
  });

  /// 思考强度在 API 侧的取值。DeepSeek 只认 low / high / max，
  /// "medium" 会被映射成 high，所以滑块只暴露这三档，避免用户选了个假档位。
  static const List<String> effortWireValues = <String>['low', 'high', 'max'];
  static const List<String> effortLabels = <String>['低（更快更省）', '标准（默认）', '极限（最难问题）'];

  String get reasoningEffort => effortWireValues[thinkingEffort.clamp(0, 2)];

  String get thinkingEffortLabel => effortLabels[thinkingEffort.clamp(0, 2)];

  /// temperature 的语义标签，供 UI 滑块下方提示。
  String get temperatureLabel {
    if (temperature <= 0.3) return '严谨 / 确定性（适合代码、数学、精确指令）';
    if (temperature <= 0.7) return '平衡（适合日常问答）';
    if (temperature <= 1.3) return '发散 / 有创造性（适合头脑风暴、写作）';
    return '高随机性（适合创意探索，但可能偏离规范）';
  }

  ConversationSettings copyWith({
    String? conversationId,
    String? title,
    String? systemPrompt,
    double? temperature,
    int? thinkingEffort,
    bool? compressionEnabled,
    double? compressionThreshold,
    int? contextLimit,
    int? keepRecentCount,
    int? compressionLevel,
    double? keepRecentRatio,
    double? keepOldestRatio,
    bool? suppressCompressionPrompt,
    String? model,
    int? maxOutputTokens,
    bool? autoMemory,
    bool? memorySync,
    String? memoryCode,
    bool clearMemoryCode = false,
    String? aiFont,
    String? userFont,
    DateTime? updatedAt,
    bool clearSystemPrompt = false,
    bool clearTitle = false,
    bool clearContextLimit = false,
    bool clearModel = false,
    bool clearMaxOutputTokens = false,
    bool clearAiFont = false,
    bool clearUserFont = false,
  }) =>
      ConversationSettings(
        conversationId: conversationId ?? this.conversationId,
        title: clearTitle ? null : (title ?? this.title),
        systemPrompt: clearSystemPrompt ? null : (systemPrompt ?? this.systemPrompt),
        temperature: temperature ?? this.temperature,
        thinkingEffort: thinkingEffort ?? this.thinkingEffort,
        compressionEnabled: compressionEnabled ?? this.compressionEnabled,
        compressionThreshold: compressionThreshold ?? this.compressionThreshold,
        contextLimit: clearContextLimit ? null : (contextLimit ?? this.contextLimit),
        keepRecentCount: keepRecentCount ?? this.keepRecentCount,
        compressionLevel: compressionLevel ?? this.compressionLevel,
        keepRecentRatio: keepRecentRatio ?? this.keepRecentRatio,
        keepOldestRatio: keepOldestRatio ?? this.keepOldestRatio,
        suppressCompressionPrompt:
            suppressCompressionPrompt ?? this.suppressCompressionPrompt,
        model: clearModel ? null : (model ?? this.model),
        maxOutputTokens:
            clearMaxOutputTokens ? null : (maxOutputTokens ?? this.maxOutputTokens),
        autoMemory: autoMemory ?? this.autoMemory,
        memorySync: memorySync ?? this.memorySync,
        memoryCode: clearMemoryCode ? null : (memoryCode ?? this.memoryCode),
        aiFont: clearAiFont ? null : (aiFont ?? this.aiFont),
        userFont: clearUserFont ? null : (userFont ?? this.userFont),
        updatedAt: updatedAt ?? this.updatedAt,
      );

  Map<String, dynamic> toJson() => {
        'conversation_id': conversationId,
        if (title != null) 'title': title,
        if (systemPrompt != null) 'system_prompt': systemPrompt,
        'temperature': temperature,
        'thinking_effort': thinkingEffort,
        'compression_enabled': compressionEnabled ? 1 : 0,
        'compression_threshold': compressionThreshold,
        if (contextLimit != null) 'context_limit': contextLimit,
        'keep_recent_count': keepRecentCount,
        'compression_level': compressionLevel,
        'keep_recent_ratio': keepRecentRatio,
        'keep_oldest_ratio': keepOldestRatio,
        'suppress_compression_prompt': suppressCompressionPrompt ? 1 : 0,
        if (model != null) 'model': model,
        if (maxOutputTokens != null) 'max_output_tokens': maxOutputTokens,
        'auto_memory': autoMemory ? 1 : 0,
        'memory_sync': memorySync ? 1 : 0,
        if (memoryCode != null) 'memory_code': memoryCode,
        if (aiFont != null) 'ai_font': aiFont,
        if (userFont != null) 'user_font': userFont,
        if (updatedAt != null) 'updated_at': updatedAt!.millisecondsSinceEpoch,
      };

  factory ConversationSettings.fromJson(Map<String, dynamic> json) => ConversationSettings(
        conversationId: json['conversation_id'] as String,
        title: json['title'] as String?,
        systemPrompt: json['system_prompt'] as String?,
        temperature: (json['temperature'] as num?)?.toDouble() ?? 1.0,
        thinkingEffort: (json['thinking_effort'] as num?)?.toInt() ?? 1,
        compressionEnabled: (json['compression_enabled'] as num?) == 1,
        compressionThreshold:
            (json['compression_threshold'] as num?)?.toDouble() ?? 0.8,
        contextLimit: (json['context_limit'] as num?)?.toInt(),
        keepRecentCount: (json['keep_recent_count'] as num?)?.toInt() ?? 6,
        compressionLevel: (json['compression_level'] as num?)?.toInt() ?? 1,
        keepRecentRatio: (json['keep_recent_ratio'] as num?)?.toDouble() ?? 0.15,
        keepOldestRatio: (json['keep_oldest_ratio'] as num?)?.toDouble() ?? 0.10,
        suppressCompressionPrompt: (json['suppress_compression_prompt'] as num?) == 1,
        model: json['model'] as String?,
        maxOutputTokens: (json['max_output_tokens'] as num?)?.toInt(),
        // 旧库没有这两列时按"自动提取开、记忆共享关"处理：
        // 自动提取是既有行为（旧版本一直在跑），共享是新能力，默认不打开。
        autoMemory: (json['auto_memory'] as num?) == null
            ? true
            : (json['auto_memory'] as num) == 1,
        memorySync: (json['memory_sync'] as num) == 1,
        memoryCode: json['memory_code'] as String?,
        aiFont: json['ai_font'] as String?,
        userFont: json['user_font'] as String?,
        updatedAt: (json['updated_at'] as num?) == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(
                (json['updated_at'] as num).toInt(),
                isUtc: true,
              ),
      );

  factory ConversationSettings.forNew(String conversationId) =>
      ConversationSettings(conversationId: conversationId);
}
