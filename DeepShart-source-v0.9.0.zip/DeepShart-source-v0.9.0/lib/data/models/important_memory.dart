// target: lib/data/models/important_memory.dart
// 职责：定义重要记忆点实体及其冲突记录，字段与 ChatMessage 保持同一套 CRDT 语义。

import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import 'chat_message.dart';
import 'conflict_record.dart' show ConflictStatus;

/// 重要记忆点实体。与 ChatMessage 共用 versionVector / deviceId / deleted / 软删除语义，
/// 这样在多端 P2P 同步时，记忆点能和消息一样走 insertOrMerge 与用户裁决。
@immutable
class ImportantMemory {
  final String id;
  final String conversationId;
  final String summary;
  final List<String> tags;
  final double importance;
  final DateTime createdAt;
  final VectorClock versionVector;
  final String deviceId;
  final bool deleted;

  /// 用户锁定：锁定的记忆点不参加"一键整理"（避免 AI 把核心锚点改掉）。
  final bool locked;

  /// 被自动提取重新命中的次数。模拟"回忆越多记得越牢"——
  /// 每次同样的内容被再次提取，计数 +1，用于对抗时间衰减。
  final int reextractCount;

  const ImportantMemory({
    required this.id,
    required this.conversationId,
    required this.summary,
    required this.tags,
    required this.importance,
    required this.createdAt,
    required this.versionVector,
    required this.deviceId,
    this.deleted = false,
    this.locked = false,
    this.reextractCount = 0,
  });

  factory ImportantMemory.create({
    required String conversationId,
    required String summary,
    required List<String> tags,
    required double importance,
    required String deviceId,
  }) {
    final now = DateTime.now().toUtc();
    return ImportantMemory(
      id: const Uuid().v4(),
      conversationId: conversationId,
      summary: summary,
      tags: tags,
      importance: importance,
      createdAt: now,
      versionVector: VectorClock.empty().tick(deviceId),
      deviceId: deviceId,
    );
  }

  /// 用户编辑 summary/tags/权重/锁定/删除后调用：递增向量时钟并更新最后修改设备。
  ImportantMemory edit({
    required String editingDeviceId,
    String? newSummary,
    List<String>? newTags,
    double? newImportance,
    bool? newLocked,
    bool? newDeleted,
    int? newReextractCount,
  }) =>
      ImportantMemory(
        id: id,
        conversationId: conversationId,
        summary: newSummary ?? summary,
        tags: newTags ?? tags,
        importance: newImportance ?? importance,
        createdAt: createdAt,
        deviceId: editingDeviceId,
        deleted: newDeleted ?? deleted,
        locked: newLocked ?? locked,
        reextractCount: newReextractCount ?? reextractCount,
        versionVector: versionVector.tick(editingDeviceId),
      );

  /// 计算"时间衰减后的有效权重"，供上下文预算排序与记忆整理使用。
  ///
  /// 规则（用户要求"严厉一些"）：
  ///   - 低级记忆（importance < 0.7）随时间明显打折：每 30 天衰减到 0.7 倍，
  ///     90 天后只剩约 0.34 倍，避免陈年琐事挤占核心记忆。
  ///   - 高级记忆（importance ≥ 0.7）几乎不衰减——核心锚点不因时间流逝而失色。
  ///   - 反复被重新提取的记忆加权：每次 +8%，最多+60%，模拟"回忆越多记得越牢"。
  /// 结果 clamp 到 [0, 1]。
  double effectiveImportance({DateTime? now}) {
    final ageDays = (now ?? DateTime.now()).toUtc().difference(createdAt).inDays;
    final decay = importance >= 0.7
        ? 1.0
        : _pow(0.7, (ageDays / 30).clamp(0, 12).toDouble());
    const perRecallBoost = 0.08;
    final recallBoost = 1.0 + (reextractCount * perRecallBoost).clamp(0.0, 0.6);
    return (importance * decay * recallBoost).clamp(0.0, 1.0);
  }

  static double _pow(double base, double exp) {
    // 避免引入 dart:math 的整数字面量歧义，直接展开常用场景。
    if (exp == 0) return 1;
    var result = 1.0;
    for (var i = 0; i < exp.round(); i++) {
      result *= base;
    }
    return result;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'conversation_id': conversationId,
        'summary': summary,
        'tags': jsonEncode(tags),
        'importance': importance,
        'created_at': createdAt.millisecondsSinceEpoch,
        'version_vector': versionVector.serialize(),
        'device_id': deviceId,
        'deleted': deleted ? 1 : 0,
        'locked': locked ? 1 : 0,
        'reextract_count': reextractCount,
      };

  factory ImportantMemory.fromJson(Map<String, dynamic> json) {
    final rawTags = json['tags'];
    List<String> tags;
    if (rawTags is String) {
      tags = (jsonDecode(rawTags) as List<dynamic>).cast<String>();
    } else {
      tags = (rawTags as List<dynamic>?)?.cast<String>() ?? const <String>[];
    }
    final rawVv = json['version_vector'];
    return ImportantMemory(
      id: json['id'] as String,
      conversationId: json['conversation_id'] as String,
      summary: json['summary'] as String,
      tags: tags,
      importance: (json['importance'] as num).toDouble(),
      createdAt: DateTime.fromMillisecondsSinceEpoch(
        (json['created_at'] as num).toInt(),
        isUtc: true,
      ),
      versionVector: rawVv is String
          ? VectorClock.parse(rawVv)
          : VectorClock.fromJson((rawVv as Map).cast<String, dynamic>()),
      deviceId: json['device_id'] as String,
      deleted: (json['deleted'] as num?) == 1,
      locked: (json['locked'] as num?) == 1,
      reextractCount: (json['reextract_count'] as num?)?.toInt() ?? 0,
    );
  }
}

/// 记忆点冲突记录。与 ConflictRecord 同构，完整保存两个版本交用户裁决。
@immutable
class MemoryConflictRecord {
  final String memoryId;
  final String conversationId;
  final ImportantMemory versionA;
  final ImportantMemory versionB;
  final DateTime detectedAt;
  final ConflictStatus status;

  const MemoryConflictRecord({
    required this.memoryId,
    required this.conversationId,
    required this.versionA,
    required this.versionB,
    required this.detectedAt,
    this.status = ConflictStatus.pending,
  });

  MemoryConflictRecord copyWith({ConflictStatus? status}) => MemoryConflictRecord(
        memoryId: memoryId,
        conversationId: conversationId,
        versionA: versionA,
        versionB: versionB,
        detectedAt: detectedAt,
        status: status ?? this.status,
      );
}
