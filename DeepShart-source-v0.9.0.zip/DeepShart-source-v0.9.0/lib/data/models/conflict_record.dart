// target: lib/data/models/conflict_record.dart
// 职责：描述一对并发版本的冲突记录，承载用户裁决所需的完整版本、时间戳与输入上下文。

import 'dart:convert';

import 'package:flutter/foundation.dart';

import 'chat_message.dart';

/// 冲突在裁决队列中的状态。
///
/// 为什么不用布尔标志位拼接："暂不同步此条"是用户的显式决定，记录必须继续留在队列中，
/// 只是标记为 deferred 从而不阻塞其他冲突的裁决；用枚举可以自然地扩展
/// （例如后续增加 autoResolved / expired）而不需要散落的条件判断。
enum ConflictStatus { pending, deferred }

/// 一次并发修改的快照。
///
/// 为什么保存两个完整 ChatMessage 而不是只存 diff：
///   1) 裁决界面需要展示完整内容、时间、附件与设备标识；
///   2) 裁决后要把选中版本直接写回主表，存完整对象可以避免重建时的字段遗漏；
///   3) 冲突记录本身也要持久化，应用重启后用户仍能继续裁决（"暂不同步"不能丢）。
///
/// lastUserInputA/B 由 MessageStore 在生成冲突时从各自版本的前序用户消息中提取：
/// 两个版本的内容可能不同，创建/修改时间也可能不同，因此上下文必须分别取。
@immutable
class ConflictRecord {
  final String messageId;
  final String conversationId;
  final ChatMessage versionA;
  final ChatMessage versionB;
  final DateTime detectedAt;
  final String? lastUserInputA;
  final String? lastUserInputB;
  final ConflictStatus status;

  const ConflictRecord({
    required this.messageId,
    required this.conversationId,
    required this.versionA,
    required this.versionB,
    required this.detectedAt,
    this.lastUserInputA,
    this.lastUserInputB,
    this.status = ConflictStatus.pending,
  });

  DateTime get updatedAtA => versionA.updatedAt;
  DateTime get updatedAtB => versionB.updatedAt;

  ConflictRecord copyWith({ConflictStatus? status}) => ConflictRecord(
        messageId: messageId,
        conversationId: conversationId,
        versionA: versionA,
        versionB: versionB,
        detectedAt: detectedAt,
        lastUserInputA: lastUserInputA,
        lastUserInputB: lastUserInputB,
        status: status ?? this.status,
      );

  /// 当同一消息又收到一个更新的远端版本、但旧冲突尚未裁决时，替换候选 B。
  /// 保留候选 A（本地版本）不动——用户仍然面对"本地 vs 远端"的二选一，
  /// 不会因为新包到达而悄悄丢掉原本需要裁决的并发修改。
  ConflictRecord withVersionB(ChatMessage newVersionB, String? newLastUserInput) => ConflictRecord(
        messageId: messageId,
        conversationId: conversationId,
        versionA: versionA,
        versionB: newVersionB,
        detectedAt: detectedAt,
        lastUserInputA: lastUserInputA,
        lastUserInputB: newLastUserInput,
        status: status,
      );

  Map<String, dynamic> toJson() => {
        'message_id': messageId,
        'conversation_id': conversationId,
        'version_a': jsonEncode(versionA.toJson()),
        'version_b': jsonEncode(versionB.toJson()),
        'detected_at': detectedAt.millisecondsSinceEpoch,
        if (lastUserInputA != null) 'last_user_input_a': lastUserInputA,
        if (lastUserInputB != null) 'last_user_input_b': lastUserInputB,
        'status': status.index,
      };

  factory ConflictRecord.fromJson(Map<String, dynamic> json) => ConflictRecord(
        messageId: json['message_id'] as String,
        conversationId: json['conversation_id'] as String,
        versionA: ChatMessage.fromJson(jsonDecode(json['version_a'] as String) as Map<String, dynamic>),
        versionB: ChatMessage.fromJson(jsonDecode(json['version_b'] as String) as Map<String, dynamic>),
        detectedAt: DateTime.fromMillisecondsSinceEpoch((json['detected_at'] as num).toInt(), isUtc: true),
        lastUserInputA: json['last_user_input_a'] as String?,
        lastUserInputB: json['last_user_input_b'] as String?,
        status: ConflictStatus.values[(json['status'] as num?)?.toInt() ?? 0],
      );

  @override
  String toString() => 'ConflictRecord($messageId, ${versionA.updatedAt} vs ${versionB.updatedAt}, $status)';
}
