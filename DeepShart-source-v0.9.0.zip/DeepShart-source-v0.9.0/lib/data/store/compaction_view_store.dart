// target: lib/data/store/compaction_view_store.dart
// 职责：压缩视图的持久化。一个会话最多一条视图（重新压缩即替换，撤销即删除）。

import 'dart:async';

import 'package:sqflite/sqflite.dart';

import '../models/compaction_view.dart';

abstract class CompactionViewStore {
  Future<CompactionView?> get(String conversationId);
  Future<void> save(CompactionView view);
  Future<void> delete(String conversationId);

  /// 全量读取，供 P2P 同步交换使用。
  Future<List<CompactionView>> readAll();

  /// 变更通知：UI 订阅后可在压缩/撤销时自动刷新折叠态。
  Stream<String> get changes;

  Future<void> dispose();
}

class SqliteCompactionViewStore implements CompactionViewStore {
  final Database _db;
  static const String _table = 'compaction_views';

  final StreamController<String> _changes = StreamController<String>.broadcast();

  SqliteCompactionViewStore._(this._db);

  static Future<SqliteCompactionViewStore> open(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS $_table (
        conversation_id TEXT PRIMARY KEY,
        view_id TEXT NOT NULL,
        level INTEGER NOT NULL DEFAULT 1,
        summary TEXT NOT NULL,
        folded_ids TEXT NOT NULL,
        excerpts TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL,
        device_id TEXT NOT NULL
      )
    ''');
    return SqliteCompactionViewStore._(db);
  }

  @override
  Stream<String> get changes => _changes.stream;

  @override
  Future<CompactionView?> get(String conversationId) async {
    final rows = await _db.query(
      _table,
      where: 'conversation_id = ?',
      whereArgs: <Object?>[conversationId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return CompactionView.fromJson(rows.first);
  }

  @override
  Future<void> save(CompactionView view) async {
    await _db.insert(
      _table,
      view.toJson(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    _changes.add(view.conversationId);
  }

  @override
  Future<void> delete(String conversationId) async {
    await _db.delete(
      _table,
      where: 'conversation_id = ?',
      whereArgs: <Object?>[conversationId],
    );
    _changes.add(conversationId);
  }

  @override
  Future<List<CompactionView>> readAll() async {
    final rows = await _db.query(_table);
    return rows.map(CompactionView.fromJson).toList(growable: false);
  }

  @override
  Future<void> dispose() => _changes.close();
}
