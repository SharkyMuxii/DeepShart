// target: lib/data/store/conversation_store.dart
// 职责：会话元数据、单会话设置、会话摘要的 SQLite 持久化，供外壳列表与设置页真实读写。

import 'dart:async';

import 'package:sqflite/sqflite.dart';

import '../models/conversation_settings.dart';
import '../models/session_summary.dart';
import 'deleted_conversation_store.dart';

/// 会话元数据。标题与时间戳独立于消息存储，便于列表快速展示。
class Conversation {
  final String id;
  final String title;
  final DateTime createdAt;
  final DateTime updatedAt;

  /// 会话置顶。置顶的会话排在列表最前，方便快速回到重要对话。
  final bool pinned;

  const Conversation({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.updatedAt,
    this.pinned = false,
  });

  factory Conversation.create({required String id, required String title}) {
    final now = DateTime.now().toUtc();
    return Conversation(id: id, title: title, createdAt: now, updatedAt: now);
  }

  Conversation copyWith({String? title, DateTime? updatedAt, bool? pinned}) => Conversation(
        id: id,
        title: title ?? this.title,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        pinned: pinned ?? this.pinned,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'created_at': createdAt.millisecondsSinceEpoch,
        'updated_at': updatedAt.millisecondsSinceEpoch,
        'pinned': pinned ? 1 : 0,
      };

  factory Conversation.fromJson(Map<String, dynamic> json) => Conversation(
        id: json['id'] as String,
        title: json['title'] as String,
        createdAt: DateTime.fromMillisecondsSinceEpoch((json['created_at'] as num).toInt(), isUtc: true),
        updatedAt: DateTime.fromMillisecondsSinceEpoch((json['updated_at'] as num).toInt(), isUtc: true),
        pinned: (json['pinned'] as num?) == 1,
      );
}

abstract class ConversationStore {
  Future<List<Conversation>> watchAllStreamSource(); // 占位，实际用 watchAll
  Stream<List<Conversation>> watchAll();
  Future<Conversation?> get(String id);
  Future<void> upsert(Conversation conversation);
  Future<void> delete(String id);
  Future<void> touch(String id);

  Future<ConversationSettings> getSettings(String conversationId);
  Future<void> saveSettings(ConversationSettings settings);

  /// 双端合并设置：只有对端版本更新时才覆盖本地（后写优先）。
  /// 返回是否真的写入了，便于调用方决定要不要刷新 UI。
  Future<bool> mergeSettings(ConversationSettings incoming);

  Future<SessionSummary?> getSummary(String conversationId);
  Future<void> saveSummary(SessionSummary summary);
  Future<void> deleteSummary(String conversationId);

  /// 全量摘要，供 P2P 同步交换（按"较新版本优先"合并）。
  Future<List<SessionSummary>> readAllSummaries();

  Future<void> dispose();
}

class SqliteConversationStore implements ConversationStore {
  final Database _db;
  static const String _convTable = 'conversations';
  static const String _settingsTable = 'conversation_settings';
  static const String _summaryTable = 'session_summaries';

  final StreamController<void> _changes = StreamController<void>.broadcast();

  SqliteConversationStore._(this._db);

  static Future<SqliteConversationStore> open(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS $_convTable (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS $_settingsTable (
        conversation_id TEXT PRIMARY KEY,
        title TEXT,
        system_prompt TEXT,
        temperature REAL NOT NULL DEFAULT 1.0,
        thinking_effort INTEGER NOT NULL DEFAULT 1,
        compression_enabled INTEGER NOT NULL DEFAULT 1,
        compression_threshold REAL NOT NULL DEFAULT 0.8,
        context_limit INTEGER,
        keep_recent_count INTEGER NOT NULL DEFAULT 6,
        compression_level INTEGER NOT NULL DEFAULT 1,
        keep_recent_ratio REAL NOT NULL DEFAULT 0.15,
        keep_oldest_ratio REAL NOT NULL DEFAULT 0.10,
        suppress_compression_prompt INTEGER NOT NULL DEFAULT 0,
        model TEXT,
        max_output_tokens INTEGER,
        auto_memory INTEGER NOT NULL DEFAULT 1,
        memory_sync INTEGER NOT NULL DEFAULT 0,
        memory_code TEXT,
        ai_font TEXT,
        user_font TEXT,
        updated_at INTEGER
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS $_summaryTable (
        id TEXT PRIMARY KEY,
        conversation_id TEXT NOT NULL UNIQUE,
        summary_text TEXT NOT NULL,
        generated_at INTEGER NOT NULL,
        user_edited INTEGER NOT NULL DEFAULT 0,
        source_message_count INTEGER NOT NULL DEFAULT 0,
        version_vector TEXT NOT NULL
      )
    ''');

    // 老版本建的表缺少后续新增的列时，CREATE TABLE IF NOT EXISTS 是空操作，
    // 之后任何写法新列的 INSERT 都会抛 "no such column"，表现为"保存了但没生效"。
    // 这里显式补齐，保证从任意历史版本升级上来都能正常读写。
    await _ensureColumns(db, _settingsTable, <String, String>{
      'title': 'TEXT',
      'system_prompt': 'TEXT',
      'temperature': 'REAL NOT NULL DEFAULT 1.0',
      'thinking_effort': 'INTEGER NOT NULL DEFAULT 1',
      'compression_enabled': 'INTEGER NOT NULL DEFAULT 1',
      'compression_threshold': 'REAL NOT NULL DEFAULT 0.8',
      'context_limit': 'INTEGER',
      'keep_recent_count': 'INTEGER NOT NULL DEFAULT 6',
      'compression_level': 'INTEGER NOT NULL DEFAULT 1',
      'keep_recent_ratio': 'REAL NOT NULL DEFAULT 0.15',
      'keep_oldest_ratio': 'REAL NOT NULL DEFAULT 0.10',
      'suppress_compression_prompt': 'INTEGER NOT NULL DEFAULT 0',
      'model': 'TEXT',
      'max_output_tokens': 'INTEGER',
      'auto_memory': 'INTEGER NOT NULL DEFAULT 1',
      'memory_sync': 'INTEGER NOT NULL DEFAULT 0',
      'memory_code': 'TEXT',
      'ai_font': 'TEXT',
      'user_font': 'TEXT',
      'updated_at': 'INTEGER',
    });
    await _ensureColumns(db, _convTable, <String, String>{
      'title': 'TEXT NOT NULL DEFAULT ""',
      'created_at': 'INTEGER NOT NULL DEFAULT 0',
      'updated_at': 'INTEGER NOT NULL DEFAULT 0',
      'pinned': 'INTEGER NOT NULL DEFAULT 0',
    });

    return SqliteConversationStore._(db);
  }

  static Future<void> _ensureColumns(
    Database db,
    String table,
    Map<String, String> expected,
  ) async {
    final info = await db.rawQuery('PRAGMA table_info($table)');
    if (info.isEmpty) return;
    final existing = info.map((row) => row['name']?.toString() ?? '').toSet();
    for (final entry in expected.entries) {
      if (existing.contains(entry.key)) continue;
      await db.execute('ALTER TABLE $table ADD COLUMN ${entry.key} ${entry.value}');
    }
  }

  @override
  Stream<List<Conversation>> watchAll() async* {
    yield await _readAll();
    await for (final _ in _changes.stream) {
      yield await _readAll();
    }
  }

  @override
  Future<List<Conversation>> watchAllStreamSource() => _readAll();

  Future<List<Conversation>> _readAll() async {
    // 置顶优先，其次按更新时间倒序。
    final rows = await _db.query(_convTable, orderBy: 'pinned DESC, updated_at DESC');
    return rows.map(Conversation.fromJson).toList(growable: false);
  }

  @override
  Future<Conversation?> get(String id) async {
    final rows = await _db.query(_convTable, where: 'id = ?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return null;
    return Conversation.fromJson(rows.first);
  }

  @override
  Future<void> upsert(Conversation conversation) async {
    await _db.insert(
      _convTable,
      conversation.toJson(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    _changes.add(null);
  }

  @override
  Future<void> delete(String id) async {
    await _db.transaction((txn) async {
      await txn.delete(_convTable, where: 'id = ?', whereArgs: [id]);
      await txn.delete(_settingsTable, where: 'conversation_id = ?', whereArgs: [id]);
      await txn.delete(_summaryTable, where: 'conversation_id = ?', whereArgs: [id]);
      // 消息也必须一起删：只删会话元数据会留下孤儿消息，
      // 下次同步还会把它们推给对端，表现为"删了又冒出来"。
      await txn.delete('chat_messages', where: 'conversation_id = ?', whereArgs: [id]);
      await txn.delete('important_memories', where: 'conversation_id = ?', whereArgs: [id]);
      // 墓碑：在同一事务内记录被删的内部 ID。合并快照时据此过滤，
      // 防止该会话被对端旧快照"复活"。放这里统一挂接，覆盖所有删除入口。
      await txn.execute('''
        CREATE TABLE IF NOT EXISTS ${DeletedConversationStore.table} (
          conversation_id TEXT PRIMARY KEY,
          deleted_at     INTEGER NOT NULL
        )
      ''');
      await txn.insert(
        DeletedConversationStore.table,
        {
          'conversation_id': id,
          'deleted_at': DateTime.now().toUtc().millisecondsSinceEpoch,
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    });
    _changes.add(null);
  }

  @override
  Future<void> touch(String id) async {
    final conv = await get(id);
    if (conv == null) return;
    await upsert(conv.copyWith(updatedAt: DateTime.now().toUtc()));
  }

  @override
  Future<ConversationSettings> getSettings(String conversationId) async {
    final rows = await _db.query(
      _settingsTable,
      where: 'conversation_id = ?',
      whereArgs: [conversationId],
      limit: 1,
    );
    if (rows.isEmpty) return ConversationSettings.forNew(conversationId);
    return ConversationSettings.fromJson(rows.first);
  }

  @override
  Future<void> saveSettings(ConversationSettings settings) async {
    await _db.insert(
      _settingsTable,
      settings.toJson(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    _changes.add(null);
  }

  /// 双端合并：只有对端版本严格更新时才覆盖本地。
  ///
  /// 本地从未落盘（updatedAt 为 null）时接受对端版本；对端时间戳缺失或更旧
  /// 一律忽略，避免同步时把本机刚改的设置冲掉。
  @override
  Future<bool> mergeSettings(ConversationSettings incoming) async {
    final local = await getSettings(incoming.conversationId);
    final localAt = local.updatedAt;
    final incomingAt = incoming.updatedAt;
    if (localAt != null) {
      if (incomingAt == null || !incomingAt.isAfter(localAt)) return false;
    }
    await saveSettings(incoming);
    return true;
  }

  @override
  Future<SessionSummary?> getSummary(String conversationId) async {
    final rows = await _db.query(
      _summaryTable,
      where: 'conversation_id = ?',
      whereArgs: [conversationId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return SessionSummary.fromJson(rows.first);
  }

  @override
  Future<void> saveSummary(SessionSummary summary) async {
    await _db.insert(
      _summaryTable,
      summary.toJson(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    _changes.add(null);
  }

  @override
  Future<void> deleteSummary(String conversationId) async {
    await _db.delete(_summaryTable, where: 'conversation_id = ?', whereArgs: [conversationId]);
    _changes.add(null);
  }

  @override
  Future<List<SessionSummary>> readAllSummaries() async {
    final rows = await _db.query(_summaryTable);
    return rows.map(SessionSummary.fromJson).toList(growable: false);
  }

  @override
  Future<void> dispose() => _changes.close();
}
