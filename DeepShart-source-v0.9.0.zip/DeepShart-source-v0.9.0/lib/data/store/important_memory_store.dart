// target: lib/data/store/important_memory_store.dart
// 职责：重要记忆点的 SQLite 存储，复用与 ChatMessage 相同的向量时钟 insertOrMerge 语义与用户裁决流程。

import 'dart:async';
import 'dart:convert';

import 'package:sqflite/sqflite.dart';

import '../models/chat_message.dart' show ClockRelation;
import '../models/conflict_record.dart' show ConflictStatus;
import '../models/important_memory.dart';
import 'message_store.dart' show MergeResult;

/// 记忆点存储接口。与 MessageStore 对称：insertOrMerge / watch / 裁决。
abstract class ImportantMemoryStore {
  Future<MergeResult> insertOrMerge(ImportantMemory memory);
  Stream<List<ImportantMemory>> watchAll(String conversationId);
  Stream<List<MemoryConflictRecord>> watchConflicts();
  Future<void> resolveConflict(String memoryId, ImportantMemory chosenVersion);

  /// 一次性读取（不含已删除），按重要度倒序。
  ///
  /// 为什么单独暴露：上下文预算、记忆整理、同步都需要"拿全量做计算"，
  /// 用 watch 流去等一次快照既绕又可能丢事件。
  Future<List<ImportantMemory>> readAll(String conversationId);

  /// 跨会话读取全部记忆点，供记忆共享与 P2P 同步使用。
  Future<List<ImportantMemory>> readAllAcrossConversations();

  /// 按关键词跨全部会话搜索记忆点（summary 或 tags 命中任意一个即可）。
  /// 供「记忆索引」用：上下文里没带到的记忆，靠关键词把全库的捞回来。
  /// 命中数按 importance 倒序，最多返回 [limit] 条。
  Future<List<ImportantMemory>> searchAcrossConversations(
    List<String> keywords, {
    int limit = 20,
  });

  /// 物理删除（整理记忆点时的去重合并会用）。
  Future<void> delete(String memoryId);

  /// 清空指定会话的全部记忆点（含已删除），用于"一键清空"二次确认后。
  Future<int> deleteAll(String conversationId);

  Future<void> dispose();
}

class SqliteImportantMemoryStore implements ImportantMemoryStore {
  final Database _db;
  final String _localDeviceId;

  static const String _table = 'important_memories';
  static const String _conflictsTable = 'memory_conflicts';

  final StreamController<String> _changes = StreamController<String>.broadcast();
  final StreamController<void> _conflictChanges = StreamController<void>.broadcast();

  SqliteImportantMemoryStore._(this._db, this._localDeviceId);

  static Future<SqliteImportantMemoryStore> open(
    Database db, {
    required String localDeviceId,
  }) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS $_table (
        id TEXT PRIMARY KEY,
        conversation_id TEXT NOT NULL,
        summary TEXT NOT NULL,
        tags TEXT NOT NULL,
        importance REAL NOT NULL,
        created_at INTEGER NOT NULL,
        version_vector TEXT NOT NULL,
        device_id TEXT NOT NULL,
        deleted INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS $_conflictsTable (
        memory_id TEXT PRIMARY KEY,
        conversation_id TEXT NOT NULL,
        version_a TEXT NOT NULL,
        version_b TEXT NOT NULL,
        detected_at INTEGER NOT NULL,
        status INTEGER NOT NULL DEFAULT 0
      )
    ''');
    // 迁移：老库没有 locked / reextract_count 两列。
    // 用 PRAGMA 检查而不是 CREATE 时声明——老表已存在，CREATE IF NOT EXISTS 不会加列。
    final columns = (await db.rawQuery('PRAGMA table_info($_table)'))
        .map((c) => c['name']?.toString() ?? '')
        .toSet();
    if (!columns.contains('locked')) {
      await db.execute('ALTER TABLE $_table ADD COLUMN locked INTEGER NOT NULL DEFAULT 0');
    }
    if (!columns.contains('reextract_count')) {
      await db.execute(
          'ALTER TABLE $_table ADD COLUMN reextract_count INTEGER NOT NULL DEFAULT 0');
    }
    return SqliteImportantMemoryStore._(db, localDeviceId);
  }

  @override
  Future<MergeResult> insertOrMerge(ImportantMemory memory) async {
    final rows = await _db.query(_table, where: 'id = ?', whereArgs: [memory.id], limit: 1);
    if (rows.isEmpty) {
      await _db.insert(_table, memory.toJson());
      _changes.add(memory.conversationId);
      return const MergeResult(inserted: true);
    }

    final local = ImportantMemory.fromJson(rows.first);
    final relation = memory.versionVector.compare(local.versionVector);
    switch (relation) {
      case ClockRelation.after:
        await _db.update(_table, memory.toJson(), where: 'id = ?', whereArgs: [memory.id]);
        _changes.add(memory.conversationId);
        return const MergeResult(updated: true);

      case ClockRelation.before:
      case ClockRelation.equal:
        return const MergeResult(ignored: true);

      case ClockRelation.concurrent:
        // 与消息完全相同的原则：并发编辑不自动裁决，两版都暂存为候选。
        final record = MemoryConflictRecord(
          memoryId: memory.id,
          conversationId: memory.conversationId,
          versionA: local,
          versionB: memory,
          detectedAt: DateTime.now().toUtc(),
        );
        await _db.insert(
          _conflictsTable,
          <String, dynamic>{
            'memory_id': record.memoryId,
            'conversation_id': record.conversationId,
            'version_a': _encodeMemory(record.versionA),
            'version_b': _encodeMemory(record.versionB),
            'detected_at': record.detectedAt.millisecondsSinceEpoch,
            'status': record.status.index,
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
        _conflictChanges.add(null);
        return MergeResult(conflicts: const []); // 记忆点冲突走独立的 watchConflicts 流
    }
  }

  @override
  Stream<List<ImportantMemory>> watchAll(String conversationId) async* {
    yield await _readAll(conversationId);
    await for (final changed in _changes.stream) {
      if (changed == conversationId) yield await _readAll(conversationId);
    }
  }

  @override
  Stream<List<MemoryConflictRecord>> watchConflicts() async* {
    yield await _readConflicts();
    await for (final _ in _conflictChanges.stream) {
      yield await _readConflicts();
    }
  }

  @override
  Future<void> resolveConflict(String memoryId, ImportantMemory chosenVersion) async {
    await _db.transaction((txn) async {
      final rows = await txn.query(
        _conflictsTable,
        where: 'memory_id = ?',
        whereArgs: [memoryId],
        limit: 1,
      );
      if (rows.isEmpty) return;
      // 递增时钟，避免对端持有并发分支时下一次同步再次产生同一冲突。
      final resolved = chosenVersion.edit(editingDeviceId: _localDeviceId);
      await txn.update(_table, resolved.toJson(), where: 'id = ?', whereArgs: [memoryId]);
      await txn.delete(_conflictsTable, where: 'memory_id = ?', whereArgs: [memoryId]);
    });
    _changes.add(chosenVersion.conversationId);
    _conflictChanges.add(null);
  }

  Future<List<ImportantMemory>> _readAll(String conversationId) async {
    final rows = await _db.query(
      _table,
      where: 'conversation_id = ? AND deleted = 0',
      whereArgs: [conversationId],
      orderBy: 'importance DESC, created_at DESC',
    );
    return rows.map(ImportantMemory.fromJson).toList(growable: false);
  }

  @override
  Future<List<ImportantMemory>> readAll(String conversationId) =>
      _readAll(conversationId);

  @override
  Future<List<ImportantMemory>> readAllAcrossConversations() async {
    final rows = await _db.query(
      _table,
      where: 'deleted = 0',
      orderBy: 'importance DESC, created_at DESC',
    );
    return rows.map(ImportantMemory.fromJson).toList(growable: false);
  }

  @override
  Future<List<ImportantMemory>> searchAcrossConversations(
    List<String> keywords, {
    int limit = 20,
  }) async {
    final terms = keywords
        .map((k) => k.trim())
        .where((k) => k.isNotEmpty)
        .toList(growable: false);
    if (terms.isEmpty) return const <ImportantMemory>[];
    // 每个词对 summary 与 tags 各出一个 LIKE，全部 OR 起来。
    final conditions = <String>[];
    final args = <Object>[];
    for (final t in terms) {
      conditions.add('summary LIKE ?');
      args.add('%$t%');
      conditions.add('tags LIKE ?');
      args.add('%$t%');
    }
    final rows = await _db.query(
      _table,
      where: 'deleted = 0 AND (${conditions.join(' OR ')})',
      whereArgs: args,
      orderBy: 'importance DESC, created_at DESC',
      limit: limit,
    );
    return rows.map(ImportantMemory.fromJson).toList(growable: false);
  }

  @override
  Future<void> delete(String memoryId) async {
    final rows = await _db.query(
      _table,
      columns: <String>['conversation_id'],
      where: 'id = ?',
      whereArgs: <Object?>[memoryId],
      limit: 1,
    );
    await _db.delete(_table, where: 'id = ?', whereArgs: <Object?>[memoryId]);
    if (rows.isNotEmpty) {
      final convId = rows.first['conversation_id']?.toString() ?? '';
      if (convId.isNotEmpty) _changes.add(convId);
    }
  }

  @override
  Future<int> deleteAll(String conversationId) async {
    final count = await _db.delete(
      _table,
      where: 'conversation_id = ?',
      whereArgs: <Object?>[conversationId],
    );
    // 一并清掉该会话的待裁决冲突，避免清空后还弹旧冲突。
    await _db.delete(
      _conflictsTable,
      where: 'conversation_id = ?',
      whereArgs: <Object?>[conversationId],
    );
    _changes.add(conversationId);
    _conflictChanges.add(null);
    return count;
  }

  Future<List<MemoryConflictRecord>> _readConflicts() async {
    final rows = await _db.query(_conflictsTable);
    return rows.map((row) {
      final a = ImportantMemory.fromJson(_decodeMemory(row['version_a'] as String));
      final b = ImportantMemory.fromJson(_decodeMemory(row['version_b'] as String));
      return MemoryConflictRecord(
        memoryId: row['memory_id'] as String,
        conversationId: row['conversation_id'] as String,
        versionA: a,
        versionB: b,
        detectedAt: DateTime.fromMillisecondsSinceEpoch(row['detected_at'] as int, isUtc: true),
        status: ConflictStatus.values[row['status'] as int],
      );
    }).toList(growable: false);
  }

  // 用 dart:convert 序列化嵌套 JSON 存进 TEXT 列，避免为记忆点单独建版本表。
  String _encodeMemory(ImportantMemory m) => jsonEncode(m.toJson());
  Map<String, dynamic> _decodeMemory(String raw) => jsonDecode(raw) as Map<String, dynamic>;

  @override
  Future<void> dispose() async {
    await _changes.close();
    await _conflictChanges.close();
  }
}
