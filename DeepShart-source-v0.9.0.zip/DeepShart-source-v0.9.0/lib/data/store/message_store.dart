// target: lib/data/store/message_store.dart
// 职责：基于 SQLite 的 MessageStore 实现，负责 insertOrMerge 的并发检测、ConflictRecord 生成与用户裁决落地。
//
// 平台说明：本类只依赖 sqflite 的 Database 抽象，由调用方注入。
//   Android 直接使用 sqflite 的 databaseFactory；
//   Windows 必须在入口先执行 sqfliteFfiInit() 并令 databaseFactory = databaseFactoryFfi，
//   否则 sqflite 在桌面端没有可用的原生实现。这样做的好处是持久化层完全不感知平台。
//
// 与 offline_sync_engine 的关系（为什么这样设计）：
//   该引擎 SyncManager 的默认策略是"并发时确定性自动合并"（字段收敛、无需用户介入），
//   这与本项目"并发修改必须由用户裁决"的核心决策直接冲突。因此本项目：
//   1) 数据模型采用与该引擎同构的 operation-based 向量时钟语义（见 chat_message.dart）；
//   2) 本层在写入前先做时钟比较，concurrent 时生成 ConflictRecord 而不自动合并；
//   3) offline_sync_engine 留到任务 2 仅承担 operation 的持久化/重放与同步传输，
//      不参与任何裁决决策。用户偏好始终高于"自动合并"的便利性。

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:sqflite/sqflite.dart';

import '../models/chat_message.dart';
import '../models/conflict_record.dart';

abstract class MessageStore {
  /// 插入或合并一条消息。并发时不会选择任何一方，而是返回 ConflictRecord。
  Future<MergeResult> insertOrMerge(ChatMessage msg);

  /// 监听某个会话的消息列表。初始会立即推送一次当前快照。
  Stream<List<ChatMessage>> watchAll(String conversationId);

  /// 监听全局冲突队列。UI 层据此显示不可忽略的横幅。
  Stream<List<ConflictRecord>> watchConflicts();

  /// 用户裁决：写入选中版本，丢弃另一版本，并递增向量时钟。
  Future<void> resolveConflict(String messageId, ChatMessage chosenVersion);

  /// 暂不同步此条：保留在队列中但标记为 deferred，不阻塞其他冲突。
  Future<void> deferConflict(String messageId);

  /// 整体裁决：一次性处理所有待裁决冲突。
  ///
  /// 为什么需要它：逐条裁决在一次同步几千条差异时会产生几千个弹窗，
  /// 用户既没法点完，UI 也会因为堆叠的模态框卡死。用户明确要求
  /// "把所有对话内容视作一个整体"来选，这里就是那个整体操作。
  ///
  /// 三种策略对应三种真实意图：
  ///   - [ConflictMergeStrategy.local]：以本机为准；
  ///   - [ConflictMergeStrategy.remote]：以对端为准；
  ///   - [ConflictMergeStrategy.merge]：两条都保留，按时间穿插（信息零丢失）。
  ///
  /// 返回实际处理的条数。
  Future<int> resolveConflictsBulk({
    required ConflictMergeStrategy strategy,
    String? conversationId,
  });

  /// 一次性读取，供压缩、摘要、P2P 增量计算等非 UI 场景使用。
  Future<List<ChatMessage>> readAll(String conversationId, {bool includeDeleted = false});

  /// 撤回：把 [messageId] 及其之后的所有消息标记为已删除（软删除，时钟 tick）。
  ///
  /// 为什么不物理删除：删除本身必须能同步到对端，否则对端下次摘要把这些消息
  /// 重新推回来，用户会看到"撤回后消息自己长回来"。软删除 + 递增时钟能让删除
  /// 在因果上支配旧版本，对端接收后同样隐藏。
  ///
  /// 返回被撤回的消息条数。
  Future<int> retractFrom(String conversationId, String messageId, String deviceId);

  /// 只软删除指定的一条消息（与撤回不同：撤回删该条及之后、原文回输入框；
  /// 本方法仅隐藏这一条，不动其他消息、不放回输入框）。同样用递增时钟保证
  /// 删除在因果上支配旧版本，同步到对端后也会被隐藏。
  /// 返回是否删到了消息。
  Future<bool> deleteSingle(String conversationId, String messageId, String deviceId);

  /// 跨全部会话读取，供 P2P 摘要交换与增量计算使用。
  Future<List<ChatMessage>> readAllAcrossConversations({bool includeDeleted = true});

  /// 按关键词搜索消息正文（跨会话），按时间倒序。
  /// 用 SQL LIKE 而非全表读内存——1M 会话全读进来会卡死。
  Future<List<ChatMessage>> searchAcrossConversations(String query, {int limit = 200});

  Future<void> dispose();
}

/// 用户对一批冲突的处理方式。
enum ConflictMergeStrategy {
  /// 全部采用本机版本。
  local,

  /// 全部采用对端版本。
  remote,

  /// 两条都留下：本机版本保持原位，对端版本作为一条新消息按原时间插入。
  ///
  /// 这是"按时间合并"的显式版本——用户明确选择了保留双方，
  /// 而不是后台静默替他把两个分支揉在一起。
  merge,
}

/// 一次 insertOrMerge 的结果。
@immutable
class MergeResult {
  final bool inserted;
  final bool updated;

  /// 收到更旧版本或重复投递时，幂等忽略，不改主表。
  final bool ignored;

  /// 本次产生的冲突（可能同时来自多个导入源）。
  final List<ConflictRecord> conflicts;

  const MergeResult({
    this.inserted = false,
    this.updated = false,
    this.ignored = false,
    this.conflicts = const <ConflictRecord>[],
  });

  bool get hasConflict => conflicts.isNotEmpty;

  factory MergeResult.conflict(ConflictRecord record) =>
      MergeResult(conflicts: <ConflictRecord>[record]);
}

class SqliteMessageStore implements MessageStore {
  final Database _db;
  final String _localDeviceId;

  static const String _messagesTable = 'chat_messages';
  static const String _conflictsTable = 'conflict_records';

  final StreamController<String> _messageChanges = StreamController<String>.broadcast();
  final StreamController<void> _conflictChanges = StreamController<void>.broadcast();

  SqliteMessageStore._(this._db, this._localDeviceId);

  /// 建表并建立索引。索引 (conversation_id, created_at) 是 watchAll / 上下文提取的热路径。
  static Future<SqliteMessageStore> open(Database db, {required String localDeviceId}) async {
    final batch = db.batch();
    batch.execute('''
      CREATE TABLE IF NOT EXISTS $_messagesTable (
        id TEXT PRIMARY KEY,
        conversation_id TEXT NOT NULL,
        role TEXT NOT NULL,
        content TEXT NOT NULL,
        attachments TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL,
        device_id TEXT NOT NULL,
        deleted INTEGER NOT NULL DEFAULT 0,
        pinned INTEGER NOT NULL DEFAULT 0,
        version_vector TEXT NOT NULL
      )
    ''');
    batch.execute('''
      CREATE INDEX IF NOT EXISTS idx_messages_conversation_created
      ON $_messagesTable (conversation_id, created_at)
    ''');
    batch.execute('''
      CREATE TABLE IF NOT EXISTS $_conflictsTable (
        message_id TEXT PRIMARY KEY,
        conversation_id TEXT NOT NULL,
        version_a TEXT NOT NULL,
        version_b TEXT NOT NULL,
        detected_at INTEGER NOT NULL,
        last_user_input_a TEXT,
        last_user_input_b TEXT,
        status INTEGER NOT NULL DEFAULT 0
      )
    ''');
    batch.execute('''
      CREATE INDEX IF NOT EXISTS idx_conflicts_conversation
      ON $_conflictsTable (conversation_id)
    ''');
    await batch.commit(noResult: true);

    // 老库缺列时 CREATE TABLE IF NOT EXISTS 是空操作，之后 INSERT 新列会抛
    // "no such column"——表现就是"设了锚点但下次启动丢了"。显式补齐。
    await _ensureColumns(db, _messagesTable, <String, String>{
      'pinned': 'INTEGER NOT NULL DEFAULT 0',
    });

    return SqliteMessageStore._(db, localDeviceId);
  }

  static Future<void> _ensureColumns(
    Database db,
    String table,
    Map<String, String> expected,
  ) async {
    final info = await db.rawQuery('PRAGMA table_info($table)');
    if (info.isEmpty) return;
    final existing = info.map((row) => row['name']?.toString() ?? '').toSet();
    for (final entry in expected.entries) {
      if (existing.contains(entry.key)) continue;
      await db.execute('ALTER TABLE $table ADD COLUMN ${entry.key} ${entry.value}');
    }
  }

  @override
  Future<MergeResult> insertOrMerge(ChatMessage msg) async {
    final rows = await _db.query(
      _messagesTable,
      where: 'id = ?',
      whereArgs: <Object?>[msg.id],
      limit: 1,
    );

    if (rows.isEmpty) {
      await _db.insert(_messagesTable, _toRow(msg));
      _messageChanges.add(msg.conversationId);
      return const MergeResult(inserted: true);
    }

    final local = _fromRow(rows.first);
    final relation = msg.versionVector.compare(local.versionVector);

    switch (relation) {
      case ClockRelation.concurrent:
        // 【重要】先做"内容是否真的不同"的判断。
        //
        // 两条并发版本如果内容、角色、附件、删除标记完全一致，那它们只是同一份数据
        // 在两端各自被 tick 过一次（典型场景：同一份导出文件在两台设备各导入一次，
        // 或消息在两台设备都被"触碰"过但没有实际改动）。这种情况没有任何东西需要
        // 用户裁决——把它当冲突抛给用户，一次同步就能产生几千条无意义弹窗。
        //
        // 处理方式：时钟取并集（合并双方已知事件）后写回，让下一次摘要交换直接判为
        // equal，不会反复出现。
        if (_samePayload(local, msg)) {
          final merged = local.copyWith(
            versionVector: local.versionVector.merge(msg.versionVector),
            updatedAt: msg.updatedAt.isAfter(local.updatedAt) ? msg.updatedAt : local.updatedAt,
          );
          await _db.update(
            _messagesTable,
            _toRow(merged),
            where: 'id = ?',
            whereArgs: <Object?>[msg.id],
          );
          _messageChanges.add(msg.conversationId);
          return const MergeResult(updated: true);
        }

        // 【核心设计】这里刻意不做任何"取较新"或"字段合并"的自动裁决。
        // 时钟互不支配意味着两个分支各自包含对方不知道的修改，谁"看起来更新"都没有因果依据。
        // 两个完整版本被原样暂存进冲突表，主表暂时保留本地版本供 UI 继续展示，
        // 直到用户通过 resolveConflict 明确选择。
        final inputA = await _findLastUserInput(local);
        final inputB = await _findLastUserInput(msg);
        final record = ConflictRecord(
          messageId: msg.id,
          conversationId: msg.conversationId,
          versionA: local,
          versionB: msg,
          detectedAt: DateTime.now().toUtc(),
          lastUserInputA: inputA,
          lastUserInputB: inputB,
        );
        await _db.insert(
          _conflictsTable,
          record.toJson(),
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
        _conflictChanges.add(null);
        return MergeResult.conflict(record);

      case ClockRelation.after:
        // 若这条消息已有未裁决冲突，绝不能因为"新版本因果支配"就静默覆盖：
        // 候选 A 里的并发修改还没有被用户看过，直接覆盖等于替用户做了裁决。
        // 正确做法是把新版本换进冲突候选 B，继续等待用户裁决。
        final pending = await _readConflictById(msg.id);
        if (pending != null) {
          final refreshed = pending.withVersionB(msg, await _findLastUserInput(msg));
          await _db.update(
            _conflictsTable,
            _conflictToRow(refreshed),
            where: 'message_id = ?',
            whereArgs: <Object?>[msg.id],
          );
          _conflictChanges.add(null);
          return MergeResult.conflict(refreshed);
        }

        // 远端版本支配本地版本，且无待裁决冲突，因果明确，安全覆盖。
        await _db.update(
          _messagesTable,
          _toRow(msg),
          where: 'id = ?',
          whereArgs: <Object?>[msg.id],
        );
        _messageChanges.add(msg.conversationId);
        return const MergeResult(updated: true);

      case ClockRelation.before:
      case ClockRelation.equal:
        // 幂等：重复投递或更旧版本。不改主表，也不清除尚未裁决的冲突记录。
        return const MergeResult(ignored: true);
    }
  }

  @override
  Future<void> resolveConflict(String messageId, ChatMessage chosenVersion) async {
    await _db.transaction((txn) async {
      final rows = await txn.query(
        _conflictsTable,
        where: 'message_id = ?',
        whereArgs: <Object?>[messageId],
        limit: 1,
      );
      if (rows.isEmpty) return;

      // 为什么必须 tick：裁决本身是一次新的编辑事件。若沿用旧时钟，对端仍持有
      // 并发分支，下次同步会再次判定 concurrent，形成无限重复的冲突循环。
      final resolved = chosenVersion.touch(_localDeviceId);

      await txn.update(
        _messagesTable,
        _toRow(resolved),
        where: 'id = ?',
        whereArgs: <Object?>[messageId],
      );
      await txn.delete(
        _conflictsTable,
        where: 'message_id = ?',
        whereArgs: <Object?>[messageId],
      );
    });
    _messageChanges.add(chosenVersion.conversationId);
    _conflictChanges.add(null);
  }

  @override
  Future<void> deferConflict(String messageId) async {
    await _db.update(
      _conflictsTable,
      <String, dynamic>{'status': ConflictStatus.deferred.index},
      where: 'message_id = ?',
      whereArgs: <Object?>[messageId],
    );
    _conflictChanges.add(null);
  }

  @override
  Future<int> resolveConflictsBulk({
    required ConflictMergeStrategy strategy,
    String? conversationId,
  }) async {
    final resolved = <String, String>{}; // messageId -> conversationId

    await _db.transaction((txn) async {
      final rows = await txn.query(
        _conflictsTable,
        where: conversationId == null ? null : 'conversation_id = ?',
        whereArgs: conversationId == null ? null : <Object?>[conversationId],
      );
      if (rows.isEmpty) return;

      // 一次 batch 提交：几千条冲突逐条 await 事务，光是把 SQLite 刷盘几千次
      // 就足以让界面像死机一样。
      final batch = txn.batch();
      for (final row in rows) {
        final record = _conflictFromRow(row);

        // 裁决本身是一次新的编辑事件，必须 tick 时钟：否则对端仍持有并发分支，
        // 下一轮同步会再次判成 concurrent，冲突永远清不干净。
        switch (strategy) {
          case ConflictMergeStrategy.local:
            batch.update(
              _messagesTable,
              _toRow(record.versionA.touch(_localDeviceId)),
              where: 'id = ?',
              whereArgs: <Object?>[record.messageId],
            );

          case ConflictMergeStrategy.remote:
            batch.update(
              _messagesTable,
              _toRow(record.versionB.touch(_localDeviceId)),
              where: 'id = ?',
              whereArgs: <Object?>[record.messageId],
            );

          case ConflictMergeStrategy.merge:
            // 本机版本留在原位（tick 一次标记"已裁决"），对端版本另起一条：
            // 保留它原本的 createdAt，这样列表里仍然按时间顺序读得通。
            batch.update(
              _messagesTable,
              _toRow(record.versionA.touch(_localDeviceId)),
              where: 'id = ?',
              whereArgs: <Object?>[record.messageId],
            );
            // 【关键】任一侧是墓碑时不复活。
            //
            // 之前只判断 versionB.deleted，导致"本机撤回（墓碑）+ 对端还没收到删除"
            // 时选"合并"会把被撤回的消息原样复制回来；老版本压缩也走墓碑，
            // 于是"合并"等于把压缩结果整体作废。删除是用户的明确意图，
            // 不该被"保留双方"覆盖——想保留就不该撤回。
            if (!record.versionB.deleted && !record.versionA.deleted) {
              final copy = record.versionB.copyWith(
                // id 必须幂等：同一冲突反复裁决不能每次都造一条新副本。
                // 用内容指纹而不是时间戳，且跨设备可复现（自己实现 FNV-1a，
                // 不用 String.hashCode——它不保证跨平台稳定）。
                id: '${record.messageId}-merged-${_stableSuffix(record.messageId, record.versionB.updatedAt.millisecondsSinceEpoch)}',
                versionVector: record.versionB.versionVector.tick(_localDeviceId),
              );
              batch.insert(
                _messagesTable,
                _toRow(copy),
                conflictAlgorithm: ConflictAlgorithm.ignore,
              );
            }
        }

        batch.delete(
          _conflictsTable,
          where: 'message_id = ?',
          whereArgs: <Object?>[record.messageId],
        );
        resolved[record.messageId] = record.conversationId;
      }
      await batch.commit(noResult: true);
    });

    for (final convId in resolved.values.toSet()) {
      _messageChanges.add(convId);
    }
    _conflictChanges.add(null);
    return resolved.length;
  }

  /// 清除"内容完全一致"的伪冲突。
  ///
  /// 历史版本会把"两端各 tick 过一次、内容一模一样"的消息也记成冲突，
  /// 一次同步能积几千条。升级后启动时清一次，用户不用再面对满屏无意义冲突。
  /// 返回删除条数。
  Future<int> pruneIdenticalConflicts() async {
    final rows = await _db.query(_conflictsTable);
    final ids = <String>[];
    for (final row in rows) {
      try {
        final record = _conflictFromRow(row);
        if (_samePayload(record.versionA, record.versionB)) {
          ids.add(record.messageId);
        }
      } catch (_) {
        // 损坏的记录不影响其他记录的清理。
      }
    }
    if (ids.isEmpty) return 0;

    await _db.transaction((txn) async {
      final batch = txn.batch();
      for (final id in ids) {
        batch.delete(_conflictsTable, where: 'message_id = ?', whereArgs: <Object?>[id]);
      }
      await batch.commit(noResult: true);
    });
    _conflictChanges.add(null);
    return ids.length;
  }

  /// 生成跨设备可复现的短后缀（FNV-1a 32 位）。
  ///
  /// 为什么不用 String.hashCode：Dart 的字符串哈希不保证跨进程/跨平台一致，
  /// 两台设备算出不同 id 就变成"同一条副本出现两次"，反而是新 bug。
  static String _stableSuffix(String a, int b) {
    final input = '$a|$b';
    var hash = 0x811c9dc5;
    for (final unit in input.codeUnits) {
      hash ^= unit;
      hash = (hash * 0x01000193) & 0xFFFFFFFF;
    }
    return hash.toRadixString(36);
  }

  /// 两个并发版本是否只是"同一份内容"，没有任何实质差异。
  /// 附件只比较位置与名称：同一张图在不同设备上被解析出的本地路径可能不同，
  /// 但 file_id / 资源标识相同时仍应视为同一份。
  bool _samePayload(ChatMessage a, ChatMessage b) {
    if (a.role != b.role || a.deleted != b.deleted) return false;
    if (a.content != b.content) return false;
    if (a.attachments.length != b.attachments.length) return false;
    for (var i = 0; i < a.attachments.length; i++) {
      if (a.attachments[i].location != b.attachments[i].location) return false;
      if (a.attachments[i].fileName != b.attachments[i].fileName) return false;
    }
    return true;
  }

  @override
  Stream<List<ChatMessage>> watchAll(String conversationId) async* {
    yield await readAll(conversationId);

    // 变更要合并。
    //
    // 同步时一次会往同一个会话写入上千条消息；如果每条都触发一次"重读整表 + 重建列表"，
    // 就是 O(n²) 次 SQLite 读取与上千次 1300 行列表重建——界面会直接卡死（用户实测）。
    // 这里攒 120ms 再读一次，读取次数只和"用户能感知的帧"有关，与突发规模无关。
    Timer? timer;
    var dirty = false;
    final pump = StreamController<void>();
    final sub = _messageChanges.stream.listen((changed) {
      if (changed != conversationId) return;
      dirty = true;
      timer?.cancel();
      timer = Timer(const Duration(milliseconds: 120), () {
        if (dirty && !pump.isClosed) {
          dirty = false;
          pump.add(null);
        }
      });
    });

    try {
      await for (final _ in pump.stream) {
        yield await readAll(conversationId);
      }
    } finally {
      timer?.cancel();
      await sub.cancel();
      await pump.close();
    }
  }

  @override
  Stream<List<ConflictRecord>> watchConflicts() async* {
    yield await _readConflicts();

    // 同理：一次同步可能写入几千条冲突，逐条重读整张冲突表（每条都要 JSON 解码
    // 两个完整版本）是 O(n²)，弹窗还没弹出来界面就先卡住了。合并成一次读取。
    Timer? timer;
    var dirty = false;
    final pump = StreamController<void>();
    final sub = _conflictChanges.stream.listen((_) {
      dirty = true;
      timer?.cancel();
      timer = Timer(const Duration(milliseconds: 250), () {
        if (dirty && !pump.isClosed) {
          dirty = false;
          pump.add(null);
        }
      });
    });

    try {
      await for (final _ in pump.stream) {
        yield await _readConflicts();
      }
    } finally {
      timer?.cancel();
      await sub.cancel();
      await pump.close();
    }
  }

  @override
  Future<List<ChatMessage>> readAll(String conversationId, {bool includeDeleted = false}) async {
    final rows = await _db.query(
      _messagesTable,
      where: includeDeleted
          ? 'conversation_id = ?'
          : 'conversation_id = ? AND deleted = 0',
      whereArgs: <Object?>[conversationId],
      orderBy: 'created_at ASC',
    );
    return rows.map(_fromRow).toList(growable: false);
  }

  @override
  Future<int> retractFrom(String conversationId, String messageId, String deviceId) async {
    final rows = await _db.query(
      _messagesTable,
      where: 'id = ? AND conversation_id = ?',
      whereArgs: <Object?>[messageId, conversationId],
      limit: 1,
    );
    if (rows.isEmpty) return 0;
    final anchor = _fromRow(rows.first);

    // 用 >= 而不是 > ：被撤回的那条自己也要删除（它的内容已经回到输入框了）。
    // created_at 相同的极端情况（同一毫秒连发）一并删除，宁多勿漏——
    // 漏删会让"撤回后模型还能看到被撤回内容"，这是更难解释的 bug。
    final targets = await _db.query(
      _messagesTable,
      where: 'conversation_id = ? AND created_at >= ? AND deleted = 0',
      whereArgs: <Object?>[conversationId, anchor.createdAt.millisecondsSinceEpoch],
    );

    await _db.transaction((txn) async {
      for (final row in targets) {
        final msg = _fromRow(row);
        final tombstone = msg.touch(deviceId, newDeleted: true);
        await txn.update(
          _messagesTable,
          _toRow(tombstone),
          where: 'id = ?',
          whereArgs: <Object?>[msg.id],
        );
      }
    });

    _messageChanges.add(conversationId);
    return targets.length;
  }

  @override
  Future<bool> deleteSingle(String conversationId, String messageId, String deviceId) async {
    final rows = await _db.query(
      _messagesTable,
      where: 'id = ? AND conversation_id = ? AND deleted = 0',
      whereArgs: <Object?>[messageId, conversationId],
      limit: 1,
    );
    if (rows.isEmpty) return false;
    final msg = _fromRow(rows.first);
    // 软删除 + 递增时钟：删除在因果上支配旧版本，对端同步后同样隐藏。
    await _db.update(
      _messagesTable,
      _toRow(msg.touch(deviceId, newDeleted: true)),
      where: 'id = ?',
      whereArgs: <Object?>[msg.id],
    );
    _messageChanges.add(conversationId);
    return true;
  }

  @override
  Future<List<ChatMessage>> readAllAcrossConversations({bool includeDeleted = true}) async {
    final rows = await _db.query(
      _messagesTable,
      where: includeDeleted ? null : 'deleted = 0',
      orderBy: 'created_at ASC',
    );
    return rows.map(_fromRow).toList(growable: false);
  }

  @override
  Future<List<ChatMessage>> searchAcrossConversations(
    String query, {
    int limit = 200,
  }) async {
    final keyword = query.trim();
    if (keyword.isEmpty) return const <ChatMessage>[];
    // LIKE 的 % 和 _ 是通配符，先转义，避免用户输入"_""%"时匹配错乱。
    final escaped = keyword.replaceAll(r'\', r'\\').replaceAll('%', r'\%').replaceAll('_', r'\_');
    final rows = await _db.query(
      _messagesTable,
      where: 'deleted = 0 AND content LIKE ? ESCAPE \'\\\'',
      whereArgs: <Object?>['%$escaped%'],
      orderBy: 'created_at DESC',
      limit: limit,
    );
    return rows.map(_fromRow).toList(growable: false);
  }

  Future<List<ConflictRecord>> _readConflicts() async {
    final rows = await _db.query(
      _conflictsTable,
      orderBy: 'detected_at DESC',
    );
    return rows.map(_conflictFromRow).toList(growable: false);
  }

  Future<ConflictRecord?> _readConflictById(String messageId) async {
    final rows = await _db.query(
      _conflictsTable,
      where: 'message_id = ?',
      whereArgs: <Object?>[messageId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return _conflictFromRow(rows.first);
  }

  /// 从该版本及其前序消息中找出最近一条用户输入。
  /// 若该版本本身就是 user 消息，直接用自己的 content——冲突预览里用户最想看到的就是被改的那句话。
  Future<String?> _findLastUserInput(ChatMessage version) async {
    if (version.role == MessageRole.user) return version.content;
    final rows = await _db.query(
      _messagesTable,
      columns: <String>['content'],
      where: 'conversation_id = ? AND role = ? AND created_at <= ? AND id != ?',
      whereArgs: <Object?>[
        version.conversationId,
        MessageRole.user.wireValue,
        version.createdAt.millisecondsSinceEpoch,
        version.id,
      ],
      orderBy: 'created_at DESC',
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return rows.first['content'] as String;
  }

  Map<String, dynamic> _toRow(ChatMessage msg) => msg.toJson();

  ChatMessage _fromRow(Map<String, dynamic> row) => ChatMessage.fromJson(row);

  Map<String, dynamic> _conflictToRow(ConflictRecord record) => record.toJson();

  ConflictRecord _conflictFromRow(Map<String, dynamic> row) => ConflictRecord.fromJson(row);

  @override
  Future<void> dispose() async {
    await _messageChanges.close();
    await _conflictChanges.close();
  }
}
