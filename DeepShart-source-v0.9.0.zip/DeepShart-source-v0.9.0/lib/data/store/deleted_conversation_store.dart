// target: lib/data/store/deleted_conversation_store.dart
// 职责：会话删除墓碑表。删除会话时记录其【内部 ID】（不是标题！），
// 同步合并快照时按墓碑过滤，防止已删会话"死灰复燃"。
//
// 为什么用数据库表而不是 prefs / 云端文件：
//   备份是整库 VACUUM，墓碑放进数据库表就【自动纳入备份】，
//   回溯后墓碑与对话一起恢复，不会出现"恢复了对话却被旧墓碑二次删除"。
//   云端另有一份操作文件用于跨设备同步（见 cos_sync_provider 的 tombstone 上传）。

import 'package:sqflite/sqflite.dart';

class DeletedConversationStore {
  final Database db;
  DeletedConversationStore(this.db);

  static const table = 'deleted_conversations';

  static Future<void> ensureTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS $table (
        conversation_id TEXT PRIMARY KEY,
        deleted_at     INTEGER NOT NULL
      )
    ''');
  }

  /// 记录一条删除墓碑（幂等：重复记录更新时间）。
  Future<void> tombstone(String conversationId, {DateTime? at}) async {
    final ts = (at ?? DateTime.now().toUtc()).millisecondsSinceEpoch;
    await db.insert(
      table,
      {'conversation_id': conversationId, 'deleted_at': ts},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  /// 批量记录（合并云端墓碑时用）。
  Future<void> tombstoneAll(Iterable<String> ids, {DateTime? at}) async {
    for (final id in ids) {
      await tombstone(id, at: at);
    }
  }

  /// 是否已删除（按内部 ID 精确匹配）。
  Future<bool> isDeleted(String conversationId) async {
    final rows = await db.rawQuery(
      'SELECT 1 FROM $table WHERE conversation_id = ? LIMIT 1',
      [conversationId],
    );
    return rows.isNotEmpty;
  }

  /// 全部墓碑，形如 {id: 删除时间戳毫秒}。
  Future<Map<String, int>> readAll() async {
    final rows = await db.rawQuery('SELECT conversation_id, deleted_at FROM $table');
    return {
      for (final r in rows)
        r['conversation_id'] as String: (r['deleted_at'] as num).toInt(),
    };
  }

  /// 云端墓碑文件合并：远端记录的时间戳若更新，则覆盖本机（保留最新删除时间）。
  Future<void> mergeRemote(Map<String, int> remote) async {
    final local = await readAll();
    for (final entry in remote.entries) {
      final existing = local[entry.key];
      if (existing == null || entry.value > existing) {
        await tombstone(entry.key, at: DateTime.fromMillisecondsSinceEpoch(entry.value));
      }
    }
  }
}
