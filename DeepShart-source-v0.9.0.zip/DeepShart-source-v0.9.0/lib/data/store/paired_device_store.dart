// target: lib/data/store/paired_device_store.dart
// 职责：持久化"已配对设备列表"，供启动时自动重连；配对码本身是一次性的，不落盘。

import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// 一台已确认配对的设备。deviceId 同时作为稳定的 WebRTC peer id 后缀。
@immutable
class PairedDevice {
  final String deviceId;
  final String deviceName;
  final DateTime pairedAt;

  const PairedDevice({
    required this.deviceId,
    required this.deviceName,
    required this.pairedAt,
  });

  Map<String, dynamic> toJson() => {
        'deviceId': deviceId,
        'deviceName': deviceName,
        'pairedAt': pairedAt.toIso8601String(),
      };

  factory PairedDevice.fromJson(Map<String, dynamic> json) => PairedDevice(
        deviceId: json['deviceId'] as String,
        deviceName: json['deviceName'] as String,
        pairedAt: DateTime.parse(json['pairedAt'] as String),
      );
}

abstract class PairedDeviceStore {
  Future<List<PairedDevice>> loadAll();
  Future<void> upsert(PairedDevice device);
  Future<void> remove(String deviceId);
}

/// 用 SharedPreferences 存储：配对设备数量少、读写频率低，无需引入关系表。
class SharedPrefsPairedDeviceStore implements PairedDeviceStore {
  static const String _key = 'deepshart.paired_devices.v1';

  final SharedPreferences _prefs;

  SharedPrefsPairedDeviceStore(this._prefs);

  static Future<SharedPrefsPairedDeviceStore> create() async =>
      SharedPrefsPairedDeviceStore(await SharedPreferences.getInstance());

  @override
  Future<List<PairedDevice>> loadAll() async {
    final raw = _prefs.getString(_key);
    if (raw == null || raw.isEmpty) return const <PairedDevice>[];
    final decoded = jsonDecode(raw) as List<dynamic>;
    return decoded
        .map((e) => PairedDevice.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
  }

  @override
  Future<void> upsert(PairedDevice device) async {
    final all = await loadAll();
    final next = <PairedDevice>[
      ...all.where((d) => d.deviceId != device.deviceId),
      device,
    ];
    await _prefs.setString(_key, jsonEncode(next.map((d) => d.toJson()).toList()));
  }

  @override
  Future<void> remove(String deviceId) async {
    final all = await loadAll();
    final next = all.where((d) => d.deviceId != deviceId).toList();
    await _prefs.setString(_key, jsonEncode(next.map((d) => d.toJson()).toList()));
  }
}
